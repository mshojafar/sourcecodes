package UDPFlooding;
public class runUDP {

	public runUDP() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UDPFloodingDetector s = new UDPFloodingDetector();
		double rate, portSDNEnt;
		rate  = 0.5; portSDNEnt = 0.5;
		double[] myNum = {rate, portSDNEnt};
		
		double[] f = s.crispInference(myNum);
		double ff = f[0];
		System.out.println(ff);

	}

}
