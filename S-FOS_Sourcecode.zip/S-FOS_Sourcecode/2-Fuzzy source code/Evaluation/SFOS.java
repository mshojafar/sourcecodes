package Evaluation;
import java.io.BufferedReader;  
import java.io.FileReader;  
import java.io.IOException;

import IPSpoofing.IPSpoofingDetector;
import TCPFlooding.TCPFloodingDetector;
import UDPFlooding.UDPFloodingDetector; 

public class SFOS {

	public SFOS() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args)   
	{  
		String line = "";  
		String splitBy = ",";  
		try   
		{  
			//parsing a CSV file into BufferedReader class constructor  
			BufferedReader br = new BufferedReader(new FileReader("G:\\1\\evaluationCodes\\evaluationCodes\\inputs\\data.csv"));  
			int counter, tp, fp, tn, fn;
			counter = tp = fp = tn = fn = 0;
			while ((line = br.readLine()) != null)   //returns a Boolean value  
			{  
				counter ++;
				boolean flag = false;
				String[] App = line.split(splitBy);    // use comma as separator  
				String Protocol = App[11].trim();
				String IP = App[12];
				String SDNPort = App[13];
				String SrcPort = App[14];
				String Credit = App[15];
				String Rate = App[16]; 
				if (Protocol.equals("TCP"))
				{
					
					TCPFloodingDetector TCPDetector = new TCPFloodingDetector();
					double credit = Double.parseDouble(Credit);
					double port = Double.parseDouble(SDNPort);
					double[] myNum = {credit, port};
					double[] f = TCPDetector.crispInference(myNum);
					double tcpFit = f[0];
					if (tcpFit<=0.5) 
					{
						System.out.println(App[0]+": TCP Flooding Attack" );
						flag = true;
						if (counter<=300)
							tn++;
						else
							fn++;
					}
				}
				if (Protocol.equals("UDP"))
				{
					UDPFloodingDetector UDPDetector = new UDPFloodingDetector();
					double rate = Double.parseDouble(Rate);
					double port = Double.parseDouble(SDNPort);
					double[] myNum = {rate, port};
					double[] f = UDPDetector.crispInference(myNum);
					double udpFit = f[0];
					if (udpFit<=0.5)
					{
						System.out.println(App[0]+": UDP Flooding Attack" );
						flag = true;
						if (counter<=300)
							tn++;
						else
							fn++;
					}
				}
				/*
				IPSpoofingDetector SpoofingDetector = new IPSpoofingDetector();
				double ip = Double.parseDouble(IP);
				double port = Double.parseDouble(SrcPort);
				double[] myNum = {ip, port};
				double[] f = SpoofingDetector.crispInference(myNum);
				double ipFit = f[0];
				if (ipFit<0.5)
				{
					System.out.println(App[0]+": IP Spoofing Attack" );
					flag = true;
					if (counter<=300)
						tn++;
					else
						fn++;
				}*/
				if (flag == false)
				{
					System.out.println(App[0]+": Normal" );
					if (counter<=300)
						fp++;
					else
						tp++;
				}	
				 
			} 
			// acc
			double accuracy, precision, recall, tpr, fpr, tnr, fnr;
			recall = (double) tp/(tp+fn);
			precision = (double)  tp/(tp+fp);
			accuracy = (double)  (tp + tn) / (tp + tn + fp + fn);
			tpr = (double) tp/(tp+fn);
			fnr = (double) fn/(tp+fn);
			tnr = (double) tn/(tn+fp);
			fpr = (double) fp/(tn+fp);
						
			System.out.println("Accuracy:" + accuracy +"\n"+	"Recall:" + recall +"\n"+ "Precision:" + precision +"\n"+
					"TPR:" + tpr +"\n"+ "FNR:" + fnr +"\n"+ "TNR:" + tnr+"\n"+ "FPR:" + fpr+"\n");
		}   
		catch (IOException e)   
		{  
			e.printStackTrace();  
		}  
	}  
	  

}


 

