package NSGA;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Vm;

/*
 * @author Amin
 */

//Individual class
public class Individual {

    public int[] position;
    public double[] cost = {Double.MAX_VALUE, Double.MAX_VALUE};
    int rank;
    List<Integer> dominationSet = new ArrayList<>();
    int dominatedCount;
    double crowdingDistance;
    double[] normalizedCost = new double[2];
    int associatedRef;
    double distanceToAssociatedRef;

    public List<Vm> melList;
    public List<Host> hostList;
    
    public Individual(List<Vm> melList, List<Host> hostList) {

    	Random rn = new Random();
    	int nVar = melList.size();
    	int numHosts = hostList.size();
        
        int[] list = new int[nVar];
        for (int i = 0; i < nVar; i++)  {
      	  list[i] = i % (numHosts);
        }
        
        
        position = new int[nVar];
        if(rn.nextDouble()<0.3)
        {
        	position = list;
        }
        else {
	        for (int i = 0; i < nVar; i++) {
	        	position[i] = rn.nextInt(numHosts);
	        }
        }
        
        
        this.melList = melList;
        this.hostList = hostList;
        dominatedCount = 0;
        crowdingDistance = 0;
        

    }

    public int[] SortedIndividual() {
    	int nVar = this.melList.size();
    	int numHosts = this.hostList.size();
        
        int[] list = new int[nVar];
        for (int i = 0; i < nVar; i++)  {
      	  list[i] = i % (numHosts);
        }
        
        return list;
        
        
    }
    //Calculate fitness
    public void calcFitness() {

  	  	boolean flag = true;
	  
  	  	int nVar = this.melList.size();
  	  	int numHosts = this.hostList.size();
  	  	
  	  	double[] delay = new double[numHosts];
  	  	double[] usedMips = new double[numHosts];
  	  	double[] usedBw = new double[numHosts];
  	  	//double[] availableMips = new double[numHosts];
	  	//double[] availableBw = new double[numHosts];
  	  	for (int h = 0; h < numHosts; h++) {
  	  		// save all mels that assigned to host h'th in the list
  	  		List<Integer> list = new ArrayList<Integer>();
  	  		for (int v = 0; v < nVar; v++) {
  	  			if(this.position[v] == h) {
  	  				list.add(v);
  	  			}
  	  		}
  	  		double sumRequiredMIPS = 0.0;
  	  		double sumRequiredBw = 0.0;
  	  		for (int i = 0; i < list.size(); i++) {
  	  			Vm vm = this.melList.get(list.get(i));
  	  			sumRequiredMIPS += vm.getCurrentRequestedTotalMips();
  	  			sumRequiredBw += (long) vm.getCurrentRequestedBw();
  	  		}
  	  		
  	  	    double mipsCapacity = (double)hostList.get(h).getTotalMips();
  	  	    double bwCapacity = (double)hostList.get(h).getBw();
  	  	    
  	  	    // can run this mels on h'th host?
  	  	    if (sumRequiredMIPS > mipsCapacity || sumRequiredBw > bwCapacity) {
  	  	    	flag = false;
  	  	    	break;
  	  	    }
  	  	    //availableBw[h] = bwCapacity - sumRequiredBw;
  	  	    //availableMips[h] = mipsCapacity - sumRequiredMIPS;
  	  	    usedBw[h] = sumRequiredBw;
  	  	    usedMips[h] = sumRequiredMIPS;
  	  	    delay[h] = sumRequiredMIPS / mipsCapacity;
  	  	}


  	  	//delay[i] = requiredMips/ (double)hostList.get(idx).getAvailableMips() ;

  	  	if (flag == true)
  	  	{  			
  			double loadBalence = 0;
  			double avgUsedMips = 0.0;
  			double avgUsedBW = 0.0;

  			for (int h = 0; h < numHosts; h++) {
  				avgUsedMips += usedMips[h];
  				avgUsedBW += usedBw[h];
  			}
  			avgUsedMips /= numHosts;
  			avgUsedBW /= numHosts;

  			double sMips = 0.0;
  			double sBw = 0.0;
  			
  			for (int h = 0; h < numHosts; h++) {
  				sMips += Math.pow((usedMips[h] - avgUsedMips), 2);
  				sBw += Math.pow((usedBw[h] - avgUsedBW), 2);
  			}

  			loadBalence = Math.sqrt(sMips) + Math.sqrt(sBw);
  			/*********************************************/
  			
  			double avgDealy = 0.0;
  			for (int i = 0; i < numHosts; i++) {
  				avgDealy += delay[i];
  			}
  			avgDealy /= numHosts;
  			
  			this.cost[0] = loadBalence;
  			this.cost[1] = avgDealy;
  	  	}
  	  	else
  	  	{
  	  		this.cost[0] = Double.MAX_VALUE;
			this.cost[1] = Double.MAX_VALUE;
  	  	}
    }
    
    
}


