package NSGA;

/*
 * @author Amin
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Vm;


public class GA{
	
    public Population population;
    double[][] Zr;
    int nZr;
    double[] zmin;
    double[][] zmax;
    double[] smin;
    int nPop;
    int nObj;
    public List<List<Integer>> frontsList;
    double[][] d;
    double[] rho;
    public List<Vm> melList;
    public List<Host> hostList;
    
    public GA( int nPop, int nObj, int nDivision, List<Vm> melList, List<Host> hostList){
        this.nPop = nPop;
        population = new Population(nPop, melList, hostList);
        
        //Initialize population
        population.initializePopulation();

        //Calculate cost of each myIndividual
        population.calculateFitness();
        
        //Zr = new double[nObj][nDivision];
        Zr = GA.GenerateReferencePoints(nObj, nDivision, hostList);
        
        nZr = Zr[0].length;
        
        this.nObj = nObj;
        
        zmin = new double[nObj];
        for(int i=0; i<nObj; i++)
            zmin[i] = Double.POSITIVE_INFINITY;
        
        zmax = new double[nObj][nObj];
        smin = new double[nObj];
        for(int i=0; i<nObj; i++)
            smin[i] = Double.POSITIVE_INFINITY;
        
        this.melList = melList;
        this.hostList = hostList;
        
    }
    
    public static double[][] GenerateReferencePoints(int nObj, int nDivision, List<Host> hList){
    	int numHosts =   hList.size();
    	if(numHosts<nDivision) {
    		nDivision = numHosts;
    	}
    	double [][] arr=new double[nObj][nDivision];
        /*
         * double [][] arr=new double[nObj][nDivision];
        int numHosts =   hList.size();
        for(int i=0;i< nDivision;i++){
            arr[0][i] = (double)i/nDivision;
            arr[1][i] = 1-arr[0][i];
        }
        */
    	double mips = 0.0;
    	double storage = 0.0;
    	double ram = 0.0;
    	for(int i=0;i< numHosts;i++){
    		 mips =  mips + hList.get(i).getAvailableMips();
    		 storage =  storage + hList.get(i).getStorage();
    		 ram =  ram + hList.get(i).getRam();
    	}
    	
    	double amips = mips/numHosts;
    	double astorage =  storage/numHosts;
    	double aram = ram/numHosts;
    	if (numHosts<nDivision) {
    		nDivision = numHosts;
    	}
        for(int i=0;i< nDivision;i++){
            arr[0][i] = (double)hList.get(i).getAvailableMips()+
            		hList.get(i).getStorage()+ hList.get(i).getRam()/(amips+astorage+aram);
            arr[1][i] = 1-arr[0][i];
        }
        return arr;
    }
    
    public void UpdateIdealPoint(){
        for(int i=0; i<this.nPop; i++){
            for (int j=0;j<this.nObj; j++)
            {
                zmin[j] = Math.min(zmin[j], population.individuals[i].cost[j]);
            }
        }
    }
    
    public void PerformScalarizing(double[][] z){
        for (int j=0; j<nObj; j++){
       
            double[] w = new double[nObj];
            for (int i=0; i<nObj; i++)
                w[i] = Math.pow(10, -10);
            w[j] = 1;
            

            double[] s = new double[nPop];
            double[][] zw = new double[nObj][nPop];
            for (int k=0; k<nObj; k++){
                for (int i=0; i<nPop; i++){
                    zw[k][i] = z[k][i]/w[k];
                }
            }
            for (int i=0; i<nPop; i++)
                s[i] = Math.max(zw[0][i],  zw[1][i]);

            double sminj = getMinValue(s);
            int ind = getMinIndex(s);
            if (sminj < smin[j])
            {
                zmax[0][j] = z[0][ind];
                zmax[1][j] = z[1][ind];
                smin[j] = sminj;
            }
        }
    }
    
    public static double getMinValue(double[] numbers){
        double minValue = numbers[0];
        for(int i=1;i<numbers.length;i++){
            if(numbers[i] < minValue){
                minValue = numbers[i];
            }
        }
        return minValue;
    }
    
    public static int getMinIndex(double[] numbers){
        double minValue = numbers[0];
        int minIndex =0;
        for(int i=1;i<numbers.length;i++){
            if(numbers[i] < minValue){
                minValue = numbers[i];
                minIndex = i;
            }
        }
        return minIndex;
    }
    
    public void NormalizePopulation(){
        UpdateIdealPoint();
        double[][] fp = new double [this.nObj][this.nPop];
        for (int i=0; i<this.nObj; i++){
            for(int j=0; j<this.nPop; j++){
                fp[i][j] = (this.population.individuals[j].cost[i] - this.zmin[i]);
            }
        }
        PerformScalarizing(fp);
        
        // reverse matrix in java
        double [][] rZmax = new  double [nObj][nObj];
        if (nObj==2){
            double determinan = (zmax[0][0]*zmax[1][1] - zmax[0][1]*zmax[1][0]);
            
            if (determinan != 0){
                rZmax[0][0] = 1/determinan * zmax[1][1];
                rZmax[0][1] = 1/determinan * -zmax[0][1];
                rZmax[1][0] = 1/determinan * -zmax[1][0];
                rZmax[1][1] = 1/determinan * zmax[0][0];
            }
        }
        
        // w matrix
        double[] w = new double[nObj];
        w[0] = rZmax[0][0] + rZmax[1][0];
        w[1] = rZmax[0][1] + rZmax[1][1];
        
        w[0] = 1/w[0];
        w[1] = 1/w[1];
        
        for (int i = 0; i<this.nPop; i++){
            this.population.individuals[i].normalizedCost[0] = fp[0][i]/w[0];
            this.population.individuals[i].normalizedCost[1] = fp[1][i]/w[1];
        }
    }
   
    public void SortAndSelectPopulation(){
        NormalizePopulation();
        NonDominatedSorting();
        AssociateToReferencePoint();
        MovingPops();
        this.population.calculateFitness();
        CrowdingDistance();
        sortPopulation();
    }
    
    public void MovingPops(){
        Random rn = new Random();
        int n = this.frontsList.size();
        int f1 = this.frontsList.get(0).size();
        Individual q = this.population.individuals[this.frontsList.get(0).get(rn.nextInt(f1))];
        int numHosts = this.hostList.size();
        int nVar = q.position.length;
        
        for (int i=1;i<n;i++){
            int m = this.frontsList.get(i).size();
            for (int j=0; j<m; j++){
                Individual p = this.population.individuals[this.frontsList.get(i).get(j)];
                
                for(int k=0; k<nVar; k++){
                    double  r = rn.nextGaussian();
                    p.position[k] = (int) Math.round(p.position[k] + r*q.position[k]);
                    if(p.position[k]>=numHosts || p.position[k]<0){
                        p.position[k] = rn.nextInt(numHosts);
                    }
                }
                
                this.population.individuals[this.frontsList.get(i).get(j)] = p;
                 
            }
        }
        
    }
    //Selection
    public void selection() {
        //this.sortPopulation();
    }

    //Crossover
    public void crossover(double pc) {
        Random rn = new Random();
        int nc=(int)(Math.round(pc*nPop));      // Number of Offsprings (Parnets)
       
        // Keep the best 20% and do the crossover for the remaining 80%  
        for (int i=0; i<nc; i++){
            // Select 2 parents for crossover randomly
        	
            int p1 = rn.nextInt(nPop);
            int p2 = rn.nextInt(nPop);
            Individual inP1 = this.population.individuals[p1];
            Individual inP2 = this.population.individuals[p2];
            
            // Select a random crossover point
            int individualSize = inP1.position.length;
            int point = rn.nextInt(individualSize);
            
            // Swap values among parents
            for (int j=point; j<individualSize; j++){
                int temp = inP1.position[j];
                inP1.position[j] = inP2.position[j];
                inP2.position[j] = temp;
            }
            inP1.calcFitness();
            inP2.calcFitness();
            if (Dominates(inP1.cost, this.population.individuals[p1].cost))
            	this.population.individuals[p1] = inP1;
            if (Dominates(inP2.cost, this.population.individuals[p2].cost))
            	this.population.individuals[p2] = inP2;
        }
    }

    //Mutation
    public void mutation(double pm, double mu) {
        Random rn = new Random();
        double nm = Math.round(pm*nPop);        // Number of Mutants
        int numHosts = this.hostList.size();
        for (int i=0; i<nm; i++){
            // Select for mutation randomly except bestSolution(0)
            int p1 = rn.nextInt(nPop-1)+1;
            Individual inP1 = this.population.individuals[p1];
            
            if(inP1.rank>1) {
	            int individualSize = inP1.position.length;
	            for (int j=0; j<individualSize; j++)
	                if (rn.nextDouble() <= mu){
	                    inP1.position[j] = rn.nextInt(numHosts);
	                }
	            //inP1.calcFitness("Sphere");
	            this.population.individuals[p1] = inP1;
	        }
        }
    }
    
    public void sortPopulation(){
        //Sort Based on Crowding Distance descending
        for (int i = 0; i < this.nPop; i++) {
            int maxIndex = i;
            double maxCost = this.population.individuals[i].crowdingDistance;
            
            for (int j = i+1; j < this.nPop; j++) {
                if (maxCost < this.population.individuals[j].crowdingDistance )
                {
                    maxIndex = j;
                    maxCost = this.population.individuals[j].crowdingDistance;
                }
            }
            Individual temp = this.population.individuals[i];
            this.population.individuals[i] = this.population.individuals[maxIndex];
            this.population.individuals[maxIndex] = temp;
        }
        
        //Sort Based on Rank
        for (int i = 0; i < this.nPop; i++) {
            int minIndex = i;
            double minCost = this.population.individuals[i].rank;
            
            for (int j = i+1; j < this.nPop; j++) {
                if (this.population.individuals[j].rank < minCost )
                {
                    minIndex = j;
                    minCost = this.population.individuals[j].rank;
                }
            }
            Individual temp = this.population.individuals[i];
            this.population.individuals[i] = this.population.individuals[minIndex];
            this.population.individuals[minIndex] = temp;
        }
        
    }
    
    // Dominates
    public boolean Dominates(double[] x,double[] y){
    	 boolean all, any;
         all = true;
         for (int i=0; i<x.length; i++){
             if (x[i] >= y[i]){
                 all = false;
                 break;
             }
         }
         /*
         any = false;
         for (int i=0; i<x.length; i++){
             if (x[i] < y[i]){
                 any = true;
                 break;
             }
         }
         return (all && any);
         */
         return all;
    }
    
    
    public void NonDominatedSorting(){
        List<Integer> front = new ArrayList<>();
        this.frontsList = new ArrayList<>();
        for (int i=0; i<this.nPop; i++){
            this.population.individuals[i].dominationSet.clear();
            this.population.individuals[i].dominatedCount = 0;
        }
        for (int i=0; i<this.nPop; i++){
            for (int j=i+1; j<this.nPop; j++){
                Individual p = this.population.individuals[i];
                Individual q = this.population.individuals[j];
                if (Dominates(p.cost, q.cost)){
                    p.dominationSet.add(j);
                    q.dominatedCount += 1;
                }
                if (Dominates(q.cost, p.cost)){
                    q.dominationSet.add(i);
                    p.dominatedCount += 1;
                }
                this.population.individuals[i] = p;
                this.population.individuals[j] = q;
            }
            
            if (this.population.individuals[i].dominatedCount == 0)
            {
                this.population.individuals[i].rank = 1;
                front.add(i);
            }
        }
        /*
        if(front.isEmpty())
            for (int i=0; i<this.nPop; i++){
                this.population.individuals[i].dominatedCount -=1;
                if (this.population.individuals[i].dominatedCount == 0)
                {
                    this.population.individuals[i].rank = 1;
                    front.add(i);
                }
            }
        */
        this.frontsList.add(front);
        
        int k = 1;
        
        //this.frontsList.add(front);
        while(true){
            List<Integer> Q = new ArrayList<>();
            for (int i=0; i<front.size(); i++){
                int idx1 = front.get(i);
                Individual p = this.population.individuals[idx1];
                for (int j=0; j<p.dominationSet.size(); j++){
                    int idx2 = p.dominationSet.get(j);
                    Individual q = this.population.individuals[idx2];
                    q.dominatedCount -= 1;
                
                    if (q.dominatedCount == 0){
                        
                        q.rank=k+1;
                        Q.add(idx2);
                    }
                    this.population.individuals[idx2] = q;
                }      
            }
            if (Q.isEmpty())
                break;
            
            this.frontsList.add(Q);
            //front.clear();
            front = Q;
            k = k+1;
        }
    }
   
    public List<Integer> SortByCost(List<Integer> Q, int sortBy){
        
        for(int i=0; i<Q.size(); i++){
            int minIndex = i;
            double minValue = this.population.individuals[Q.get(i)].cost[sortBy];
            // Find min
            for(int j=i+1; j<Q.size(); j++){
                if(this.population.individuals[Q.get(j)].cost[sortBy]<minValue){
                    minValue = this.population.individuals[Q.get(j)].cost[sortBy];
                    minIndex = j;
                }
            }
            //Swap
            int temp1 = Q.get(i);
            int temp2 = Q.get(minIndex);

            Q.remove(i);
            Q.add(i,temp2);
            Q.remove(minIndex);
            Q.add(minIndex,temp1);
        }
        return Q;
    }
    
    public void  AssociateToReferencePoint(){
        d = new double[nPop][nZr];
        rho = new double[nZr];
        
        for (int i=0; i<nPop; i++){
            double[] w = new double[nObj];
            for (int j=0; j<nZr; j++){
                double n = norm(Zr[0][j],Zr[1][j]); 
                for (int k=0; k<nObj; k++){
                   w[k] = Zr[k][j]/n;
                }    
                d[i][j] = distance(this.population.individuals[i].normalizedCost, w);
            }
            double minValue = Double.MAX_VALUE;
            int minIndex = 0;
            for (int j=0; j<nZr; j++){
                if (d[i][j] < minValue){
                    minValue = d[i][j];
                    minIndex = j;
                }
            }
            this.population.individuals[i].associatedRef = minIndex;
            this.population.individuals[i].distanceToAssociatedRef = minValue;
            rho[minIndex] ++;
        } 
    }
    
    public double norm(double a, double b){
        return Math.sqrt(a*a+b*b);
    }
    
    public double distance(double[] z, double [] w){
        double[] x = new double[nObj];
        for (int i=0; i<nObj; i++){
            for (int j=0; j<nObj; j++){
                x[i] = x[i] + w[i]*z[j]*w[i];
            }
        }            
        return norm(z[0]-x[0],z[1]-x[1]);
    }
    
    public void CrowdingDistance(){
        int nF = frontsList.size();
        List<Integer> front;
        for (int k=0; k<nF; k++){ 
            int nObj = 2;
            int n = frontsList.get(k).size(); 
            if(n>0){
                front = frontsList.get(k);
                double d[][] = new double[n][nObj];
                /*
                for (int i = 0; i<n; i++){
                    for (int j = 0; j<nObj; j++){
                        d[i][j] = 0;
                    }
                }*/
                for (int j = 0; j<nObj; j++){
                    front = SortByCost(front, j);
                    int f = front.size();

                    d[0][j] = Double.POSITIVE_INFINITY;

                    double cMin = this.population.individuals[front.get(0)].cost[j];
                    double cMax = this.population.individuals[front.get(front.size()-1)].cost[j];

                    for (int i=1; i< n-1; i++)
                    {   
                        double cp = this.population.individuals[front.get(i-1)].cost[j];
                        double cn = this.population.individuals[front.get(i+1)].cost[j];

                        d[i][j] = Math.abs(cn-cp)/Math.abs(cMax-cMin);
                    }

                    d[n-1][j] = Double.POSITIVE_INFINITY;
                }
                double sumD[] =new double[n];
                for (int i=0; i<n; i++){
                    for (int j=0; j<nObj; j++){
                        sumD[i] = sumD[i]+d[i][j];
                    }
                }
                for (int i=0; i<n; i++){
                    this.population.individuals[front.get(i)].crowdingDistance = sumD[i];

                }
            }
        }
    }
    
    public void checkingRange(){
	   	Random rn = new Random();
	   	int numHosts = this.hostList.size();
	   	for (int i=0; i<nPop; i++){
	       Individual p = this.population.individuals[i];
           int nVar = p.position.length;
           for (int j=0; j<nVar; j++){
	            if(p.position[j]>=numHosts || p.position[j]<0){
	                p.position[j] =  rn.nextInt(numHosts);
	            }
           }
	   	}
    }
    public void calcfit(){
	   	
	   	for (int i=0; i<nPop; i++){
	         Individual p = this.population.individuals[i];
	         p.calcFitness();
	         this.population.individuals[i] = p;
	   	}
   }
    
}
