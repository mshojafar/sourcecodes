package UDPPORT;

public class run {

	public run() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UDPFlooding s = new UDPFlooding();
		double entropy, rate;
		entropy  = 0.01; rate = 0.01;
		double[] myNum = {entropy, rate};
		double[] f = s.crispInference(myNum);
		double ff = f[0];
		System.out.println(ff);

	}
}