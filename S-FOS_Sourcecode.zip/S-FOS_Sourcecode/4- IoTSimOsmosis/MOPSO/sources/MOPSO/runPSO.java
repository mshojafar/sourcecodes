package MOPSO;

/*
 * @author Amin Nazari
 */

import java.util.List;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Vm;


//Main class
public class runPSO {
    public static String printSol(int[] arr){
        int size = arr.length;
        String[] str = new String[size];

        for(int i=0; i<size; i++) {
           str[i] = String.valueOf(arr[i]);
        }
        
        return String.join(",", str);
    }
    
    private static String printSol(double[] arr) {
    	int size = arr.length;
        String[] str = new String[size];

        for(int i=0; i<size; i++) {
           str[i] = String.valueOf(arr[i]);
        }
        
        return String.join(",", str);
	}
/*
    public static void main(String[] args) {

        //Random rn = new Random();

        String costFunctionName = "MOP2";     // Cost Function
        //int nVar = 3;                   // Number of Decision Variables
        //int VarMin = 0;               // Lower Bound of Variables
        //int VarMax = 1;                // Upper Bound of Variables
        int nPop = 20;
        int MaxIt = 20;      

        int nObj;
        nObj = 2;
    
        List<Vm> melList; 
        List<Host> hostList;
        PSO demo = new PSO( nPop, nObj, melList, hostList);
        
        demo.determinDominate();
        List<Object> rep;
        rep = demo.setRep();
        demo.createGrid(rep);
        demo.findGrid(rep);
        System.out.println("Generation: [" + printSol(demo.population.individuals[0].position) + "] Fittest: " + printSol(demo.population.individuals[0].cost));

        //While population gets an myIndividual with maximum cost
        int it = 0;
        while (it<MaxIt) {
            it++;

            demo.moving(rep, hostList.size());
            
            demo.determinDominate();

            rep = demo.setRep();
            
            demo.createGrid(rep);
        
            demo.findGrid(rep);
            
            Individual bestSol = (Individual) rep.get(0);
            //System.out.println("Generation: " + it  + " Fittest: " +
            //        printSol(bestSol.cost) + " Number of rep :" + rep.size());

        }
        //System.out.println("***************Pareto Front*****************");
        
        
        for(int i=0;i<rep.size();i++){
            Individual bestSol = (Individual) rep.get(i);
            System.out.println("Position: " + i +" [" + 
                printSol(bestSol.position)+ "] Fitness: " + printSol(bestSol.cost));
        }
    }

	*/
}


