package MOPSO;

/*
 * @author Amin
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Vm;


public class PSO{
	
    public Population population;
    int nPop;
    int nObj;
    List<List<Integer>> frontsList;
    int nGrid = 5;
    double[][] GridLB;
    double[][] GridUB;
    
    
    public PSO( int nPop, int nObj, List<Vm> melList, List<Host> hostList){
        this.nPop = nPop;
        this.nObj = nObj;
        population = new Population(nPop, melList, hostList);
        
        //Initialize population
        population.initializePopulation();

        //Calculate cost of each myIndividual
        population.calculateFitness();
        
        GridLB = new double[nObj][nGrid+2]; //nObj, 
        GridUB = new double[nObj][nGrid+2]; //nObj, 
        
    }
   
    //Mutation
    public Individual mutation(Individual p, double mu, int nHost ) {
        Random rn = new Random();
        int nVar = p.position.length;
        for (int j=0; j<nVar; j++)
            if (rn.nextDouble() <= mu){
                p.position[j] = rn.nextInt(nHost);
            }

        return p;
    }

    // Dominates
    public boolean Dominates(int[] x,int[] y){
    	boolean all, any;
        all = true;
        for (int i=0; i<x.length; i++){
            if (x[i] >= y[i]){
                all = false;
                break;
            }
        }
        /*
        any = false;
        for (int i=0; i<x.length; i++){
            if (x[i] < y[i]){
                any = true;
                break;
            }
        }
        return (all && any);
        */
        return all;
        
    }
    public boolean Dominates(double[] x,double[] y){
        boolean all, any;
        all = true;
        for (int i=0; i<x.length; i++){
            if (x[i] >= y[i]){
                all = false;
                break;
            }
        }
        /*
        any = false;
        for (int i=0; i<x.length; i++){
            if (x[i] < y[i]){
                any = true;
                break;
            }
        }
        return (all && any);
        */
        return all;
    }
    
    public void determinDominate(){
        
        for (int i=0; i<this.nPop; i++){
            this.population.individuals[i].isDominated = false;
        }
        for (int i=0; i<this.nPop; i++){
            Individual p = this.population.individuals[i];
            for (int j=i+1; j<this.nPop; j++){
                Individual q = this.population.individuals[j];
                if (Dominates(p.cost, q.cost)){
                    q.isDominated = true;
                }
                if (Dominates(q.cost, p.cost)){
                    p.isDominated = true;
                }
                this.population.individuals[j] = q;
            }
            this.population.individuals[i] = p;

        }
    }
    
    public List<Object> setRep(){
        List<Object> rep = new ArrayList<Object>();
        List<Integer> repIndex = new ArrayList<Integer>();
        for (int i=0; i<this.nPop; i++){
            if (this.population.individuals[i].isDominated == false){
                rep.add(this.population.individuals[i]);
                repIndex.add(i);
            }
        }
        //System.out.print("repIndex" + repIndex);
        return rep;
    }
    
    public void createGrid(List<Object> rep){
        double[] cmin = new double[nObj];
        double[] cmax = new double[nObj];
        
        for (int i=0; i<this.nObj; i++){
            cmin[i] = Double.MAX_VALUE;
            cmax[i] = Double.MIN_VALUE;
        }
        int n = rep.size();
        for (int i=0; i<this.nObj; i++){
            for (int j=0; j<n; j++){
                Individual p = (Individual)rep.get(j);
                if (p.cost[i] < cmin[i])
                    cmin[i] = p.cost[i];
                
                if (p.cost[i] > cmax[i])
                    cmax[i] = p.cost[i];
            }
        }
        
        double[] d = new double[nObj];
        double alpha = 0.1;
        for (int i=0; i<this.nObj; i++){
            d[i] = cmax[i]-cmin[i];
            cmin[i] = cmin[i] - d[i] * alpha;
            cmax[i] = cmax[i] + d[i] * alpha;
        }    
        
        for (int i=0; i<this.nObj; i++){
            
            double[] c = new double[nGrid+1];
            c[0] = cmin[i];
            c[nGrid] = cmax[i];
            double dc = (cmax[i] -cmin[i])/nGrid;
            for(int j=1; j<this.nGrid+1; j++){
                c[j] = c[j-1]+dc;
            }
            
            for(int j=0; j<this.nGrid+1; j++){
                GridLB[i][j+1] = c[j];
                GridUB[i][j] = c[j];
            }
            
            GridLB[i][0] = Double.NEGATIVE_INFINITY;
            GridUB[i][nGrid+1] = Double.POSITIVE_INFINITY;
        }
    }
    
    public void findGrid(List<Object> rep){
        int n = rep.size();
        
        for (int j=0; j<n; j++){
            Individual p = (Individual)rep.get(j);
            for (int i=0; i<this.nObj; i++){
                for(int k=0; k<nGrid+2; k++){
                    
                    if(p.cost[i]<GridUB[i][k]){
                        p.gridSubIndex[i] = k;
                        break;
                    }
                }
            }
            
            
            p.gridIndex = p.gridSubIndex[0];
            for (int i=1; i<this.nObj; i++){
                p.gridIndex=p.gridIndex-1;
                p.gridIndex=nGrid*p.gridIndex;
                p.gridIndex=p.gridIndex+p.gridSubIndex[i];
            }
            rep.set(j, p);
        }
    }

    public Individual selectLeader(List<Object> rep){
        int n = rep.size();
        Random rn = new Random();
        //int r = rn.nextInt(n);
        
        
        int[] N = new int[(nGrid+2) * (nGrid+2)];
        for (int j=0; j<n; j++){
            Individual q =(Individual) rep.get(j);
            N[q.gridIndex] = N[q.gridIndex] + 1;
        }
        
        boolean flag = true;
        int k = 0;
        List<Integer> cellsIndex = new ArrayList<Integer>();
        while(flag){
            k++;
            for (int i=0; i<(nGrid+2)*(nGrid+2); i++){
                if(N[i]==k){
                    cellsIndex.add(i);
                    flag = false;
                }
            }
        }
        
        
                
        int r = rn.nextInt(cellsIndex.size());
        int cellIndex = cellsIndex.get(r);
        
        List<Object> bestRep = new ArrayList<>();
        for (int j=0; j<n; j++){
            Individual q =(Individual) rep.get(j);
            if (cellIndex == q.gridIndex){
                bestRep.add(q);
            }
        }
        int rr;
        if(bestRep.size()>0)
        {    rr = rn.nextInt(bestRep.size());
            return (Individual)bestRep.get(rr);
        }
        else
        {              
            rr = rn.nextInt(rep.size());
            return (Individual)rep.get(rr);

        }
        /*
        
        
        for (int i=0; i<(nGrid+2)*(nGrid+2); i++){
            if(N[i]>=1){
                cellsIndex.add(i);
            }
        }
        
        // Selection Probabilities
        int beta = 2;
        
        double[] P = new double[(nGrid+2) * (nGrid+2)];
        double sumP=0.0;
        for (int i=0; i<(nGrid+2) * (nGrid+2); i++){
            P[i] = Math.exp(-beta*N[i]);
            sumP=sumP+P[i];
        }
        
        double[] cumsum= new double[(nGrid+2) * (nGrid+2)];
        
        for (int i=0; i<(nGrid+2) * (nGrid+2); i++){
            P[i] = P[i]/sumP;
        }
        
        cumsum[0] = P[0];
        for (int i=1; i<(nGrid+2) * (nGrid+2); i++){
            cumsum[i] = cumsum[i-1] +  P[i];
        }
        Random rn = new Random();
        double r = rn.nextDouble();
        
        int RouletteWheelSelection = -1;
        for (int i=0; i<(nGrid+2) * (nGrid+2); i++){
            if (r<=cumsum[i]){
                RouletteWheelSelection = i;
                break;
            }
        }
       
        List<Object> bestRep = new ArrayList<>();
        for (int j=0; j<n; j++){
            Individual q =(Individual) rep.get(j);
            if (RouletteWheelSelection == q.gridIndex){
                bestRep.add(q);
            }
        }
        int rr;
        if(bestRep.size()>0)
        {    rr = rn.nextInt(bestRep.size());
            return (Individual)bestRep.get(rr);
        }
        else
        {              
            rr = rn.nextInt(rep.size());
            return (Individual)rep.get(rr);

        }
         */
        
        
    }
    
    public void checkingRange( int nHost){
    	 Random rn = new Random();
    	for (int i=0; i<nPop; i++){
            Individual p = this.population.individuals[i];
            int nVar = p.position.length;
            for (int j=0; j<nVar; j++){
	            if(p.position[j]>=nHost || p.position[j]<0){
	                p.position[j] =  rn.nextInt(nHost);
	            }
            }
    	}
    }

    public void calcfit(){
	   	
	   	for (int i=0; i<nPop; i++){
	         Individual p = this.population.individuals[i];
	         p.calcFitness();
	         this.population.individuals[i] = p;
	   	}
   }
 
    
  
    
    
    public void moving(List<Object> rep, int nHost){
        double w=0.5;              // Inertia Weight
        double wdamp=0.99;         // Intertia Weight Damping Rate
        double c1=1;               // Personal Learning Coefficient
        double c2=2;               // Global Learning Coefficient
        
        for (int i=0; i<nPop; i++){
        	Individual p = this.population.individuals[i];
        	if(p.isDominated == true) {
                Individual q = selectLeader(rep);
                int nVar = p.velocity.length;
                Random rn = new Random();
                double r1,r2;
                for (int j=0; j<nVar; j++){
                    r1 = rn.nextDouble();
                    r2 = rn.nextDouble();
                    p.velocity[j] = w*p.velocity[j] + c1*r1*(p.bestPosition[j]- p.position[j])+
                            c2*r2*(q.position[j]-p.position[j]);
                    
                    
                    p.position[j] = (int) Math.floor(p.position[j]+p.velocity[j]);
                    if(p.position[j]>=nHost || p.position[j]<0){
                        p.position[j] =  rn.nextInt(nHost);
                    }
                    
                }
                p.calcFitness();
                double mu = 0.0;
                Individual newP = mutation( p,  mu,nHost);
                newP.calcFitness();
                
                if (Dominates(newP.cost, p.cost))
                    p = newP;
                else if(Dominates(p.cost, newP.cost))
                        {}
                else{
                    double rr = rn.nextDouble();
                    if(rr<0.5)
                        p = newP;
                }
                               
                if (Dominates(p.cost, p.bestCost))
                {   
                    p.bestPosition = p.position;
                    p.bestCost = p.cost;
                
                }
                else if(Dominates(p.bestCost, p.cost))
                        {}
                else{
                    double rr = rn.nextDouble();
                    if(rr<0.5)
                    {
                        p.bestPosition = p.position;
                        p.bestCost = p.cost;
                    }
                }
                this.population.individuals[i] = p;
        	}
            
            
        }
        w=w*wdamp;
        checkingRange(nHost);
        calcfit();
    }
}
