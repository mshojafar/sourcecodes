package MOPSO;

import java.util.List;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Vm;

//Population class
public class Population {
    int nPop;
    public Individual[] individuals;
    List<Vm> melList;
    List<Host> hostList;
    
    public Population(int nPop, List<Vm> melList, List<Host> hostList) {
		this.nPop = nPop;
		individuals = new Individual[nPop];
		this.melList = melList;
		this.hostList = hostList;
    }

    //Initialize population
    public void initializePopulation() {
        for (int i = 0; i < this.nPop; i++) {
            individuals[i] = new Individual(this.melList, this.hostList );
            individuals[i].calcFitness();
            individuals[i].bestCost = individuals[i].cost;

        }
    }

    //Calculate cost of each Individual
    public void calculateFitness() {
        for (Individual individual : individuals) {
            individual.calcFitness();
        }
        //getFittest();
    }
    
    
}
