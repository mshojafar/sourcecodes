import random
from statistics import mean
import csv
import numpy as np
from scipy.stats import entropy

def Entropy(labels, base=None):
    value,counts = np.unique(labels, return_counts=True)
    return entropy(counts, base=base)

numRecords = 100
def createData(ID, Type):
    if (Type == 'IP_Spoofing' or Type == 'Normal'):
        ProtocolType = ['TCP', 'UDP']
        Protocol = ProtocolType[random.randint(0, 1)]
    else: 
        Protocol = Type

    records = []
    for _ in range(numRecords):
        IP_No = random.randint(1, 10)
        Port_No_SDN = random.randint(1, 10)
        Port_No_SRC = random.randint(1, 10)
        Rate = random.randint(1, 10)
        Credit = random.randint(1, 10)
        row = [ID, IP_No, Port_No_SDN, Port_No_SRC, Protocol, Credit, Rate]
        records.append(row)

    return records

def createNormalData(ID):
    ProtocolType = ['TCP', 'UDP']
    Protocol = ProtocolType[random.randint(0, 1)]
    records = []
    for _ in range(numRecords):
        IP_No = random.randint(1,2)
        Port_No_SDN = random.randint(1, 2)
        Port_No_SRC = random.randint(1,10)
        Rate = random.randint(1, 4)
        Credit = random.randint(7, 10)
        row = [ID, IP_No, Port_No_SDN, Port_No_SRC, Protocol, Credit, Rate]
        records.append(row)

    return records
def isSatisfy(log,type):
    a = []
    for i in range(1,numRecords+1):
        a.append(i%11)
    
    maxEnt = Entropy(a)

    ip = []; sdnPort = [];  srcPort = []; credit = []; rate = []
    TCredit = 0.4
    TSDN = 0.7
    TRate = 0.7
    TIP = 0.7
    TSrc = 0.6
    
    for row in log:
        ip.append(row[1])
        sdnPort.append(row[2])
        srcPort.append(row[3])
        credit.append(row[5])
        rate.append(row[6])

    if (type == 'TCP'):
        Credit = mean(credit)/10
        Port_Ent_SDN = Entropy(sdnPort)/maxEnt
        if (Credit <= TCredit or Port_Ent_SDN > TSDN):
            return True
        
        return False
    if (type == 'UDP'):
        Rate = mean(rate)/10
        Port_Ent_SDN = Entropy(sdnPort)/maxEnt
        if (Rate >= TRate or Port_Ent_SDN > TSDN):
            return True
        
        return False
    if (type == 'IP_Spoofing'):
        IP_Ent_SRC = Entropy(ip)/maxEnt
        Port_Ent_SRC = Entropy(srcPort)/maxEnt
        
        if (IP_Ent_SRC < TIP or Port_Ent_SRC > TSrc):
            return True
        
        return False
    else: #Normal
        nTCredit = 0.7
        nTSDN = 0.4
        nTRate = 0.4
        nTIP = 0.4
        nTSrc = 0.7
        Credit = mean(credit)/10
        Rate = mean(rate)/10
        Port_Ent_SDN = Entropy(sdnPort)/maxEnt
        IP_Ent_SRC = Entropy(ip)/maxEnt
        Port_Ent_SRC = Entropy(srcPort)/maxEnt
        if (Credit >= nTCredit and Rate < nTRate and\
            IP_Ent_SRC <= nTIP and Port_Ent_SDN < nTSDN and\
                Port_Ent_SRC >= nTSrc):
            return True
        return False



def logger(nNode, nMalicious):
    data = []
    for i in range(1, nNode+1):
        print(i)
        if (i <= nMalicious):
            if i <= nMalicious/2:
                type = 'TCP'
                flag = True
                while(flag):
                    log = createData(i, type)
                    if(isSatisfy(log, type)):
                        flag = False

            else:
                type = 'UDP'
                flag = True
                while(flag):
                    log = createData(i, type)
                    if(isSatisfy(log,type)):
                        flag = False
        
            

        else:
            type = 'Normal'
            flag = True
            while(flag):
                log = createNormalData(i)
                if(isSatisfy(log,type)):
                    flag = False

        data.append(log)
    
    dataset = []
    textfile = open("dataset.txt", "w")
    for i in data:
        for j in i:
            textfile.write(str(j) + "\n")
            dataset.append(j)

    textfile.close()
    return dataset

def createApps(dataset, nNodes, nMELs, nVMs):
    a = []
    for i in range(1,numRecords+1):
        a.append(i%11)
    
    maxEnt = Entropy(a)

    file = open('Example1_Worload.csv', 'w+', newline ='')
    header =  ['OsmesisApp','ID','DataRate_Sec','StopDataGeneration_Sec','IoTDevice','IoTDeviceOutputData_Mb','MELName','OsmesisEdgelet_MI','MELOutputData_Mb','VmName','OsmesisCloudlet_MI', 'Protocol', 'IP_Entropy', 'SDN_Port_Entropy', 'Src_Port_Entropy', 'Credit', 'Rate']
    apps = [header]
    
    for n in range(nNodes):
        IPList = []
        PortSDNList = []
        PortSrcList = []
        Credit = []
        Rate = []
        for row in dataset:
            if row[0] == n+1:
                IPList.append(row[1])
                PortSDNList.append(row[2])
                PortSrcList.append(row[3])
                Credit.append(row[5])
                Rate.append(row[6])
                Protocol = row[4]
            elif row[0] > n+1:
                break
        
        flowType = n%4
        if flowType ==0:
            flowRAM = 50
            flowMIPS = 200
        elif flowType == 1:
            flowRAM = 100
            flowMIPS = 300
        elif flowType == 2:
            flowRAM = 150
            flowMIPS = 400
        else:
            flowRAM = 200
            flowMIPS = 500

        if IPList != [] : 
            IP_Entropy = Entropy(IPList)/maxEnt
            Port_SDN_Entropy = Entropy(PortSDNList)/maxEnt
            Port_Src_Entropy = Entropy(PortSrcList)/maxEnt
            Rate = mean(Rate)/10
            Credit = mean(Credit)/10
            mel = (n % nMELs) + 1
            vm = (n % nVMs) + 1
        

            App = ['App_'+ str(n+1), n+1, 1.2 ,250,'temperature_'+\
                str(n+1), flowRAM, 'MEL_' + str(mel), flowMIPS, flowRAM/2, 'VM_' +\
                    str(vm), flowMIPS/2, Protocol, IP_Entropy, Port_SDN_Entropy,\
                        Port_Src_Entropy, Credit, Rate]
            apps.append(App)
        
    with file:
        write = csv.writer(file) 
        write.writerows(apps)

    file.close()
    #OsmesisApp,ID,DataRate_Sec,StopDataGeneration_Sec,IoTDevice,IoTDeviceOutputData_Mb,MELName,OsmesisEdgelet_MI,MELOutputData_Mb,VmName,OsmesisCloudlet_M


