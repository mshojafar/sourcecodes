from logger import createApps, logger
from TopologyGenerator import TopologyGenerator
#APP
numIoTDevices = 60                           #number of IoT Device
attackRate = 0.30
malicious = int(attackRate*numIoTDevices)       #number of Attack =300

dataset = logger(numIoTDevices, malicious)
numEdgeDevices = 5; numMEL = numEdgeDevices
numCloudHosts = 6;  numVMs = numCloudHosts
createApps(dataset, numIoTDevices, numMEL, numVMs) 
TopologyGenerator(numIoTDevices, numMEL, numEdgeDevices, numVMs, numCloudHosts)