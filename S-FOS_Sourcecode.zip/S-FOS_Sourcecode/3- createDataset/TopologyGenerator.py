import json

def TopologyGenerator(numIoTDevices, numMEL, numEdgeDevices, numVMs, numCloudHosts):
    with open('config.json') as f:
        data = json.load(f)

    '''
    edgeDataCenter = data['edgeDatacenter'] 
    edgeHosts = edgeDataCenter[0]['hosts'] 
    edgeHost = edgeDataCenter[0]['hosts'][0]
    '''

    edgeDevices = []

    # Create Edge Devices
    for i in range(numEdgeDevices):
        edgeHost = {
                'name': 'edgeDevice_' + str(i+1),
                "pes" : 4,
                "ramSize":20000,
                "bwSize":200,	
                "storage":20000,
                "mips":20000			
                }
        edgeDevices.append(edgeHost)

    # Add Edge Devices
    data['edgeDatacenter'][0]['hosts'] = edgeDevices

    # Create MELs
    MELEntities = []

    for i in range(numMEL):
        mel = {
                "name":"MEL_" + str(i+1),								
                "bw":100,				 
                "mips":250,			
                "ram":10000,
                "pesNumber":1,
                "vmm":"xxx",			
                "cloudletSchedulerClassName":"org.cloudbus.cloudsim.CloudletSchedulerTimeShared"
            }
        MELEntities.append(mel)

    # Add MELs
    data['edgeDatacenter'][0]['MELEntities'] = MELEntities

    # Create Switch
    numEdgeSwitch = 6
    switches = []
    links = []
    for i in range(numEdgeSwitch):
        sw = {
                "type" : "edge",
                "name": "edge" + str(i+1),
                "controller": "edge1_sdn1",
                "iops":1000000000
            }

        core = 1 if (numEdgeSwitch/2) > i else 2
        link = { "source" : "core" + str(core) , "destination" : "edge" + str(i+1), "bw" : 100}
        
        switches.append(sw)
        links.append(link)

    # Add Switchs and thier links
    data['edgeDatacenter'][0]['switches'][3:] = switches

    # Create link:edge device to edge switch
    for i in range(numEdgeDevices):
        edgeSW =  (i % numEdgeSwitch) + 1
        link = { "source" : "edge" + str(edgeSW), "destination" : "edgeDevice_" + str(i+1), "bw" : 100}
        links.append(link)
    
    # Add Connection between edge device and edge switch
    data['edgeDatacenter'][0]['links'][2:] = links

    # Create IoT Devices
    ioTDevices = []
    mobility = data['edgeDatacenter'][0]['ioTDevices'][0]['mobilityEntity']  
    false = False
    for i in range(numIoTDevices):
        iot = {
                "name":"temperature_" + str(i+1),
                "bw":10,				
                "max_battery_capacity":100.0,
                "battery_sensing_rate":0.001,
                "battery_sending_rate":0.002,
                "ioTClassName":"org.cloudbus.cloudsim.edge.iot.TemperatureSensor",		
                "mobilityEntity":mobility,
                "networkModelEntity":{
                    "communicationProtocol":"xmpp",
                    "networkType":"wifi"
                }
            }
        ioTDevices.append(iot)

    # Add IoT Devices
    data['edgeDatacenter'][0]['ioTDevices'] = ioTDevices

    # Create Host Cloud
    cloudHosts = []
    for i in range(numCloudHosts):
        host = {
                "name": "host" + str(i+1),
                "pes" : 16,
                "mips" : 500000,
                "ram" : 1000000,                
                "bw" : 10000,                
                "storage" : 6400000000000                
                }
        cloudHosts.append(host)

    # Add Host Cloud
    data['cloudDatacenter'][0]['hosts'] = cloudHosts

    # Create VMs
    VMs = []
    for i in range(numVMs):
        vm = {			
                "name": "VM_"+ str(i+1),				
                "pes" : 2,
                "mips" : 2000,
                "ram" : 10000,
                "storage" : 20000,
                "bw" : 1000,
                "cloudletPolicy": "TimeShared" 
            }
        VMs.append(vm)

    # Add VMs
    data['cloudDatacenter'][0]['VMs'] = VMs

    # Create link:cloud device to cloud switch
    links = []
    for i in range(numCloudHosts):
        cloudSW =  (i % 8) + 1
        link = { "source" : "edge" + str(cloudSW) , "destination" : "host" + str(i+1) , "bw" : 1000}
        links.append(link)

    # Add Connection 
    data['cloudDatacenter'][0]['links'][36:] = links

    with open('Example1_configuration.json', 'w') as json_file:
        json.dump(data, json_file, indent=4)
    return data