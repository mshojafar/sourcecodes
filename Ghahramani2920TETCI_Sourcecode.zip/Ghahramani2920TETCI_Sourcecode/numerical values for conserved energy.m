a1=zeros(1,86); %A matrix for short distances
a2=zeros(1,86); %A matrix for large distances
a3=zeros(1,172); %Result matrix
k=10; %Number of adversarial messages
l1=16; %Lenght of random numbers
l2=128; %Lenght of ID
for x=0:86
   a1(1,x+1)=k*(l1+l2)*((50+0.1*x^2));
   a3(1,x+1)=k*(l1+l2)*((50+0.1*x^2));
   a2(1,x+1)=k*(l1+l2)*((50+0.1*x^4));
   a3(1,86+x)=k*(l1+l2)*((50+0.1*((x+86)^4)));
end
hold on;
plot(a1);
plot(a2);
