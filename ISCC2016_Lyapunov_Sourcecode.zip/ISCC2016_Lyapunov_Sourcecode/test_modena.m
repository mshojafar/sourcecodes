f_max=10;
f=[2:2:f_max];
f1=[0:2:f_max];
f2=[1.6:0.2:2.6].*10^9;
f3=[0, 1.6, 1.8, 2, 2.2, 2.4, 2.6].*10^9;
mu_min=200;
mu_max=400;
E_c_Idle=0.5;%(Joule)
E_c_max=240;%(Joule)
omega=0.5;%communication coeffient (Joule)
r_max=10; %communication link rate (Joule)
RTT=700;% (micro watt)
ke={0.5,0.005};%(j/(MHz)^2)
Delta=1;
P_N_idle=0.5;%(joule)
%%%%%%mu Linear
mu=((mu_max-mu_min)/(f(length(f))-f(1)))*(f(:)-f(1))+mu_min;% F1
mu_1=((mu_max-mu_min)/(f1(length(f1))-f1(1)))*(f1(:)-f1(1))+mu_min;% F3
mu_2=((mu_max-mu_min)/(f2(length(f2))-f2(1)))*(f2(:)-f2(1))+mu_min;% F2
mu_3=((mu_max-mu_min)/(f3(length(f3))-f3(1)))*(f3(:)-f3(1))+mu_min;% F4
%%%%%%mu quadratic (mu_min=200, mu_max=296)
mu1=f.^2+(mu_min-f(1).^2);%F1
mu1_1=f1.^2+(mu_min-f1(1).^2);%F3
mu1_2=f2.^2+(mu_min-f2(1).^2);%F2
mu1_3=f3.^2+(mu_min-f3(1).^2);%f4
%%%Overal Energy
E_c_LAN=(P_N_idle+omega*(RTT*r_max)^2)*Delta;
E_c_tot_max=E_c_max+E_c_LAN;
E_c_tot=E_c_Idle+((f./f(length(f))).^2)*(E_c_max-E_c_Idle);%F1
E_c_tot_1=E_c_Idle+((f1./f1(length(f1))).^2)*(E_c_max-E_c_Idle);%F3
E_c_tot_2=E_c_Idle+((f2./f2(length(f2))).^2)*(E_c_max-E_c_Idle);%F2
E_c_tot_3=E_c_Idle+((f3./f3(length(f3))).^2)*(E_c_max-E_c_Idle);%F4
%E_c_tot_min=
%%%%%%%%%%%%%plots
figure(20211)
%hold all
%for a=1:1
%Linear
%[ax,p1,p2]=plotyy(f(:),mu(:),f(:),E_c_tot(:),'plot','plot');%F1 
%[ax,p1,p2]=plotyy(f1(:),mu_1(:),f1(:),E_c_tot_1(:),'plot','plot');%F3 with zero (Consolidation)
%[ax,p1,p2]=plotyy(f2(:),mu_2(:),f2(:),E_c_tot_2(:),'plot','plot');%F2
%[ax,p1,p2]=plotyy(f3(:),mu_3(:),f3(:),E_c_tot_3(:),'plot','plot');%F4 with zero (Consolidation)

%Quadratic
%[ax,p1,p2]=plotyy(f(:),mu1(:),f(:),E_c_tot(:),'plot','plot');%F1
% [ax,p1,p2]=plotyy(f1(:),mu1_1(:),f1(:),E_c_tot_1(:),'plot','plot');%F3 with zero (Consolidation)
%[ax,p1,p2]=plotyy(f2(:),mu1_2(:),f2(:),E_c_tot_2(:),'plot','plot');%F2
 [ax,p1,p2]=plotyy(f3(:),mu1_3(:),f3(:),E_c_tot_3(:),'plot','plot');%F4 with zero (Consolidation)
% 
  %  plot(f(:),mu(:),f(:),mu1(:));
%plot(f,mu);
%end
%hold off
xlabel('$f_{j}$ $(IU/slot)$','Interpreter','latex','FontSize',35);
ylabel(ax(1),'$\mu_{ij}$  $(request/slot)$','Interpreter','latex','FontSize',35);
ylabel(ax(2),'$\mathcal{E}_j^{tot}(t)$  $(Joule)$','Interpreter','latex','FontSize',35);
%legend('$Linear=\mu_{ij}(f_j)$','$Quadratic=\mu_{ij}(f_j)$','Interpreter','latex','FontSize',40);
legend('$\mu_{ij}(f_j;t)$','$\mathcal{E}_j^{tot}(t)$','Interpreter','latex','FontSize',35);
%subplot(2,1,1);
%[ax,p1,p2]=plotyy(energy_ave_vector,F_D_vector(:),energy_ave_vector,T_tot_vector(:));
%ylabel(ax(1),'$\overline{F}_{D}^*$  $(slot)$','Interpreter','latex','FontSize',40);
%ylabel(ax(2),'$\overline{T}_{tot}$  $(slot)$','Interpreter','latex','FontSize',40);
%legend('$\overline{F}_{D}^*$','$\overline{T}_{tot}^*$','Interpreter','latex','FontSize',40);
%set(ax(2),'XAxisLocation','Top');
set(ax(1),'FontSize',35); 
set(p1,'color','black');
set(p2,'color','black');
set(ax,{'ycolor'},{'black';'black'})
set(ax(2),'FontSize',35); 

set(p1,'Marker','o','MarkerSize',30,'LineWidth',6);
set(p2,'Marker','diamond','MarkerSize',30,'LineWidth',6);

 %set(ax(1),'ylim',[0.6 1.04]);
 %set(ax(2),'ylim',[0 80]);
 %set(ax(2),'YTick',E_c_tot);
 %set(ax(1),'YTick',mu);
 %set(ax(1),'FontSize',19); 
 %set(ax(2),'FontSize',19); 
 set(ax(1),'XTick',f3);
 set(ax(2),'XTick',f3);
 %set(ax(1),'xlim',f3);
 %set(ax(2),'xlim',f3);
%p1.FontSize=20.0;
%p2.FontSize=20.0;
% hTitle = title(ax(2),'$M=100$, $\theta=0.5$, $slot=2000$, $E_{ave}=0.125$, $\Delta=1$','Interpreter','latex','FontSize');
% Pos = get(hTitle,'Position');
% Pos(2) = Pos(2)*4.02; %increase the height by 2%
% set(hTitle,'Position',Pos);
%title('$M=100$, $\theta=0.5$, $slot=2000$, $E_{ave}=0.125$, $\Delta=0.1$','Interpreter','latex','FontSize',30);
grid on
