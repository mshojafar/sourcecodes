%Fig 4a
 %%%%%%%%%%%%%%%%%%%%%%%%%saving%%%%%%%%%%%%%%%%
 
save('gamma1rPMR=2.mat','r');
save('gamma1pavgPMR=2.mat','e');
save('gamma1ON_SERVERPMR=2.mat','MM1');
save('gamma1OFF_SERVERPMR=2.mat','MM2');
save('gamma1SLEEP_SERVERPMR=2.mat','MM3');
save('gamma1aDELAYPMR=2.mat','Avg_ADELAY');
save('gamma1APPMR=2.mat','AP');
save('gamma1LOFFPMR=2.mat','L_off');
save('gamma1UTILITYPMR=2.mat','UUTILITY');
save('gamma1ARPMR=2.mat','AR');
save('gamma1AWPMR=2.mat','AW');
save('gamma1AVGLOFFPMR=2.mat','AVG_L_off');
save('gamma1rravgPMR=2.mat','rr');
save('gamma1TotDELAYPMR=2.mat','TOT_DELAY');

save('gamma1AverageSwichPMR=2.mat','Mean_SW');
save('gamma1AverageChannelPMR=2.mat','Mean_AAfterRouting_ChannelCost');
save('gamma1ppavgPMR=2.mat','ee');
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% VM=[2:2:20]; Jobs=8,PMR=2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% F=[2:(10-2)/10:10], F=[0:(10-2)/10:10]; 
%%%%%%%%%%%%%%%%%%%%Q=[2,6,15,\infty]; \infty=1000;
save('JDLS_Q=2_CPU_M20_N10_gamma1_V104_PMR=2.mat','mean_e');%Q=2
save('JDLS_Q=2_SW_M20_N10_gamma1_V104_PMR=2.mat','mean_SW');%Q=2
save('JDLS_Q=2_Chnl_M20_N10_gamma1_V104_PMR=2.mat','mean_Channel');%Q=2
save('JDLS_Q=2_Tot_M20_N10_gamma1_V104_PMR=2.mat','mean_avg_energy');%Q=2

save('JDLS_Q=6_CPU_M20_N10_gamma1_V104_PMR=2.mat','mean_e');%Q=6
save('JDLS_Q=6_SW_M20_N10_gamma1_V104_PMR=2.mat','mean_SW');%Q=6
save('JDLS_Q=6_Chnl_M20_N10_gamma1_V104_PMR=2.mat','mean_Channel');%Q=6
save('JDLS_Q=6_Tot_M20_N10_gamma1_V104_PMR=2.mat','mean_avg_energy');%Q=6

save('JDLS_Q=15_CPU_M20_N10_gamma1_V104_PMR=2.mat','mean_e');%Q=15
save('JDLS_Q=15_SW_M20_N10_gamma1_V104_PMR=2.mat','mean_SW');%Q=15
save('JDLS_Q=15_Chnl_M20_N10_gamma1_V104_PMR=2.mat','mean_Channel');%Q=15
save('JDLS_Q=15_Tot_M20_N10_gamma1_V104_PMR=2.mat','mean_avg_energy');%Q=15

save('JDLS_Q=1000_CPU_M20_N10_gamma1_V104_PMR=2.mat','mean_e');%Q=1000
save('JDLS_Q=1000_SW_M20_N10_gamma1_V104_PMR=2.mat','mean_SW');%Q=1000
save('JDLS_Q=1000_Chnl_M20_N10_gamma1_V104_PMR=2.mat','mean_Channel');%Q=1000
save('JDLS_Q=1000_Tot_M20_N10_gamma1_V104_PMR=2.mat','mean_avg_energy');%Q=1000

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%fig5c
 %Q=2
 JDLS_energy_tot_Q2=load('JDLS_Q=2_Tot_M20_N10_gamma1_V104_PMR=2.mat','mean_avg_energy');%Q=2
 JDLS_energy_tot_Q2=JDLS_energy_tot_Q2.mean_avg_energy;
 %Q=6
 JDLS_energy_tot_Q6=load('JDLS_Q=6_Tot_M20_N10_gamma1_V104_PMR=2.mat','mean_avg_energy');%Q=6
 JDLS_energy_tot_Q6=JDLS_energy_tot_Q6.mean_avg_energy;
 %Q=15
 JDLS_energy_tot_Q15=load('JDLS_Q=15_Tot_M20_N10_gamma1_V104_PMR=2.mat','mean_avg_energy');%Q=15
 JDLS_energy_tot_Q15=JDLS_energy_tot_Q15.mean_avg_energy;
 %Q=1000
 JDLS_energy_tot_Q1000=load('JDLS_Q=1000_Tot_M20_N10_gamma1_V104_PMR=2.mat','mean_avg_energy');%Q=1000
 JDLS_energy_tot_Q1000=JDLS_energy_tot_Q1000.mean_avg_energy;

 
figure(2000) %fig 5c
plot(VM,JDLS_energy_tot_Q2,'-b',VM,JDLS_energy_tot_Q6,'--r',VM,JDLS_energy_tot_Q15,'-.k',VM,JDLS_energy_tot_Q1000,':g');
xlabel('$M$','Interpreter','latex','FontSize',40);
ylabel('$\overline{\xi}^*_{j}$','Interpreter','latex','FontSize',40);
legend('$Q=2$','$Q=6$','$Q=15$','$Q=\infty$','Interpreter','latex','FontSize',40);
grid on

% figure(2001) %fig 5c
% plot(VM,JDLS_Channel_Omega02,'-b',VM,JDLS_Channel_Omega05,'--r',VM,JDLS_Channel_Omega02Hetr,'-.k',VM,JDLS_Channel_Omega05Hetr,':g');
% xlabel('$M$','Interpreter','latex','FontSize',40);
% ylabel('$\overline{mathcal{E}}^*_{LAN}^*$','Interpreter','latex','FontSize',40);
% legend('$\Omega_j=0.2$','$\Omega_j=0.5$','$\Omega_j=0.2+0.125(j-1)$','$\Omega_j=0.5+0.25(j-1)$','Interpreter','latex','FontSize',40);
% grid on
% 






figure(2000) %fig 4b
%subplot(2,1,1);
plot(VM,JDLS_energy_tot,'b',VM,GRADIS_energy_tot,'r',VM,NetDC_energy_tot,'g',VM,SLS_energy_tot,'k',VM,HybridNetDC_energy_tot);
%[ax,p1,p2]=plotyy(VM,JDLS_TOT_DELAY,VM,[U1, U2, U3],'plot', 'plot');
%xlabel('$V$','Interpreter','latex','FontSize',40);
xlabel('$M$','Interpreter','latex','FontSize',40);
ylabel('$\overline{\xi_j}^*$','Interpreter','latex','FontSize',40);
%ylabel(ax(1),'$\overline{T}_{tot}^*$','Interpreter','latex','FontSize',40);
%ylabel(ax(2),'$\mathcal{U}_{tot}$','Interpreter','latex','FontSize',40);
legend('JDLS', 'GRADIS','NetDC','SLS','H-NetDC');
%legend([p1;p2],'$Delay$', '$\mathcal{U}_{tot},\:\gamma=2$','$\mathcal{U}_{tot},\:\gamma=1$','$\mathcal{U}_{tot},\:\gamma=0.5$');

%set(ax(2),'XAxisLocation','Top');
%set(ax(1),'FontSize',40); 
%set(ax(2),'FontSize',40); 
%set(ax(1),'YColor','k'); 
%set(ax(2),'YColor','k'); 
%set(p1, 'MarkerSize',20,'Marker','diamond','LineWidth',6);
%set(p2, 'MarkerSize',20,'Marker','square','LineWidth',6);
%set(ax(1),'ylim',[0.982 1.02]);
%set(ax(2),'ylim',[5 12]);
%set(ax(2),'YTick',[4, 6, 8, 10, 12]);
%set(ax(1),'YTick',[0.5 1]);
%set(ax(1),'XTick',[0, 100, 200, 300, 500, 1000]);
%set(ax(2),'XTick',[0, 100, 200, 300, 500, 1000]);
%set(ax(1),'xlim',[0 1]);
%set(ax(1),'xlim',[1 1000]);
%set(ax(2),'xlim',[1 1000]);
title('' ,'Interpreter','latex','FontSize',40);
grid on

%%%%%%%%%%%
