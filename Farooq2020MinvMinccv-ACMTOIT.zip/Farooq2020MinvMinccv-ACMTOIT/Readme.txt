Help file to run the program written in MATLAB. (version 2018b)

This implementation was done by Farooq Hoseiny.


Member of Computing Systems Research Lab in University of Kurdistan.

Email: farooq.hoseiny@eng.uok.ac.ir, farooq.hosainy@gmail.com

Steps of running program:

1- Open the MATLAB environment.
2- Open the main.m file and run the program.

