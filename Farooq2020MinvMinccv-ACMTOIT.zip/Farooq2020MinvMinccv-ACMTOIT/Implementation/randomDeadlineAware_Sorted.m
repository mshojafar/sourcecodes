function [gf] = randomDeadlineAware_Sorted(firstAddress,secondAddress,dataSetNum)

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com

    node = load('dataset\node.mat');
    completeAddress = strcat(firstAddress, secondAddress);
    activeTime = zeros(dataSetNum,size(node.node , 2));
    PDST = zeros(dataSetNum,1);
    
    violation = 0;
    violCost = 0;
    
    counter = 1;
    while(counter <= dataSetNum)
        
        x = load(strcat('dataset\dataset', num2str(counter), '.mat'));
        list = zeros(2,size(x.X , 2));
        
        numT = [1:size(x.X , 2)];
        x.X = [numT; x.X(1:end,:)];
        sortData = sortrows(x.X',6)';
        
        for i = 1:size(x.X , 2)
            
            acceptList = [];
            unacceptList = [];

            for j = 1:size(node.node , 2)
                
                if(sortData(3,i)) <= (node.node(6,j))
                    
                    exeTime = sortData(2,i) / node.node(1,j);
                    resTime = exeTime + node.node(9,j) + activeTime(counter,j);
                    
                    compNode = (exeTime * node.node(2,j)) + (sortData(3,i) * node.node(3,j));
                    compCost = compNode;
                    commNode = (sortData(4,i) + sortData(5,i)) * node.node(4,j);
                    commCost = commNode;
                    
                    top = resTime - sortData(6,i);
                    if(top > 0)
                        violation = (top / sortData(6,i)) * 100;
                        pF = violation - (100 - sortData(7,i));
                        pS = sortData(8,i) * pF;
                        if(pS > 0)
                            violCost = pS;
                        end
                    end
                    
                    if(resTime <= sortData(6,i))
                        acceptList(1,end+1) = j;
                        acceptList(2,end) = resTime;
                        acceptList(3,end) = exeTime + activeTime(counter,j);
                        acceptList(4,end) = compCost + commCost;
                    else
                        unacceptList(1,end+1) = j;
                        unacceptList(2,end) = resTime;
                        unacceptList(3,end) = exeTime + activeTime(counter,j);
                        unacceptList(4,end) = violCost;
                    end
                    
                end
                
            end
            
            if(size(acceptList) >= 1)
                sD = sortrows(acceptList',4)';
                list(1,sortData(1,i)) = sD(1,1);
                list(2,sortData(1,i)) = sD(2,1);
                activeTime(counter,list(1,sortData(1,i))) = sD(3,1);
            else
                sD = sortrows(unacceptList',4)';
                list(1,sortData(1,i)) = sD(1,1);
                list(2,sortData(1,i)) = sD(2,1);
                activeTime(counter,list(1,sortData(1,i))) = sD(3,1);
            end
            
            clear acceptList;
            clear unacceptList;

        end
        
        data_name = strcat(completeAddress,num2str(counter),'.mat');
        save(data_name,'list');
        
        % PDST
        pdstCounter = 0;
        for i = 1:size(x.X , 2)
            if (x.X(6,i) >= list(2,i))
                pdstCounter = pdstCounter + 1;
            end
        end
        PDST(counter,1) = (pdstCounter / size(x.X , 2)) * 100;
        
        counter = counter + 1;
        
    end
    
    save(strcat(completeAddress,'activeTime','.mat'),'activeTime');
    save(strcat(completeAddress,'PDST','.mat'),'PDST');

    computationCost(firstAddress,secondAddress,dataSetNum);   % Computation and Communication Cost
    violationCost(firstAddress,secondAddress,dataSetNum);
    gf = goalFunction(completeAddress);

end