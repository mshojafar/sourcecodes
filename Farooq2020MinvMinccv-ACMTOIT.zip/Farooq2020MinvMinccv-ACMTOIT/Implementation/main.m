function [] = main()

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com

    dataSetNum = 6;
    
    fARR = 'MIterations\rr\';
    fARand = 'MIterations\random\';
    fARDA = 'MIterations\deadlineAware\';
    fARDAS = 'MIterations\sortedDeadlineAware\';
    
    iteration = 2;
    
    resultRR = zeros(iteration,dataSetNum);
    resultRand = zeros(iteration,dataSetNum);
    resultRDA = zeros(iteration,dataSetNum);
    resultRDAS = zeros(iteration,dataSetNum);

    counter = 1;
    while(counter <= iteration)
        
        secondAddress = strcat(num2str(counter),'\');
        adrsRR = strcat(fARR,secondAddress);
        adrsRand = strcat(fARand,secondAddress);
        adrsRDA = strcat(fARDA,secondAddress);
        adrsRDAS = strcat(fARDAS,secondAddress);

        status = mkdir(adrsRR);
        status = mkdir(adrsRand);
        status = mkdir(adrsRDA);
        status = mkdir(adrsRDAS);
  
        createDataset();
        createNode();

        gfRR = roundRobinMethod(fARR,secondAddress,dataSetNum);
        gfRand = randomMethod(fARand,secondAddress,dataSetNum);
        gfRDA = randomDeadlineAware(fARDA,secondAddress,dataSetNum);
        gfRDAS = randomDeadlineAware_Sorted(fARDAS,secondAddress,dataSetNum);
        
        resultRR(counter,:) = gfRR;   
        resultRand(counter,:) = gfRand;
        resultRDA(counter,:) = gfRDA;
        resultRDAS(counter,:) = gfRDAS;
        
        counter = counter + 1;
    end
    
    save(strcat(fARR,'GFResult','.mat'),'resultRR');
    save(strcat(fARand,'GFResult','.mat'),'resultRand');
    save(strcat(fARDA,'GFResult','.mat'),'resultRDA');
    save(strcat(fARDAS,'GFResult','.mat'),'resultRDAS');
    
    ctrl = zeros(4,dataSetNum);
    ctrl(1,:) = sum(resultRR,1) / iteration;
    ctrl(2,:) = sum(resultRand,1) / iteration;
    ctrl(3,:) = sum(resultRDA,1) / iteration;
    ctrl(4,:) = sum(resultRDAS,1) / iteration;
    
    save(strcat('MIterations\','GFResult.mat'),'ctrl');
    
    x = [50 100 150 200 250 300];

    vals = [ctrl(1,1) ctrl(2,1) ctrl(3,1) ctrl(4,1);
            ctrl(1,2) ctrl(2,2) ctrl(3,2) ctrl(4,2);
            ctrl(1,3) ctrl(2,3) ctrl(3,3) ctrl(4,3);
            ctrl(1,4) ctrl(2,4) ctrl(3,4) ctrl(4,4);
            ctrl(1,5) ctrl(2,5) ctrl(3,5) ctrl(4,5);
            ctrl(1,6) ctrl(2,6) ctrl(3,6) ctrl(4,6);];  
        
    figure
    bar(x,vals);
    legend('Round Robin','Random','Deadline Aware','Sorted Deadline Aware');
    title('Goal Function Result');

    communicationResult(fARR,fARand,fARDA,fARDAS,iteration,dataSetNum);
    computationResult(fARR,fARand,fARDA,fARDAS,iteration,dataSetNum);
    violationResult(fARR,fARand,fARDA,fARDAS,iteration,dataSetNum);
    makespanResult(fARR,fARand,fARDA,fARDAS,iteration,dataSetNum);
    PDST(fARR,fARand,fARDA,fARDAS,iteration,dataSetNum);

end