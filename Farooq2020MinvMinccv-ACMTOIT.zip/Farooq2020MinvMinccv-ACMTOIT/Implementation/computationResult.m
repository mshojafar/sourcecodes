function [] = computationResult(fARR,fARand,fARDA,fARDAS,iteration,dataSetNum)

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com
    
    rCompRR = zeros(iteration,dataSetNum);
    rCompRand = zeros(iteration,dataSetNum);
    rCompRDA = zeros(iteration,dataSetNum);
    rCompRDAS = zeros(iteration,dataSetNum);
    
    counter = 1;
    while(counter <= iteration)
        
        secondAddress = strcat(num2str(counter),'\','comp.mat');
        compRR = load(strcat(fARR,secondAddress));
        compRand = load(strcat(fARand,secondAddress));
        compRDA = load(strcat(fARDA,secondAddress));
        compRDAS = load(strcat(fARDAS,secondAddress));

        rCompRR(counter,:) = sum(compRR.comp,2);   
        rCompRand(counter,:) = sum(compRand.comp,2);
        rCompRDA(counter,:) = sum(compRDA.comp,2);
        rCompRDAS(counter,:) = sum(compRDAS.comp,2);
        
        counter = counter + 1;
    end
    
    ctrl = zeros(4,dataSetNum);
    ctrl(1,:) = sum(rCompRR,1) / iteration;
    ctrl(2,:) = sum(rCompRand,1) / iteration;
    ctrl(3,:) = sum(rCompRDA,1) / iteration;
    ctrl(4,:) = sum(rCompRDAS,1) / iteration;
    
    save(strcat('MIterations\','ComputationResult.mat'),'ctrl');
    
    x = [50 100 150 200 250 300];

    vals = [ctrl(1,1) ctrl(2,1) ctrl(3,1) ctrl(4,1);
            ctrl(1,2) ctrl(2,2) ctrl(3,2) ctrl(4,2);
            ctrl(1,3) ctrl(2,3) ctrl(3,3) ctrl(4,3);
            ctrl(1,4) ctrl(2,4) ctrl(3,4) ctrl(4,4);
            ctrl(1,5) ctrl(2,5) ctrl(3,5) ctrl(4,5);
            ctrl(1,6) ctrl(2,6) ctrl(3,6) ctrl(4,6);];    
        
    figure
    bar(x,vals);
    legend('Round Robin','Random','Deadline Aware','Sorted Deadline Aware');
    title('Computation Result');

end