function [] = computationCost(firstAddress,secondAddress,dataSetNum)

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com

    address = strcat(firstAddress, secondAddress);

    node = load('dataset\node.mat');
    
    comp = zeros(dataSetNum,size(node.node , 2));
    comm = zeros(dataSetNum,size(node.node , 2));
    
    counter = 1;
    while(counter <= dataSetNum)
        
        y = load(strcat(address,num2str(counter),'.mat'));
        x = load(strcat('dataset\dataset',num2str(counter),'.mat'));
        
        for i = 1:size(y.list , 2)
            
            exeTime = x.X(1,i) / node.node(1,y.list(1,i));
            comp(counter,y.list(1,i)) = comp(counter,y.list(1,i)) + ((exeTime * node.node(2,y.list(1,i))) + (x.X(2,i) * node.node(3,y.list(1,i))));   % Computation Cost
            
            comm(counter,y.list(1,i)) = comm(counter,y.list(1,i)) + ((x.X(3,i) + x.X(4,i)) * node.node(4,y.list(1,i)));    % Communication Cost
        end
        
        counter = counter + 1;
    end
    
    save(strcat(address,'comp','.mat'),'comp');
    save(strcat(address,'comm','.mat'),'comm');
    
end