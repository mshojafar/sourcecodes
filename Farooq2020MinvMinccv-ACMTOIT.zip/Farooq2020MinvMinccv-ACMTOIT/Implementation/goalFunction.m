function [F] = goalFunction(firstAddress)

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com
    
    computation = load(strcat(firstAddress,'comp','.mat'));
    communication = load(strcat(firstAddress,'comm','.mat'));
    violationCost = load(strcat(firstAddress,'violationCost','.mat'));
    
    F = sum(computation.comp,2) + sum(communication.comm,2) + (violationCost.violCost);
    save(strcat(firstAddress,'GF','.mat'),'F');
    
end