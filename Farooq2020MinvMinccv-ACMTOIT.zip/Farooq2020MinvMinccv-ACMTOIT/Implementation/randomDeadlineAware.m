function [gf] = randomDeadlineAware(firstAddress,secondAddress,dataSetNum)

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com

    node = load('dataset\node.mat');
    completeAddress = strcat(firstAddress, secondAddress);
    activeTime = zeros(dataSetNum,size(node.node , 2));
    PDST = zeros(dataSetNum,1);
    
    ctrl = zeros(7,size(node.node , 2));
    ctrlTotal = zeros(7,size(node.node , 2));
    violation = 0;
    violCost = 0;
    
    counter = 1;
    while(counter <= dataSetNum)
        
        x = load(strcat('dataset\dataset', num2str(counter), '.mat'));
        list = zeros(2,size(x.X , 2));
        
        for i = 1:size(x.X , 2)
            
            ctrl = ctrlTotal;
            
            for j = 1:size(node.node , 2)
                
                if(x.X(2,i) <= node.node(6,j))
                
                    
                    exeTime = x.X(1,i) / node.node(1,j);
                    compNode = (exeTime * node.node(2,j)) + (x.X(2,i) * node.node(3,j));
                    compCost = compNode;
                    commNode = (x.X(3,i) + x.X(4,i)) * node.node(4,j);
                    commCost = commNode;

                    ET = exeTime + node.node(9,j) + activeTime(counter,j);

                    top = ET - x.X(5,i);
                    if(top > 0)
                        violation = (top / x.X(5,i)) * 100;
                        pF = violation - (100 - x.X(6,i));
                        pS = x.X(7,i) * pF;
                        if(pS > 0)
                            violCost = violCost + pS;
                        end
                    end

                    ctrl(1,j) = j;
                    ctrl(2,j) = compCost;
                    ctrl(3,j) = commCost;
                    ctrl(4,j) = ctrl(4,j) + exeTime;
                    ctrl(5,j) = violCost;
                    ctrl(6,j) = ET;
                    ctrl(7,j) = ctrl(2,j) + ctrl(3,j) + ctrl(5,j);

                else
                    ctrl(1,j) = j;
                    ctrl(7,j) = 100000;                                        
                end
                violCost = 0;
            end
            
            sortData = sortrows(ctrl',7)';
            list(1,i) = sortData(1,1);
            list(2,i) = sortData(6,1);
            activeTime(counter,sortData(1,1)) = sortData(4,1);
            ctrlTotal(1:7,sortData(1,1)) = sortData(1:7,1);
            
            ctrl(:) = 0;
            
        end
        
        data_name = strcat(completeAddress,num2str(counter),'.mat');
        save(data_name,'list');
        
        
        ctrlTotal(:) = 0;
        
        % PDST
        pdstCounter = 0;
        for i = 1:size(x.X , 2)
            if (x.X(5,i) >= list(2,i))
                pdstCounter = pdstCounter + 1;
            end
        end
        PDST(counter,1) = (pdstCounter / size(x.X , 2)) * 100;
        
        counter = counter + 1;
        
    end
    
    save(strcat(completeAddress,'activeTime','.mat'),'activeTime');
    save(strcat(completeAddress,'PDST','.mat'),'PDST');
    
    computationCost(firstAddress,secondAddress,dataSetNum);   % Computation and Communication Cost
    violationCost(firstAddress,secondAddress,dataSetNum);
    gf = goalFunction(completeAddress);
            

end