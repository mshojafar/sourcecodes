function [] = communicationResult(fARR,fARand,fARDA,fARDAS,iteration,dataSetNum)
    
% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com

    rCommRR = zeros(iteration,dataSetNum);
    rCommRand = zeros(iteration,dataSetNum);
    rCommRDA = zeros(iteration,dataSetNum);
    rCommRDAS = zeros(iteration,dataSetNum);

    counter = 1;
    while(counter <= iteration)
        
        secondAddress = strcat(num2str(counter),'\','comm.mat');
        commRR = load(strcat(fARR,secondAddress));
        commRand = load(strcat(fARand,secondAddress));
        commRDA = load(strcat(fARDA,secondAddress));
        commRDAS = load(strcat(fARDAS,secondAddress));

        rCommRR(counter,:) = sum(commRR.comm,2);   
        rCommRand(counter,:) = sum(commRand.comm,2);
        rCommRDA(counter,:) = sum(commRDA.comm,2);
        rCommRDAS(counter,:) = sum(commRDAS.comm,2);
        
        counter = counter + 1;
    end
    
    ctrl = zeros(4,dataSetNum);
    ctrl(1,:) = sum(rCommRR,1) / iteration;
    ctrl(2,:) = sum(rCommRand,1) / iteration;
    ctrl(3,:) = sum(rCommRDA,1) / iteration;
    ctrl(4,:) = sum(rCommRDAS,1) / iteration;
    
    save(strcat('MIterations\','CommunicationResult.mat'),'ctrl');
    
    x = [50 100 150 200 250 300];

    vals = [ctrl(1,1) ctrl(2,1) ctrl(3,1) ctrl(4,1);
            ctrl(1,2) ctrl(2,2) ctrl(3,2) ctrl(4,2);
            ctrl(1,3) ctrl(2,3) ctrl(3,3) ctrl(4,3);
            ctrl(1,4) ctrl(2,4) ctrl(3,4) ctrl(4,4);
            ctrl(1,5) ctrl(2,5) ctrl(3,5) ctrl(4,5);
            ctrl(1,6) ctrl(2,6) ctrl(3,6) ctrl(4,6);];
           
    figure
    bar(x,vals);
    legend('Round Robin','Random','Deadline Aware','Sorted Deadline Aware');
    title('Communication Result');

end