function [] = violationCost(firstAddress,secondAddress,dataSetNum)

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com

    address = strcat(firstAddress, secondAddress);
    violCost = zeros(dataSetNum,1);
    violTime = zeros(dataSetNum,1);
    
    counter = 1;
    while(counter <= dataSetNum)
        
        x = load(strcat('dataset\dataset', num2str(counter), '.mat'));
        y = load(strcat(address,num2str(counter),'.mat'));
        violation = zeros(2,size(x.X , 2));
        
        for i = 1:size(x.X , 2)
            
            top = y.list(2,i) - x.X(5,i);
            if(top > 0)
                violation(1,i) = (top / x.X(5,i)) * 100; 
                pF = violation(1,i) - (100 - x.X(6,i));
                pS = x.X(7,i) * pF;
                if(pS > 0)
                    violation(2,i) = pS;
                end

                violTime(counter) = violTime(counter) + top;
            end
            
        end
        
        violCost(counter) = sum(violation(2,:));
        
        counter = counter + 1;
        
    end

    save(strcat(address,'violationCost','.mat'),'violCost');
    save(strcat(address,'violationTime','.mat'),'violTime');
    
end