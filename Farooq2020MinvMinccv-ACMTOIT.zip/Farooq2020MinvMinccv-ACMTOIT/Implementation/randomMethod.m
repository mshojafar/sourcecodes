function [gf] = randomMethod(firstAddress,secondAddress,dataSetNum)

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com

    node = load('dataset\node.mat');
    completeAddress = strcat(firstAddress, secondAddress);
    activeTime = zeros(dataSetNum,size(node.node , 2));
    PDST = zeros(dataSetNum,1);
    
    counter = 1;
    while(counter <= dataSetNum)
        
        x = load(strcat('dataset\dataset', num2str(counter), '.mat'));
        list = randi(size(node.node , 2),2,size(x.X , 2));
        list(2,:) = 0;
        
        for i = 1:size(x.X , 2)

            unacceptList = [];

            while (x.X(2,i)) > (node.node(6,list(1,i)))
                unacceptList(end+1) = list(1,i);
                old = setdiff(1:size(node.node , 2), unacceptList);
                list(1,i) = old(randi(numel(old)));
            end

            clear unacceptList;

        end
        
%         Response Time
        for i = 1:size(node.node , 2)
            
            nodeTasks = [;];
            
            if (size(find(list(1,:) == i)) ~= 0)
                nodeTasks(1,:) = find(list(1,:) == i);
                nodeTasks(2,:) = x.X(5,nodeTasks(1,:));
            end
            
            for j = 1:size(nodeTasks,2)
                
                exeTime = (x.X(1,nodeTasks(1,j)) / node.node(1,i));
                list(2,nodeTasks(1,j)) = exeTime + node.node(9,i) + activeTime(counter,i);                
                activeTime(counter,i) = activeTime(counter,i) + exeTime;
                
            end
            
            clear sortNT;
            clear nodeTasks;
            
        end
        
        
        data_name = strcat(completeAddress,num2str(counter),'.mat');
        save(data_name,'list');
        
        % PDST
        pdstCounter = 0;
        for i = 1:size(x.X , 2)
            if (x.X(5,i) >= list(2,i))
                pdstCounter = pdstCounter + 1;
            end
        end
        
        PDST(counter,1) = (pdstCounter / size(x.X , 2)) * 100;
        
        counter = counter + 1;
        
    end
    
    save(strcat(completeAddress,'activeTime','.mat'),'activeTime');
    save(strcat(completeAddress,'PDST','.mat'),'PDST');
    
    computationCost(firstAddress,secondAddress,dataSetNum);   % Computation and Communication Cost
    violationCost(firstAddress,secondAddress,dataSetNum);
    gf = goalFunction(completeAddress);

end