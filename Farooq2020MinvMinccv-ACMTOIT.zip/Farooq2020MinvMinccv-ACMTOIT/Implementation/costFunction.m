function [F] = costFunction(gen,alpha,minMakespan,minTotal)

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com

    node = load('dataset\node.mat');
    counter = size(gen , 2) / 50;
    x = load(strcat('dataset\dataset', num2str(counter), '.mat'));
    F = zeros(1,size(gen , 1));
    
    for j = 1:size(gen , 1)
        
        ctrl = zeros(4,size(node.node , 2));
        compNode = 0;
        compCost = 0;
        commNode = 0;
        commCost = 0;
        
        for k = 1:size(gen , 2)
            
            exeTime = x.X(1,k) / node.node(1,gen(j,k));
            compNode = (exeTime * node.node(2,gen(j,k))) + (x.X(2,k) * node.node(3,gen(j,k)));
            compCost = compNode + sum(ctrl(1,:));
            
            commNode = (x.X(3,k) + x.X(4,k)) * node.node(4,gen(j,k));
            commCost = commNode + sum(ctrl(2,:));
            
            ctrl(1,gen(j,k)) = compCost;
            ctrl(2,gen(j,k)) = commCost;
            ctrl(3,gen(j,k)) = ctrl(3,gen(j,k)) + exeTime;
            
        end
        
        ctrl(4,:) = ctrl(1,:) + ctrl(2,:);
        makespan = max(ctrl(3,:));
        
        F(j) = (alpha * (minMakespan / makespan)) + ((1 - alpha) *(minTotal / sum(ctrl(4,:))));
        
    end

end