function createDataset()

% Farooq hoseiny
% Senior student of Kurdistan University
% Member of the Internet of Things Association of Kurdistan University
% http://iot.uok.ac.ir/
% Email: farooq.hoseiny@eng.uok.ac.ir
% Gmail: farooq.hosainy@gmail.com

    n = 50;
    m = 1;

    while(n <= 300) && (m <= 6)

        X = zeros(7,n);
        X(2,:) = randi([50 200],1,n); %Memory required
        X(3,:) = (1.5-0.3).*rand(1,n) + 0.3; %Input file size
        X(4,:) = (1-0.1).*rand(1,n) + 0.1; %Output file size
        X(6,:) = (99.99-90).*rand(1,n) + 90; %Quality of Service
        X(7,:) = (0.5-0.1).*rand(1,n) + 0.1; %Penalty
        
        for i = 1:n
            randNum = randi(3);
            if (randNum == 1)
                X(1,i) = randi([100 372]); %Number of instructions(MI)
                X(5,i) = (0.5-0.1).*rand(1) + 0.1; %Deadline
            elseif (randNum == 2)
                X(1,i) = randi([1028 4280]); %Number of instructions(MI)
                X(5,i) = (2.5-0.5).*rand(1) + 0.5; %Deadline
            elseif (randNum == 3)
                X(1,i) = randi([5123 9784]); %Number of instructions(MI)
                X(5,i) = (10-2.5).*rand(1) + 2.5; %Deadline
            end
        end

        data_name = strcat('dataset\dataset',int2str(m),'.mat');
        save(data_name,'X');

        n = n + 50;
        m = m + 1;
    end

end