Help file to run the project written in AVISPA tool.

Ali Shahidinejad did this implementation.  
Mostafa Ghobaei-Arani and Alireza Souri helped on idea brainstorming
Mohammad Shojafar and Saru Kumari helped in English correction, documentation organization, and leading the team.

Contact: Qom Islamic Azad University, 201523 Qom, Iran (the Islamic Republic of), 3716665371 
(e-mail: a.shahidinejad@qom-iau.ac.ir)

Step of the running project:
 
In formal security analysis, the Light-Edge protocol is evaluated by the AVISPA tool.

The Light-Edge protocol is presented in HLPSL structure.

There are three main components in the Light-Edge protocol:

The device, the cloud provider and the trust center
Each role is presented in device.txt, cloud provider.txt, and trust center.txt.

After determining the role and performance of each component in the proposed protocol,
a session will get established between them. 
The session's structure which contains the main roles in the Light-Edge protocol and a combination of communications between them is presented in session.txt.

The protocol's environment is the highest level of the Light-Edge protocol.
Environment shows the environment's structure in this protocol.