# -*- coding: utf-8 -*-

#Importing* libraries
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder,OneHotEncoder
from sklearn import preprocessing
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split 
import warnings
import time
import tensorflow as tf

import collections
import pandas as pd
import numpy as np
import tensorflow as tf
import tensorflow_federated as tff

np.random.seed(0)

"""#Importing Dataset"""

col_names = ["duration","protocol_type","service","flag","src_bytes",
    "dst_bytes","land","wrong_fragment","urgent","hot","num_failed_logins",
    "logged_in","num_compromised","root_shell","su_attempted","num_root",
    "num_file_creations","num_shells","num_access_files","num_outbound_cmds",
    "is_host_login","is_guest_login","count","srv_count","serror_rate",
    "srv_serror_rate","rerror_rate","srv_rerror_rate","same_srv_rate",
    "diff_srv_rate","srv_diff_host_rate","dst_host_count","dst_host_srv_count",
    "dst_host_same_srv_rate","dst_host_diff_srv_rate","dst_host_same_src_port_rate",
    "dst_host_srv_diff_host_rate","dst_host_serror_rate","dst_host_srv_serror_rate",
    "dst_host_rerror_rate","dst_host_srv_rerror_rate","label"]

dataset_train=pd.read_csv('KDDTrain+.csv',names = col_names)

"""Attach the columns names to the dataset"""

set(dataset_train['label'])

"""Categorical features"""

categorical_columns=['protocol_type', 'service', 'flag'] 
 # Get the categorical values into a 2D numpy array
dataset_train_categorical_values = dataset_train[categorical_columns]

dataset_train_categorical_values.head()

unique_protocol=sorted(dataset_train.protocol_type.unique())
string1 = 'Protocol_type_'
unique_protocol2=[string1 + x for x in unique_protocol]
# service
unique_service=sorted(dataset_train.service.unique())
string2 = 'service_'
unique_service2=[string2 + x for x in unique_service]
# flag
unique_flag=sorted(dataset_train.flag.unique())
string3 = 'flag_'
unique_flag2=[string3 + x for x in unique_flag]
# put together
dumcols=unique_protocol2 + unique_service2 + unique_flag2
print(dumcols)

"""Transform categorical features"""

dataset_train_categorical_values_enc=dataset_train_categorical_values.apply(LabelEncoder().fit_transform)
print(dataset_train_categorical_values_enc.head())

"""One-Hot-Encoding"""

enc = OneHotEncoder()
dataset_train_categorical_values_encenc = enc.fit_transform(dataset_train_categorical_values_enc)
dataset_train_cat_data = pd.DataFrame(dataset_train_categorical_values_encenc.toarray(),columns=dumcols)

"""Join encoded categorical dataframe with the non-categorical dataframe"""

newdf=dataset_train.join(dataset_train_cat_data)
newdf.drop('flag', axis=1, inplace=True)
newdf.drop('protocol_type', axis=1, inplace=True)
newdf.drop('service', axis=1, inplace=True)

"""Join encoded categorical dataframe with the non-categorical dataframe"""

newdf=dataset_train.join(dataset_train_cat_data)
newdf.drop('flag', axis=1, inplace=True)
newdf.drop('protocol_type', axis=1, inplace=True)
newdf.drop('service', axis=1, inplace=True)

print(newdf.shape)

"""change the label column"""

labeldf=newdf['label']
newlabeldf=labeldf.replace({ 'normal' : 0, 'neptune' : 1 ,'back': 1, 'land': 1, 'pod': 1, 'smurf': 1, 'teardrop': 1,'mailbomb': 1, 'apache2': 1, 'processtable': 1, 'udpstorm': 1, 'worm': 1,
                           'ipsweep' : 1,'nmap' : 1,'portsweep' : 1,'satan' : 1,'mscan' : 1,'saint' : 1
                           ,'ftp_write': 1,'guess_passwd': 1,'imap': 1,'multihop': 1,'phf': 1,'spy': 1,'warezclient': 1,'warezmaster': 1,'sendmail': 1,'named': 1,'snmpgetattack': 1,'snmpguess': 1,'xlock': 1,'xsnoop': 1,'httptunnel': 1,
                           'buffer_overflow': 1,'loadmodule': 1,'perl': 1,'rootkit': 1,'ps': 1,'sqlattack': 1,'xterm': 1})



newdf['label'] = newlabeldf
print(newdf['label'].head())

New_data_train = newdf

"""Splitting data"""

X_train = New_data_train.drop('label',1)
y_train = New_data_train.label

colNames=list(X_train)

"""#Feature scaling"""

colNames=list(X_train)

scaler1 = preprocessing.StandardScaler().fit(X_train)
X_train=scaler1.transform(X_train)

"""Recursive Feature Elimination (RFE)"""

from sklearn.feature_selection import RFE
clf = DecisionTreeClassifier(random_state=0)
rfe = RFE(estimator=clf, n_features_to_select=60, step=1)
rfe.fit(X_train, y_train.astype(int))
X_rfe=rfe.transform(X_train)
true=rfe.support_
rfecolindex=[i for i, x in enumerate(true) if x]
rfecolname=list(colNames[i] for i in rfecolindex)

X_train=X_rfe

from tensorflow import keras

from keras.utils.np_utils import to_categorical

y_train=to_categorical(y_train)

"""Importing librareries for federated learning"""

from tensorflow.keras.models import Model
from tensorflow.keras import regularizers

tmp = []
c = 0
for i in range(1,len(New_data_train)):
  tmp.append(c)
  if i %8000 == 0 :
    c+= 1
tmp.append(15)

for i in set(tmp):
  print(i,tmp.count(i))

new_input_data = pd.DataFrame({'Client_ID':tmp,'x':list(X_train),'y':list(y_train)})

New_data_train.insert(0, 'Client_ID', tmp)

from random import sample

"""Create a federated dataset from a CSV format"""

client_id_colname = 'Client_ID' # the column that represents client ID
SHUFFLE_BUFFER = 1000
NUM_EPOCHS = 1

# split client id into train and test clients
client_ids = new_input_data[client_id_colname].unique()
train_client_ids = sample(client_ids.tolist(), 12)
test_client_ids = [x for x in client_ids if x not in train_client_ids]

NUM_EPOCHS = 50
BATCH_SIZE = 128
SHUFFLE_BUFFER = 500
PREFETCH_BUFFER = 10

def preprocess(dataset):

  def batch_format_fn(element):
    return collections.OrderedDict(
        x=tf.reshape(element['x'], [-1, 60]),
        y=tf.reshape(element['y'], [-1, 2]))

  return dataset.repeat(NUM_EPOCHS).shuffle(SHUFFLE_BUFFER).batch(
      BATCH_SIZE).map(batch_format_fn).prefetch(PREFETCH_BUFFER)

def map_fn(example):
  return collections.OrderedDict(
      x=tf.reshape(example['x'], [-1, 60]), y=tf.reshape(example['y'],[-1,2]))
def client_data(n):
  ds = train_data.create_tf_dataset_for_client(train_data.client_ids[n])
  return ds.repeat(10).shuffle(500).batch(BATCH_SIZE).map(map_fn)

def create_tf_dataset_for_client_fn(client_id):
  # a function which takes a client_id and returns a
  # tf.data.Dataset for that client
  client_data = new_input_data[new_input_data[client_id_colname] == client_id]
  dataset = tf.data.Dataset.from_tensor_slices(client_data.to_dict('list'))
  return dataset

train_data = tff.simulation.ClientData.from_clients_and_fn(
        client_ids=train_client_ids,
        create_tf_dataset_for_client_fn=create_tf_dataset_for_client_fn
    )
test_data = tff.simulation.ClientData.from_clients_and_fn(
        client_ids=test_client_ids,
        create_tf_dataset_for_client_fn=create_tf_dataset_for_client_fn
    )

train_data.element_type_structure

example_dataset = train_data.create_tf_dataset_for_client(
    train_data.client_ids[0])

example_element = next(iter(example_dataset))

preprocessed_example_dataset = preprocess(example_dataset)

sample_batch = tf.nest.map_structure(lambda x: x.numpy(),
                                     next(iter(preprocessed_example_dataset)))

sample_batch

"""Construct a list of datasets from the given set of users as an input to a round of training or evaluation."""

def make_federated_data(client_data, client_ids):
  return [
      preprocess(client_data.create_tf_dataset_for_client(x))
      for x in client_ids
  ]

"""Sampling users"""

sample_clients = train_data.client_ids[0:16]

federated_train_data = make_federated_data(train_data, sample_clients)

print('Number of client datasets: {l}'.format(l=len(federated_train_data)))
print('First dataset: {d}'.format(d=federated_train_data[0]))

from keras.layers import LeakyReLU

def model_fn():
  model = tf.keras.models.Sequential([
      tf.keras.layers.Input(shape=(60,)),
      tf.keras.layers.Dense(70,activation=LeakyReLU(),kernel_regularizer=regularizers.l1_l2(l1=1e-5, l2=1e-4),
          ),
      tf.keras.layers.Dense(200, activation=LeakyReLU(),kernel_regularizer=regularizers.l1_l2(l1=1e-5, l2=1e-4),
          ),
      tf.keras.layers.Dense(20, activation=LeakyReLU(),kernel_regularizer=regularizers.l1_l2(l1=1e-5, l2=1e-4),
          ),
      
      tf.keras.layers.Dense(2,activation='softmax')
  ])
  return tff.learning.from_keras_model(
      model,
      input_spec=preprocessed_example_dataset.element_spec,
      loss=tf.keras.losses.CategoricalCrossentropy(),
      metrics=[tf.keras.metrics.CategoricalAccuracy(), tf.keras.metrics.Precision(),tf.keras.metrics.Recall()])

"""Training the model on federated data"""

trainer = tff.learning.build_federated_averaging_process(
    model_fn, client_optimizer_fn=lambda: tf.keras.optimizers.Adamax(),
    server_optimizer_fn=lambda: tf.keras.optimizers.Adamax())

sample_clients_test = test_data.client_ids[0:15]

federated_test_data = make_federated_data(test_data, sample_clients_test)

len(federated_test_data), federated_test_data[0]

def evaluate(num_rounds=15):
  global state
  global logdir
  acc,loss,precision,recall = [],[],[],[]
  acct,losst,precisiont,recallt = [],[],[],[]
  times=[]
  logdir = "/tmp/logs/scalars/training/"
  summary_writer = tf.summary.create_file_writer(logdir)
  state = trainer.initialize()
  evaluation = tff.learning.build_federated_evaluation(model_fn)

  for _ in range(num_rounds):
    t1 = time.time()
    state, metrics = trainer.next(state, federated_train_data)
    test_metrics = evaluation(state.model, federated_test_data)
    for name, value in metrics['train'].items():
      tf.summary.scalar(name, value, step=num_rounds)

    t2 = time.time()
    acc.append(metrics['train']['categorical_accuracy'])
    loss.append(metrics['train']['loss'])
    precision.append(metrics['train']['precision'])
    recall.append(metrics['train']['recall'])

    acct.append(test_metrics['categorical_accuracy'])
    losst.append(test_metrics['loss'])
    precisiont.append(test_metrics['precision'])
    recallt.append(test_metrics['recall'])
    times.append(t2 - t1)
   
    

    print('metrics {m},test{testm} ,round time {t:.2f} seconds'.format(
        m=metrics,testm=test_metrics, t=t2 - t1))
    

  return acc,loss,precision,recall ,acct,losst,precisiont,recallt, times

acc,loss,precision,recall,acct,losst,precisiont,recallt, times = evaluate(200)

np.average(times)

import statistics
statistics.mean(times)

x_test = []
y_test = []
for i in range(len(new_input_data)):
  if new_input_data['Client_ID'][i] in sample_clients_test:
    x_test.append(new_input_data['x'][i])
    y_test.append(new_input_data['y'][i])

"""# To make the prediction we assign the federated model weights to a simple DNN model"""

model = tf.keras.models.Sequential([
      tf.keras.layers.Input(shape=(60,)),
      tf.keras.layers.Dense(70,activation=LeakyReLU(),kernel_regularizer=regularizers.l1_l2(l1=1e-5, l2=1e-4),
          ),
      tf.keras.layers.Dense(200, activation=LeakyReLU(),kernel_regularizer=regularizers.l1_l2(l1=1e-5, l2=1e-4),
          ),
      tf.keras.layers.Dense(20, activation=LeakyReLU(),kernel_regularizer=regularizers.l1_l2(l1=1e-5, l2=1e-4),
          ),
      
      tf.keras.layers.Dense(2,activation='softmax')
  ])

model.compile(loss=tf.keras.losses.CategoricalCrossentropy(),
      metrics=[tf.keras.metrics.CategoricalAccuracy(),tf.keras.metrics.Precision(),tf.keras.metrics.Recall()])

state.model.assign_weights_to(model)

model.evaluate(np.array(x_test),np.array(y_test))

y_pred = model.predict(np.array(x_test))

from sklearn.metrics import confusion_matrix,classification_report

y_pred_arg = [np.argmax(j) for j in y_pred]

y_test_arg = [np.argmax(j) for j in y_test]

confusion_matrix(y_test_arg,y_pred_arg)

print(classification_report(y_test_arg,y_pred_arg))

import keras
from matplotlib import pyplot as plt
f, axes = plt.subplots(1, 2, figsize=(12,7))
f. tight_layout(pad=5.0)
plt.tick_params(axis='both', which='major', labelsize=18)
axes[0].plot(acc,'--', color = 'k', linewidth=2)
axes[0].set_xlim([5, 200])
axes[0].set_ylim([60, 100])
axes[0].tick_params(labelsize=18)
axes[0].plot(acct, color = 'b', marker='*',ms='8', markevery=5, linewidth=3)
axes[1].plot(loss,'--', color = 'k', linewidth=2)
plt.xlim([10, 200])
axes[1].plot(losst, color = 'b', marker='*',ms='8', markevery=5, linewidth=3)
plt.ylim([0.011, 1.2])
axes[0].set_ylabel('Accuracy (%)', fontsize = 25)
axes[1].set_ylabel('Loss', fontsize = 25)
f.text(0.5, 0.04, 'Communication interaction', ha='center', fontsize=25)
axes[1].legend(['train', 'test'], loc='top right', fontsize = 20, handlelength=5, handleheight=3)
axes[0].legend(['train', 'test'], loc='lower right', fontsize = 20, handlelength=5, handleheight=3)
plt.savefig('/content/accuracyvsloss.pdf')
plt.show()

import matplotlib.pyplot as plt
features = list(range(30, 122, 10))
fig = plt.figure(figsize=(10,6))
plt.plot(features, FDNN_Time, label = "FDNN", marker = '*', ms=10 , color='b', linewidth=4)
plt.xlabel('Number of features', fontsize=25)
plt.ylabel('End_to_End delay (Sec)', fontsize = 25)
plt.legend(loc='lower right', fontsize=25)
plt.yticks(fontsize=16)
plt.xticks(fontsize=16)
plt.savefig('/content/time.pdf')