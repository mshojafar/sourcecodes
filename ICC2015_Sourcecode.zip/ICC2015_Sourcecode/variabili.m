clear all;
close all;
clc;
X = rand(1,10000000);
EPS = rand(1,10000000);
DELTA_IP = rand(1,10000000);

save('X');
save('EPS');
save('DELTA_IP');