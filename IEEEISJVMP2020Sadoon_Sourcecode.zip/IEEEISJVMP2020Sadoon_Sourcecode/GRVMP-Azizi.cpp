#include<sys/time.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<math.h>
#define max 6000
struct machine {
	int id,c,r,b,rank,loc;
	float pow_eff,l,h,cu,ru,bu,a,v,p_min,p_max; // pc for power consumption pow_eff for power efficieny of a PM
};
struct machine vm[max],pm[max];
struct timeval start, end, start1, end1;
int i, j, x, y, nvm, npm, r, nrun=30;
void FFD(struct machine [],struct machine [],int,int);
void BFD(struct machine [],struct machine [],int,int);
void MBFD(struct machine [],struct machine [],int,int);
void MaxMin(struct machine [],struct machine [],int,int);
void Random(struct machine [],struct machine [],int,int);
void GRVMP_d(struct machine [],struct machine [],int,int);
void pm_increasing_order(struct machine [],struct machine [], int);
void pm_decreasing_order(struct machine [], int);
void vm_increasing_order(struct machine [], int);
void vm_decreasing_order(struct machine [], int);
void vm_decreasing_order_c(struct machine [], int);
void vm_decreasing_order_r(struct machine [], int);
void vm_decreasing_order_prob_c(struct machine [], int);
void vm_decreasing_order_prob_r(struct machine [], int);
void pm_decreasing_order_c(struct machine pm[], int npm);
void pm_decreasing_order_r(struct machine pm[], int npm);
void pm_decreasing_order_powerEfficiency(struct machine [], int);
void pm_decreasing_order_prob_rank(struct machine [], int);
void vm_decreasing_order_prob_rank(struct machine [], int);
void machines(int, int);
main()
{
//	srand(100);
	int i, j, code, nvm, npm, x, y;
	while(1) {
//	printf("\nEnter # of PMs and # of VMs: \n");
//	scanf("%d %d", &npm, &nvm);
	npm = 2000;
//	nvm = 4096;
	printf("\nEnter # of VMs: \n");
	scanf("%d", &nvm);
//	printf("\nEnter # of PMs: \n");
//	scanf("%d", &npm);
	while (1) {	
	printf("\n1-FFD");
	printf("\n2-BFD");
	printf("\n3-Random");
	printf("\n4-MBFD");
	printf("\n5-MaxMin");
	printf("\n6-GRVMP_d");
	printf("\n7-Start New Iteration\n"); 
	printf("\nEnter Your Choice: ");
	scanf("%d", &code);
	switch(code)
	{
		case 1: FFD(pm,vm,npm,nvm);
				break;
		case 2: BFD(pm,vm,npm,nvm);
				break;
		case 3: Random(pm,vm,npm,nvm);
				break;
		case 4: MBFD(pm,vm,npm,nvm);
				break;
		case 5: MaxMin(pm,vm,npm,nvm);
				break;
		case 6: GRVMP_d(pm,vm,npm,nvm);
				break;
		case 7: break; 	
	}
	if (code == 7)
		break;
	}
	}
}

/////////////////////////  FFD  ////////////////////////////////
void FFD(struct machine pm[],struct machine vm[],int npm,int nvm)
{
	int max_unaloc_vm=0, min_unaloc_vm=10000, sum_unaloc_vm=0; // number of unallocated vms
	int max_ac_pm=0, min_ac_pm=10000, sum_ac_pm=0;  //number of active pms
	float max_cu=0.0, min_cu=1.0, tot_cu=0.0;  //total cpu utilization
	float max_ru=0.0, min_ru=1.0, tot_ru=0.0;  //total ram utilization
	float max_rw=0.0, min_rw=1000.0, tot_rw=0.0;  //total rw
	float max_pc=0.0, min_pc=1000000.0, tot_pc=0.0;  //total pc
	for (r=1; r<=nrun; r++) {
//	printf("Run=%d\n",r);
	int i, j, idle=0, unaloc_vm=0, ac_pm=0;
	float sum_cu=0, sum_ru=0, rw=0, pc=0, ave, var=0;
	struct machine pm_org[npm], vm_copy[nvm];
	machines(npm, nvm);
	for (i=0; i<npm; i++) 
		pm_org[i] = pm[i];
	for (i=0; i<nvm; i++) 
		vm_copy[i] = vm[i];
	gettimeofday(&start, NULL);
	vm_decreasing_order(vm_copy, nvm);
//	printf("\npm_list\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
//	printf("\nvm_list\n");
//	for (i=0; i<nvm; i++)
//		printf("[%d,%d,%d]\n", vm_copy[i].id, vm_copy[i].c, vm_copy[i].r);
//	printf("\n");	
	for (i=0; i<nvm; i++)
		for (j=0; j<npm; j++) {
			if (vm_copy[i].c <= pm_org[j].c && vm_copy[i].r <= pm_org[j].r)
			{
				pm_org[j].c -= vm_copy[i].c;
				pm_org[j].r -= vm_copy[i].r;
				vm_copy[i].c = 0;
//				printf("vm[%d] --> pm[%d]\n", vm_copy[i].id, pm_org[j].id);
//				getch();
				break;
			}
		}
	gettimeofday(&end, NULL);
    printf("\nElapsed time: %ld microsecons\n", (end.tv_usec - start.tv_usec));
//    getch();
//	printf("\nFinal PM list :\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r, pm_org[i].b);
	for (i=0; i<npm; i++) {
		pm_org[i].cu = (float)(pm[i].c-pm_org[i].c)/pm[i].c;
		pm_org[i].ru = (float)(pm[i].r-pm_org[i].r)/pm[i].r;
		if (pm_org[i].c == pm[i].c)
			idle++;
		else
			rw += (fabs(pm_org[i].cu-pm_org[i].ru)+0.0001)/(pm_org[i].cu+pm_org[i].ru);
//		printf("pm_org[%d].cu=%.2f\n",pm_org[i].id, pm_org[i].cu);
//		printf("pm_org[%d].ru=%.2f\n",pm_org[i].id, pm_org[i].ru);
	}
	for (i=0; i<npm; i++)
		if (pm_org[i].cu > 0) {
			sum_cu += pm_org[i].cu;
			sum_ru += pm_org[i].ru;
			pc += (pm_org[i].p_min+(pm_org[i].p_max-pm_org[i].p_min)*pm_org[i].cu);
			ave = (pm_org[i].cu + pm_org[i].ru)/2;
			var += 0.5*((pm_org[i].cu - ave,2)+pow(pm_org[i].ru - ave,2));
		}
	for (i=0; i<nvm; i++) 
		if (vm_copy[i].c != 0)
			unaloc_vm++;
	ac_pm = npm - idle;
//	printf("\n\nThe number of unallocated VMs: %d\n",unaloc_vm);
//	printf("The number of active PMs: %d\n",ac_pm);
//	printf("The mean CPU utilization ratio: %.2f\n",sum_cu/(npm-idle));		
//	printf("The mean RAM utilization ratio: %.2f\n",sum_ru/(npm-idle));	
//	printf("The resource wastage: %.2f\n",rw);
////	printf("The total variance: %.2f\n",var);
//	printf("The power consumption: %.2f W\n",pc);
	// number of unallocated vms
	sum_unaloc_vm += unaloc_vm;
	if (unaloc_vm > max_unaloc_vm)
		max_unaloc_vm = unaloc_vm;
	if (unaloc_vm < min_unaloc_vm)
		min_unaloc_vm = unaloc_vm;
	// number of active pms	
	sum_ac_pm += ac_pm;
	if (ac_pm > max_ac_pm)
		max_ac_pm = ac_pm;
	if (ac_pm < min_ac_pm)
		min_ac_pm = ac_pm;
	// total CPU utilization ratio	
	tot_cu += sum_cu/ac_pm;
	if (sum_cu/ac_pm > max_cu)
		max_cu = sum_cu/ac_pm;
	if (sum_cu/ac_pm < min_cu)
		min_cu = sum_cu/ac_pm;
	// total ram utilization ratio	
	tot_ru += sum_ru/ac_pm;
	if (sum_ru/ac_pm > max_ru)
		max_ru = sum_ru/ac_pm;
	if (sum_ru/ac_pm < min_ru)
		min_ru = sum_ru/ac_pm;
	// resource wastage
	tot_rw += rw;
	if (rw > max_rw)
		max_rw = rw;
	if (rw < min_rw)
		min_rw = rw;
	// power consumption 
	tot_pc += pc;
	if (pc > max_pc)
		max_pc = pc;
	if (pc < min_pc)
		min_pc = pc;
//	printf("----------------------------------------\n");
//	getch();
	}
	printf("Final:\n");
	printf("The number of unallocated VMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_unaloc_vm-(float)sum_unaloc_vm/nrun, (float)sum_unaloc_vm/nrun-min_unaloc_vm, (float)sum_unaloc_vm/nrun);
	printf("The number of active PMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ac_pm-(float)sum_ac_pm/nrun, (float)sum_ac_pm/nrun-min_ac_pm, (float)sum_ac_pm/nrun); 
	printf("The mean CPU utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_cu, min_cu, tot_cu/nrun);	
	printf("The mean RAM utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ru, min_ru, tot_ru/nrun);
	printf("The total Resource Wastage: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_rw-tot_rw/nrun, tot_rw/nrun-min_rw, tot_rw/nrun);
	printf("The total Power Consumption: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_pc-tot_pc/nrun, tot_pc/nrun-min_pc, tot_pc/nrun);
}	

//////////////////////////// BFD ////////////////////////////////
void BFD(struct machine pm[],struct machine vm[],int npm,int nvm)
{
	int max_unaloc_vm=0, min_unaloc_vm=10000, sum_unaloc_vm=0; // number of unallocated vms
	int max_ac_pm=0, min_ac_pm=10000, sum_ac_pm=0;  //number of active pms
	float max_cu=0.0, min_cu=1.0, tot_cu=0.0;  //total cpu utilization
	float max_ru=0.0, min_ru=1.0, tot_ru=0.0;  //total ram utilization
	float max_rw=0.0, min_rw=1000.0, tot_rw=0.0;  //total rw
	float max_pc=0.0, min_pc=1000000.0, tot_pc=0.0;  //total pc
	for (r=1; r<=nrun; r++) {
//	printf("Run=%d\n",r);
	int i, j, idle=0, unaloc_vm=0, ac_pm=0;
	float sum_cu=0, sum_ru=0, rw=0, pc=0, ave, var=0;
	struct machine pm_org[npm], pm_copy[npm], vm_copy[nvm];
	machines(npm, nvm);
	for (i=0; i<npm; i++) 
		pm_org[i] = pm_copy[i]= pm[i];
	for (i=0; i<nvm; i++) 
		vm_copy[i] = vm[i];
	gettimeofday(&start, NULL);
	vm_decreasing_order(vm_copy, nvm);
//	printf("\npm_org:\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
//	printf("\nvm_copy:\n");
//	for (i=0; i<nvm; i++)
//		printf("[%d,%d,%d]\n", vm_copy[i].id, vm_copy[i].c, vm_copy[i].r);
//	printf("\n");		
	int min = 100000, rem, index;
	for (i=0; i<nvm; i++) {
		min = 100000;
		for (j=0; j<npm; j++) 
			if (vm_copy[i].c <= pm_org[j].c && vm_copy[i].r <= pm_org[j].r) {
				rem = pm_org[j].c - vm_copy[i].c;
//				printf("i=%d , j=%d rem=%d\n",i,j,rem);
//				getch();
				if (rem <min) {
					index = j;
					min = rem;
				}
			}
		pm_org[index].c -= vm_copy[i].c;
		pm_org[index].r -= vm_copy[i].r;
		vm_copy[i].c = 0;
//		printf("vm[%d] --> pm[%d]\n", vm_copy[i].id, pm_org[index].id);
//		printf("pm[%d,%d,%d]\n", pm_org[index].id, pm_org[index].c, pm_org[index].r);
	}
	gettimeofday(&end, NULL);
    printf("\nElapsed time: %ld microsecons\n", (end.tv_usec - start.tv_usec));
//    getch();
//	printf("\npm_org --> final pm list :\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
	for (i=0; i<npm; i++) {
		pm_org[i].cu = (float)(pm_copy[i].c-pm_org[i].c)/pm_copy[i].c;
		pm_org[i].ru = (float)(pm_copy[i].r-pm_org[i].r)/pm_copy[i].r;
		if (pm_org[i].c == pm_copy[i].c)
			idle++;
		else
			rw += (fabs(pm_org[i].cu-pm_org[i].ru)+0.0001)/(pm_org[i].cu+pm_org[i].ru);
//		printf("pm_org[%d].cu=%.2f\n",pm_org[i].id, pm_org[i].cu);
//		printf("pm_org[%d].ru=%.2f\n",pm_org[i].id, pm_org[i].ru);
	}
	for (i=0; i<npm; i++)
		if (pm_org[i].cu>0) {
			sum_cu += pm_org[i].cu;
			sum_ru += pm_org[i].ru;
			pc += (pm_org[i].p_min+(pm_org[i].p_max-pm_org[i].p_min)*pm_org[i].cu);
			ave = (pm_org[i].cu + pm_org[i].ru)/2;
			var += 0.5*((pm_org[i].cu - ave,2)+pow(pm_org[i].ru - ave,2));
		}
	for (i=0; i<nvm; i++) 
		if (vm_copy[i].c != 0)
			unaloc_vm++;
	ac_pm = npm - idle;
//	printf("The number of unallocated VMs: %d\n",unaloc_vm);
//	printf("The number of active PMs: %d\n",ac_pm);
//	printf("The mean CPU utilization ratio: %.2f\n",sum_cu/(npm-idle));		
//	printf("The mean RAM utilization ratio: %.2f\n",sum_ru/(npm-idle));	
//	printf("The resource wastage: %.2f\n",rw);	
////	printf("The total variance: %.2f\n",var);
//	printf("The power consumption: %.2f W\n",pc);
	
	// number of unallocated vms
	sum_unaloc_vm += unaloc_vm;
	if (unaloc_vm > max_unaloc_vm)
		max_unaloc_vm = unaloc_vm;
	if (unaloc_vm < min_unaloc_vm)
		min_unaloc_vm = unaloc_vm;
	// number of active pms	
	sum_ac_pm += ac_pm;
	if (ac_pm > max_ac_pm)
		max_ac_pm = ac_pm;
	if (ac_pm < min_ac_pm)
		min_ac_pm = ac_pm;
	// total CPU utilization ratio	
	tot_cu += sum_cu/ac_pm;
	if (sum_cu/ac_pm > max_cu)
		max_cu = sum_cu/ac_pm;
	if (sum_cu/ac_pm < min_cu)
		min_cu = sum_cu/ac_pm;
	// total ram utilization ratio	
	tot_ru += sum_ru/ac_pm;
	if (sum_ru/ac_pm > max_ru)
		max_ru = sum_ru/ac_pm;
	if (sum_ru/ac_pm < min_ru)
		min_ru = sum_ru/ac_pm;
	// resource wastage
	tot_rw += rw;
	if (rw > max_rw)
		max_rw = rw;
	if (rw < min_rw)
		min_rw = rw;
	// power consumption 
	tot_pc += pc;
	if (pc > max_pc)
		max_pc = pc;
	if (pc < min_pc)
		min_pc = pc;
//	printf("----------------------------------------\n");
//	getch();
	}
	printf("Final:\n");
	printf("The number of unallocated VMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_unaloc_vm-(float)sum_unaloc_vm/nrun, (float)sum_unaloc_vm/nrun-min_unaloc_vm, (float)sum_unaloc_vm/nrun);
	printf("The number of active PMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ac_pm-(float)sum_ac_pm/nrun, (float)sum_ac_pm/nrun-min_ac_pm, (float)sum_ac_pm/nrun); 
	printf("The mean CPU utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_cu, min_cu, tot_cu/nrun);	
	printf("The mean RAM utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ru, min_ru, tot_ru/nrun);
	printf("The total Resource Wastage: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_rw-tot_rw/nrun, tot_rw/nrun-min_rw, tot_rw/nrun);
	printf("The total Power Consumption: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_pc-tot_pc/nrun, tot_pc/nrun-min_pc, tot_pc/nrun);
}

//////////////////////////// MBFD ////////////////////////////
void MBFD(struct machine pm[],struct machine vm[],int npm,int nvm)
{
	int max_unaloc_vm=0, min_unaloc_vm=10000, sum_unaloc_vm=0; // number of unallocated vms
	int max_ac_pm=0, min_ac_pm=10000, sum_ac_pm=0;  //number of active pms
	float max_cu=0.0, min_cu=1.0, tot_cu=0.0;  //total cpu utilization
	float max_ru=0.0, min_ru=1.0, tot_ru=0.0;  //total ram utilization
	float max_rw=0.0, min_rw=1000.0, tot_rw=0.0;  //total rw
	float max_pc=0.0, min_pc=1000000.0, tot_pc=0.0;  //total pc
	for (r=1; r<=nrun; r++) {
//	printf("Run=%d\n",r);
	int i, j, idle=0, index, unaloc_vm=0, ac_pm=0;
	float sum_cu=0, sum_ru=0, rw=0, pc=0, ave, var=0;
	struct machine pm_org[npm], pm_copy[npm], vm_copy[nvm];
	machines(npm, nvm);
	for (i=0; i<npm; i++) 
		pm_org[i] = pm_copy[i] = pm[i];
	for (i=0; i<nvm; i++) 
		vm_copy[i] = vm[i];
	gettimeofday(&start, NULL);
	vm_decreasing_order(vm_copy, nvm);
//	printf("\nPM_List:\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
//	printf("\nVM_List:\n");
//	for (i=0; i<nvm; i++)
//		printf("[%d,%d,%d]\n", vm_copy[i].id, vm_copy[i].c, vm_copy[i].r);
//	printf("\n");	
	float minp_inc,p_inc, old_cu, new_cu; // min power increase 	
	for (i=0; i<nvm; i++) {
		minp_inc=1000;
		for (j=0; j<npm; j++) {
			if (vm_copy[i].c <= pm_org[j].c && vm_copy[i].r <= pm_org[j].r) {
				old_cu = (pm_copy[j].c - pm_org[j].c)/(float)pm_copy[j].c;
				new_cu = (pm_copy[j].c - pm_org[j].c + vm_copy[i].c)/(float)pm_copy[j].c;
				if (old_cu==0)
					p_inc = pm_org[j].p_min + (pm_org[j].p_max - pm_org[j].p_min)*new_cu;
				else
					p_inc = (new_cu - old_cu)*(pm_org[j].p_max - pm_org[j].p_min);  
			}
			if (vm_copy[i].c <= pm_org[j].c && vm_copy[i].r <= pm_org[j].r && p_inc < minp_inc)	{
				minp_inc = p_inc;
				index = j;
			}
		}
		pm_org[index].c -= vm_copy[i].c;
		pm_org[index].r -= vm_copy[i].r;				
		vm_copy[i].c = 0;
//		vm_copy[i].loc = index;
//		printf("vm[%d] --> pm[%d]\n",vm_copy[i].id,pm_org[index].id);
//		getch();
	}
	gettimeofday(&end, NULL);
    printf("\nElapsed time: %ld microsecons\n", (end.tv_usec - start.tv_usec));
//    getch();
//	printf("\npm_org --> final pm list :\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
	for (i=0; i<npm; i++) {
		pm_org[i].cu = (float)(pm_copy[i].c-pm_org[i].c)/pm_copy[i].c;
		pm_org[i].ru = (float)(pm_copy[i].r-pm_org[i].r)/pm_copy[i].r;
		if (pm_org[i].c == pm_copy[i].c)
			idle++;
		else
			rw += (fabs(pm_org[i].cu-pm_org[i].ru)+0.0001)/(pm_org[i].cu+pm_org[i].ru);
//		printf("pm_org[%d].cu=%.2f\n",pm_org[i].id, pm_org[i].cu);
//		printf("pm_org[%d].ru=%.2f\n",pm_org[i].id, pm_org[i].ru);
	}
	for (i=0; i<npm; i++)
		if (pm_org[i].cu>0) {
			sum_cu += pm_org[i].cu;
			sum_ru += pm_org[i].ru;
			pc += (pm_org[i].p_min+(pm_org[i].p_max-pm_org[i].p_min)*pm_org[i].cu);	
			ave = (pm_org[i].cu + pm_org[i].ru)/2;
			var += 0.5*((pm_org[i].cu - ave,2)+pow(pm_org[i].ru - ave,2));
		}
	for (i=0; i<nvm; i++) 
		if (vm_copy[i].c != 0)
			unaloc_vm++;
	ac_pm = npm - idle;
//	printf("The number of unallocated VMs: %d\n",unaloc_vm);
//	printf("The number of active PMs: %d\n",ac_pm);
//	printf("The mean CPU utilization ratio: %.2f\n",sum_cu/(npm-idle));		
//	printf("The mean RAM utilization ratio: %.2f\n",sum_ru/(npm-idle));	
//	printf("The resource wastage: %.2f\n",rw);
////	printf("The total variance: %.2f\n",var);
//	printf("The power consumption: %.2f W\n",pc);
	
	// number of unallocated vms
	sum_unaloc_vm += unaloc_vm;
	if (unaloc_vm > max_unaloc_vm)
		max_unaloc_vm = unaloc_vm;
	if (unaloc_vm < min_unaloc_vm)
		min_unaloc_vm = unaloc_vm;
	// number of active pms	
	sum_ac_pm += ac_pm;
	if (ac_pm > max_ac_pm)
		max_ac_pm = ac_pm;
	if (ac_pm < min_ac_pm)
		min_ac_pm = ac_pm;
	// total CPU utilization ratio	
	tot_cu += sum_cu/ac_pm;
	if (sum_cu/ac_pm > max_cu)
		max_cu = sum_cu/ac_pm;
	if (sum_cu/ac_pm < min_cu)
		min_cu = sum_cu/ac_pm;
	// total ram utilization ratio	
	tot_ru += sum_ru/ac_pm;
	if (sum_ru/ac_pm > max_ru)
		max_ru = sum_ru/ac_pm;
	if (sum_ru/ac_pm < min_ru)
		min_ru = sum_ru/ac_pm;
	// resource wastage
	tot_rw += rw;
	if (rw > max_rw)
		max_rw = rw;
	if (rw < min_rw)
		min_rw = rw;
	// power consumption 
	tot_pc += pc;
	if (pc > max_pc)
		max_pc = pc;
	if (pc < min_pc)
		min_pc = pc;
//	printf("----------------------------------------\n");
//	getch();
	}
	printf("Final:\n");
	printf("The number of unallocated VMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_unaloc_vm-(float)sum_unaloc_vm/nrun, (float)sum_unaloc_vm/nrun-min_unaloc_vm, (float)sum_unaloc_vm/nrun);
	printf("The number of active PMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ac_pm-(float)sum_ac_pm/nrun, (float)sum_ac_pm/nrun-min_ac_pm, (float)sum_ac_pm/nrun); 
	printf("The mean CPU utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_cu, min_cu, tot_cu/nrun);	
	printf("The mean RAM utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ru, min_ru, tot_ru/nrun);
	printf("The total Resource Wastage: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_rw-tot_rw/nrun, tot_rw/nrun-min_rw, tot_rw/nrun);
	printf("The total Power Consumption: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_pc-tot_pc/nrun, tot_pc/nrun-min_pc, tot_pc/nrun);
}

/////////////////////////  MaxMin  ////////////////////////////////
void MaxMin(struct machine pm[],struct machine vm[],int npm,int nvm)
{
	int max_unaloc_vm=0, min_unaloc_vm=10000, sum_unaloc_vm=0; // number of unallocated vms
	int max_ac_pm=0, min_ac_pm=10000, sum_ac_pm=0;  //number of active pms
	float max_cu=0.0, min_cu=1.0, tot_cu=0.0;  //total cpu utilization
	float max_ru=0.0, min_ru=1.0, tot_ru=0.0;  //total ram utilization
	float max_rw=0.0, min_rw=1000.0, tot_rw=0.0;  //total rw
	float max_pc=0.0, min_pc=1000000.0, tot_pc=0.0;  //total pc
	for (r=1; r<=nrun; r++) {
//	printf("Run=%d\n",r);
	int i, j, k, l=0, h=nvm-1, idle=0, unaloc_vm=0, ac_pm=0;
	float sum_cu=0, sum_ru=0, rw=0, pc=0, ave, var=0;
	struct machine pm_org[npm], vm_copy[nvm];
	machines(npm, nvm);
	for (i=0; i<npm; i++) 
		pm_org[i] = pm[i];
	for (i=0; i<nvm; i++) 
		vm_copy[i] = vm[i];
	gettimeofday(&start, NULL);
	vm_decreasing_order(vm_copy, nvm);
//	printf("\npm_list\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
//	printf("\nvm_list\n");
//	for (i=0; i<nvm; i++)
//		printf("[%d,%d,%d]\n", vm_copy[i].id, vm_copy[i].c, vm_copy[i].r);
//	printf("\n");	
	while (1) {
		for (i=0; i<npm; i++) {
//			printf("---------------------------\n");
//			printf("pm[%d,%d,%d] is ready!\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
			for (j=l; j<=h; j++) {
//				printf("Loop 1\n");
//				printf("j=%d\n",j);
				if (vm_copy[j].c <= pm_org[i].c && vm_copy[j].r <= pm_org[i].r)	{
					pm_org[i].c -= vm_copy[j].c;
					pm_org[i].r -= vm_copy[j].r;
					vm_copy[j].c = 0;
					l++;
//					printf("vm[%d] --> pm[%d]\n", vm_copy[j].id, pm_org[i].id);
//					printf("pm[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
//					printf("l=%d\n",l);
//					printf("-------------------------\n");
//					getch();
				}
				else 
					break;	
			}
			for (k=h; k>l; k--) {
//				printf("Loop 2\n");
//				printf("k=%d\n",k);
				if (vm_copy[k].c <= pm_org[i].c && vm_copy[k].r <= pm_org[i].r)	{
					pm_org[i].c -= vm_copy[k].c;
					pm_org[i].r -= vm_copy[k].r;
					vm_copy[k].c = 0;
					h--;
//					printf("vm[%d] --> pm[%d]\n", vm_copy[k].id, pm_org[i].id);
//					printf("pm[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
//					printf("h=%d\n",h);
//					printf("-------------------------\n");
//					getch();
				}
				else 
					break;
			}
			if (l>h)
				break;	
		}
		if (l>h)
			break;	
	}
	gettimeofday(&end, NULL);
    printf("\nElapsed time: %ld microsecons\n", (end.tv_usec - start.tv_usec));
//    getch();
//	printf("\nFinal PM list :\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
	for (i=0; i<npm; i++) {
		pm_org[i].cu = (float)(pm[i].c-pm_org[i].c)/pm[i].c;
		pm_org[i].ru = (float)(pm[i].r-pm_org[i].r)/pm[i].r;
		if (pm_org[i].c == pm[i].c)
			idle++;
		else
			rw += (fabs(pm_org[i].cu-pm_org[i].ru)+0.0001)/(pm_org[i].cu+pm_org[i].ru);
//		printf("pm_org[%d].cu=%.2f\n",pm_org[i].id, pm_org[i].cu);
//		printf("pm_org[%d].ru=%.2f\n",pm_org[i].id, pm_org[i].ru);
	}
	for (i=0; i<npm; i++)
		if (pm_org[i].cu > 0) {
			sum_cu += pm_org[i].cu;
			sum_ru += pm_org[i].ru;
			pc += (pm_org[i].p_min+(pm_org[i].p_max-pm_org[i].p_min)*pm_org[i].cu);
			ave = (pm_org[i].cu + pm_org[i].ru)/2;
			var += 0.5*((pm_org[i].cu - ave,2)+pow(pm_org[i].ru - ave,2));
		}
	for (i=0; i<nvm; i++) 
		if (vm_copy[i].c != 0)
			unaloc_vm++;
	ac_pm = npm - idle;
//	printf("The number of unallocated VMs: %d\n",unaloc_vm);
//	printf("The number of active PMs: %d\n",ac_pm);
//	printf("The mean CPU utilization ratio: %.2f\n",sum_cu/(npm-idle));		
//	printf("The mean RAM utilization ratio: %.2f\n",sum_ru/(npm-idle));	
//	printf("The resource wastage: %.2f\n",rw);
////	printf("The total variance: %.2f\n",var);
//	printf("The power consumption: %.2f W\n",pc);

	// number of unallocated vms
	sum_unaloc_vm += unaloc_vm;
	if (unaloc_vm > max_unaloc_vm)
		max_unaloc_vm = unaloc_vm;
	if (unaloc_vm < min_unaloc_vm)
		min_unaloc_vm = unaloc_vm;
	// number of active pms	
	sum_ac_pm += ac_pm;
	if (ac_pm > max_ac_pm)
		max_ac_pm = ac_pm;
	if (ac_pm < min_ac_pm)
		min_ac_pm = ac_pm;
	// total CPU utilization ratio	
	tot_cu += sum_cu/ac_pm;
	if (sum_cu/ac_pm > max_cu)
		max_cu = sum_cu/ac_pm;
	if (sum_cu/ac_pm < min_cu)
		min_cu = sum_cu/ac_pm;
	// total ram utilization ratio	
	tot_ru += sum_ru/ac_pm;
	if (sum_ru/ac_pm > max_ru)
		max_ru = sum_ru/ac_pm;
	if (sum_ru/ac_pm < min_ru)
		min_ru = sum_ru/ac_pm;
	// resource wastage
	tot_rw += rw;
	if (rw > max_rw)
		max_rw = rw;
	if (rw < min_rw)
		min_rw = rw;
	// power consumption 
	tot_pc += pc;
	if (pc > max_pc)
		max_pc = pc;
	if (pc < min_pc)
		min_pc = pc;
//	printf("----------------------------------------\n");
//	getch();
	}
	printf("Final:\n");
	printf("The number of unallocated VMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_unaloc_vm-(float)sum_unaloc_vm/nrun, (float)sum_unaloc_vm/nrun-min_unaloc_vm, (float)sum_unaloc_vm/nrun);
	printf("The number of active PMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ac_pm-(float)sum_ac_pm/nrun, (float)sum_ac_pm/nrun-min_ac_pm, (float)sum_ac_pm/nrun); 
	printf("The mean CPU utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_cu, min_cu, tot_cu/nrun);	
	printf("The mean RAM utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ru, min_ru, tot_ru/nrun);
	printf("The total Resource Wastage: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_rw-tot_rw/nrun, tot_rw/nrun-min_rw, tot_rw/nrun);
	printf("The total Power Consumption: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_pc-tot_pc/nrun, tot_pc/nrun-min_pc, tot_pc/nrun);
}	

/////////////////////////  Random  ////////////////////////////////
void Random(struct machine pm[],struct machine vm[],int npm,int nvm)
{
	int max_unaloc_vm=0, min_unaloc_vm=10000, sum_unaloc_vm=0; // number of unallocated vms
	int max_ac_pm=0, min_ac_pm=10000, sum_ac_pm=0;  //number of active pms
	float max_cu=0.0, min_cu=1.0, tot_cu=0.0;  //total cpu utilization
	float max_ru=0.0, min_ru=1.0, tot_ru=0.0;  //total ram utilization
	float max_rw=0.0, min_rw=1000.0, tot_rw=0.0;  //total rw
	float max_pc=0.0, min_pc=1000000.0, tot_pc=0.0;  //total pc
	for (r=1; r<=nrun; r++) {
//	printf("Run=%d\n",r);
	int N=1;  // The number of Choices
	int i, j, idle=0, unaloc_vm=0, nvm1=nvm, x, flag, ac_pm=0;
	float sum_cu=0, sum_ru=0, rw=0, pc=0, ave, var=0, y;
	struct machine pm_org[npm], pm_copy[npm], vm_copy[nvm], vm1[nvm];
	machines(npm, nvm);
	for (i=0; i<npm; i++) 
		pm_org[i] = pm[i];
//	pm_decreasing_order_powerEfficiency(pm_org, npm);  //sorting PMs by their power effciency in decreasing order
	for (i=0; i<npm; i++) 
		pm_copy[i] = pm_org[i];
	for (i=0; i<nvm; i++) 
		vm_copy[i] = vm[i];
//	printf("\nPM List:\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
//	printf("\nVM List:\n");
//	for (i=0; i<nvm; i++)
//		printf("[%d,%d,%d]\n", vm_copy[i].id, vm_copy[i].c, vm_copy[i].r);
//	printf("\n");	
//	printf("Enter the number of choices: ");
//	scanf("%d",&N);
	float a[N][4], av, thr=0;
//	printf("Enter thr: ");
//	scanf("%f",&thr);
	gettimeofday(&start, NULL);
	while (nvm1>0) {
//		printf("\n------------------------------");
//		printf("\nThe number of remaining VMs = %d\n",nvm1);
			x=rand()%nvm1;
//			printf("x=%d , i=%d\n",(int)x,i);
			a[0][0]=x;
			a[0][1]=0; //cu
			a[0][2]=0; //ru
//			printf("i=%d , Generated number: %d\n",i, (int)a[i][0]);
//		getch();
		for (j=0; j<npm; j++) {
//			printf("\npm[%d, %d, %d] is ready!\n",pm_org[j].id,pm_org[j].c,pm_org[j].r); //min(N,nvm1)
				x = (int)a[0][0];
//				printf("VM#%d = %d %d\n",x , vm_copy[x].c, vm_copy[x].r);
				if (vm_copy[x].c <= pm_org[j].c && vm_copy[x].r <= pm_org[j].r) {
					a[0][1] = (float)(pm_copy[j].c-pm_org[j].c+vm_copy[x].c)/pm_copy[j].c;
					a[0][2] = (float)(pm_copy[j].r-pm_org[j].r+vm_copy[x].r)/pm_copy[j].r;
					break;
//					printf("a[%d][1]=%g , a[%d][2]=%g\n",i,a[i][1],i,a[i][2]);
				}
//				printf("at least one VM is ready!\n\n");
//						 if (fabs(a[i][1]-a[i][2])<thr)
//						if (a[i][1]<thr && a[i][2]<thr)  
//							flag_thr=1;
			}
//					printf("min_var=%g, min_var_index=%d, \n
//					max_ut=%g, max_ut_index=%d, \nflag_thr=%d\n",
//					min_var, min_var_index, max_ut, max_ut_index, flag_thr); //main
//					printf("min_var=%g, min_var_index=%d\n",min_var, min_var_index); //for test
						pm_org[j].c -= vm_copy[j].c;
						pm_org[j].r -= vm_copy[j].r;
						vm1[vm_copy[j].id].c=0;	
//						printf("The index of selected VM=%d\n",index);
//						printf("under threshold\n");
//						printf("vm[%d] --> pm[%d]\n", vm_copy[index].id, pm_org[j].id);
//						printf("pm[%d,%d,%d]\n",pm_org[j].id, pm_org[j].c, pm_org[j].r);
//						getch();
						for (int k=j; k<nvm1-1; k++)
							vm_copy[k]=vm_copy[k+1];
						nvm1--;	
			}
	gettimeofday(&end, NULL);
    printf("\nElapsed time: %ld microsecons\n", (end.tv_usec - start.tv_usec));
//    getch();
//	printf("\nfinal pm list :\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
	for (i=0; i<npm; i++) {
		pm_org[i].cu = (float)(pm_copy[i].c-pm_org[i].c)/pm_copy[i].c;
		pm_org[i].ru = (float)(pm_copy[i].r-pm_org[i].r)/pm_copy[i].r;
		if (pm_org[i].c == pm_copy[i].c)
			idle++;
		else
			rw += (fabs(pm_org[i].cu-pm_org[i].ru)+0.0001)/(pm_org[i].cu+pm_org[i].ru);
//		printf("pm_org[%d].cu=%.2f\n",pm_org[i].id, pm_org[i].cu);
//		printf("pm_org[%d].ru=%.2f\n",pm_org[i].id, pm_org[i].ru);
	}
	
	for (i=0; i<npm; i++)
		if (pm_org[i].cu>0) {
			sum_cu += pm_org[i].cu;
			sum_ru += pm_org[i].ru;
			pc += (pm_org[i].p_min+(pm_org[i].p_max-pm_org[i].p_min)*pm_org[i].cu);
			ave = (pm_org[i].cu+pm_org[i].ru)/2;
			var += 0.5*((pm_org[i].cu - ave,2)+pow(pm_org[i].ru - ave,2));
		}
	for (i=0; i<nvm; i++) 
		if (vm1[i].c != 0)
			unaloc_vm++;
	ac_pm = npm - idle;
//	printf("The number of unallocated VMs: %d\n",unaloc_vm);
//	printf("The number of active PMs: %d\n",ac_pm);
//	printf("The mean CPU utilization ratio: %.2f\n",sum_cu/(npm-idle));		
//	printf("The mean RAM utilization ratio: %.2f\n",sum_ru/(npm-idle));	
//	printf("The resource wastage: %.2f\n",rw);
////	printf("The total variance: %.2f\n",var);
//	printf("The power consumption: %.2f W\n",pc);
		
	// number of unallocated vms
	sum_unaloc_vm += unaloc_vm;
	if (unaloc_vm > max_unaloc_vm)
		max_unaloc_vm = unaloc_vm;
	if (unaloc_vm < min_unaloc_vm)
		min_unaloc_vm = unaloc_vm;
	// number of active pms	
	sum_ac_pm += ac_pm;
	if (ac_pm > max_ac_pm)
		max_ac_pm = ac_pm;
	if (ac_pm < min_ac_pm)
		min_ac_pm = ac_pm;
	// total CPU utilization ratio	
	tot_cu += sum_cu/ac_pm;
	if (sum_cu/ac_pm > max_cu)
		max_cu = sum_cu/ac_pm;
	if (sum_cu/ac_pm < min_cu)
		min_cu = sum_cu/ac_pm;
	// total ram utilization ratio	
	tot_ru += sum_ru/ac_pm;
	if (sum_ru/ac_pm > max_ru)
		max_ru = sum_ru/ac_pm;
	if (sum_ru/ac_pm < min_ru)
		min_ru = sum_ru/ac_pm;
	// resource wastage
	tot_rw += rw;
	if (rw > max_rw)
		max_rw = rw;
	if (rw < min_rw)
		min_rw = rw;
	// power consumption 
	tot_pc += pc;
	if (pc > max_pc)
		max_pc = pc;
	if (pc < min_pc)
		min_pc = pc;
//	printf("----------------------------------------\n");
//	getch();
	}
	printf("Final:\n");
	printf("The number of unallocated VMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_unaloc_vm-(float)sum_unaloc_vm/nrun, (float)sum_unaloc_vm/nrun-min_unaloc_vm, (float)sum_unaloc_vm/nrun);
	printf("The number of active PMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ac_pm-(float)sum_ac_pm/nrun, (float)sum_ac_pm/nrun-min_ac_pm, (float)sum_ac_pm/nrun); 
	printf("The mean CPU utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_cu, min_cu, tot_cu/nrun);	
	printf("The mean RAM utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ru, min_ru, tot_ru/nrun);
	printf("The total Resource Wastage: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_rw-tot_rw/nrun, tot_rw/nrun-min_rw, tot_rw/nrun);
	printf("The total Power Consumption: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_pc-tot_pc/nrun, tot_pc/nrun-min_pc, tot_pc/nrun);

}	


/////////////////////////  GRVMP_d  ////////////////////////////////
void GRVMP_d(struct machine pm[],struct machine vm[],int npm,int nvm)
{
	int N=4;  // The number of Choices
//	for (int N=1; N<=64; N*=2) {
	int max_unaloc_vm=0, min_unaloc_vm=10000, sum_unaloc_vm=0; // number of unallocated vms
	int max_ac_pm=0, min_ac_pm=10000, sum_ac_pm=0;  //number of active pms
	float max_cu=0.0, min_cu=1.0, tot_cu=0.0;  //total cpu utilization
	float max_ru=0.0, min_ru=1.0, tot_ru=0.0;  //total ram utilization
	float max_rw=0.0, min_rw=1000.0, tot_rw=0.0;  //total rw
	float max_pc=0.0, min_pc=1000000.0, tot_pc=0.0;  //total pc
	printf("N=%d, Run=%d\n",N, nrun);
	for (r=1; r<=nrun; r++) {
//	printf("N=%d, Run=%d\n",N, r);
	int i, j, idle=0, unaloc_vm=0, nvm1=nvm, x, flag, ac_pm=0;
	float sum_cu=0, sum_ru=0, rw=0, pc=0, ave, var=0, y;
	struct machine pm_org[npm], pm_copy[npm], vm_copy[nvm], vm1[nvm];
	machines(npm, nvm);
	for (i=0; i<npm; i++) 
		pm_org[i] = pm[i];
	gettimeofday(&start, NULL);
	pm_decreasing_order_powerEfficiency(pm_org, npm);  //sorting PMs by their power effciency in decreasing order
	for (i=0; i<npm; i++) 
		pm_copy[i] = pm_org[i];
	for (i=0; i<nvm; i++) 
		vm_copy[i] = vm[i];
//	printf("\nPM List:\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
//	printf("\nVM List:\n");
//	for (i=0; i<nvm; i++)
//		printf("[%d,%d,%d]\n", vm_copy[i].id, vm_copy[i].c, vm_copy[i].r);
//	printf("\n");	
//	printf("Enter the number of choices: ");
//	scanf("%d",&N);
	float a[N][4], av, thr=0.0;
//	printf("Enter thr: ");
//	scanf("%f",&thr);
	gettimeofday(&end, NULL);
	while (nvm1>0) {
		a[0][0]= -1;
//		printf("\n------------------------------");
//		printf("\nThe number of remaining VMs = %d\n",nvm1);
		for (i=0; i<(N<nvm1?N:nvm1); i++) {
			flag =1;
			x=rand()%nvm1;
//			printf("x=%d , i=%d\n",(int)x,i);
			for(j=0; j<i; j++)
				if (x==a[j][0]) {
					i--;
					flag =0;
					break;
				}
			if (flag==0)
				continue;
			a[i][0]=x;
			a[i][1]=0; //cu
			a[i][2]=0; //ru
//			printf("i=%d , Generated number: %d\n",i, (int)a[i][0]);
		}
		gettimeofday(&start1, NULL);
//		getch();
		for (j=0; j<npm; j++) {
//			printf("\npm[%d, %d, %d] is ready!\n",pm_org[j].id,pm_org[j].c,pm_org[j].r);
			for (i=0; i<(N<nvm1?N:nvm1); i++) {  //min(N,nvm1)
				x = (int)a[i][0];
//				printf("VM#%d = %d %d\n",x , vm_copy[x].c, vm_copy[x].r);
				if (vm_copy[x].c <= pm_org[j].c && vm_copy[x].r <= pm_org[j].r) {
					a[i][1] = (float)(pm_copy[j].c-pm_org[j].c+vm_copy[x].c)/pm_copy[j].c;
					a[i][2] = (float)(pm_copy[j].r-pm_org[j].r+vm_copy[x].r)/pm_copy[j].r;
//					printf("a[%d][1]=%g , a[%d][2]=%g\n",i,a[i][1],i,a[i][2]);
				}
			}
			flag = 0;
			for (i=0; i<(N<nvm1?N:nvm1); i++)
				if (a[i][1]!=0) {
					flag = 1;
					break;
				}	
			if (flag==0)
				continue;
			else {
//				printf("at least one VM is ready!\n\n");
				float min_rw=1000, max_ut=0;
				int min_rw_index,max_ut_index;
				for (i=0; i<(N<nvm1?N:nvm1); i++)
					if (a[i][1]!=0) {
						a[i][3] = (fabs(a[i][1]-a[i][2])+0.0001)/(a[i][1]+a[i][2]);	
						if (a[i][3]<min_rw) {
							min_rw=a[i][3];
							min_rw_index=i;
						}
						if (a[i][1]<thr && a[i][2]<thr && a[i][1]*a[i][2] > max_ut) {
							max_ut=a[i][1]*a[i][2];
							max_ut_index=i;
						}
//						 if (fabs(a[i][1]-a[i][2])<thr)
//						if (a[i][1]<thr && a[i][2]<thr)  
//							flag_thr=1;
					}
//					printf("min_var=%g, min_var_index=%d, \n
//					max_ut=%g, max_ut_index=%d, \nflag_thr=%d\n",
//					min_var, min_var_index, max_ut, max_ut_index, flag_thr); //main
//					printf("min_var=%g, min_var_index=%d\n",min_var, min_var_index); //for test
					if(max_ut > 0) {
						int index=a[max_ut_index][0];
						pm_org[j].c -= vm_copy[index].c;
						pm_org[j].r -= vm_copy[index].r;
						vm1[vm_copy[index].id].c=0;	
//						printf("The index of selected VM=%d\n",index);
//						printf("under threshold\n");
//						printf("vm[%d] --> pm[%d]\n", vm_copy[index].id, pm_org[j].id);
//						printf("pm[%d,%d,%d]\n",pm_org[j].id, pm_org[j].c, pm_org[j].r);
//						getch();
						for (int k=index; k<nvm1-1; k++)
							vm_copy[k]=vm_copy[k+1];
						nvm1--;
					}
					else {
						int index = a[min_rw_index][0];
						pm_org[j].c -= vm_copy[index].c;
						pm_org[j].r -= vm_copy[index].r;
						vm1[vm_copy[index].id].c=0;	
//						printf("The index of selected VM=%d\n",index);
//						printf("Resource wastage = %f\n", min_rw);
//						printf("vm[%d] --> pm[%d]\n", vm_copy[index].id, pm_org[j].id);
//						printf("pm[%d,%d,%d]\n",pm_org[j].id, pm_org[j].c, pm_org[j].r);
//						printf("--------------------------------\n");
//						getch();
						for (int k=index; k<nvm1-1; k++)
							vm_copy[k]=vm_copy[k+1];
						nvm1--;
					}
				break;		
			}
		}
	}
	gettimeofday(&end1, NULL);
    printf("\nElapsed time: %ld microsecons\n", (end.tv_usec - start.tv_usec)+(end1.tv_usec - start1.tv_usec));
    printf("\nElapsed time: %ld microsecons (total)\n", (end1.tv_usec - start.tv_usec));
//    getch();
//	printf("\nfinal pm list :\n");
//	for (i=0; i<npm; i++)
//		printf("[%d,%d,%d]\n", pm_org[i].id, pm_org[i].c, pm_org[i].r);
	for (i=0; i<npm; i++) {
		pm_org[i].cu = (float)(pm_copy[i].c-pm_org[i].c)/pm_copy[i].c;
		pm_org[i].ru = (float)(pm_copy[i].r-pm_org[i].r)/pm_copy[i].r;
		if (pm_org[i].c == pm_copy[i].c)
			idle++;
		else
			rw += (fabs(pm_org[i].cu-pm_org[i].ru)+0.0001)/(pm_org[i].cu+pm_org[i].ru);
//		printf("pm_org[%d].cu=%.2f\n",pm_org[i].id, pm_org[i].cu);
//		printf("pm_org[%d].ru=%.2f\n",pm_org[i].id, pm_org[i].ru);
	}
	
	for (i=0; i<npm; i++)
		if (pm_org[i].cu>0) {
			sum_cu += pm_org[i].cu;
			sum_ru += pm_org[i].ru;
			pc += (pm_org[i].p_min+(pm_org[i].p_max-pm_org[i].p_min)*pm_org[i].cu);
			ave = (pm_org[i].cu+pm_org[i].ru)/2;
			var += 0.5*((pm_org[i].cu - ave,2)+pow(pm_org[i].ru - ave,2));
		}
	for (i=0; i<nvm; i++) 
		if (vm1[i].c != 0)
			unaloc_vm++;
	ac_pm = npm - idle;
//	printf("The number of unallocated VMs: %d\n",unaloc_vm);
//	printf("The number of active PMs: %d\n",ac_pm);
//	printf("The mean CPU utilization ratio: %.2f\n",sum_cu/(npm-idle));		
//	printf("The mean RAM utilization ratio: %.2f\n",sum_ru/(npm-idle));	
//	printf("The resource wastage: %.2f\n",rw);
////	printf("The total variance: %.2f\n",var);
//	printf("The power consumption: %.2f W\n",pc);
//	
	// number of unallocated vms
	sum_unaloc_vm += unaloc_vm;
	if (unaloc_vm > max_unaloc_vm)
		max_unaloc_vm = unaloc_vm;
	if (unaloc_vm < min_unaloc_vm)
		min_unaloc_vm = unaloc_vm;
	// number of active pms	
	sum_ac_pm += ac_pm;
	if (ac_pm > max_ac_pm)
		max_ac_pm = ac_pm;
	if (ac_pm < min_ac_pm)
		min_ac_pm = ac_pm;
	// total CPU utilization ratio	
	tot_cu += sum_cu/ac_pm;
	if (sum_cu/ac_pm > max_cu)
		max_cu = sum_cu/ac_pm;
	if (sum_cu/ac_pm < min_cu)
		min_cu = sum_cu/ac_pm;
	// total ram utilization ratio	
	tot_ru += sum_ru/ac_pm;
	if (sum_ru/ac_pm > max_ru)
		max_ru = sum_ru/ac_pm;
	if (sum_ru/ac_pm < min_ru)
		min_ru = sum_ru/ac_pm;
	// resource wastage
	tot_rw += rw;
	if (rw > max_rw)
		max_rw = rw;
	if (rw < min_rw)
		min_rw = rw;
	// power consumption 
	tot_pc += pc;
	if (pc > max_pc)
		max_pc = pc;
	if (pc < min_pc)
		min_pc = pc;
//	printf("----------------------------------------\n");
//	getch();
	}
	printf("Final:\n");
	printf("The number of unallocated VMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_unaloc_vm-(float)sum_unaloc_vm/nrun, (float)sum_unaloc_vm/nrun-min_unaloc_vm, (float)sum_unaloc_vm/nrun);
	printf("The number of active PMs: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ac_pm-(float)sum_ac_pm/nrun, (float)sum_ac_pm/nrun-min_ac_pm, (float)sum_ac_pm/nrun); 
	printf("The mean CPU utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_cu, min_cu, tot_cu/nrun);	
	printf("The mean RAM utilization ratio: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_ru, min_ru, tot_ru/nrun);
	printf("The total Resource Wastage: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_rw-tot_rw/nrun, tot_rw/nrun-min_rw, tot_rw/nrun);
	printf("The total Power Consumption: (max=%.2f , min=%.2f , ave=%.2f)\n\n",max_pc-tot_pc/nrun, tot_pc/nrun-min_pc, tot_pc/nrun);
//	printf("----------------------------------------\n");
//	getch();
//	}
	
}	

//////////////////////////////  Functions  //////////////////////////////
void pm_increasing_order(struct machine pm[], struct machine pm_copy[], int npm)
{
	int i , j;
	struct machine temp;
	for (i=0; i<npm-1; i++)
		pm[i].a = (pm[i].cu + pm[i].ru)/2;
	for (i=0; i<npm-1; i++)
		for (j=i+1; j<npm; j++)
			if (pm[i].b == 1 && pm[j].b ==1 && pm[i].a > pm[j].a)
			{
				temp = 	pm[i];
				pm[i] = pm[j];
				pm[j] = temp;
				
				temp = 	pm_copy[i];
				pm_copy[i] = pm_copy[j];
				pm_copy[j] = temp;
			}
//	printf("inside sorting function\n");	
//	for (i=0; i<npm; i++)
//		printf("pm[%d,%d,%d]\n",pm[i].id, pm[i].c, pm[i].r);
//	printf("\n");
}
void pm_decreasing_order(struct machine pm[], int npm)
{
	int i , j;
	struct machine temp;
	for (i=0; i<npm-1; i++)
		for (j=i+1; j<npm; j++)
			if (pm[i].c < pm[j].c)
			{
				temp = 	pm[i];
				pm[i] = pm[j];
				pm[j] = temp;
			}	
}
void vm_decreasing_order(struct machine vm[], int nvm)
{
	int i , j;
	struct machine temp;
	for (i=0; i<nvm-1; i++)
		for (j=i+1; j<nvm; j++)
			if (vm[i].c < vm[j].c)
			{
				temp = 	vm[i];
				vm[i] = vm[j];
				vm[j] = temp;
			}
}

void vm_decreasing_order_c(struct machine vm[], int nvm)
{
	int i, j;
	struct machine temp;
	for (i=0; i<nvm-1; i++)
		for (j=i+1; j<nvm; j++)
			if (vm[i].c < vm[j].c)
			{
				temp = 	vm[i];
				vm[i] = vm[j];
				vm[j] = temp;
			}
}

void vm_decreasing_order_r(struct machine vm[], int nvm)
{
	int i , j;
	struct machine temp;
	for (i=0; i<nvm-1; i++)
		for (j=i+1; j<nvm; j++)
			if (vm[i].r < vm[j].r)
			{
				temp = 	vm[i];
				vm[i] = vm[j];
				vm[j] = temp;
			}
}

void vm_increasing_order(struct machine vm[], int nvm)
{
	int i , j;
	struct machine temp;
	for (i=0; i<nvm-1; i++)
		for (j=i+1; j<nvm; j++)
			if (vm[i].c > vm[j].c)
			{
				temp = 	vm[i];
				vm[i] = vm[j];
				vm[j] = temp;
			}
}

void vm_decreasing_order_prob_c(struct machine vm[], int nvm)
{
	int i, j;
	struct machine temp;
	for (i=0; i<nvm-1; i++)
		for (j=i+1; j<nvm; j++)
			if (vm[i].l < vm[j].l)
			{
				temp = 	vm[i];
				vm[i] = vm[j];
				vm[j] = temp;
			}
}

void vm_decreasing_order_prob_r(struct machine vm[], int nvm)
{
	int i, j;
	struct machine temp;
	for (i=0; i<nvm-1; i++)
		for (j=i+1; j<nvm; j++)
			if (vm[i].h < vm[j].h)
			{
				temp = 	vm[i];
				vm[i] = vm[j];
				vm[j] = temp;
			}
}

void pm_decreasing_order_c(struct machine pm[], int npm)
{
	int i , j;
	struct machine temp;
	for (i=0; i<npm-1; i++)
		for (j=i+1; j<npm; j++)
			if (pm[i].c < pm[j].c)
			{
				temp = 	pm[i];
				pm[i] = pm[j];
				pm[j] = temp;
			}	
}

void pm_decreasing_order_r(struct machine pm[], int npm)
{
	int i , j;
	struct machine temp;
	for (i=0; i<npm-1; i++)
		for (j=i+1; j<npm; j++)
			if (pm[i].r < pm[j].r || (pm[i].r == pm[j].r && pm[i].c < pm[j].c))	{
				temp = 	pm[i];
				pm[i] = pm[j];
				pm[j] = temp;
			}		
}


void pm_decreasing_order_powerEfficiency(struct machine pm[], int npm)
{
	int i, j;
	struct machine temp;
	for (i=0; i<npm; i++)
		pm[i].pow_eff = pm[i].c / pm[i].p_max;
		
	for (i=0; i<npm-1; i++)
		for (j=i+1; j<npm; j++) 
			if (pm[i].pow_eff < pm[j].pow_eff) {
				temp = 	pm[i];
				pm[i] = pm[j];
				pm[j] = temp;
			}
}

void vm_decreasing_order_prob_rank(struct machine vm[], int nvm)
{
	int i, j;
	struct machine temp;
	for (i=0; i<nvm-1; i++)
		for (j=i+1; j<nvm; j++) {
			if (vm[i].rank > vm[j].rank) {
				temp = 	vm[i];
				vm[i] = vm[j];
				vm[j] = temp;
			}
			if (vm[i].rank == vm[j].rank && (vm[i].c+vm[i].r)<(vm[j].c+vm[j].r)) {
				temp = 	vm[i];
				vm[i] = vm[j];
				vm[j] = temp;
			}
		}
}

void machines(int npm, int nvm) {
	for (i=0; i<npm; i++) {
		pm[i].c = rand()%6001 + 4000; // our dataset
		pm[i].r = rand()%12289 + 4096;
		pm[i].p_max = rand()%201 + 100;
		pm[i].p_min = (rand()%11 + 60)/100.0*pm[i].p_max;

//		pm[i].c = rand()%10001 + 10000; // Expert Systems dataset
//		pm[i].r = rand()%20001 + 20000;
//		pm[i].p_max = rand()%301 + 100;
//		pm[i].p_min = 0.7*pm[i].p_max;//rand()%101 + 400;

//		x = rand()%2;  // RAVMP dataset both synthetic and real world
//		if (x==0) {
//			pm[i].c = 5320; 
//			pm[i].r = 4096;
//			pm[i].p_min = 93.7;
//			pm[i].p_max = 135;
//		}	
//		else if (x==1) {
//			pm[i].c = 3720;
//			pm[i].r = 4096;
//			pm[i].p_min = 86;
//			pm[i].p_max = 117;
//		}
//		else if (x==2){
//			pm[i].c = 10120;
//			pm[i].r = 8000;
//			pm[i].p_min = 192;
//			pm[i].p_max = 320;
//		}
//		else {
//			pm[i].c = 24480;
//			pm[i].r = 16000;
//			pm[i].p_min = 342;
//			pm[i].p_max = 570;
//		}
//		pm[i].b = rand()%8001 + 2000;

//		pm[i].c = 150; //DRR-BinFill all minus HeterExtrCase
//		pm[i].r = 150;

//		pm[i].c = 100; //HeterExtrCase
//		pm[i].r = 100;
	
//	    pm[i].b = rand()%6001 + 2000;
	    
		pm[i].id = i;
//		printf("pm[%d] = %d\t%d\n", pm[i].id, pm[i].c, pm[i].r);
	}
//	printf("\n VMs:\n");
	for (i=0; i<nvm; i++) {	
//		x = rand()%4;  //  Amazon EC2 Instances
//		if (x==0) {
//			vm[i].c = 500;
//			vm[i].r = 613;
//		}	
//		else if (x==1) {
//			vm[i].c = 1000;
//			vm[i].r = 1700;
//		}
//		else if (x==2) {
//			vm[i].c = 2000;
//			vm[i].r = 3750;
//		}
//		else  {
//			vm[i].c = 2500;
//			vm[i].r = 850;
//		}



		x = rand()%4;  //  Dr. Shojafar dataset
		if (x==0)
			vm[i].c = 500;
		else if (x==1)
			vm[i].c = 1000;
		else if (x==2) 
			vm[i].c = 2000;
		else  
			vm[i].c = 4000;
					
		y = rand()%4; 
		if (y==0)
			vm[i].r = 512;
		else if (y==1)
			vm[i].r = 1024;
		else if (y==2) 
			vm[i].r = 2048;
		else  
			vm[i].r = 4096;

//		vm[i].c = rand()%1501 + 500;  //Sadoon dataset
//		vm[i].r = rand()%3585 + 512;

//		vm[i].c = rand()%7001 + 1000;  //Expert Systems dataset
//		vm[i].r = rand()%10001 + 10000;
		
//		vm[i].c = rand()%3001 + 1000; // RAVMP dataset 
//		vm[i].r = rand()%3001 + 1000;
		
//		vm[i].c = rand()% 1801 + 450; // RAVMP dataset with a little change 
//		vm[i].r = rand()% 1601 + 400;
		
//		vm[i].c = rand()% 1500 + 500; // RAVMP dataset with a little change the best
//		vm[i].r = rand()% 1500 + 500;

//		vm[i].c = rand()%3501 + 500;  //IBFD dataset
//		vm[i].r = rand()%3501 + 500;

//		vm[i].c = rand()%81 + 20;  //DRR-BinFill dataset fix for Random, NegCorr, PosCorr
//		vm[i].r = rand()%81 + 20; // Random
//		vm[i].r = vm[i].c + (rand()%21-10);	// NegCorr
//		vm[i].r =(rand()%21+10+100)- vm[i].c;		//PosCorr
	
//		x = rand()%2;  //HeterExtrCase
//		if (x==0) {
//			vm[i].c=20;
//			vm[i].r=1;
//		}
//		else {
//			vm[i].c=3;
//			vm[i].r=20;
//		}
//		
		vm[i].id = i;
//		printf("vm[%d] = %d\t%d\n", vm[i].id, vm[i].c, vm[i].r);
	}
}

