function [credit, rate] = GetInfoCloudSDN(model)

    credit = model.SuccessConnection;
    rate = model.RequestRate;
    
end