function Model = RandomCome(Model)

    a = 1:Model.NIoT;
    b = Model.NIoT:-1:1;
    c = [a;b];
    c = c(:,1:ceil(Model.NIoT/2));
    c = c(:);
    r = c(1:Model.NIoT);
    
    Model.BWR = Model.BWR(r);
    Model.RamR = Model.RamR(r);
    Model.CPUR = Model.CPUR(r);
    
end