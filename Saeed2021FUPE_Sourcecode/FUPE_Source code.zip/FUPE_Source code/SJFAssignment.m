function PositionSJF = SJFAssignment(NumIOTDevice, NumFogDevice)

    PositionSJF = zeros(1, NumIOTDevice);
    k = 0;
    for i=1:NumIOTDevice
        k = k+1;
        PositionSJF(i) = k;
        k = mod(k, NumFogDevice);
    end
end