function Position = GAAssignment(model, rate)

% Cost Function
CostFunction=@(q) MyCost(q, model, rate);      

%% GA Parameters

MaxIt=100;              % Maximum Number of Iterations
nPop=100;                % Population Size

pc=0.8;                 % Crossover Percentage
nc=2*round(pc*nPop/2);   % Number fo Parents (Offsprings)

pm=0.1;                 % Mutation Percentage
nm=round(pm*nPop);       % Number of Mutants

%% Initialization

% Create Empty Structure
empty_individual.Position=[];
empty_individual.Cost=[];

% Create Structre Array to Save Population Data
pop=repmat(empty_individual,nPop,1);

% Initilize Population
for i=1:nPop
    % Create Random Solution (Position)
    Position=CreateRandomSolution(model);
    [Cost]=CostFunction(Position);
    
    pop(i).Position=Position;
    pop(i).Cost=Cost;
    
end

% Sort Population
Costs=[pop.Cost];
[~, SortOrder]=sort(Costs);
pop=pop(SortOrder);

% Store Best Solution Ever Found
BestSol=pop(1); 

% Create Array to Hold Best Cost Values
BestCost=zeros(MaxIt,1);

%% GA Main Loop

for it=1:MaxIt
    it
    % Perform Crossover
    popc=repmat(empty_individual,nc/2,2);
    for k=1:nc/2
        
        % Select First Parent
        i1=randi([1 nPop]);
        p1=pop(i1);
        
        % Select Second Parent
        i2=randi([1 nPop]);
        p2=pop(i2);
        
        % Perform Crossover
        [popc(k,1).Position, popc(k,2).Position]=...
            Crossover(p1.Position,p2.Position);
        
        % Evaluate Offsprings
        popc(k,1).Cost=CostFunction(popc(k,1).Position);
                
        popc(k,2).Cost=CostFunction(popc(k,2).Position);
                      
    end
    popc=popc(:);
    
    % Perform Mutation
    popm=repmat(empty_individual,nm,1);
    for l=1:nm
        
        % Select Parent
        i1=randi([1 nPop]);
        p=pop(i1);
        
        % Perform Mutation
        popm(l).Position=Mutate(p.Position);
        
        popm(l).Cost=CostFunction(popm(l).Position);
              
    end
    
    % Merge Pops
    pop=[pop
         popc
         popm];

    % Sort Population
    Costs=[pop.Cost];
    [Costs, SortOrder]=sort(Costs);
    pop=pop(SortOrder);
    
    % Truncate Extra Individuals
    pop=pop(1:nPop);
    Costs=Costs(1:nPop); %#ok
    
    % Store Best Solution Ever Found
    BestSol=pop(1);
    
    % Store Best Cost
    BestCost(it)=BestSol.Cost;
        
    % Show Iteration Information
    % disp(['Iteration ' num2str(it) ...
    %     ': Best Cost = ' num2str(BestCost(it))]);
      
    % Display Iteration Information
    
    % disp(['Iteration ' num2str(it)  ' Best Cost = ' num2str(BestCost(it)) ]);
    % Plot Solution
    %figure(1);
    %PlotSolution(BestSol.Sol,model);
    %pause(0.01);
    
end
Position = BestSol.Position;
%{
figure;
plot(BestCost,'LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
grid on;
%}
end