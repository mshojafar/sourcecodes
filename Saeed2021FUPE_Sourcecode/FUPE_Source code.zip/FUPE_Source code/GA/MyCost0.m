
function z = MyCost0(Position, Model, Rate)
    
    TrafficDelay = 0.01;
    Delay = zeros(1, Model.NIoT);
    for i=1:Model.NFD
        jobs = find(Position == i);
        CPUC = Model.CPUC(i);
        RamC = Model.RamC(i);
        BWC = Model.BWC(i);
        
        for j=1:length(jobs)
            CPUR = Model.CPUR(jobs(j));
            RamR = Model.RamR(jobs(j));
            if (CPUR<CPUC && RamR<RamC) 
                % Delay = Link Delay + TrafficVolume * Traffic Delay
                Delay(jobs(j)) = CPUR/BWC + Rate(i, 1)*TrafficDelay;
            else
                CPUC = Model.CPUC(i);
                RamC = Model.RamC(i);
                Delay(jobs(j)) = max(Delay(jobs)) + CPUR/BWC + Rate(i, 1)*TrafficDelay;
            end
            CPUC = CPUC-CPUR;
            RamC = RamC-RamR;
        end
    end
    z = sum(Delay);
end