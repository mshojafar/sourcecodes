
function q = CreateRandomSolution(model)

    VM = model.NIoT;
    H = model.NFD;
    q = randi([1 H],1,VM);

end