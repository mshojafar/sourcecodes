clc, clear, close all;
warning off all;
addpath('FIFO')
addpath('FUPE')
addpath('GA')
addpath('PSO')
addpath('SJF')

% Get number of IoT Devices, Fog Device and Attack Rate
prompt = {'Enter IoT Device Numbers:','Enter Fog Device Numbers:', 'Enter Attack Rate(%):'};
title = 'Input';
dims = [1 35];
definput = {'60', '10', '0.3'};
answer = inputdlg(prompt,title,dims,definput);

IOTDevice = str2num(answer{1})             % Number of IoT Device 
FogDevice = str2num(answer{2})             % Number of Fog Device 
AttackRate = str2num(answer{3})            % Attack Rate

FogGateway = 2;                             % Number of Fog Gateway 
CloudSDN = 1;                               % Number of SDN Cloud 

RequestRate = 60;                           % RequestRate per each Minute
RequestRateFactorAttack = 10;               % alpha
NumFogDeviceAttacked = 2;                   % Number of FogDevice Attacked

[Model] = CreateModel(IOTDevice, FogDevice, FogGateway, CloudSDN, ...
	AttackRate, NumFogDeviceAttacked, RequestRate, RequestRateFactorAttack);

[subTasks] = SplitJobs(Model);

[Credit, Rate] = GetInfoCloudSDN(Model);
[CreditIoTD, RateIoTD] = SimulateAttack(IOTDevice, AttackRate, RequestRate, RequestRateFactorAttack);

% Select scheduling method
list = {'FIFO','SJF','PSO','GA','FUPE'};
indx = listdlg('ListString',list,'SelectionMode','single',...
    'ListSize',[350,250],'Name','Select scheduling method',...
    'PromptString','Select a method:');

if (indx==1)
    Model = RandomCome(Model);
    Position = FIFOAssignment(IOTDevice, FogDevice);
elseif(indx==2)
    Position = SJFAssignment(IOTDevice, FogDevice);
elseif(indx==3)
    Position = PSOAssignment(Model, Rate);
elseif(indx==4)
    Position = GAAssignment(Model, Rate);
elseif(indx==5)
    addpath('FUPE\FuzzySystem\Security\');
    addpath('FUPE\FuzzySystem\Utility\');
    addpath('FUPE\MPSO');
    Position = FUPEAssignment(Model, Credit, Rate);
    DestructiveIoTD = BlockFuture(IOTDevice, CreditIoTD, RateIoTD);
end

[ResponseTime, MaxResponseTime, LoadBalance, Delay, MaxDelay, NetU, Utility] =...
        Evaluation(Model, Rate, Position);
    