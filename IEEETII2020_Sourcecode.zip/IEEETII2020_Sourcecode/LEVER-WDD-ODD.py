# #!/usr/bin/env python

# #!/usr/bin/env python
# '''
# This program doing duplication testing. Always change the UChunksize, SH_LEN, and Popularity constant for the simulation.
# '''


import os
import hashlib
from hashlib import md5
import sqlite3
import DB
import uuid
import hmac

import random
import matplotlib.pyplot as plt  # this package is for drawing plots
import numpy as np

import myCrypto
from paillier_gmpy2 import *  # this package is for Paillier encryption

################## Constant parameters
SH_LEN = 16;        # Short hash length (8 and 16)
rand_value = 50;
POPULARITY = 99999999;   # Popularity constant
PROB = 0.3; #p = 0.3, 0.8

Uchunksize1 = 128;  # Chunk size 
Uchunksize2 = 256;
Uchunksize3 = 512;
Uchunksize4 = 1024;
Uchunksize5 = 2048;
Uchunksize6 = 4192; 

tbl_ch1 = 'tbl_Uchunksize1' # Name of tables in DB
tbl_ch2 = 'tbl_Uchunksize2'
tbl_ch3 = 'tbl_Uchunksize3'
tbl_ch4 = 'tbl_Uchunksize4'
tbl_ch5 = 'tbl_Uchunksize5'
tbl_ch6 = 'tbl_Uchunksize6'

################## get the path to the database
out = 1;
#path1 = os.getcwd();
path = '/Users/pooranian/Desktop/Esorics/Deduplication/clouddatabase2/';   # change database_XXX into 1K 2K 4K and also Uchunksize accordingly
#print(path);

Cloud_Store1 = []; # Upload chunk in cloud 
Cloud_Store2 = [];
Cloud_Store3 = [];
Cloud_Store4 = [];
Cloud_Store5 = [];
Cloud_Store6 = [];

Store1 = []; # Chunk in cloud 
Store2 = [];
Store3 = [];
Store4 = [];
Store5 = [];
Store6 = [];

SH_Store1 = []; # Short hash of chunk in cloud 
SH_Store2 = [];
SH_Store3 = [];
SH_Store4 = [];
SH_Store5 = [];
SH_Store6 = [];

cnt1 = 0;
cnt2 = 0;
cnt3 = 0;
cnt4 = 0;
cnt5 = 0;
cnt6 = 0;

###client Checking hash values with the cloud server without Data Deduplication 

def HashSendToCloudWithoutDatadedpulication(receivedList, Cloud_Store, rand_file_number):
    out1 = 0;
      
    out1 = 1;
    return out1;

###client Checking hash values with the cloud server with Normal Data Deduplication 

def HashSendToCloudNormalDatadedpulication(receivedList, Cloud_Store, rand_file_number):
    out1 = 0;
    if not receivedList in Cloud_Store:    
        out1 = 1;
    return out1;
    

def check_drive_key(sh, chunk, Item1, Item2, n):
  # Checking the indexes to find potential key          

  pub = PublicKey(n)
  # print("pub after recover", pub)
  r2 = select_rand_num(pub)
  epsilon_sh = encrypt(pub, sh, r2)
  # print("epsilon_sh =", epsilon_sh)

  sum_item1_sh = e_add(pub, Item1, epsilon_sh)
  # print("Item1 + sh =", sum_item1_sh)

  epsilon_key = (invert(pow(r2, pub.n), pub.n_sq) * sum_item1_sh) % pub.n_sq
  # print("epsilon_key =", epsilon_key)

  
  result = myCrypto.aes_decrypt_np(Item2, str(epsilon_key))
  # print("------result:", result)

  key = int(myCrypto.aes_decrypt_np(result, str(sh))) 
  
  # print("key after decrypt:", key)

  Item3_prime = myCrypto.aes_encrypt_wp(str(chunk), str(key))

  # print("Item3_prime:", Item3_prime)

  return Item3_prime, key;

def compute_indexes(sh, chunk):
  # Computing all indexes to insert into DB

  # ################### Computing Item3 ###################
  id  = uuid.uuid1()   # Generating unique id for each chunk

  k_f = id.int         # Random key (k_f) 


  Item3 = myCrypto.aes_encrypt_wp(str(chunk), str(k_f)) # Encryption of chunk by k_f

  # print("int id: ", id.int)
  # print("random key:", str(k_f))
  # print("Item3 ", Item3)

  # ################### Computing Item2 ###################

  priv, pub, n = generate_keypair(16)

  # print("n", n)

  # print(pub)

  r1 = select_rand_num(pub)
  
  epsilon_kf = encrypt(pub, k_f, r1)  # Encryption k_f by Paillier encryption ---> Key for Item2


  myCrypto_key = myCrypto.aes_encrypt_wp(str(k_f), str(sh))     # ---> Message for Item2, Encryption of k_f by sh(f)
  

  Item2 = myCrypto.aes_encrypt_np(myCrypto_key, str(epsilon_kf))
  # print("epsilon_kf", epsilon_kf)
  # print("Message: ", myCrypto_key)
  # print("Item2:", Item2)

  # ################### Computing Item1 ###################

  Item1 = encrypt(pub, k_f - sh, r1)
  # print("Item1 =", Item1)

  return Item1, Item2, Item3, n;


def first_time_upload(tb_name, sh, chunk):
  # Uploding short hash and other indexes for the first time into the DB
  
  Item1, Item2, Item3, n = compute_indexes(sh, chunk)
  db.insert(tb_name, ['SH_cl', 'n_cl', 'Item1_cl', 'Item2_cl', 'Item3_cl'], [sh, str(n), str(Item1), Item2, str(Item3)])

  #check_drive_key(sh, chunk, Item1, Item2, Item3, pub)
    
def second_time_upload(tb_name, sh, chunk, matches):
  # Uploding file if matches find for the second time into the Cloud
  found = 0
  ID_found = []
  n_found = []
  Item1_found = []
  Item2_found = []
  Item3_found = []

  # print(matches)

  for ID, n_cl, Item1_cl, Item2_cl, Item3_cl in matches:
    ID_found.append(ID)
    n_found.append(n_cl[:])
    Item1_found.append(Item1_cl[:])
    Item2_found.append(Item2_cl[:])
    Item3_found.append(Item3_cl[:])


  count = len(ID_found)
  print("count", count)

  for i in range(count):
    # print("Item3_found[0]", Item3_found[i])
    Item3_prime, key = check_drive_key(sh, chunk, int(Item1_found[i]), Item2_found[i], int(n_found[i]))

    if str(Item3_prime) == str(Item3_found[i]):
      # print("######")
      # print("Item3_prime", Item3_prime)
      # print("Item3_found[i]", Item3_found[i])
      # db.mem_cur.execute("UPDATE tbl_Uchunksize1 SET popularity = popularity + 1 WHERE ID = (?)", (ID_found[i], ))
      # print("######")
      sql_cmd = "UPDATE {} SET popularity = popularity + 1 WHERE ID =({})".format(tbl_ch1, ID_found[i])
      db.mem_cur.execute(sql_cmd)
      Cloud_Store1.append(Item3_prime)
      found = 1
      break
  
  if not found:
    print("again first upload")
    first_time_upload(tb_name, sh, chunk)

  return found, key;

def uploading_Uchunksize1():
  ##################### this set of codes select 1000 files randomly from the database 1 and store them in the cloud store which has only hash values
  cnt1 = 0;
  for filename in os.listdir(path):
    fin1 = open("/Users/pooranian/Desktop/Esorics/Deduplication/clouddatabase2/"+filename, 'r', encoding='latin-1');
    wi1 = 0;
    while wi1 == 0:
      line1 = fin1.read(Uchunksize1) #it reads with the size of Uchunksize1 from file
      while line1 != '':
        # print("line:", line1)
        # Store1.append(str([hashlib.sha512(line1.encode('utf-8')).digest()])) 
        # SH_Store1.append(Store1[cnt1][0:SH_LEN])
        Store1.append(int(hashlib.sha512(line1.encode('utf-8')).hexdigest(), 16))
        SH_Store1.append(Store1[cnt1]% 10**SH_LEN)

        # x = int(hashlib.sha512(line1.encode('utf-8')).hexdigest(), 16)
        # shx = x % 10**SH_LEN
        # print("x Store1:", x, len(str(x)))
        # print("x SH_Store1: ", shx)

        print("Store1:", Store1[cnt1], len(str(Store1[cnt1])))
        print("SH_Store1: ", SH_Store1[cnt1])
        print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize1 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (SH_Store1[cnt1],)).fetchall()
       
        # print("len matches", len(matches))

        if not matches:
          first_time_upload(tbl_ch1, SH_Store1[cnt1], Store1[cnt1])
          print("not find")
        else:
          print("find")
          second_time_upload(tbl_ch1, SH_Store1[cnt1], Store1[cnt1], matches)
          
          # print(".......................")

        cnt1 += 1;

        line1 = fin1.read(Uchunksize1)
        if len(line1) == 0:
          wi1 = 1
    fin1.close();

  # db.print_data('tbl_Uchunksize1')


def uploading_Uchunksize2():
  ##################### this set of codes select 1000 files randomly from the database 1 and store them in the cloud store which has only hash values
  # print("second one")
  cnt2 = 0;
  for filename in os.listdir(path):
    fin2 = open("/Users/pooranian/Desktop/Esorics/Deduplication/clouddatabase2/"+filename, 'r', encoding='latin-1');
    wi2 = 0;
    while wi2 == 0:
      line2 = fin2.read(Uchunksize2) #it reads with the size of Uchunksize2 from file
      while line2 != '':
        # print("line:", line2)
        # Store2.append(str([hashlib.sha512(line2.encode('utf-8')).digest()])) 
        # SH_Store2.append(Store2[cnt2][0:SH_LEN])
        Store2.append(int(hashlib.sha512(line2.encode('utf-8')).hexdigest(), 16))
        SH_Store2.append(Store2[cnt2]% 10**SH_LEN)

        # print("Store2:", Store2[cnt2])
        # print("SH_Store2: ", SH_Store2[cnt2])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize2 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (SH_Store2[cnt2],)).fetchall()
       
        # print("len matches", len(matches))

        if not matches:
          first_time_upload(tbl_ch2, SH_Store2[cnt2], Store2[cnt2])
          print("not find")
        else:
          print("find")
          second_time_upload(tbl_ch2, SH_Store2[cnt2], Store2[cnt2], matches)
          
          # print(".......................")

        cnt2 += 1;

        line2 = fin2.read(Uchunksize2)
        if len(line2) == 0:
          wi2 = 1
    fin2.close();

  # db.print_data('tbl_Uchunksize2')

def uploading_Uchunksize3():
  ##################### this set of codes select 1000 files randomly from the database 1 and store them in the cloud store which has only hash values
  # print("second one")
  cnt3 = 0;
  for filename in os.listdir(path):
    fin3 = open("/Users/pooranian/Desktop/Esorics/Deduplication/clouddatabase2/"+filename, 'r', encoding='latin-1');
    wi3 = 0;
    while wi3 == 0:
      line3 = fin3.read(Uchunksize3) #it reads with the size of Uchunksize3 from file
      while line3 != '':
        # print("line:", line3)
        # Store3.append(str([hashlib.sha512(line3.encode('utf-8')).digest()])) 
        # SH_Store3.append(Store3[cnt3][0:SH_LEN])
        Store3.append(int(hashlib.sha512(line3.encode('utf-8')).hexdigest(), 16))
        SH_Store3.append(Store3[cnt3]% 10**SH_LEN)

        # print("Store3:", Store3[cnt3])
        # print("SH_Store3: ", SH_Store3[cnt3])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize3 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (SH_Store3[cnt3],)).fetchall()
       
        # print("len matches", len(matches))

        if not matches:
          first_time_upload(tbl_ch3, SH_Store3[cnt3], Store3[cnt3])
          print("not find")
        else:
          print("find")
          second_time_upload(tbl_ch3, SH_Store3[cnt3], Store3[cnt3], matches)
          
          # print(".......................")

        cnt3 += 1;

        line3 = fin3.read(Uchunksize3)
        if len(line3) == 0:
          wi3 = 1
    fin3.close();

  # db.print_data('tbl_Uchunksize3')


def uploading_Uchunksize4():
  ##################### this set of codes select 1000 files randomly from the database 1 and store them in the cloud store which has only hash values
  # print("second one")
  cnt4 = 0;
  for filename in os.listdir(path):
    fin4 = open("/Users/pooranian/Desktop/Esorics/Deduplication/clouddatabase2/"+filename, 'r', encoding='latin-1');
    wi4 = 0;
    while wi4 == 0:
      line4 = fin4.read(Uchunksize4) #it reads with the size of Uchunksize4 from file
      while line4 != '':
        # print("line:", line4)
        # Store4.append(str([hashlib.sha512(line4.encode('utf-8')).digest()])) 
        # SH_Store4.append(Store4[cnt4][0:SH_LEN])
        Store4.append(int(hashlib.sha512(line4.encode('utf-8')).hexdigest(), 16))
        SH_Store4.append(Store4[cnt4]% 10**SH_LEN)

        # print("Store4:", Store4[cnt4])
        # print("SH_Store4: ", SH_Store4[cnt4])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize4 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (SH_Store4[cnt4],)).fetchall()
       
        # print("len matches", len(matches))

        if not matches:
          first_time_upload(tbl_ch4, SH_Store4[cnt4], Store4[cnt4])
          print("not find")
        else:
          print("find")
          second_time_upload(tbl_ch4, SH_Store4[cnt4], Store4[cnt4], matches)
          
          # print(".......................")

        cnt4 += 1;

        line4 = fin4.read(Uchunksize4)
        if len(line4) == 0:
          wi4 = 1
    fin4.close();

  # db.print_data('tbl_Uchunksize4')


def uploading_Uchunksize5():
  ##################### this set of codes select 1000 files randomly from the database 1 and store them in the cloud store which has only hash values
  # print("second one")
  cnt5 = 0;
  for filename in os.listdir(path):
    fin5 = open("/Users/pooranian/Desktop/Esorics/Deduplication/clouddatabase2/"+filename, 'r', encoding='latin-1');
    wi5 = 0;
    while wi5 == 0:
      line5 = fin5.read(Uchunksize5) #it reads with the size of Uchunksize5 from file
      while line5 != '':
        # print("line:", line5)
        # Store5.append(str([hashlib.sha512(line5.encode('utf-8')).digest()])) 
        # SH_Store5.append(Store5[cnt5][0:SH_LEN])
        Store5.append(int(hashlib.sha512(line5.encode('utf-8')).hexdigest(), 16))
        SH_Store5.append(Store5[cnt5]% 10**SH_LEN)

        # print("Store5:", Store5[cnt5])
        # print("SH_Store5: ", SH_Store5[cnt5])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize5 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (SH_Store5[cnt5],)).fetchall()
       
        # print("len matches", len(matches))

        if not matches:
          first_time_upload(tbl_ch5, SH_Store5[cnt5], Store5[cnt5])
          print("not find")
        else:
          print("find")
          second_time_upload(tbl_ch5, SH_Store5[cnt5], Store5[cnt5], matches)
          
          # print(".......................")

        cnt5 += 1;

        line5 = fin5.read(Uchunksize5)
        if len(line5) == 0:
          wi5 = 1
    fin5.close();

  # db.print_data('tbl_Uchunksize5')

def uploading_Uchunksize6():
  ##################### this set of codes select 1000 files randomly from the database 1 and store them in the cloud store which has only hash values
  # print("second one")
  cnt6 = 0;
  for filename in os.listdir(path):
    fin6 = open("/Users/pooranian/Desktop/Esorics/Deduplication/clouddatabase2/"+filename, 'r', encoding='latin-1');
    wi6 = 0;
    while wi6 == 0:
      line6 = fin6.read(Uchunksize6) #it reads with the size of Uchunksize6 from file
      while line6 != '':
        # print("line:", line6)
        # Store6.append(str([hashlib.sha512(line6.encode('utf-8')).digest()])) 
        # SH_Store6.append(Store6[cnt6][0:SH_LEN])
        Store6.append(int(hashlib.sha512(line6.encode('utf-8')).hexdigest(), 16))
        SH_Store6.append(Store6[cnt6]% 10**SH_LEN)

        # x = int(hashlib.sha512(line6.encode('utf-8')).hexdigest(), 16)
        # shx = x % 10**SH_LEN
        # print("x6 Store1:", x, len(str(x)))
        # print("x6 SH_Store1: ", shx)
        # print("len Store6:", len(str(Store6[cnt6])))
        # print("Store6:", Store6[cnt6])
        # print("SH_Store6: ", SH_Store6[cnt6])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize6 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (SH_Store6[cnt6],)).fetchall()
       
        # print("len matches", len(matches))

        if not matches:
          first_time_upload(tbl_ch6, SH_Store6[cnt6], Store6[cnt6])
          print("not find")
        else:
          print("find")
          second_time_upload(tbl_ch6, SH_Store6[cnt6], Store6[cnt6], matches)
          
          # print(".......................")

        cnt6 += 1;

        line6 = fin6.read(Uchunksize6)
        if len(line6) == 0:
          wi6 = 1
    fin6.close();

  # db.print_data('tbl_Uchunksize6')


################################################################################################
communication_cost1 = 0;
communication_cost2 = 0;
communication_cost3 = 0;
communication_cost4 = 0;
communication_cost5 = 0;
communication_cost6 = 0;

deduplication_cost1 = 0;
deduplication_cost2 = 0;
deduplication_cost3 = 0;
deduplication_cost4 = 0;
deduplication_cost5 = 0;
deduplication_cost6 = 0;

ccost1 = 0;
ccost2 = 0;
ccost3 = 0;
ccost4 = 0;
ccost5 = 0;
ccost6 = 0;

dcost1 = 0;
dcost2 = 0;
dcost3 = 0;
dcost4 = 0;
dcost5 = 0;
dcost6 = 0;

flag1 = 0;
flag2 = 0;
flag3 = 0;
flag4 = 0;
flag5 = 0;
flag6 = 0;


##############send 
#path1 = os.getcwd();
path1 = '/Users/pooranian/Desktop/Esorics/Deduplication/attack2/';

AStore1 = []; # Chunk in cloud 
AStore2 = [];
AStore3 = [];
AStore4 = [];
AStore5 = [];
AStore6 = [];

ASH_Store1 = []; # Short hash of chunk in cloud 
ASH_Store2 = [];
ASH_Store3 = [];
ASH_Store4 = [];
ASH_Store5 = [];
ASH_Store6 = [];

send_to_cloud1 = [];
send_to_cloud2 = [];
send_to_cloud3 = [];
send_to_cloud4 = [];
send_to_cloud5 = [];
send_to_cloud6 = [];

rand_value = 50;



def LEVER():

  # For Normal Deduplication
  communication_cost_NormalDatadedpulication_1 = 0;
  communication_cost_NormalDatadedpulication_2 = 0;
  communication_cost_NormalDatadedpulication_3 = 0;
  communication_cost_NormalDatadedpulication_4 = 0;
  communication_cost_NormalDatadedpulication_5 = 0;
  communication_cost_NormalDatadedpulication_6 = 0;


  deduplication_cost_Normal_1 = 0;
  deduplication_cost_Normal_2 = 0;
  deduplication_cost_Normal_3 = 0;
  deduplication_cost_Normal_4 = 0;
  deduplication_cost_Normal_5 = 0;
  deduplication_cost_Normal_6 = 0;

  # For Without Deduplication
  communication_cost_WithoutDatadedpulication_1 = 0;
  communication_cost_WithoutDatadedpulication_2 = 0;
  communication_cost_WithoutDatadedpulication_3 = 0;
  communication_cost_WithoutDatadedpulication_4 = 0;
  communication_cost_WithoutDatadedpulication_5 = 0;
  communication_cost_WithoutDatadedpulication_6 = 0;

  deduplication_cost_Without_1 = 0;
  deduplication_cost_Without_2 = 0;
  deduplication_cost_Without_3 = 0;
  deduplication_cost_Without_4 = 0;
  deduplication_cost_Without_5 = 0;
  deduplication_cost_Without_6 = 0;

  # For LEVER
  communication_cost1 = 0;
  communication_cost2 = 0;
  communication_cost3 = 0;
  communication_cost4 = 0;
  communication_cost5 = 0;
  communication_cost6 = 0;
  comm_cost1 = 0;
  comm_cost2 = 0;
  comm_cost3 = 0;
  comm_cost4 = 0;
  comm_cost5 = 0;
  comm_cost6 = 0;

  deduplication_cost1 = 0;
  deduplication_cost2 = 0;
  deduplication_cost3 = 0;
  deduplication_cost4 = 0;
  deduplication_cost5 = 0;
  deduplication_cost6 = 0;
  dedup_cost1 = 0;
  dedup_cost2 = 0;
  dedup_cost3 = 0;
  dedup_cost4 = 0;
  dedup_cost5 = 0;
  dedup_cost6 = 0;

  cnt1 = 0;
  cnt2 = 0;
  cnt3 = 0;
  cnt4 = 0;
  cnt5 = 0;
  cnt6 = 0;

  for filename in os.listdir(path1):

    ############################## Uchunksize1 = 128 #################################
    fin1 = open(path1+filename, 'r', encoding='latin-1');
    wi1 = 0;
    while wi1 == 0:
      line1 = fin1.read(Uchunksize1)
      # Number_of_packets_1 = Number_of_packets_1 + 1;
      # print("len chunck", len(line1))
        
      while line1 != '':
        #print("i am here");
        AStore1.append(int(hashlib.sha512(line1.encode('utf-8')).hexdigest(), 16))
        ASH_Store1.append(AStore1[cnt1]% 10**SH_LEN)

        rand_file_number = random.randint(1, rand_value);    #random.randint(a, b), Return N, a <= N <= b.

        # print("chunk size", len(str(AStore1[cnt1])))
        # print("hash size", len(str(ASH_Store1[cnt1])))
        # print("AStore1:", AStore1[cnt1])
        # print("ASH_Store1: ", ASH_Store1[cnt1])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize1 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (ASH_Store1[cnt1],)).fetchall()
       
        # print("len matches", len(matches))
        ccost11 = 0;
        ccost12 = 0;
        tmp_ccost11 = 0;
        tmp_ccost12 = 0;

        dcost11 = 0;
        dcost12 = 0;
        tmp_dcost11 = 0;
        tmp_dcost12 = 0;

        ccost_norm11 = 0;
        ccost_norm12 = 0;

        dcost_norm11 = 0;
        dcost_norm12 = 0;

        ccost_out11 = 0;
        ccost_out12 = 0;

        if not matches:

          # Run LEVER protocol
          first_time_upload(tbl_ch1, ASH_Store1[cnt1], AStore1[cnt1])
          print("not find");

          communication_cost1 = communication_cost1 + 0;
          comm_cost1 = comm_cost1 + 0;

          deduplication_cost1 = deduplication_cost1 + 0;
          dedup_cost1 = dedup_cost1 + 0;


          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_1 = communication_cost_NormalDatadedpulication_1 + Uchunksize1;
          communication_cost_NormalDatadedpulication_1 = communication_cost_NormalDatadedpulication_1 + 0;
          deduplication_cost_Normal_1 = deduplication_cost_Normal_1 + 0;
          
          #result_normalDeduplication_1 = HashSendToCloudNormalDatadedpulication(AStore1, Cloud_Store1, rand_file_number);

          #if result_normalDeduplication_1 == 1:
           # print("Normal dedup 1,sh not in cloud");
            #communication_cost_NormalDatadedpulication_1 = communication_cost_NormalDatadedpulication_1 + Uchunksize1;
          
          # Run Without Deduplication protocol
          communication_cost_WithoutDatadedpulication_1 = communication_cost_WithoutDatadedpulication_1 + 2 * Uchunksize1;
          deduplication_cost_Without_1 = deduplication_cost_Without_1 + 0;
          #result_WithoutDeduplication_1 = HashSendToCloudWithoutDatadedpulication(AStore1, Cloud_Store1, rand_file_number);
          
          #if result_WithoutDeduplication_1 == 1:
           # communication_cost_WithoutDatadedpulication_1 = communication_cost_WithoutDatadedpulication_1 + 2*Uchunksize1;
         
        else:
          print("find")
          flag1, key = second_time_upload(tbl_ch1, ASH_Store1[cnt1], AStore1[cnt1], matches)
          
          if flag1 == 1: # sh in cloud and chunck in cloud
            ccost11 = len(str(AStore1[cnt1])) + (((2 * len(str(key))) + len(str(ASH_Store1[cnt1]))) * len(matches)); # Real testing
            tmp_ccost11 = 128 + (((2 * len(str(key))) + SH_LEN) * len(matches)); # Formula testing
           
            dcost11 = len(str(AStore1[cnt1]));
            tmp_dcost11 = 128;


            # Run Without Deduplication protocol
            ccost_out11 = ccost11;
            deduplication_cost_Without_1 = deduplication_cost_Without_1 + 0;
            
            # Run Normal Deduplication protocol
            ccost_norm11 = ccost11;
            dcost_norm11 = dcost11;

          else: # sh in cloud and chunck not in cloud
            print("here is not zero")
            ccost12 = (((2 * len(str(key))) + len(str(ASH_Store1[cnt1]))) * len(str(matches))) + (2 * len(str(key))) + (2 * len(str(ASH_Store1[cnt1]))) + len(str(AStore1[cnt1]));
            tmp_ccost12 = (((2 * len(str(key))) + SH_LEN) * len(str(matches))) + (2 * len(str(key))) + (2 * SH_LEN) + 128;
            
            dcost12 = (2 * len(str(key))) + (2 * len(str(ASH_Store1[cnt1]))) + len(str(AStore1[cnt1]));
            tmp_dcost12 = (2 * len(str(key))) + (2 * SH_LEN) + 128;

            # Run Without Deduplication protocol
            ccost_out12 = ccost12;
            deduplication_cost_Without_1 = deduplication_cost_Without_1 + 0;

            # Run Normal Deduplication protocol
            #ccost_norm12 = 0;
            #dcost_norm12 = 0;
            #result_normalDeduplication_1 = HashSendToCloudNormalDatadedpulication(AStore1, Cloud_Store1, rand_file_number);

            #if result_normalDeduplication_1 == 1:
             # print("Normal dedup 1,sh in cloud and chunck not in cloud");
             # communication_cost_NormalDatadedpulication_1 = communication_cost_NormalDatadedpulication_1 + Uchunksize1;
          

          communication_cost1 =  communication_cost1 + ((PROB * (ccost11)) + ((1 - PROB) * (ccost12)));
          comm_cost1 =  communication_cost1 + ((PROB * (tmp_ccost11)) + ((1 - PROB) * (tmp_ccost12)));
          
          deduplication_cost1 = deduplication_cost1 + (1 - ( ( (PROB * (dcost11)) + ((1 - PROB) * (dcost12)) ) / (len(str(AStore1[cnt1]))) ));
          dedup_cost1 = dedup_cost1 + (1 - ( ( (PROB * (tmp_dcost11)) + ((1 - PROB) * (tmp_dcost12)) ) / (128) ));
           

          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_1 = communication_cost_NormalDatadedpulication_1 + ccost_norm11 + ccost_norm12;
          communication_cost_NormalDatadedpulication_1 = communication_cost_NormalDatadedpulication_1 + ((PROB * (ccost_norm11)) + ((1 - PROB) * (ccost_norm12)));
          deduplication_cost_Normal_1 = deduplication_cost_Normal_1 + (1 - ( ( (PROB * (dcost_norm11)) + ((1 - PROB) * (0)) ) / (len(str(AStore1[cnt1]))) ));
         
          #result_normalDeduplication_1 = HashSendToCloudNormalDatadedpulication(AStore1, Cloud_Store1, rand_file_number);

          #if result_normalDeduplication_1 == 1:
           # communication_cost_NormalDatadedpulication_1 = communication_cost_NormalDatadedpulication_1 + Uchunksize1;
          
          # Run Without Deduplication protocol
          #communication_cost_WithoutDatadedpulication_1 = communication_cost_WithoutDatadedpulication_1 + ccost_out11 + ccost_out12;
          communication_cost_WithoutDatadedpulication_1 = communication_cost_WithoutDatadedpulication_1 + ((PROB * (ccost_out11)) + ((1 - PROB) * (ccost_out12)));
          deduplication_cost_Without_1 = deduplication_cost_Without_1 + 0;
          #result_WithoutDeduplication_1 = HashSendToCloudWithoutDatadedpulication(AStore1, Cloud_Store1, rand_file_number);
          
          #if result_WithoutDeduplication_1 == 1:
           # communication_cost_WithoutDatadedpulication_1 = communication_cost_WithoutDatadedpulication_1 + 2*Uchunksize1;
        
        line1 = fin1.read(Uchunksize1)
        cnt1 += 1;
     
        if len(line1) == 0:
          wi1 = 1
          #print("i am here");
    fin1.close();
    # Number_of_packets_1 = 0;

    ############################## Uchunksize2 = 256 #################################
    fin2 = open(path1+filename, 'r', encoding='latin-1');
    wi2 = 0;
    while wi2 == 0:
      line2 = fin2.read(Uchunksize2)
      # Number_of_packets_2 = Number_of_packets_2 + 1;
        
      while line2 != '':
        #print("i am here");
        AStore2.append(int(hashlib.sha512(line2.encode('utf-8')).hexdigest(), 16))
        ASH_Store2.append(AStore2[cnt2]% 10**SH_LEN)

        # print("AStore2:", AStore2[cnt2])
        # print("ASH_Store2: ", ASH_Store2[cnt2])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize2 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (ASH_Store2[cnt2],)).fetchall()
       
        # print("len matches", len(matches))
        ccost21 = 0;
        ccost22 = 0;
        tmp_ccost21 = 0;
        tmp_ccost22 = 0;

        dcost21 = 0;
        dcost22 = 0;
        tmp_dcost21 = 0;
        tmp_dcost22 = 0;

        ccost_norm21 = 0;
        ccost_norm22 = 0;

        dcost_norm21 = 0;
        dcost_norm22 = 0;

        ccost_out21 = 0;
        ccost_out22 = 0;

        if not matches:

          # Run LEVER protocol
          first_time_upload(tbl_ch2, ASH_Store2[cnt2], AStore2[cnt2])
          print("not find")

          communication_cost2 = communication_cost2 + 0;
          comm_cost2 = comm_cost2 + 0;

          deduplication_cost2 = deduplication_cost2 + 0;
          dedup_cost2 = dedup_cost2 + 0;

          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_2 = communication_cost_NormalDatadedpulication_2 + Uchunksize2;
          communication_cost_NormalDatadedpulication_2 = communication_cost_NormalDatadedpulication_2 + 0;
          deduplication_cost_Normal_2 = deduplication_cost_Normal_2 + 0;
          #result_normalDeduplication_2 = HashSendToCloudNormalDatadedpulication(AStore2, Cloud_Store2, rand_file_number);

          #if result_normalDeduplication_2 == 1:
           # communication_cost_NormalDatadedpulication_2 = communication_cost_NormalDatadedpulication_2 + Uchunksize2;
          
          # Run Without Deduplication protocol
          communication_cost_WithoutDatadedpulication_2 = communication_cost_WithoutDatadedpulication_2 + 2* Uchunksize2;
          deduplication_cost_Without_2 = deduplication_cost_Without_2 + 0;

          #result_WithoutDeduplication_2 = HashSendToCloudWithoutDatadedpulication(AStore2, Cloud_Store2, rand_file_number);
          
          #if result_WithoutDeduplication_2 == 1:
           # communication_cost_WithoutDatadedpulication_2 = communication_cost_WithoutDatadedpulication_2 + 2*Uchunksize2;
         

        else:
          print("find")
          flag2, key = second_time_upload(tbl_ch2, ASH_Store2[cnt2], AStore2[cnt2], matches)
          
          if flag2 == 1: # sh in cloud and chunck in cloud
            ccost21 = len(str(AStore2[cnt2])) + (((2 * len(str(key))) + len(str(ASH_Store2[cnt2]))) * len(matches));
            tmp_ccost21 = 256 + (((2 * len(str(key))) + SH_LEN) * len(matches));
           
            dcost21 = len(str(AStore2[cnt2]));
            tmp_dcost21 = 256;

            # Run Without Deduplication protocol
            ccost_out21 = ccost21;
            deduplication_cost_Without_2 = deduplication_cost_Without_2 + 0;
            
            # Run Normal Deduplication protocol
            ccost_norm21 = ccost21;
            dcost_norm21 = dcost21;

          else: # sh in cloud and chunck not in cloud
            ccost22 = (((2 * len(str(key))) + len(str(ASH_Store2[cnt2]))) * len(str(matches))) + (2 * len(str(key))) + (2 * len(str(ASH_Store2[cnt2]))) + len(str(AStore2[cnt2]));
            tmp_ccost22 = (((2 * len(str(key))) + SH_LEN) * len(str(matches))) + (2 * len(str(key))) + (2 * SH_LEN) + 256;
            
            dcost22 = (2 * len(str(key))) + (2 * len(str(ASH_Store2[cnt2]))) + len(str(AStore2[cnt2]));
            tmp_dcost22 = (2 * len(str(key))) + (2 * SH_LEN) + 256;

            # Run Without Deduplication protocol
            ccost_out22 = ccost22;
            deduplication_cost_Without_2 = deduplication_cost_Without_2 + 0;

            # Run Normal Deduplication protocol
            #ccost_norm22 = 0;
            #dcost_norm22 = 0;

            #result_normalDeduplication_2 = HashSendToCloudNormalDatadedpulication(AStore2, Cloud_Store2, rand_file_number);

            #if result_normalDeduplication_2 == 1:
             # print("Normal dedup 2,sh in cloud and chunck not in cloud");
              #communication_cost_NormalDatadedpulication_2 = communication_cost_NormalDatadedpulication_2 + Uchunksize2;
          

          communication_cost2 =  communication_cost2 + ((PROB * (ccost21)) + ((1 - PROB) * (ccost22)));
          comm_cost2 =  communication_cost2 + ((PROB * (tmp_ccost21)) + ((1 - PROB) * (tmp_ccost22)));
          
          deduplication_cost2 = deduplication_cost2 + (1 - ( ( (PROB * (dcost21)) + ((1 - PROB) * (dcost22)) ) / (len(str(AStore2[cnt2]))) ));
          dedup_cost2 = dedup_cost2 + (1 - ( ( (PROB * (tmp_dcost21)) + ((1 - PROB) * (tmp_dcost22)) ) / (256) ));



          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_2 = communication_cost_NormalDatadedpulication_2 + ccost_norm21 + ccost_norm22;
          communication_cost_NormalDatadedpulication_2 = communication_cost_NormalDatadedpulication_2 + ((PROB * (ccost_norm21)) + ((1 - PROB) * (ccost_norm22)));
          deduplication_cost_Normal_2 = deduplication_cost_Normal_2 + (1 - ( ( (PROB * (dcost_norm21)) + ((1 - PROB) * (0)) ) / (len(str(AStore2[cnt2]))) ));
          #result_normalDeduplication_2 = HashSendToCloudNormalDatadedpulication(AStore2, Cloud_Store2, rand_file_number);

          #if result_normalDeduplication_2 == 1:
           # communication_cost_NormalDatadedpulication_2 = communication_cost_NormalDatadedpulication_2 + Uchunksize2;
          
          # Run Without Deduplication protocol
          communication_cost_WithoutDatadedpulication_2 = communication_cost_WithoutDatadedpulication_2 + ((PROB * (ccost_out21)) + ((1 - PROB) * (ccost_out22))); 

          deduplication_cost_Without_2 = deduplication_cost_Without_2 + 0;
          #result_WithoutDeduplication_2 = HashSendToCloudWithoutDatadedpulication(AStore2, Cloud_Store2, rand_file_number);
          
          #if result_WithoutDeduplication_2 == 1:
           # communication_cost_WithoutDatadedpulication_2 = communication_cost_WithoutDatadedpulication_2 + 2*Uchunksize2;
         
        
        line2 = fin2.read(Uchunksize2)
        cnt2 += 1;
    

        if len(line2) == 0:
          wi2 = 1
          #print("i am here");
    fin2.close();
    # Number_of_packets_2 = 0;

    ############################## Uchunksize3 = 512 #################################
    fin3 = open(path1+filename, 'r', encoding='latin-1');
    wi3 = 0;
    while wi3 == 0:
      line3 = fin3.read(Uchunksize3)
      # Number_of_packets_3 = Number_of_packets_3 + 1;
        
      while line3 != '':
        #print("i am here");
        AStore3.append(int(hashlib.sha512(line3.encode('utf-8')).hexdigest(), 16))
        ASH_Store3.append(AStore3[cnt3]% 10**SH_LEN)

        # print("AStore3:", AStore3[cnt3])
        # print("ASH_Store3: ", ASH_Store3[cnt3])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize3 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (ASH_Store3[cnt3],)).fetchall()
       
        # print("len matches", len(matches))
        ccost31 = 0;
        ccost32 = 0;
        tmp_ccost31 = 0;
        tmp_ccost32 = 0;

        dcost31 = 0;
        dcost32 = 0;
        tmp_dcost31 = 0;
        tmp_dcost32 = 0;

        ccost_norm31 = 0;
        ccost_norm32 = 0;

        dcost_norm31 = 0;
        dcost_norm32 = 0;

        ccost_out31 = 0;
        ccost_out32 = 0;

        if not matches:

          # Run LEVER protocol
          first_time_upload(tbl_ch3, ASH_Store3[cnt3], AStore3[cnt3])
          print("not find")

          communication_cost3 = communication_cost3 + 0;
          comm_cost3 = comm_cost3 + 0;

          deduplication_cost3 = deduplication_cost3 + 0;
          dedup_cost3 = dedup_cost3 + 0;

          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_3 = communication_cost_NormalDatadedpulication_3 + Uchunksize3;
          communication_cost_NormalDatadedpulication_3 = communication_cost_NormalDatadedpulication_3 + 0;
          deduplication_cost_Normal_3 = deduplication_cost_Normal_3 + 0;
          #result_normalDeduplication_3 = HashSendToCloudNormalDatadedpulication(AStore3, Cloud_Store3, rand_file_number);

          #if result_normalDeduplication_3 == 1:
           # communication_cost_NormalDatadedpulication_3 = communication_cost_NormalDatadedpulication_3 + Uchunksize3;
          
          # Run Without Deduplication protocol
          communication_cost_WithoutDatadedpulication_3 = communication_cost_WithoutDatadedpulication_3 + 2 * Uchunksize3;
          deduplication_cost_Without_3 = deduplication_cost_Without_3 + 0;
          #result_WithoutDeduplication_3 = HashSendToCloudWithoutDatadedpulication(AStore3, Cloud_Store3, rand_file_number);
          
          #if result_WithoutDeduplication_3 == 1:
           # communication_cost_WithoutDatadedpulication_3 = communication_cost_WithoutDatadedpulication_3 + 2*Uchunksize3;
         

        else:
          print("find")
          flag3, key = second_time_upload(tbl_ch3, ASH_Store3[cnt3], AStore3[cnt3], matches)
          
          if flag3 == 1: # sh in cloud and chunck in cloud
            ccost31 = len(str(AStore3[cnt3])) + (((2 * len(str(key))) + len(str(ASH_Store3[cnt3]))) * len(matches));
            tmp_ccost31 = 512 + (((2 * len(str(key))) + SH_LEN) * len(matches));
           
            dcost31 = len(str(AStore3[cnt3]));
            tmp_dcost31 = 512;

            # Run Without Deduplication protocol
            ccost_out31 = ccost31;
            deduplication_cost_Without_3 = deduplication_cost_Without_3 + 0;
            
            # Run Normal Deduplication protocol
            ccost_norm31 = ccost31;
            dcost_norm31 = dcost31;

          else: # sh in cloud and chunck not in cloud
            ccost32 = (((2 * len(str(key))) + len(str(ASH_Store3[cnt3]))) * len(str(matches))) + (2 * len(str(key))) + (2 * len(str(ASH_Store3[cnt3]))) + len(str(AStore3[cnt3]));
            tmp_ccost32 = (((2 * len(str(key))) + SH_LEN) * len(str(matches))) + (2 * len(str(key))) + (2 * SH_LEN) + 512;
            
            dcost32 = (2 * len(str(key))) + (2 * len(str(ASH_Store3[cnt3]))) + len(str(AStore3[cnt3]));
            tmp_dcost32 = (2 * len(str(key))) + (2 * SH_LEN) + 512;

            # Run Without Deduplication protocol
            ccost_out32 = ccost32;
            deduplication_cost_Without_3 = deduplication_cost_Without_3 + 0;

            # Run Normal Deduplication protocol
            #ccost_norm32 = 0;
            #dcost_norm32 = 0;

            # Run Normal Deduplication protocol
            #result_normalDeduplication_3 = HashSendToCloudNormalDatadedpulication(AStore3, Cloud_Store3, rand_file_number);

            #if result_normalDeduplication_3 == 1:
             # print("Normal dedup 3,sh in cloud and chunck not in cloud");
              #communication_cost_NormalDatadedpulication_3 = communication_cost_NormalDatadedpulication_3 + Uchunksize3;
          

          communication_cost3 =  communication_cost3 + ((PROB * (ccost31)) + ((1 - PROB) * (ccost32)));
          comm_cost3 =  communication_cost3 + ((PROB * (tmp_ccost31)) + ((1 - PROB) * (tmp_ccost32)));
          
          deduplication_cost3 = deduplication_cost3 + (1 - ( ( (PROB * (dcost31)) + ((1 - PROB) * (dcost32)) ) / (len(str(AStore3[cnt3]))) ));
          dedup_cost3 = dedup_cost3 + (1 - ( ( (PROB * (tmp_dcost31)) + ((1 - PROB) * (tmp_dcost32)) ) / (512) ));

          # Run Normal Deduplication protocol
          communication_cost_NormalDatadedpulication_3 = communication_cost_NormalDatadedpulication_3 + ((PROB * (ccost_norm31)) + ((1 - PROB) * (ccost_norm32))); 
          deduplication_cost_Normal_3 = deduplication_cost_Normal_3 + (1 - ( ( (PROB * (dcost_norm31)) + ((1 - PROB) * (0)) ) / (len(str(AStore3[cnt3]))) ));
         
          #result_normalDeduplication_3 = HashSendToCloudNormalDatadedpulication(AStore3, Cloud_Store3, rand_file_number);

          #if result_normalDeduplication_3 == 1:
            #communication_cost_NormalDatadedpulication_3 = communication_cost_NormalDatadedpulication_3 + Uchunksize3;
          
          # Run Without Deduplication protocol
          communication_cost_WithoutDatadedpulication_3 = communication_cost_WithoutDatadedpulication_3 + ((PROB * (ccost_out31)) + ((1 - PROB) * (ccost_out32))); 
          deduplication_cost_Without_3 = deduplication_cost_Without_3 + 0;
          #result_WithoutDeduplication_3 = HashSendToCloudWithoutDatadedpulication(AStore3, Cloud_Store3, rand_file_number);
          
          #if result_WithoutDeduplication_3 == 1:
           # communication_cost_WithoutDatadedpulication_3 = communication_cost_WithoutDatadedpulication_3 + 2*Uchunksize3;
         
 
        line3 = fin3.read(Uchunksize3)
        cnt3 += 1; 
       

        if len(line3) == 0:
          wi3 = 1
          #print("i am here");
    fin3.close();
    # Number_of_packets_3 = 0;

    ############################## Uchunksize4 = 1K #################################
    fin4 = open(path1+filename, 'r', encoding='latin-1');
    wi4 = 0;
    while wi4 == 0:
      line4 = fin4.read(Uchunksize4)
      # Number_of_packets_4 = Number_of_packets_4 + 1;
        
      while line4 != '':
        #print("i am here");
        AStore4.append(int(hashlib.sha512(line4.encode('utf-8')).hexdigest(), 16))
        ASH_Store4.append(AStore4[cnt4]% 10**SH_LEN)

        # print("AStore4:", AStore4[cnt4])
        # print("ASH_Store4: ", ASH_Store4[cnt4])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize4 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (ASH_Store4[cnt4],)).fetchall()
       
        # print("len matches", len(matches))
        ccost41 = 0;
        ccost42 = 0;
        tmp_ccost41 = 0;
        tmp_ccost42 = 0;

        dcost41 = 0;
        dcost42 = 0;
        tmp_dcost41 = 0;
        tmp_dcost42 = 0;

        ccost_norm41 = 0;
        ccost_norm42 = 0;

        dcost_norm41 = 0;
        dcost_norm42 = 0;

        ccost_out41 = 0;
        ccost_out42 = 0;

        if not matches:

          # Run LEVER protocol
          first_time_upload(tbl_ch4, ASH_Store4[cnt4], AStore4[cnt4])
          print("not find")

          communication_cost4 = communication_cost4 + 0;
          comm_cost4 = comm_cost4 + 0;

          deduplication_cost4 = deduplication_cost4 + 0;
          dedup_cost4 = dedup_cost4 + 0;

          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_4 = communication_cost_NormalDatadedpulication_4 + Uchunksize4;
          communication_cost_NormalDatadedpulication_4 = communication_cost_NormalDatadedpulication_4 + 0;
          deduplication_cost_Normal_4 = deduplication_cost_Normal_4 + 0;
          #result_normalDeduplication_4 = HashSendToCloudNormalDatadedpulication(AStore4, Cloud_Store4, rand_file_number);

          #if result_normalDeduplication_4 == 1:
           # communication_cost_NormalDatadedpulication_4 = communication_cost_NormalDatadedpulication_4 + Uchunksize4;
          
          # Run Without Deduplication protocol
          communication_cost_WithoutDatadedpulication_4 = communication_cost_WithoutDatadedpulication_4 + 2 * Uchunksize4;
          deduplication_cost_Without_4 = deduplication_cost_Without_4 + 0;
          #result_WithoutDeduplication_4 = HashSendToCloudWithoutDatadedpulication(AStore4, Cloud_Store4, rand_file_number);
          
          #if result_WithoutDeduplication_4 == 1:
           # communication_cost_WithoutDatadedpulication_4 = communication_cost_WithoutDatadedpulication_4 + 2*Uchunksize4;
         

        else:
          print("find")
          flag4, key = second_time_upload(tbl_ch4, ASH_Store4[cnt4], AStore4[cnt4], matches)
          
          if flag4 == 1: # sh in cloud and chunck in cloud
            ccost41 = len(str(AStore4[cnt4])) + (((2 * len(str(key))) + len(str(ASH_Store4[cnt4]))) * len(matches));
            tmp_ccost41 = 1024 + (((2 * len(str(key))) + SH_LEN) * len(matches));
           
            dcost41 = len(str(AStore4[cnt4]));
            tmp_dcost41 = 1024;

            # Run Without Deduplication protocol
            ccost_out41 = ccost41;
            deduplication_cost_Without_4 = deduplication_cost_Without_4 + 0;
            
            # Run Normal Deduplication protocol
            ccost_norm41 = ccost41;
            dcost_norm41 = dcost41;


          else: # sh in cloud and chunck not in cloud
            ccost42 = (((2 * len(str(key))) + len(str(ASH_Store4[cnt4]))) * len(str(matches))) + (2 * len(str(key))) + (2 * len(str(ASH_Store4[cnt4]))) + len(str(AStore4[cnt4]));
            tmp_ccost42 = (((2 * len(str(key))) + SH_LEN) * len(str(matches))) + (2 * len(str(key))) + (2 * SH_LEN) + 1024;
            
            dcost42 = (2 * len(str(key))) + (2 * len(str(ASH_Store4[cnt4]))) + len(str(AStore4[cnt4]));
            tmp_dcost42 = (2 * len(str(key))) + (2 * SH_LEN) + 1024;

            # Run Without Deduplication protocol
            ccost_out42 = ccost42;
            deduplication_cost_Without_4 = deduplication_cost_Without_4 + 0;

            # Run Normal Deduplication protocol
            #ccost_norm42 = 0;
            #dcost_norm42 = 0;

            # Run Normal Deduplication protocol
            #result_normalDeduplication_4 = HashSendToCloudNormalDatadedpulication(AStore4, Cloud_Store4, rand_file_number);

            #if result_normalDeduplication_4 == 1:
             # print("Normal dedup 4,sh in cloud and chunck not in cloud");
              #communication_cost_NormalDatadedpulication_4 = communication_cost_NormalDatadedpulication_4 + Uchunksize4;
         

          communication_cost4 =  communication_cost4 + ((PROB * (ccost41)) + ((1 - PROB) * (ccost42)));
          comm_cost4 =  communication_cost4 + ((PROB * (tmp_ccost41)) + ((1 - PROB) * (tmp_ccost42)));
          
          deduplication_cost4 = deduplication_cost4 + (1 - ( ( (PROB * (dcost41)) + ((1 - PROB) * (dcost42)) ) / (len(str(AStore4[cnt4]))) ));
          dedup_cost4 = dedup_cost4 + (1 - ( ( (PROB * (tmp_dcost41)) + ((1 - PROB) * (tmp_dcost42)) ) / (1024) ));
          

          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_4 = communication_cost_NormalDatadedpulication_4 + ccost_norm41 + ccost_norm42;
          communication_cost_NormalDatadedpulication_4 = communication_cost_NormalDatadedpulication_4 + ((PROB * (ccost_norm41)) + ((1 - PROB) * (ccost_norm42))); 
          deduplication_cost_Normal_4 = deduplication_cost_Normal_4 + (1 - ( ( (PROB * (dcost_norm41)) + ((1 - PROB) * (0)) ) / (len(str(AStore4[cnt4]))) ));
         
          #result_normalDeduplication_4 = HashSendToCloudNormalDatadedpulication(AStore4, Cloud_Store4, rand_file_number);

          #if result_normalDeduplication_4 == 1:
           # communication_cost_NormalDatadedpulication_4 = communication_cost_NormalDatadedpulication_4 + Uchunksize4;
          
          # Run Without Deduplication protocol
          #communication_cost_WithoutDatadedpulication_4 = communication_cost_WithoutDatadedpulication_4 + ccost_out41 + ccost_out42;
          communication_cost_WithoutDatadedpulication_4 = communication_cost_WithoutDatadedpulication_4 + ((PROB * (ccost_out41)) + ((1 - PROB) * (ccost_out42))); 
          deduplication_cost_Without_4 = deduplication_cost_Without_4 + 0;
          #result_WithoutDeduplication_4 = HashSendToCloudWithoutDatadedpulication(AStore4, Cloud_Store4, rand_file_number);
          
          #if result_WithoutDeduplication_4 == 1:
           # communication_cost_WithoutDatadedpulication_4 = communication_cost_WithoutDatadedpulication_4 + 2*Uchunksize4;
         
           
        line4 = fin4.read(Uchunksize4)
        cnt4 += 1;
       

        if len(line4) == 0:
          wi4 = 1
          #print("i am here");
    fin4.close();
    # Number_of_packets_4 = 0;

    ############################## Uchunksize5 = 2K #################################
    fin5 = open(path1+filename, 'r', encoding='latin-1');
    wi5 = 0;
    while wi5 == 0:
      line5 = fin5.read(Uchunksize5)
      # Number_of_packets_5 = Number_of_packets_5 + 1;
        
      while line5 != '':
        #print("i am here");
        AStore5.append(int(hashlib.sha512(line5.encode('utf-8')).hexdigest(), 16))
        ASH_Store5.append(AStore5[cnt5]% 10**SH_LEN)

        # print("AStore5:", AStore5[cnt5])
        # print("ASH_Store5: ", ASH_Store5[cnt5])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize5 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (ASH_Store5[cnt5],)).fetchall()
       
        # print("len matches", len(matches))
        ccost51 = 0;
        ccost52 = 0;
        tmp_ccost51 = 0;
        tmp_ccost52 = 0;

        dcost51 = 0;
        dcost52 = 0;
        tmp_dcost51 = 0;
        tmp_dcost52 = 0;

        ccost_norm51 = 0;
        ccost_norm52 = 0;

        dcost_norm51 = 0;
        dcost_norm52 = 0;

        ccost_out51 = 0;
        ccost_out52 = 0;

        if not matches:

          # Run LEVER protocol
          first_time_upload(tbl_ch5, ASH_Store5[cnt5], AStore5[cnt5])
          print("not find")

          communication_cost5 = communication_cost5 + 0;
          comm_cost5 = comm_cost5 + 0;

          deduplication_cost5 = deduplication_cost5 + 0;
          dedup_cost5 = dedup_cost5 + 0;

          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_5 = communication_cost_NormalDatadedpulication_5 + Uchunksize5;
          communication_cost_NormalDatadedpulication_5 = communication_cost_NormalDatadedpulication_5 + 0;
          deduplication_cost_Normal_5 = deduplication_cost_Normal_5 + 0;
          #result_normalDeduplication_5 = HashSendToCloudNormalDatadedpulication(AStore5, Cloud_Store5, rand_file_number);

          #if result_normalDeduplication_5 == 1:
            #communication_cost_NormalDatadedpulication_5 = communication_cost_NormalDatadedpulication_5 + Uchunksize5;
          
          # Run Without Deduplication protocol
          communication_cost_WithoutDatadedpulication_5 = communication_cost_WithoutDatadedpulication_5 + 2 * Uchunksize5;
          deduplication_cost_Without_5 = deduplication_cost_Without_5 + 0;
          #result_WithoutDeduplication_5 = HashSendToCloudWithoutDatadedpulication(AStore5, Cloud_Store5, rand_file_number);
          
          #if result_WithoutDeduplication_5 == 1:
            #communication_cost_WithoutDatadedpulication_5 = communication_cost_WithoutDatadedpulication_5 + 2*Uchunksize5;
         

        else:
          print("find")
          flag5, key = second_time_upload(tbl_ch5, ASH_Store5[cnt5], AStore5[cnt5], matches)
          
          if flag5 == 1: # sh in cloud and chunck in cloud
            ccost51 = len(str(AStore5[cnt5])) + (((2 * len(str(key))) + len(str(ASH_Store5[cnt5]))) * len(matches));
            tmp_ccost51 = 2048 + (((2 * len(str(key))) + SH_LEN) * len(matches));
           
            dcost51 = len(str(AStore5[cnt5]));
            tmp_dcost51 = 2048;

            # Run Without Deduplication protocol
            ccost_out51 = ccost51;
            deduplication_cost_Without_5 = deduplication_cost_Without_5 + 0;
            
            # Run Normal Deduplication protocol
            ccost_norm51 = ccost51;
            dcost_norm51 = dcost51;
             

          else: # sh in cloud and chunck not in cloud
            ccost52 = (((2 * len(str(key))) + len(str(ASH_Store5[cnt5]))) * len(str(matches))) + (2 * len(str(key))) + (2 * len(str(ASH_Store5[cnt5]))) + len(str(AStore5[cnt5]));
            tmp_ccost52 = (((2 * len(str(key))) + SH_LEN) * len(str(matches))) + (2 * len(str(key))) + (2 * SH_LEN) + 2048;
            
            dcost52 = (2 * len(str(key))) + (2 * len(str(ASH_Store5[cnt5]))) + len(str(AStore5[cnt5]));
            tmp_dcost52 = (2 * len(str(key))) + (2 * SH_LEN) + 2048;

            # Run Without Deduplication protocol
            ccost_out52 = ccost52;
            deduplication_cost_Without_5 = deduplication_cost_Without_5 + 0;

            # Run Normal Deduplication protocol
            #ccost_norm52 = 0;
            #dcost_norm52 = 0;

            # Run Normal Deduplication protocol
            #result_normalDeduplication_5 = HashSendToCloudNormalDatadedpulication(AStore5, Cloud_Store5, rand_file_number);

            #if result_normalDeduplication_5 == 1:
             # print("Normal dedup 5,sh in cloud and chunck not in cloud");
              #communication_cost_NormalDatadedpulication_5 = communication_cost_NormalDatadedpulication_5 + Uchunksize5;
          

          communication_cost5 =  communication_cost5 + ((PROB * (ccost51)) + ((1 - PROB) * (ccost52)));
          comm_cost5 =  communication_cost5 + ((PROB * (tmp_ccost51)) + ((1 - PROB) * (tmp_ccost52)));
          
          deduplication_cost5 = deduplication_cost5 + (1 - ( ( (PROB * (dcost51)) + ((1 - PROB) * (dcost52)) ) / (len(str(AStore5[cnt5]))) ));
          dedup_cost5 = dedup_cost5 + (1 - ( ( (PROB * (tmp_dcost51)) + ((1 - PROB) * (tmp_dcost52)) ) / (2048) ));

          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_5 = communication_cost_NormalDatadedpulication_5 + ccost_norm51 + ccost_norm52;
          communication_cost_NormalDatadedpulication_5 = communication_cost_NormalDatadedpulication_5 + ((PROB * (ccost_norm51)) + ((1 - PROB) * (ccost_norm52))); 
          deduplication_cost_Normal_5 = deduplication_cost_Normal_5 + (1 - ( ( (PROB * (dcost_norm51)) + ((1 - PROB) * (0)) ) / (len(str(AStore5[cnt5]))) ));
         
          #result_normalDeduplication_5 = HashSendToCloudNormalDatadedpulication(AStore5, Cloud_Store5, rand_file_number);

          #if result_normalDeduplication_5 == 1:
           # communication_cost_NormalDatadedpulication_5 = communication_cost_NormalDatadedpulication_5 + Uchunksize5;
          
          # Run Without Deduplication protocol
          #communication_cost_WithoutDatadedpulication_5 = communication_cost_WithoutDatadedpulication_5 + ccost_out51 + ccost_out52;
          communication_cost_WithoutDatadedpulication_5 = communication_cost_WithoutDatadedpulication_5 + ((PROB * (ccost_out51)) + ((1 - PROB) * (ccost_out52))); 
          deduplication_cost_Without_5 = deduplication_cost_Without_5 + 0;
          #result_WithoutDeduplication_5 = HashSendToCloudWithoutDatadedpulication(AStore5, Cloud_Store5, rand_file_number);
          
          #if result_WithoutDeduplication_5 == 1:
           # communication_cost_WithoutDatadedpulication_5 = communication_cost_WithoutDatadedpulication_5 + 2*Uchunksize5;
      
           
        
        line5 = fin5.read(Uchunksize5)
        cnt5 += 1;
       
        if len(line5) == 0:
          wi5 = 1
          #print("i am here");
    fin5.close();
    # Number_of_packets_1 = 0;

    ############################## Uchunksize6 = 4K #################################
    fin6 = open(path1+filename, 'r', encoding='latin-1');
    wi6 = 0;
    while wi6 == 0:
      line6 = fin6.read(Uchunksize6)
      # Number_of_packets_6 = Number_of_packets_6 + 1;
        
      while line6 != '':
        #print("i am here");
        AStore6.append(int(hashlib.sha512(line6.encode('utf-8')).hexdigest(), 16))
        ASH_Store6.append(AStore6[cnt6]% 10**SH_LEN)

        # hash_6_1 = str([hashlib.sha512(line6.encode('utf-8')).digest()])
        # print("chunk", len(hash_6_1))

        # print("AStore6:", AStore6[cnt6])
        # print("ASH_Store6: ", ASH_Store6[cnt6])
        # print(".......................")

        matches = db.mem_cur.execute("SELECT ID, n_cl, Item1_cl, Item2_cl, Item3_cl FROM tbl_Uchunksize6 WHERE SH_cl = (?) ORDER BY popularity DESC LIMIT {}".format(POPULARITY), (ASH_Store6[cnt6],)).fetchall()
       
        # print("len matches", len(matches))
        ccost61 = 0;
        ccost62 = 0;
        tmp_ccost61 = 0;
        tmp_ccost62 = 0;

        dcost61 = 0;
        dcost62 = 0;
        tmp_dcost61 = 0;
        tmp_dcost62 = 0;

        ccost_norm61 = 0;
        ccost_norm62 = 0;

        dcost_norm61 = 0;
        dcost_norm62 = 0;

        ccost_out61 = 0;
        ccost_out62 = 0;

        if not matches:

          # Run LEVER protocol
          first_time_upload(tbl_ch6, ASH_Store6[cnt6], AStore6[cnt6])
          print("not find")

          communication_cost6 = communication_cost6 + 0;
          comm_cost6 = comm_cost6 + 0;

          deduplication_cost6 = deduplication_cost6 + 0;
          dedup_cost6 = dedup_cost6 + 0;

          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_6 = communication_cost_NormalDatadedpulication_6 + Uchunksize6;
          communication_cost_NormalDatadedpulication_6 = communication_cost_NormalDatadedpulication_6 + 0;
          deduplication_cost_Normal_6 = deduplication_cost_Normal_6 + 0;
          #result_normalDeduplication_6 = HashSendToCloudNormalDatadedpulication(AStore6, Cloud_Store6, rand_file_number);

          #if result_normalDeduplication_6 == 1:
           # communication_cost_NormalDatadedpulication_6 = communication_cost_NormalDatadedpulication_6 + Uchunksize6;
          
          # Run Without Deduplication protocol
          communication_cost_WithoutDatadedpulication_6 = communication_cost_WithoutDatadedpulication_6 + 2 * Uchunksize6;
          deduplication_cost_Without_6 = deduplication_cost_Without_6 + 0;
          #result_WithoutDeduplication_6 = HashSendToCloudWithoutDatadedpulication(AStore6, Cloud_Store6, rand_file_number);
          
          #if result_WithoutDeduplication_6 == 1:
           # communication_cost_WithoutDatadedpulication_6 = communication_cost_WithoutDatadedpulication_6 + 2*Uchunksize6;
         

        else:
          print("find")
          flag6, key = second_time_upload(tbl_ch6, ASH_Store6[cnt6], AStore6[cnt6], matches)
          
          if flag6 == 1: # sh in cloud and chunck in cloud
            ccost61 = len(str(AStore6[cnt6])) + (((2 * len(str(key))) + len(str(ASH_Store6[cnt6]))) * len(matches));
            tmp_ccost61 = 4192 + (((2 * len(str(key))) + SH_LEN) * len(matches));
           
            dcost61 = len(str(AStore6[cnt6]));
            tmp_dcost61 = 4192;

            # Run Without Deduplication protocol
            ccost_out61 = ccost61;
            deduplication_cost_Without_6 = deduplication_cost_Without_6 + 0;
            
            # Run Normal Deduplication protocol
            ccost_norm61 = ccost61;
            dcost_norm61 = dcost61;


          else: # sh in cloud and chunck not in cloud
            print("I am in chunk6");
            ccost62 = (((2 * len(str(key))) + len(str(ASH_Store6[cnt6]))) * len(str(matches))) + (2 * len(str(key))) + (2 * len(str(ASH_Store6[cnt6]))) + len(str(AStore6[cnt6]));
            tmp_ccost62 = (((2 * len(str(key))) + SH_LEN) * len(str(matches))) + (2 * len(str(key))) + (2 * SH_LEN) + 4192;
            
            dcost62 = (2 * len(str(key))) + (2 * len(str(ASH_Store6[cnt6]))) + len(str(AStore6[cnt6]));
            tmp_dcost62 = (2 * len(str(key))) + (2 * SH_LEN) + 4192;

            # Run Without Deduplication protocol
            ccost_out62 = ccost62;
            deduplication_cost_Without_6 = deduplication_cost_Without_6 + 0;

            # Run Normal Deduplication protocol
            #ccost_norm62 = 0;
            #dcost_norm62 = 0;

            # Run Normal Deduplication protocol
            #result_normalDeduplication_6 = HashSendToCloudNormalDatadedpulication(AStore6, Cloud_Store6, rand_file_number);

            #if result_normalDeduplication_6 == 1:
             # print("Normal dedup 6,sh in cloud and chunck not in cloud");
              #communication_cost_NormalDatadedpulication_6 = communication_cost_NormalDatadedpulication_6 + Uchunksize6;
          

          communication_cost6 =  communication_cost6 + ((PROB * (ccost61)) + ((1 - PROB) * (ccost62)));
          comm_cost6 =  communication_cost6 + ((PROB * (tmp_ccost61)) + ((1 - PROB) * (tmp_ccost62)));
          
          deduplication_cost6 = deduplication_cost6 + (1 - ( ( (PROB * (dcost61)) + ((1 - PROB) * (dcost62)) ) / (len(str(AStore6[cnt6]))) ));
          dedup_cost6 = dedup_cost6 + (1 - ( ( (PROB * (tmp_dcost61)) + ((1 - PROB) * (tmp_dcost62)) ) / (4192) ));

          # Run Normal Deduplication protocol
          #communication_cost_NormalDatadedpulication_6 = communication_cost_NormalDatadedpulication_6 + ccost_norm61 + ccost_norm62;
          communication_cost_NormalDatadedpulication_6 = communication_cost_NormalDatadedpulication_6 + ((PROB * (ccost_norm61)) + ((1 - PROB) * (ccost_norm62))); 
          deduplication_cost_Normal_6 = deduplication_cost_Normal_6 + (1 - ( ( (PROB * (dcost_norm61)) + ((1 - PROB) * (0)) ) / (len(str(AStore6[cnt6]))) ));
         
          #result_normalDeduplication_6 = HashSendToCloudNormalDatadedpulication(AStore6, Cloud_Store6, rand_file_number);

          #if result_normalDeduplication_6 == 1:
           # communication_cost_NormalDatadedpulication_6 = communication_cost_NormalDatadedpulication_6 + Uchunksize6;
          
          # Run Without Deduplication protocol
          #communication_cost_WithoutDatadedpulication_6 = communication_cost_WithoutDatadedpulication_6 + ccost_out61 + ccost_out62;
          communication_cost_WithoutDatadedpulication_6 = communication_cost_WithoutDatadedpulication_6 + ((PROB * (ccost_out61)) + ((1 - PROB) * (ccost_out62))); 
          deduplication_cost_Without_6 = deduplication_cost_Without_6 + 0;
          #result_WithoutDeduplication_6 = HashSendToCloudWithoutDatadedpulication(AStore6, Cloud_Store6, rand_file_number);
          
          #if result_WithoutDeduplication_6 == 1:
           # communication_cost_WithoutDatadedpulication_6 = communication_cost_WithoutDatadedpulication_6 + 2*Uchunksize6;
            
        
        line6 = fin6.read(Uchunksize6)
        cnt6 += 1;
       

        if len(line6) == 0:
          wi6 = 1
          #print("i am here");
    fin6.close();
    # Number_of_packets_6 = 0;



######################## Print Computation Cost ########################
  print("128 bytes result");
  print("communication_LEVER_1  ", communication_cost1) 
  print("communication_Norm_1  ", communication_cost_NormalDatadedpulication_1)     
  print("communication_Out_1  ", communication_cost_WithoutDatadedpulication_1)   
  

  print("256 bytes result");
  print("communication_LEVER_2  ", communication_cost2)
  print("communication_Norm_2  ", communication_cost_NormalDatadedpulication_2)     
  print("communication_Out_2  ", communication_cost_WithoutDatadedpulication_2)   
  

  print("512 bytes result");
  print("communication_LEVER_3  ", communication_cost3) 
  print("communication_Norm_3  ", communication_cost_NormalDatadedpulication_3)    
  print("communication_Out_3  ", communication_cost_WithoutDatadedpulication_3)   
  

  print("1K bytes result");
  print("communication_LEVER_4  ", communication_cost4) 
  print("communication_Norm_4  ", communication_cost_NormalDatadedpulication_4)    
  print("communication_Out_4  ", communication_cost_WithoutDatadedpulication_4)   
  

  print("2K bytes result");
  print("communication_LEVER_5  ", communication_cost5) 
  print("communication_Norm_5  ", communication_cost_NormalDatadedpulication_5)    
  print("communication_Out_5  ", communication_cost_WithoutDatadedpulication_5)   
  

  print("4K bytes result");
  print("communication_LEVER_6  ", communication_cost6) 
  print("communication_Norm_6  ", communication_cost_NormalDatadedpulication_6)   
  print("communication_Out_6  ", communication_cost_WithoutDatadedpulication_6)   
  

  fo_check = open("/Users/pooranian/Desktop/Esorics/Deduplication/check1.txt" , 'a+')

  fo_out = open("/Users/pooranian/Desktop/Esorics/Deduplication/Data_deduplication_result_movie.txt" , 'a+')


  fo_out.write(str(communication_cost1))
  fo_out.write("\n")
  fo_out.write(str(communication_cost2)) 
  fo_out.write("\n")
  fo_out.write(str(communication_cost3)) 
  fo_out.write("\n")
  fo_out.write(str(communication_cost4)) 
  fo_out.write("\n")
  fo_out.write(str(communication_cost5)) 
  fo_out.write("\n")
  fo_out.write(str(communication_cost6)) 
  fo_out.write("\n")
  fo_out.write(str(communication_cost_NormalDatadedpulication_1))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_NormalDatadedpulication_2))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_NormalDatadedpulication_3))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_NormalDatadedpulication_4))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_NormalDatadedpulication_5))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_NormalDatadedpulication_6))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_WithoutDatadedpulication_1))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_WithoutDatadedpulication_2))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_WithoutDatadedpulication_3))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_WithoutDatadedpulication_4))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_WithoutDatadedpulication_5))
  fo_out.write("\n")
  fo_out.write(str(communication_cost_WithoutDatadedpulication_6))
  fo_out.write("\n")
  

  data1 = [communication_cost1, 
          communication_cost2, 
          communication_cost3,
          communication_cost4,
          communication_cost5,
          communication_cost6];
  data2 = [communication_cost_NormalDatadedpulication_1, 
          communication_cost_NormalDatadedpulication_2, 
          communication_cost_NormalDatadedpulication_3,
          communication_cost_NormalDatadedpulication_4,
          communication_cost_NormalDatadedpulication_5,
          communication_cost_NormalDatadedpulication_6];
  data3 = [communication_cost_WithoutDatadedpulication_1, 
          communication_cost_WithoutDatadedpulication_2, 
          communication_cost_WithoutDatadedpulication_3,
          communication_cost_WithoutDatadedpulication_4,
          communication_cost_WithoutDatadedpulication_5,
          communication_cost_WithoutDatadedpulication_6];


  data1_array = np.array(data1)
  data2_array = np.array(data2)
  data3_array = np.array(data3)

  max_data5_array = np.amax(data3_array)
  #print(data1_array)
  t = np.arange(len(data1_array))
  # print("length of t, ",len(t))
  # print("length of data1_array, ",len(data1_array))
  plt.figure(1)
  l1, = plt.plot(t, data1_array, 'r--', label='LEVER')
  plt.hold(True)
  l2, = plt.plot(t, data2_array, 'b^', label='Normal Data deduplication')
  plt.hold(True)
  l3, = plt.plot(t, data3_array, 'ys', label='Without Data deduplication')
  plt.hold(True)

  plt.legend([l1, l2, l3], ["LEVER", "Normal Data deduplication", "Without Data deduplication"], loc=2)

  my_xticks = ['128B','256B','512B','1K','2K','4K']
  plt.xticks(t, my_xticks)
  ax = plt.gca()
  ax.set_ylim(0,max_data5_array*1.5)
  #plt.autoscale()
  #plt.tight_layout()
  plt.gcf().subplots_adjust(left=0.20)
  plt.gcf().subplots_adjust(bottom=0.15)
  plt.xlabel('Chunk size', fontsize=20)
  plt.ylabel('Communication cost (bit)',  fontsize=20)
  #plt.title('About as simple as it gets, folks')
  plt.grid(True)
  plt.savefig("communication_cost.eps")


  ######################## Print Deduplication Cost ########################

  print("128 bytes result");
  print("deduplication_LEVER_1  ", deduplication_cost1) 
  print("deduplication_Norm_1  ", deduplication_cost_Normal_1) 
  print("deduplication_Out_1  ", deduplication_cost_Without_1)   

  print("256 bytes result");
  print("deduplication_LEVER_2  ", deduplication_cost2)  
  print("deduplication_Norm_2  ", deduplication_cost_Normal_2) 
  print("deduplication_Out_2  ", deduplication_cost_Without_2) 

  print("512 bytes result");
  print("deduplication_LEVER_3  ", deduplication_cost3)  
  print("deduplication_Norm_3  ", deduplication_cost_Normal_3) 
  print("deduplication_Out_3  ", deduplication_cost_Without_3) 

  print("1K bytes result");
  print("deduplication_LEVER_4  ", deduplication_cost4)  
  print("deduplication_Norm_4  ", deduplication_cost_Normal_4) 
  print("deduplication_Out_4  ", deduplication_cost_Without_4) 

  print("2K bytes result");
  print("deduplication_LEVER_5  ", deduplication_cost5)  
  print("deduplication_Norm_5  ", deduplication_cost_Normal_5) 
  print("deduplication_Out_5  ", deduplication_cost_Without_5) 

  print("4K bytes result");
  print("deduplication_LEVER_6  ", deduplication_cost6)  
  print("deduplication_Norm_6  ", deduplication_cost_Normal_6) 
  print("deduplication_Out_6  ", deduplication_cost_Without_6) 
  

  fo_out.write(str(deduplication_cost1))
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost2)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost3)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost4)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost5)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost6)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Normal_1))
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Normal_2)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Normal_3)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Normal_4)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Normal_5)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Normal_6)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Without_1))
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Without_2)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Without_3)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Without_4)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Without_5)) 
  fo_out.write("\n")
  fo_out.write(str(deduplication_cost_Without_6)) 
  fo_out.write("\n")

  dcost_data1 = [deduplication_cost1, 
          deduplication_cost2, 
          deduplication_cost3,
          deduplication_cost4,
          deduplication_cost5,
          deduplication_cost6];
  dcost_data2 = [deduplication_cost_Normal_1, 
          deduplication_cost_Normal_2, 
          deduplication_cost_Normal_3,
          deduplication_cost_Normal_4,
          deduplication_cost_Normal_5,
          deduplication_cost_Normal_6];
  dcost_data3 = [deduplication_cost_Without_1, 
          deduplication_cost_Without_2, 
          deduplication_cost_Without_3,
          deduplication_cost_Without_4,
          deduplication_cost_Without_5,
          deduplication_cost_Without_6];

  dcost_data1_array = np.array(dcost_data1)
  dcost_data2_array = np.array(dcost_data2)
  dcost_data3_array = np.array(dcost_data3)

  max_data5_array = np.amax(dcost_data3_array)
  #print(dcost_data1_array)
  t_dcost = np.arange(len(dcost_data1_array))
  # print("length of t_scost, ",len(t_dcost))
  # print("length of dcost_data1_array, ",len(dcost_data1_array))
  plt.figure(2)
  l1_dcost, = plt.plot(t_dcost, dcost_data1_array, 'r^', label='LEVER')
  plt.hold(True)
  l2_dcost, = plt.plot(t_dcost, dcost_data2_array, 'bo--', label='Normal Data deduplication')
  plt.hold(True)
  l3_dcost, = plt.plot(t_dcost, dcost_data3_array, 'ys', label='Without Data deduplication')
  plt.hold(True)

  plt.legend([l1_dcost, l2_dcost, l3_dcost], ["LEVER", "Normal Data deduplication", "Without Data deduplication"], loc=2)
  my_xticks_dcost = ['128B','256B','512B','1K','2K','4K']
  plt.xticks(t_dcost, my_xticks_dcost)
  ax = plt.gca()
  ax.set_ylim(0,max_data5_array*1.5)
  #plt.autoscale()
  #plt.tight_layout()
  plt.gcf().subplots_adjust(left=0.20)
  plt.gcf().subplots_adjust(bottom=0.15)
  plt.xlabel('Chunk size', fontsize=20)
  plt.ylabel('Deduplication percentage (bit)',  fontsize=20)
  #plt.title('About as simple as it gets, folks')
  plt.grid(True)
  plt.savefig("deduplication.eps")


  ###############################################################################################


if __name__ == "__main__":
  # Make an object of database

  db = DB.Database()

  db.create(tbl_ch1)
  db.create(tbl_ch2)
  db.create(tbl_ch3)
  db.create(tbl_ch4)
  db.create(tbl_ch5)
  db.create(tbl_ch6)


  uploading_Uchunksize1()
  uploading_Uchunksize2()
  uploading_Uchunksize3()
  uploading_Uchunksize4()
  uploading_Uchunksize5()
  uploading_Uchunksize6()

  LEVER()

  # db.print_data(tbl_ch1)

  # sql = """SELECT popularity FROM `%s`""" % (tbl_ch1)
  # db.mem_cur.execute(sql)

  # print("\nfetch one:")
  # res = db.mem_cur.fetchone() 
  # rows = db.mem_cur.fetchall() 

  # for row in rows:
  #   print("row",row)
  
  db.close()
