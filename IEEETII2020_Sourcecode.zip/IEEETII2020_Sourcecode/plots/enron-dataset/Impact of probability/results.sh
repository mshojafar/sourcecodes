gnuplot << EOF
reset 
clear

set terminal postscript eps enhanced color solid "Helvetica,34"
set style data histograms
set style fill solid 1.00 border
#set style fill pattern border
set bmargin 3

#######################################################################################
#######################################################COMMUNICATION COST#############
#######################################################################################

############################################################ prob Communication cost - 128bit

set grid ytics
# key/legend
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 1
 
set key width +1
set key outside horizontal                         

#plot 1
set pointsize 2
set output "enron-prob-Communication128.eps"
set ylabel "Commun. Cost (Mbit)" offset 0,0,0
set xlabel "Probability" offset 0,0,0
set ytics nomirror
set xtics("0.1" 1, "0.2" 2, "0.3" 3, "0.4" 4, "0.5" 5, "0.6" 6, "0.7" 7, "0.8" 8, "0.9" 9) textcolor rgbcolor "black" font "Times-Roman,34"
set term post eps "Times-Roman" 34
set key font "Times-Roman,34"

set style fill pattern 1 border -1


plot [] []\
"prob-Communication.data" using 1:2 t "LEVER"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"prob-Communication.data" using 1:6 t "O-DD"  w lp lw 5 ps 2 dt 2 pt 2 lt rgb "red",\
#"prob-Communication.data" using 1:4 t "W-DD"  w lp lw 5 ps 2 pt 3 lt rgb "black"

############################################################ prob Communication cost - 128bit & 4Kbit

set grid ytics
# key/legend
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 1
set key width +1
set key outside horizontal                         

#plot 1
set pointsize 2
set output "enron-prob-Communication128-4k.eps"
set ylabel "Commun. Cost (Mbit)" offset 0,0,0
set xlabel "Probability" offset 0,0,0
set ytics nomirror
set xtics("0.1" 1, "0.2" 2, "0.3" 3, "0.4" 4, "0.5" 5, "0.6" 6, "0.7" 7, "0.8" 8, "0.9" 9) textcolor rgbcolor "black" font "Times-Roman,34"
set term post eps "Times-Roman" 34
set key font "Times-Roman,34"

set style fill pattern 1 border -1



plot [] []\
"prob-Communication.data" using 1:2 t "LEVER-128"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"prob-Communication.data" using 1:3 t "LEVER-4K"  w lp lw 5 ps 2 dt 2 pt 6 lt rgb "blue", \
"prob-Communication.data" using 1:6 t "O-DD-128"  w lp lw 5 ps 2 pt 2 lt rgb "red", \
"prob-Communication.data" using 1:7 t "O-DD-4K"  w lp lw 5 ps 2 dt 2 pt 2 lt rgb "red"

############################################################ prob Communication cost - 4Kbit

set grid ytics
# key/legend
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 1

set key width +1
set key outside horizontal                         

#plot 1
set pointsize 2
set output "enron-prob-Communication4K.eps"
set ylabel "Commun. Cost (Mbit)" offset 0,0,0
set xlabel "Probability" offset 0,0,0
set ytics nomirror
set xtics("0.1" 1, "0.2" 2, "0.3" 3, "0.4" 4, "0.5" 5, "0.6" 6, "0.7" 7, "0.8" 8, "0.9" 9) textcolor rgbcolor "black" font "Times-Roman,34"
set term post eps "Times-Roman" 34
set key font "Times-Roman,34"

set style fill pattern 1 border -1

plot [] []\
"prob-Communication.data" using 1:3 t "LEVER"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"prob-Communication.data" using 1:7 t "O-DD"  w lp lw 5 ps 2 dt 2 pt 2 lt rgb "red", \
#"prob-Communication.data" using 1:5 t "W-DD"  w lp lw 5 ps 2 pt 3 lt rgb "black"



#######################################################################################
#######################################################DEDUPLICATION COST#############
#######################################################################################

############################################################ prob dedubplication cost - 128bit

set grid ytics
# key/legend
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 1

set key width +1
set key outside horizontal                         

#plot 1
set pointsize 2
set output "enron-prob-Deduplication128.eps"
set ylabel "Deduplication (%)" offset 0,0,0
set xlabel "Probability" offset 0,0,0
set ytics nomirror
set xtics("0.1" 1, "0.2" 2, "0.3" 3, "0.4" 4, "0.5" 5, "0.6" 6, "0.7" 7, "0.8" 8, "0.9" 9) textcolor rgbcolor "black" font "Times-Roman,34"
set term post eps "Times-Roman" 34
set key font "Times-Roman,34"

set style fill pattern 1 border -1

plot [] []\
"prob-Deduplication.data" using 1:2 t "LEVER"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"prob-Deduplication.data" using 1:6 t "O-DD"  w lp lw 5 ps 2 dt 2 pt 2 lt rgb "red",\
#"prob-Deduplication.data" using 1:4 t "W-DD"  w lp lw 5 ps 2 pt 3 lt rgb "black"

############################################################ prob Deduplication cost - 128bit & 4Kbit

set grid ytics
# key/legend
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 1

set key width +1
set key outside horizontal                         

#plot 1
set pointsize 2
set output "enron-prob-Deduplication128-4K.eps"
set ylabel "Deduplication (%)" offset 0,0,0
set xlabel "Probability" offset 0,0,0
set ytics nomirror
set xtics("0.1" 1, "0.2" 2, "0.3" 3, "0.4" 4, "0.5" 5, "0.6" 6, "0.7" 7, "0.8" 8, "0.9" 9) textcolor rgbcolor "black" font "Times-Roman,34"
set term post eps "Times-Roman" 34
set key font "Times-Roman,34"

set style fill pattern 1 border -1

plot [] []\
"prob-Deduplication.data" using 1:2 t "LEVER-128"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"prob-Deduplication.data" using 1:3 t "LEVER-4K"  w lp lw 5 ps 2 dt 2 pt 6 lt rgb "blue", \
"prob-Deduplication.data" using 1:6 t "O-DD-128"  w lp lw 5 ps 2 pt 2 lt rgb "red", \
"prob-Deduplication.data" using 1:7 t "O-DD-4K"  w lp lw 5 ps 2 dt 2 pt 2 lt rgb "red"

############################################################ prob Deduplication cost - 4Kbit

set grid ytics
# key/legend
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 1


set key width +1
set key outside horizontal                         

#plot 1
set pointsize 2
set output "enron-prob-Deduplication4K.eps"
set ylabel "Deduplication (%)" offset 0,0,0
set xlabel "Probability" offset 0,0,0
set ytics nomirror
set xtics("0.1" 1, "0.2" 2, "0.3" 3, "0.4" 4, "0.5" 5, "0.6" 6, "0.7" 7, "0.8" 8, "0.9" 9) textcolor rgbcolor "black" font "Times-Roman,34"
set term post eps "Times-Roman" 34
set key font "Times-Roman,34"

set style fill pattern 1 border -1

plot [] []\
"prob-Deduplication.data" using 1:3 t "LEVER"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"prob-Deduplication.data" using 1:7 t "O-DD"  w lp lw 5 ps 2 dt 2 pt 2 lt rgb "red",\
#"prob-Deduplication.data" using 1:5 t "W-DD"  w lp lw 5 ps 2 pt 3 lt rgb "black"


EOF

