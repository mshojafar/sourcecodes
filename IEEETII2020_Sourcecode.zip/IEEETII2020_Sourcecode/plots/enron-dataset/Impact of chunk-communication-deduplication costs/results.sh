gnuplot << EOF
reset 
clear

set terminal postscript eps enhanced color solid "Helvetica,34"
set style data histograms
set style fill solid 1.00 border
#set style fill pattern border
set bmargin 4

############################################################
############################################################ chunk Communication cost

set grid ytics
# key/legend
set key box
set key right top
#set key bmargin 
set key spacing 1
set rmargin 1
set key width +1
set key inside vertical                         

#plot 1
set pointsize 2
set output "enron-chunk-Communication.eps"
set ylabel "Commun. Cost (Mbit)" offset 0,0,0
set xlabel "Chunk Size (bit)" offset 0,0,0
set ytics nomirror
set xtics("128" 1, "256" 2, "512" 3, "1K" 4, "2K" 5, "4K" 6) textcolor rgbcolor "black" font "Times-Roman,34" rotate by -90
set term post eps "Times-Roman" 34
set key font "Times-Roman,34"

#"chunk-Communication.data" using 2:1 smooth cumul t "FNN" w lp lw 3 lt rgb "black", \

plot [] []\
"chunk-Communication.data" using 1:2 t "LEVER"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"chunk-Communication.data" using 1:3 t "O-DD"  w lp lw 5 ps 2 dt 2 pt 2 lt rgb "red",\
"chunk-Communication.data" using 1:4 t "W-DD"  w lp lw 5 ps 2 pt 3 lt rgb "black"



#"chunk-Communication.data" using 1:2:3 with yerrorbars, \
#"chunk-Communication.data" using 1:($2-$3):($2-$3):($2+$3):($2+$3) with candlesticks

############################################################ chunk Deduplication cost

set grid ytics
# key/legend
set key box
set key right top
#set key bmargin 
set key spacing 1
set rmargin 1
set key width +1
set key inside vertical                         

#plot 1
set pointsize 2
set output "enron-chunk-Deduplication.eps"
set ylabel "Deduplication (%)" offset 0,0,0
set xlabel "Chunk Size (bit)" offset 0,0,0
set ytics nomirror
set xtics("128" 1, "256" 2, "512" 3, "1K" 4, "2K" 5, "4K" 6) textcolor rgbcolor "black" font "Times-Roman,34" rotate by -90
set term post eps "Times-Roman" 34
set key font "Times-Roman,34"

#"chunk-Deduplication.data" using 2:1 smooth cumul t "FNN" w lp lw 3 lt rgb "black", \

plot [] []\
"chunk-Deduplication.data" using 1:2 t "LEVER"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"chunk-Deduplication.data" using 1:3 t "O-DD"  w lp lw 5 ps 2 dt 2 pt 2 lt rgb "red",\
"chunk-Deduplication.data" using 1:4 t "W-DD"  w lp lw 5 ps 2 pt 3 lt rgb "black"

#"chunk-Deduplication.data" using 1:2:3 with yerrorbars, \
#"chunk-Deduplication.data" using 1:($2-$3):($2-$3):($2+$3):($2+$3) with candlesticks


EOF

