gnuplot << EOF
reset 
clear

set terminal postscript eps enhanced color solid "Helvetica,24"
set style data histograms
set style fill solid 1.00 border
#set style fill pattern border
set bmargin 5

############################################################
############################################################ Communication cost

set grid ytics
# key/legend
set key box
set key right top
#set key bmargin 
set key spacing 1
set rmargin 1
set key width +1
set key inside vertical                         

#plot 1
set pointsize 2
set output "Communication-new.eps"
set ylabel "Communication Cost (Mbit)" offset 0,0,0
set xlabel "Chunk size (bit)" offset 0,0,0
set ytics nomirror
set xtics("128" 1, "256" 2, "512" 3, "1K" 4, "2K" 5, "4K" 6) textcolor rgbcolor "black" font "Times-Roman,24" rotate by -90
set term post eps "Times-Roman" 24
set key font "Times-Roman,24"

#"FPR-attack.data" using 2:1 smooth cumul t "FNN" w lp lw 3 lt rgb "black", \

plot [] []\
"Communication-new.data" using 1:2 t "LEVER"  w lp lw 5 ps 2 pt 6 lt rgb "black", \
"Communication-new.data" using 1:3 t "CC-ND"  w lp lw 5 ps 2 pt 4 lt rgb "blue", \
"Communication-new.data" using 1:4 t "CC-W\D"  w lp lw 5 ps 2 pt 5 lt rgb "red"
#"Communication-25dirty.data" using 1:4 t "W-DD" w lp lw 5 dt 4 lt rgb "green", \


#"FPR-attack.data" using 1:2:3 with yerrorbars, \
#"FPR-attack.data" using 1:($2-$3):($2-$3):($2+$3):($2+$3) with candlesticks

############################################################ Deduplication cost

set grid ytics
# key/legend
set key box
set key right top
#set key bmargin 
set key spacing 1
set rmargin 1
set key width +1
set key inside vertical                         

#plot 1
set pointsize 2
set output "Deduplication.eps"
set ylabel "Deduplication Cost" offset 0,0,0
set xlabel "Chunk size (bit)" offset 0,0,0
set ytics nomirror
set xtics("128" 1, "256" 2, "512" 3, "1K" 4, "2K" 5, "4K" 6) textcolor rgbcolor "black" font "Times-Roman,24" rotate by -90
set term post eps "Times-Roman" 24
set key font "Times-Roman,24"

#"FPR-attack.data" using 2:1 smooth cumul t "FNN" w lp lw 3 lt rgb "black", \

plot [] []\
"Deduplication.data" using 1:2 t "LEVER"  w lp lw 5 ps 2 pt 6 lt rgb "black", \
"Deduplication.data" using 1:3 t "CC-ND"  w lp lw 5 ps 2 pt 3 lt rgb "blue"
#"Deduplication.data" using 1:4 t "CC-W\D"  w lp lw 5 ps 2 pt 5 lt rgb "red"
#"Communication-25dirty.data" using 1:4 t "W-DD" w lp lw 5 dt 4 lt rgb "green", \


#"FPR-attack.data" using 1:2:3 with yerrorbars, \
#"FPR-attack.data" using 1:($2-$3):($2-$3):($2+$3):($2+$3) with candlesticks


EOF

