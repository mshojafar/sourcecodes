gnuplot << EOF
reset 
clear

set terminal postscript eps enhanced color solid "Helvetica,34"

########## Enron-dataset
set grid ytics
#set style fill solid 1.00 border -1

set output "dataset1.eps"
set key box
set key right top
set key inside horizontal  
#set rmargin 5
set style data histograms
set style histogram clustered gap 1
set key font "Times-Roman,34"

set style fill pattern 1 border -1

set term post eps "Times-Roman" 34
set ytics nomirror
set xtics ("< 1" 0, "1-5" 1, "5-10" 2, "10-20" 3, ">20" 4) textcolor rgbcolor "black" font "Times-Roman,35" rotate by -45 autojustify
set key top right samplen 2
set boxwidth 0.9 absolute
set xlabel "File Size (KB)"
set ylabel "Number of Files"

set style fill solid

set style line 1 lt rgb 'blue' lw 3 pt 6

plot [][]\
"dataset1.data" using 2:xtic(1) ls 2 lw 3 title "Enron" #fillstyle pattern 1

################################################################################
########## Oxford-dataset
set grid ytics
#set style fill solid 1.00 border -1

set output "dataset2.eps"
set key box
set key left top
set key inside horizontal  
#set rmargin 5
set style data histograms
set style histogram clustered gap 1
set key font "Times-Roman,34"

set style fill pattern 1 border -1

set term post eps "Times-Roman" 30
set ytics nomirror
set xtics ("<0.1" 0, "0.1-0.3" 1, "0.3-0.5" 2, "0.5-0.8" 3) textcolor rgbcolor "black" font "Times-Roman,35" rotate by -45 autojustify
set key top left samplen 2
set boxwidth 0.9 absolute
set xlabel "File Size (MB)"
set ylabel "Number of Files"

set style fill solid

set style line 1 lt rgb 'blue' lw 3 pt 6


plot [][]\
"dataset2.data" using 2:xtic(1) ls 2 lw 3 title "Oxford" #fillstyle pattern 1

EOF

