function [FP,NC,F,EC] = CreateVMs(numberOfSwitches,nodeProcessingPowerToBandwidhRatio, numbrOfFunctions,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
    energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio, bandwidth,B)%Matrix of bandwidth
    %Create NC,EC --> NC: nodes processing capacity, EC: nodes' energy consumption
    for i=1:numberOfSwitches
        NC(i)=nodeProcessingPowerToBandwidhRatio*sum(B(:,i));
        EC(i)=NC(i)*energyToProcessingPowerRatio;
    end
    %Create F: functions associated with nodes
    for tmpI=1:1
    F=zeros(numberOfSwitches,numbrOfFunctions);
    numOfNodWithFunc=numberOfSwitches*prcntNodThtCanHstFunc;
    tmpRndF=rand(1,numberOfSwitches);
    for i=1:numOfNodWithFunc
        %randomly select a node (node that the random number assigned to it
        %is the minimum number)
        tmpX=find(tmpRndF==min(tmpRndF));
        F(tmpX(1),:)=AssignFuncToNode(numbrOfFunctions,prcntFncThatHostedByANode);
        tmpRndF(tmpX(1))=1;
    end
    end
    %Create FP: required processing power of funtionss
    for i=1:numbrOfFunctions
%         FP(i)=(rand()*2*funcProcessingPowerToBandwidthRatio*bandwidth)/(1024*1024);
        FP(i)=rand()*2*funcProcessingPowerToBandwidthRatio;
    end
end
function [res]=AssignFuncToNode(numbrOfFunctions,prcntFncThatHostedByANode)
    res=zeros(1,numbrOfFunctions);
    tmp=ceil(prcntFncThatHostedByANode*numbrOfFunctions);
    tmpRnd=rand(1,numbrOfFunctions);
    for i=1:tmp
        tmpX=find(tmpRnd==min(tmpRnd));
        res(tmpX(1))=1;
        tmpRnd(tmpX(1))=1;
    end
end