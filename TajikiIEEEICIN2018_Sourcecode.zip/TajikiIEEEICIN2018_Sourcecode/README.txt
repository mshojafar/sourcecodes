
README.txt

Help file to run the project written in Matlab.

Dr. Mohammad Mahdi Tajiki did this implementation. 
Dr. Mohammad Shojafar, Dr. Mohammad Mahdi Tajiki helped on idea brainstorming and documentation. 
S. Salsano, L. Chiaraviglio, B. Akbari helped in English correction and leading the team.

If you need any help on the code, feel free to drop a message to

Dr. Mohammad Shojafar <mohammad.shojafar@gmail.com> or <m.shojafar@ieee.org> or
Dr. Mohammad Mahdi Tajiki <mohammad59mt@gmail.com> 

Step of the running project:

How to run the code:

The code is done using CVX solver on MATLAB.

First, you are requested to download and install CVX solver from http://cvxr.com/cvx/doc/solver.html

Then, you can easily access model file for all the scenarios of the published paper in Wiley CPE in the ‘Simulation’ folder.

1. ’CreateTopology.m’ is used to establish the topology of the network, e.g., Abilene topology
2. ‘CreateVMs.m’ is used to establish VMs riding on each server/node of the designed topology
3. ‘SolverForONR.m’ and ‘SFC_ONR.m’ are the solver code (CVX) for ONR algorithm for without SFC and with SFC, respectively.  
4. ‘HNR-RR.m’ is used to address the relaxation of HNR algorithm. 
5. The rest m files are used to plot the results and make analytics of the results.

I will be glad to cite our paper with the following details in your research papers:
Wiley CPE:

M.M. Tajiki, M. Shojafar, S. Salsano, M. Shojafar, L. Chiaraviglio, B. Akbari, "Energy-efficient Path Allocation Heuristic for Service Function Chaining", The 21st IEEE Conference on Innovations in Clouds, Internet and Networks, (ICIN 2018), Paris, France, pp. 1-8, 2018. DOI: https://doi.org/10.1109/ICIN.2018.8401618


The papers are supported and fully funded by H2020 EU project named:

SUPERFLUIDITY

Project Link: http://superfluidity.eu/

(grant agreement No. 671566)

