function [C,T,s,d,R,K,p] = ReadFlows(numberOfSwitches, prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow, avgPrcntNmbrFlwFrmASrc,...
maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,NmbrOfFunc,prcntOfAvgBandDmnd,bandwidth,minTolrblDly,maxTolrbDly)
%     prcntOfEdgeNode=prcntOfEdgeNode/100;prcntOfSrcNode=prcntOfSrcNode/100;prcntOfDestPerFlow=prcntOfDestPerFlow/100;prcntOfAvgBandDmnd=prcntOfAvgBandDmnd/100;
    %1. Select the Edge Nodes: output-->isEdge
    for tmpi=1:1
    if prcntOfEdgeNode<=0.5
        isEdge=zeros(1,numberOfSwitches);
        for i=1:numberOfSwitches*prcntOfEdgeNode
            x=randi(numberOfSwitches);
            while isEdge(x)
                x=randi(numberOfSwitches);
            end
            isEdge(x)=1;
        end
    else
        isEdge=ones(1,numberOfSwitches);
        for i=1:numberOfSwitches-numberOfSwitches*prcntOfEdgeNode
            x=randi(numberOfSwitches);
            while ~isEdge(x)
                x=randi(numberOfSwitches);
            end
            isEdge(x)=0;
        end
    end
    end
    %2. Select the Source Nodes: output-->isSrc,nmbrEdgeNode
    for tmpi=1:1
    nmbrEdgeNode=sum(find(isEdge)>0);
    if prcntOfSrcNode<=0.5
        isSrc=zeros(1,nmbrEdgeNode);
        for i=1:nmbrEdgeNode*prcntOfSrcNode
            x=randi(nmbrEdgeNode);
            while isSrc(x)
                x=randi(nmbrEdgeNode);
            end
            isSrc(x)=1;
        end
    else
        isSrc=ones(1,nmbrEdgeNode);
        for i=1:nmbrEdgeNode-nmbrEdgeNode*prcntOfSrcNode
            x=randi(nmbrEdgeNode);
            while ~isSrc(x)
                x=randi(nmbrEdgeNode);
            end
            isSrc(x)=0;
        end
    end
    end
    %3. Create nmbrSrcNode,s,d,p    %s: source switches, d: destination switches, p:number of flows
    for tmpi=1:1
    nmbrSrcNode=sum(find(isSrc)>0);
    tmpI=1;
    tmpSrcArry=find(isSrc);
    tmpTotalDstArry=find(isEdge);
    for i=1:nmbrSrcNode
        srcNode=tmpSrcArry(i);
        nmbrOfFlwsFrmThisSrc=geornd(1/(avgPrcntNmbrFlwFrmASrc*nmbrEdgeNode));
        if(nmbrOfFlwsFrmThisSrc > maxNmbrFlwFrmASrc)
            nmbrOfFlwsFrmThisSrc = maxNmbrFlwFrmASrc;
        end
        tmpAvalblDst=AvailableDestination(tmpTotalDstArry,prcntOfDestPerFlow);
        for j=1:nmbrOfFlwsFrmThisSrc
            s(tmpI)=srcNode;
            d(tmpI)=tmpAvalblDst(randi(size(tmpAvalblDst,2)));
            cent=10;
            while (s(tmpI)==d(tmpI)) && cent>0
                d(tmpI)=tmpAvalblDst(randi(size(tmpAvalblDst,2)));
                cent=cent-1;
            end
            if cent==0
                disp('***********************error in ReadFlows, error number 4****************************');
            end
            tmpI=tmpI+1;
        end
    end
    p=size(s,2);
    end
    %4. Create K: sequence of required functions (zero in K means no function. K(1,:)=[4,3,5,0,0]-->functions 4,3, and 5 must be executed on flow 1 
    for tmpi=1:1
    K=zeros(p,maxNmbrFuncPerFlw);
    %edameye 4: foreach flow
    for i=1:p
        if avgPrcntOfNmbrOfFuncPerFlw==1
            display('The input "avgNmbrOfFuncPerFlw" must be greater than 1');
            return;
        end
        tmpNmbFuncForThisFlow=geornd(1/avgPrcntOfNmbrOfFuncPerFlw);
        if(tmpNmbFuncForThisFlow > maxNmbrFuncPerFlw)
            tmpNmbFuncForThisFlow = maxNmbrFuncPerFlw;
        elseif(tmpNmbFuncForThisFlow < minNmbrFuncPerFlw)
            tmpNmbFuncForThisFlow = minNmbrFuncPerFlw;
        end
        %assign functions to flow
        for j=1:NmbrOfFunc
            funcPool(j)=j;
        end
        indexOfLastElementOfFuncPool=NmbrOfFunc;
        for j=1:tmpNmbFuncForThisFlow 
            tmpIndJ= randi(indexOfLastElementOfFuncPool);
            K(i,j)=funcPool(tmpIndJ);
            funcPool(tmpIndJ)=funcPool(indexOfLastElementOfFuncPool);
            indexOfLastElementOfFuncPool=indexOfLastElementOfFuncPool-1;
        end
    end
    end
    %5. Create R: functions requirements of flows
    for tmpi=1:1
    R=zeros(NmbrOfFunc, size(s,2));
    for i=1:size(s,2)
        for j=1:size(K,2)
            if K(i,j)~=0
                R(K(i,j),i)=1;
            end
        end
    end
    end
    %Create C: flow bandwidth requirement
    for tmpi=1:1
    C=zeros(1,size(s,2));
    for i=1:size(s,2)
        C(i)=2*prcntOfAvgBandDmnd*bandwidth*rand();
    end
    end
    %Create T: maximum tolerable propagation delay,
    for tempi=1:1
        T=zeros(1,size(s,2));
        for i=1:size(T,2)
            T(i)=minTolrblDly+(maxTolrbDly-minTolrblDly)*rand();
        end
    end
end

function [res]=AvailableDestination(TotalDstArry,prcntOfDestPerFlow)
    for i=1:prcntOfDestPerFlow*size(TotalDstArry,2)
        res(i)=TotalDstArry(randi(size(TotalDstArry,2)));
    end
end