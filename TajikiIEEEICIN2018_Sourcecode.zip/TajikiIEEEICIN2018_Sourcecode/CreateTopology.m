function [n,B,D] = CreateTopology(bandwidth,topologyName)%B: matrix of links' bandwidth, D: Links' propagation delay
    if strcmp(topologyName,'Abilene')
        [n,B,D]=CreateTopology_Abilent(bandwidth);
    elseif strcmp(topologyName,'NSFNET')
        [n,B,D]=CreateTopology_NSFNET(bandwidth);
    end
end