function [NewC] = IncreaseFlowDemands(C,flowDemandIncreamentFactor)
    %Increase the demand by at most a factor of increamentFactor
    NewC=C;
    for i=1:size(NewC,2)
        NewC(i)=C(i)+2*rand()*flowDemandIncreamentFactor*C(i);
    end
end