%if readFrom=='' ---> generate traffic
%n: number of switches, miu: maximum link utilization
function SFC_FNR(strtOfTimeSlot,endOfTimeSlots,readFrom,ifReadFromFile_DemandIncrementRatio,ifReadFromFile_miu,ifReadFromFile_miu2)
    if size(readFrom,1)==0
    
        [prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow, avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,...
        minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,...
        prcntNodThtCanHstFunc,prcntFncThatHostedByANode,energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,miu,miu2,...
        flowDemandIncreamentFactor]= SetParameter_RA();
        %B: matrix of links' bandwidth, 
        %D: Links' propagation delay

        [n,B,D]=CreateTopology(bandwidth,'Abilene');
    %     [n,B,D]=CreateTopology(bandwidth,'NSFNET');

        %C: flow bandwidth requirement, 
        %T: maximum tolerable propagation delay,
        %s: source switches, 
        %d: destination switches, 
        %R: functions requirements of flows, 
        %K: sequence of required functions
        %p:number of flows    
        [C,T,s,d,R,K,p]=ReadFlows(n, prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow, avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc,...
            avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,bandwidth,minTolrblDly,maxTolrbDly);
    %     load('C:\Users\Mahdi\Desktop\SFC\Flows.txt','T','C','s','d','R','K','p','-mat');
    %     p=numberOfFlowsThisItr;
    %     T=T(1:numberOfFlowsThisItr);
    %     C=C(1:numberOfFlowsThisItr);
    %     s=s(1:numberOfFlowsThisItr);d=d(1:numberOfFlowsThisItr);
    %     R=R(:,1:numberOfFlowsThisItr);K=K(1:numberOfFlowsThisItr,:);

        %FP: required processing power of funtionss, 
        %NC: nodes processing capacity, 
        %F: functions associated withe nodes,
        %EC: nodes' energy consumption
        [FP,NC,F,EC]=CreateVMs(n,nodeProcessingPowerToBandwidhRatio, numbrOfFunctions,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio, bandwidth,B);
        EC=MapVMEnergyConsumptionBetween150And300(EC);
        
        [failurProb,MT]=FailurProbForDifferentPath(n);
    else
        [A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0]= LoadResult(readFrom);
        if ifReadFromFile_DemandIncrementRatio~=0
            flowDemandIncreamentFactor=ifReadFromFile_DemandIncrementRatio; end
        if ifReadFromFile_miu~=0
            miu=ifReadFromFile_miu; end
        if ifReadFromFile_miu2~=0
            miu2=ifReadFromFile_miu2; end
    end
    input(['p=',num2str(p),' press any key to continue']);
    %B: matrix of links' bandwidth, 
    %D: Links' propagation delay
    %C: flow bandwidth requirement, 
    %T: maximum tolerable propagation delay,
    %s: source switches, 
    %d: destination switches, 
    %R: functions requirements of flows, 
    %K: sequence of required functions
    %p:number of flows
    %FP: required processing power of funtionss, 
    %NC: nodes processing capacity, 
    %F: functions associated withe nodes,
    %EC: nodes' energy consumption
    %WN0: current state of switches(On/Off),

    A0=zeros(n,n,p);U0=zeros(n,numbrOfFunctions,p);WN0=zeros(1,n);
    for i=strtOfTimeSlot:endOfTimeSlots
        tic
        [A,U,WN]=SolverForFNR(n,p,numbrOfFunctions,miu,miu2,B,MT,C,s,d,R,FP,NC,F,EC,failurProb);
        [A,U,WN]=RecoveryFromCVXBug(A,U,WN);
        toc
        display(['for p=',num2str(p),' itr=',num2str(i)]);
        SaveResult(['FNR_itr=',num2str(i)],A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,'');
        C=IncreaseFlowDemands(C,flowDemandIncreamentFactor);
    end
end

function [EC]=MapVMEnergyConsumptionBetween150And300(EC)
    EC=EC-min(EC);
    EC=EC/max(EC);
    EC=150+EC*150;
end
function [failurProb,MT]=FailurProbForDifferentPath(n)
    MT=0.4;
    switchFailProb=0.001*ones(1,n);
    failurProb=ones(1,2^n);
    for i=1:n
        for j=2^(i-1):2^i:2^n
            for z=0:2^(i-1)-1
                failurProb(j+z)=failurProb(j+z)*(1-switchFailProb(i));
            end
        end
    end
    failurProb=1-failurProb;
end
function [failurProb,MT]=FailurProbForDifferentPath2Dim(n,numberOfFlows)
    MT=0.4;
    switchFailProb=0.001*ones(1,n);
    failurProb = zeros(2^n, numberOfFlows);
    failurProb=ones(1,2^n);
    for i=1:n
        for j=2^(i-1):2^i:2^n
            for z=0:2^(i-1)-1
                failurProb(j+z)=failurProb(j+z)*(1-switchFailProb(i));
            end
        end
    end
    failurProb=1-failurProb;
end