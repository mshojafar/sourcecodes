function [A,U,WN]=SolverForNR(n,p,x,miu,miu2,B,D,C,T,s,d,R,K,FP,NC,F,EC,A0)
    cvx_begin quiet
        cvx_solver MOSEK 

        variable A(n,n,p) binary;
        variable U(n,x,p) binary;
        variable WN(n) binary;
                 
        subject to
        
            %Eq. 6
            for i=1:n
                tmpEq6=sum(U(i,:,1).*FP)*C(1);
                for f=2:p
                    tmpEq6=tmpEq6+sum(U(i,:,f).*FP)*C(f);
                end
                tmpEq6<=miu2*NC(i);
            end
            %Eq. 7
            for i=1:n
                for j=1:n
                    tmpEq7=A(i,j,1)*C(1);
                    for f=2:p
                        tmpEq7=tmpEq7+A(i,j,f)*C(f);
                    end
                    tmpEq7<=miu*B(i,j);
                end
            end
        
            %Routing
            %Eq. 8
            for f=1:p
                sum(A(:,s(f),f))==0;
                sum(A(d(f),:,f))==0;
            end
            %Eq. 9
            for f=1:p
                sum(A(s(f),:,f))==1;
                sum(A(:,d(f),f))==1;
            end
            %Eq. 10
            for f=1:p
                for i=1:n
                    if(i~=d(f) && i~=s(f))
                        sum(A(i,:,f))==sum(A(:,i,f));
                    end
                end
            end
            %Eq. 11
            for f=1:p
                for i=1:n
                    sum(A(i,:,f))<=1;
                end
            end
            
            %Service Function Chaining
            %Eq. 2
            for m=1:x
                for f=1:p
                    sum(U(:,m,f))>=R(m,f);
                end
            end
            %Eq. 3
            for m=1:x
                for f=1:p
                    for j=1:n
                        if j~=s(f)
                            sum(A(:,j,f))>=U(j,m,f);
                        end
                    end
                end
            end
            %Eq. 4
            for f=1:p
                for i=1:n
                    for m=1:x
                        U(i,m,f)<=F(i,m);
                    end
                end
            end
            %Eq. 5
            for f=1:p
                for m=1:x
                    sum(U(:,m,f))<=1;
                end
            end
            
            %Energy Efficiency
            %Eq. 19
            for i=1:n
                tmp_SFC_RR6=sum(U(i,:,1));
                for f=2:p
                    tmp_SFC_RR6=tmp_SFC_RR6+sum(U(i,:,f));
                end
                WN(i)<=tmp_SFC_RR6;
            end
            %Eq. 20
            for i=1:n
                tmp_SFC_RR7=sum(U(i,:,1));
                for f=2:p
                    tmp_SFC_RR7=tmp_SFC_RR7+sum(U(i,:,f));
                end
%                 WN(i)*tmp_SFC_RR7==tmp_SFC_RR7;
                WN(i)*(1+p*x)>=tmp_SFC_RR7;
            end            

        %Objective Function Eq.s 1, 18
%         Obj1 = sum(sum(sum(A+A0-2*A.*A0)));
        Obj2 = WN(1)*EC(1);
        for i=2:n
            Obj2 = Obj2+WN(i)*EC(i);
        end
%         minimize(Obj1+Obj2);
        minimize(Obj2);
            
    cvx_end
end