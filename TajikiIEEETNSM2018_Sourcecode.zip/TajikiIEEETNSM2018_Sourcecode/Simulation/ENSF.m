function ENSF(readFrom,frst4LettrOfFileToReadFrm_RR_iOrRA_n,SortInput,LoopAllowed_Mode,LT_Mode)
    if size(readFrom,1)==0, readFrom='/Users/mohammadshojafar/Dropbox/Mahdi_SFC_Simulation/New/'; else,readFrom=[readFrom,'\'];end
    if size(frst4LettrOfFileToReadFrm_RR_iOrRA_n,1)==0, frst4LettrOfFileToReadFrm_RR_iOrRA_n='SFRA'; end
    files=dir(readFrom);
    for j=1:size(files,1)
        if strcmp(files(j).name,'.')==0 && strcmp(files(j).name,'..')==0 && files(j).isdir==0 && strcmp(files(j).name(1:4),frst4LettrOfFileToReadFrm_RR_iOrRA_n)
            [A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0]= LoadResult([readFrom,files(j).name]);
            %B: matrix of links' bandwidth, 
            %D: Links' propagation delay
            %C: flow bandwidth requirement, 
            %T: maximum tolerable propagation delay,
            %s: source switches, 
            %d: destination switches, 
            %R: functions requirements of flows, 
            %K: sequence of required functions
            %p:number of flows
            %FP: required processing power of funtionss, 
            %NC: nodes processing capacity, 
            %F: functions associated withe nodes,
            %EC: nodes' energy consumption
            %WN: current state of Servers
            
%             [A0,U0,WN0,NA0]=FindPerivousState(readFrom,files(j).name);
            tic
            if LT_Mode, F=(F*0+1); end;
            
%              NC=NC/10;
            
            %B=B*miu;
            %NC=NC*miu2;

B=B*5;
            [D]=ConvertCommonDToCSPFCompatibleD(D);
            tB=B;
            A=zeros(n,n,p);
            U=zeros(n,numbrOfFunctions,p);
            %if SortInput is true then sort flows based on their size
            if SortInput, ind=SortFlowsBasedOnTheirSize(C);else,ind=1:p;end
            WN=zeros(1,n);           
            for f=1:p
                %display(['flow ',num2str(f)]);
                if LoopAllowed_Mode
                    [tA,tU,tB,NC,WN]=ENSF_Solver_LoopAllowed(n,numbrOfFunctions,ConvertZeroToInf(tB),D,C(ind(f)),s(ind(f)),d(ind(f)),K(ind(f),:),FP,NC,F,0,WN,EC);
                else
                    [tA,tU,tB,NC,WN]=ENSF_Solver_NoLoop(n,numbrOfFunctions,ConvertZeroToInf(tB),D,C(ind(f)),s(ind(f)),d(ind(f)),K(ind(f),:),FP,NC,F,0,WN,EC);
                end
                A(:,:,ind(f))=tA;
                U(:,:,ind(f))=tU;
%                 for i=1:n
%                     WN(i)=(WN(i)+sum(U(i,:)))>0;
%                 end
            end
%             for i=1:n
%                 WN(i)=(sum(sum(U(i,:,:)))>0);
%             end
            toc
            B=B/miu;
            NC=NC/miu2;
            display(['for p= ',num2str(p)]);
            tmpName=files(j).name;
            if LT_Mode, prefixName='LT_ENSF_'; else, prefixName='ST_ENSF_'; end
            if LoopAllowed_Mode, prefixName=[prefixName,'WithLoop_'];end
            SaveResult([prefixName,tmpName(8)],A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode,prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0,tmpName(9:size(tmpName,2)));
        end
    end
end

function [B]=ConvertZeroToInf(B)
    for i=1:size(B,1)
        for j=1:size(B,2)
            if B(i,j)==0
                B(i,j)=inf;
            end
        end
    end
end

function [A,U,B,NC,WN]=ENSF_Solver_NoLoop(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD,WN,EC)
    BFactor=ones(n,n);
    A=zeros(n,n);
    U=zeros(n,numbrOfFunctions);
    G=BRatioToD*B+(1-BRatioToD)*D;
    %fix the NaN value (devisioned by zero )
    for i=1:n
        for j=1:n
            if isnan(G(i,j))
                G(i,j)=0;
            end
        end
    end
    %find the proper path from s to d with respect to SFC -- to this end
    %in each step find the shortest path from current node to the next required function
    step=0;
    for i=1:size(K,2)
        if K(i)~=0
            %Eliminate links that has a free bandwidth less than the flow required
            %capacity
            for i2=1:n
                for j2=1:n
                    if (BFactor(i2,j2)*B(i2,j2))<C
                        G(i2,j2)=0;
                    end
                end
            end
            %find shortest path from source to all nodes
            [dist, path, pred] = graphshortestpath(sparse(G), s);
            %remove nodes that doesn't support the required function
            for j=1:n
                if F(j,K(i))==0
                    dist(j)=inf;
                end
            end
            %remove nodes that doesn't have neough processing power
            for j=1:n
                if NC(j)< C*FP(K(i))
                    dist(j)=inf;
                end
            end
            
            %do not enter to destination
            dist(d)=inf;
            
            if min(dist==inf)
                disp('*****************error in ENSFF_RR, cannot find the result #3**********************');
            end
            %Select the nearest node that support the required function
%             ind=find(dist==min(dist));
%             %maybe two nodes has similar cost
%             ind=ind(1);
            ind = SelectPathBasedOnEnergyAndLength(dist,WN,EC);
            U(ind,K(i))=1;
            WN(ind)=1;
            NC(ind)=NC(ind)-C*FP(K(i));
            %calculate the path
            tmpInd=ind;
            if ind~=s
                step=step+1;
            end
            while ind~=s
                A(pred(ind),ind)=step;
                B(pred(ind),ind)=B(pred(ind),ind)-C;   
                
                BFactor(pred(ind),:)=BFactor(pred(ind),:)*inf;
                BFactor(:,pred(ind))=BFactor(:,pred(ind))*inf;
                
                ind=pred(ind);
            end
            %change the source to the node we are in currently
            s=tmpInd;
        end
    end
    %Eliminate links that has a free bandwidth less than the flow required
    %capacity
    for i2=1:n
        for j2=1:n
            if (BFactor(i2,j2)*B(i2,j2))<C
                G(i2,j2)=0;
            end
        end
    end
    %go to destination
    [dist, path, pred] = graphshortestpath(sparse(G), s);
    if d~=s
        step=step+1;
    end
    while d~=s
        A(pred(d),d)=step;
        B(pred(d),d)=B(pred(d),d)-C;
        d=pred(d);
    end
    B=ConvertInfToZero(B);
end

function [A,U,B,NC,WN]=ENSF_Solver_LoopAllowed(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD,WN,EC)
    A=zeros(n,n);
    U=zeros(n,numbrOfFunctions);
    G=BRatioToD*B+(1-BRatioToD)*D;
    %fix the NaN value (devisioned by zero )
    for i=1:n
        for j=1:n
            if isnan(G(i,j))
                G(i,j)=0;
            end
        end
    end
    %find the proper path from s to d with respect to SFC -- to this end
    %in each step find the shortest path from current node to the next required function
    step=0;
    for i=1:size(K,2)
        if K(i)~=0
            %Eliminate links that has a free bandwidth less than the flow required
            %capacity
            for i2=1:n
                for j2=1:n
                    if B(i2,j2)<C
                        G(i2,j2)=0;
                    end
                end
            end
            %find shortest path from source to all nodes
            [dist, path, pred] = graphshortestpath(sparse(G), s);
            %remove nodes that doesn't support the required function
            for j=1:n
                if F(j,K(i))==0
                    dist(j)=inf;
                end
            end
            %remove nodes that doesn't have neough processing power
            for j=1:n
                if NC(j)< C*FP(K(i))
                    dist(j)=inf;
                end
            end
            
            %do not enter to destination
            dist(d)=inf;
            
            if min(dist==inf)
                disp('*****************error in ENSFF_RR, cannot find the result #3**********************');
            end
            %Select the nearest node that support the required function
%             ind=find(dist==min(dist));
%             %maybe two nodes has similar cost
%             ind=ind(1);
            ind = SelectPathBasedOnEnergyAndLength(dist,WN,EC);
            U(ind,K(i))=1;
            WN(ind)=1;
            NC(ind)=NC(ind)-C*FP(K(i));
            %calculate the path
            tmpInd=ind;
            if ind~=s
                step=step+1;
            end
            while ind~=s
                A(pred(ind),ind)=step;
                B(pred(ind),ind)=B(pred(ind),ind)-C;   
                                
                ind=pred(ind);
            end
            %change the source to the node we are in currently
            s=tmpInd;
        end
    end
    %Eliminate links that has a free bandwidth less than the flow required
    %capacity
    for i2=1:n
        for j2=1:n
            if B(i2,j2)<C
                G(i2,j2)=0;
            end
        end
    end
    %go to destination
    [dist, path, pred] = graphshortestpath(sparse(G), s);
    if d~=s
        step=step+1;
    end
    while d~=s
        A(pred(d),d)=step;
        B(pred(d),d)=B(pred(d),d)-C;
        d=pred(d);
    end
    B=ConvertInfToZero(B);
end
        
function [B]=ConvertInfToZero(B)
    for i=1:size(B,1)
        for j=1:size(B,2)
            if B(i,j)==inf
                B(i,j)=0;
            end
        end
    end
end
        
function [ind]=SelectPathBasedOnEnergyAndLength(dist,WN,EC)
    %Select the nearest node that support the required function
%     ind=find(dist==min(dist));
    %maybe two nodes has similar cost
    energy=zeros(1,size(dist,2));energy=1./energy;
    for i=1:size(dist,2)
        if dist(i)~=inf
            energy(i)=CalculateRequiredEnergy(i,WN,EC);
        end
    end
    ind=find(energy==min(energy));
%select one that has a lower length
    selectedInd=ind(1);
    for i=2:size(ind,2)
        if dist(selectedInd)>dist(ind(i))
            selectedInd=ind(i);
        end
    end
    ind=selectedInd;
end

function [energy]=CalculateRequiredEnergy(dest,WN,EC)
    if WN(dest)
        energy=0;
    else
        energy=EC(dest);
    end
%     energy=0;
%     while dest~=src
%         if ~WN(dest)
%             energy=energy+EC(dest);
%         end
%         dest=pred(dest);
%     end
end

function [ind]=SortFlowsBasedOnTheirSize(C)
    ind=zeros(1,size(C,2));
    for i=1:size(C,2)
        tmp=find(C==max(C));
        ind(i)=tmp(1);
        C(ind(i))=-1;
    end
end