function PlotComputationalComplexity()
addrsToSaveFigures='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Simulation\Figures\';

RRR=[32.892162
821.056459
1641.2961
2443.52015
3252.86534
4871.390759
6494.06084
]; RRR=RRR';

NSFF=[0.004724
0.097299
0.195752
0.297572
0.394888
0.674906
0.870655
];NSFF=NSFF';

ENSFF=[0.004551
0.10095
0.203979
0.312174
0.42594
0.607792
0.812298
];ENSFF=ENSFF';

Flows=[10
250
500
750
1000
1500
2000
];Flows=Flows';

NewPlot3InputMatrix(1,RRR,NSFF,ENSFF,Flows,'Time (s)','Number of Flows',addrsToSaveFigures,'cmplxty3');
% input('press enter');
% NewPlot2InputMatrix(2,NSFF,ENSFF,Flows,'Time (s)','Number of Flows',addrsToSaveFigures,'cmplxty2');
end

function NewPlot3InputMatrix(figNumber, A, B, C, Xdata, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(Xdata,[A;B;C],'MarkerSize',15,'LineWidth',2);
  
    
    set(plot1(1),'Marker','*','MarkerFaceColor','g','MarkerEdgeColor','g','color','g','LineStyle','--');
    set(plot1(2),'Marker','d','MarkerFaceColor','b','MarkerEdgeColor','b','color','b','LineStyle','-.');
    set(plot1(3),'Marker','o','MarkerFaceColor','y','MarkerEdgeColor','y','color','y','MarkerSize',10);

    %Create Legend
    set(plot1(1),'DisplayName','RRR');
    set(plot1(2),'DisplayName','ENSFF');
    set(plot1(3),'DisplayName','NSFF');
    
    set(gca, 'YScale', 'log')
%     set(gca, 'XScale', 'log')
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    yticks([0 10^-2 1 10^2 10^4])
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',15,'XTick',Xdata);
    
    Leg1=legend('RRR','NSFF','ENSF');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    
    %remove white space from the pdf file
    %     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];



    %Save to file
    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
end
