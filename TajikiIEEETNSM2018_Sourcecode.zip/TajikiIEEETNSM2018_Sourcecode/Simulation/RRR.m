%n: number of switches, miu: maximum link utilization
function RRR(addr,frst4LettrOfFileToReadFrm_RR_iOrRA_n,SortFlows,LongTermMode)
    
    if size(addr,1)==0,addr='/Users/mohammadshojafar/Dropbox/Mahdi_SFC_Simulation/New/';
    else,addr=[addr,'\'];end
    
    if size(frst4LettrOfFileToReadFrm_RR_iOrRA_n,1)==0
        frst4LettrOfFileToReadFrm_RR_iOrRA_n='SFRA';
    end
    files=dir(addr);
    for j=1:size(files,1)
%         if strcmp(files(j).name,'.')==0 && strcmp(files(j).name,'..')==0 && files(j).isdir==0 && strcmp(files(j).name(1:4),'RR_i')
        if strcmp(files(j).name,'.')==0&&strcmp(files(j).name,'..')==0 && files(j).isdir==0 &&strcmp(files(j).name(1:4),frst4LettrOfFileToReadFrm_RR_iOrRA_n)
            [A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0]= LoadResult([addr,files(j).name]);
            [WN0,CL,SL]=CurrentState(n,numbrOfFunctions);
            WN0=WN0';
            A=zeros(n,n,p);
            NA=zeros(n,n,p);
            U=zeros(n,numbrOfFunctions,p);
            unsolvedCounter=0;unsolvedIndx=zeros(p);
            tic
            WN=WN0;
            
            if LongTermMode,F=(F*0+1);end
            
            if SortFlows, [T,s,d,R,K,C]=SortFlowsBasedOnSize(T,s,d,R,K,C,p); end
%             NC=NC/6;
                        
            for f=1:p
                [tA,tU,tWN,tNA]=SolverFor3R(n,1,numbrOfFunctions,miu,miu2,B,D,C(f),T(f),s(f),d(f),R(:,f),K(f,:),FP,NC,F,EC,WN,CL,SL);
                [tA,tU,tWN,tNA]=RecoveryFromCVXBug(tNA,tA,tU,tWN);              
%                 [WN,CL,SL]=ChangeCurrentState_RA(CL,SL,tA,median(C),tU,tWN,WN,n,numbrOfFunctions);
                [WN,CL,SL]=ChangeCurrentState_RA(CL,SL,tA,C(f),tU,tWN,WN,n,numbrOfFunctions);
                A(:,:,f)=tA;
                NA(:,:,f)=tNA;
                U(:,:,f)=tU;
                if(sum(sum(tA))==n*n)
                    unsolvedCounter=unsolvedCounter+1;
                    unsolvedIndx(f)=1;
                end
            end
%             t2=cputime;
            toc
            display(['time for ',num2str(p)]);
%             display(['time for ',num2str(p),' flows = ',num2str(t2-t1)]);
            display(unsolvedCounter);
            A0=zeros(n,n,p);U0=zeros(n,numbrOfFunctions,p);WN0=zeros(1,n);NA0=A0;
            tmpName=files(j).name;
            if LongTermMode, tmpText='LT_3R_';else, tmpText='ST_3R_';end
            SaveResult(tmpText,A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0,tmpName(8:size(tmpName,2)));
        end
    end
end
function [ind]=SortSize(C)
    ind=zeros(1,size(C,2));
    for i=1:size(C,2)
        tmp=find(C==max(C));
        ind(i)=tmp(1);
        C(ind(i))=-1;
    end
end
function [nT,ns,nd,nR,nK,nC]=SortFlowsBasedOnSize(T,s,d,R,K,C,p)
    ind=SortSize(C);
    nT=T(ind);
    ns=s(ind);
    nd=d(ind);
    nR=zeros(size(R));
    nK=zeros(size(K));
%     nR(:,:)=R(ind,:);
%     nK=K(ind,:);
    nC=C(ind);
    for i=1:p
        nR(:,i)=R(:,ind(i));
        nK(i,:)=K(ind(i),:);
    end
end
function [A,U,WN,NA]=SolverFor3R(n,p,x,miu,miu2,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL)
    cvx_begin quiet
        cvx_solver MOSEK

        variable A(n,n) binary;
        variable U(n,x) binary;
        variable WN(n) binary;
        variable NA(n,n) integer;
                 
        subject to
            %Routing
            %Eq. 8
            sum(A(:,s))==0;
            sum(A(d,:))==0;
            %Eq. 9
            sum(A(s,:))==1;
            sum(A(:,d))==1;
            %Eq. 10
            for i=1:n
                if(i~=d && i~=s)
                    sum(A(i,:))==sum(A(:,i));
                end
            end
            %Eq. 11 prevent loops
            for i=1:n
                sum(A(i,:))<=1;
            end
            %Eq. 12
            sum(sum(A.*D))<=T(1);
            %Eq. 23
            for i=1:n
                for j=1:n
                    A(i,j)*C(1)+CL(i,j)<=miu*B(i,j);
                end
            end            
            
            %Service Function Chaining
            %Eq. 2
            for m=1:x
%                 sum(U(:,m))>=R(m,1);
                sum(U(:,m))==R(m,1);
            end
            %Eq. 3
            for m=1:x
                for j=1:n
                    if j~=s
                        sum(A(:,j))>=U(j,m);
                    end
                end
            end
            %Eq. 4
            for i=1:n
                for m=1:x
                    U(i,m)<=F(i,m);
                end
            end
            %Eq. 5
            for m=1:x
                sum(U(:,m))<=1;
            end
            %Eq. 13
            for i=1:n
                for j=1:n
                    NA(i,j)>=A(i,j);
                end
            end
            %Eq. 14
            for i=1:n
                if i~=d
                    for j=1:n
                        NA(i,j)<=n*A(i,j);
                    end
                end
            end
            %Eq. 14+
            for i=1:n
                if i~=d
                    NA(d,i)==0;
                end
            end
            %Eq. 15
            for i=1:n
                if(i~=d && i~=s)
                    tmpNAIJ=NA(i,1);
                    tmpNAJI=NA(1,i);
                    tmpAJI=A(1,i);
                    for j=2:n
                        tmpNAIJ=tmpNAIJ+NA(i,j);
                        tmpNAJI=tmpNAJI+NA(j,i);
                        tmpAJI=tmpAJI+A(j,i);
                    end
                    tmpNAIJ==tmpNAJI+tmpAJI;
                end
            end
            %Eq. 15+
            for i=1:1
            if d==1
                NA(d,d)==sum(NA(2:size(NA,2),d))+1;
            elseif d==size(NA,2)
                NA(d,d)==sum(NA(1:d-1,d))+1;
            else
                NA(d,d)==sum(NA(1:d-1,d))+sum(NA(d+1:size(NA,2),d))+1;
            end
            end
            %Eq. 16
            sum(NA(s,:))==1;
            %Eq. 17
            for i=1:n
                for I=1:n
                    for v=1:size(find(K(1,:)),2)
                        if(K(1,v)~=0)
                            for z=1:v-1
                                (1-U(i,K(1,v)))*(2*n+1)+sum(NA(i,:))>=(U(I,K(1,z))-1)*(2*n+1)+sum(NA(I,:));
                            end
                        end
                    end
                end
            end
            
            %Energy Efficiency
            %Eq. 19
            for i=1:n
                WN(i)<=sum(U(i,:));
            end
            %Eq. 20
            for i=1:n
                WN(i)*(1+p*x)>=sum(U(i,:));
            end
            %Eq. 22
            for i=1:n
                tmpEq22=(U(i,1)*C(1)+SL(i,1))*FP(1);
                for m=2:x
                    tmpEq22=tmpEq22+(U(i,m)*C(1)+SL(i,m))*FP(m);
                end
                tmpEq22<=miu2*NC(i);
            end
            
            %Eq. New
%             for i=1:n
%                 WN(i)*WN0(i)>=WN0(i);
%             end
            
            

        %Objective Function Eq. 21
        Obj = (1-WN0(1))*WN(1)*EC(1);
        for i=2:n
            Obj = Obj + (1-WN0(i))*WN(i)*EC(i);
        end
        Obj=Obj+sum(sum(A))/(n*n);
        minimize(Obj);
            
    cvx_end
end


