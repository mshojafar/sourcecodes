%n: number of switches,                 %Miut: if 0 then the miu in file will be used otherwise it is used as maximum link/server utilization
%LongTermMode: if it is true then GRR_LongTerm otherwise GRR_ShortTerm
function GRR(strtOfTimeSlot,endOfTimeSlots,readFrom,miut,LongTermMode,frst4LettrOfFileToReadFrm_RR_iOrRA_n) 
    if size(readFrom,1)==0,readFrom='/Users/mohammadshojafar/Dropbox/Mahdi_SFC_Simulation/New/';
    else,readFrom=[readFrom,'\'];end
    if size(frst4LettrOfFileToReadFrm_RR_iOrRA_n,1)==0,frst4LettrOfFileToReadFrm_RR_iOrRA_n='SFRA';end
    files=dir(readFrom);
    for j=1:size(files,1)
        if strcmp(files(j).name,'.')==0 && strcmp(files(j).name,'..')==0 && files(j).isdir==0 && strcmp(files(j).name(1:4),frst4LettrOfFileToReadFrm_RR_iOrRA_n)
            [A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0]= LoadResult([readFrom,files(j).name]);
            %B: matrix of links' bandwidth, 
            %D: Links' propagation delay
            %C: flow bandwidth requirement, 
            %T: maximum tolerable propagation delay,
            %s: source switches, 
            %d: destination switches, 
            %R: functions requirements of flows, 
            %K: sequence of required functions
            %p:number of flows
            %FP: required processing power of funtionss, 
            %NC: nodes processing capacity, 
            %F: functions associated withe nodes,
            %EC: nodes' energy consumption
            %WN0: current state of servers(On/Off),
            %CL: current bandwidth load on links, 
            %SL: current processing load per function on each link
            if LongTermMode
                F=(F*0+1);end
            if miut~=0
                miu=miut;miu2=miut;end
            
%             NC=NC/10;

            
            A=0*A;U=0*U;WN=0*WN;NA=0*NA;
            tmpName=files(j).name;
            for i=strtOfTimeSlot:endOfTimeSlots
                tic
                A0=A;U0=U;WN0=WN;NA0=NA;
                [A,U,WN,NA]=SolverForRR(n,p,numbrOfFunctions,miu,miu2,B,D,C,T,s,d,R,K,FP,NC,F,EC,A0);
                [A,U,WN,NA]=RecoveryFromCVXBug(NA,A,U,WN);
                toc
                display(['for p=',num2str(p),' itr=',num2str(i)]);
                if LongTermMode
                    tempText='LT_GRR_itr=';
                else
                    tempText='ST_GRR_itr=';
                end
                SaveResult([tempText,num2str(i)],A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                    avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                    bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                    energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0,tmpName(3:size(tmpName,2)));
                C=IncreaseFlowDemands(C,flowDemandIncreamentFactor);
            end
        end
    end
end

function [A,U,WN,NA]=SolverForRR(n,p,x,miu,miu2,B,D,C,T,s,d,R,K,FP,NC,F,EC,A0)
    cvx_begin quiet
        cvx_solver MOSEK

        variable A(n,n,p) binary;
        variable U(n,x,p) binary;
        variable WN(n) binary;
        variable NA(n,n,p) integer;
                 
        subject to
        
            %Eq. 6
            for i=1:n
                tmpEq6=sum(U(i,:,1).*FP)*C(1);
                for f=2:p
                    tmpEq6=tmpEq6+sum(U(i,:,f).*FP)*C(f);
                end
                tmpEq6<=miu2*NC(i);
            end
            %Eq. 7
            for i=1:n
                for j=1:n
                    tmpEq7=A(i,j,1)*C(1);
                    for f=2:p
                        tmpEq7=tmpEq7+A(i,j,f)*C(f);
                    end
                    tmpEq7<=miu*B(i,j);
                end
            end
        
            %Routing
            %Eq. 8
            for f=1:p
                sum(A(:,s(f),f))==0;
                sum(A(d(f),:,f))==0;
            end
            %Eq. 9
            for f=1:p
                sum(A(s(f),:,f))==1;
                sum(A(:,d(f),f))==1;
            end
            %Eq. 10
            for f=1:p
                for i=1:n
                    if(i~=d(f) && i~=s(f))
                        sum(A(i,:,f))==sum(A(:,i,f));
                    end
                end
            end
            %Eq. 9 prevent loops
            for f=1:p
                for i=1:n
                    sum(A(i,:,f))<=1;
                end
            end
            %Eq. 12
            for f=1:p
                sum(sum(A(:,:,f).*D))<=T(f);
            end          
            
            %Service Function Chaining
            %Eq. 2
            for m=1:x
                for f=1:p
%                     sum(U(:,m,f))>=R(m,f);
                    sum(U(:,m,f))==R(m,f);
                end
            end
            %Eq. 3
            for m=1:x
                for f=1:p
                    for j=1:n
                        if j~=s(f)
                            sum(A(:,j,f))>=U(j,m,f);
                        end
                    end
                end
            end
            %Eq. 4
            for f=1:p
                for i=1:n
                    for m=1:x
                        U(i,m,f)<=F(i,m);
                    end
                end
            end
            %Eq. 5
            for f=1:p
                for m=1:x
                    sum(U(:,m,f))<=1;
                end
            end
            %Eq. 13
            for i=1:n
                for j=1:n
                    for f=1:p
                        NA(i,j,f)>=A(i,j,f);
                    end
                end
            end
            %Eq. 14
            for f=1:p
                for i=1:n
                    if i~=d(f)
                        for j=1:n
%                             NA(i,j,f)==NA(i,j,f)*A(i,j,f);
                            NA(i,j,f)<=n*A(i,j,f);
                        end
                    end
                end
            end
            %Eq. 14+
            for f=1:p
                for i=1:n
                    if i~=d(f)
                        NA(d(f),i,f)==0;
                    end
                end
            end
            %Eq. 15
            for f=1:p
                for i=1:n
                    if(i~=d(f) && i~=s(f))
                        tmpNAIJ=NA(i,1,f);
                        tmpNAJI=NA(1,i,f);
                        tmpAJI=A(1,i,f);
                        for j=2:n
                            tmpNAIJ=tmpNAIJ+NA(i,j,f);
                            tmpNAJI=tmpNAJI+NA(j,i,f);
                            tmpAJI=tmpAJI+A(j,i,f);
                        end
                        tmpNAIJ==tmpNAJI+tmpAJI;
                    end
                end
            end
            %Eq. 15+
            for f=1:p
%                 tmpNA2=NA(1,d(f),f);
%                 tmpA2=A(1,d(f),f);
%                 for i=2:n
%                     tmpNA2=NA(2,d(f),f);
%                     tmpA2=A(2,d(f),f);
%                 end
%                 NA(d(f),d(f),f)==tmpNA2+tmpA2;
                if(d(f)==1)
                    NA(d(f),d(f),f)==sum(NA(2:size(NA,2),d(f),f))+1;
                elseif(d(f)==size(NA,2))
                    NA(d(f),d(f),f)==sum(NA(1:d(f)-1,d(f),f))+1;
                else
                    NA(d(f),d(f),f)==sum(NA(1:d(f)-1,d(f),f))+sum(NA(d(f)+1:size(NA,2),d(f),f))+1;
                end
            end
            %Eq. 16
            for f=1:p
                sum(NA(s(f),:,f))==1;
            end
            %Eq. 17
            for f=1:p
                for i=1:n
                    for I=1:n
                        for v=1:size(find(K(f,:)),2)
                            if(K(f,v)~=0)
                                for z=1:v-1
                                    (1-U(i,K(f,v),f))*(2*n+1)+sum(NA(i,:,f))>=(U(I,K(f,z),f)-1)*(2*n+1)+sum(NA(I,:,f));
                                end
                            end
                        end
                    end
                end
            end
            
            %Energy Efficiency
            %Eq. 19
            for i=1:n
                tmp_SFC_RR6=sum(U(i,:,1));
                for f=2:p
                    tmp_SFC_RR6=tmp_SFC_RR6+sum(U(i,:,f));
                end
                WN(i)<=tmp_SFC_RR6;
            end
            %Eq. 20
            for i=1:n
                tmp_SFC_RR7=sum(U(i,:,1));
                for f=2:p
                    tmp_SFC_RR7=tmp_SFC_RR7+sum(U(i,:,f));
                end
%                 WN(i)*tmp_SFC_RR7==tmp_SFC_RR7;
                WN(i)*(1+p*x)>=tmp_SFC_RR7;
            end            

        %Objective Function Eq.s 1, 18
%         Obj1 = sum(sum(sum(A+A0-2*A.*A0)));
        Obj2 = WN(1)*EC(1);
        for i=2:n
            Obj2 = Obj2+WN(i)*EC(i);
        end
%         minimize(Obj1+Obj2);
        minimize(Obj2);
            
    cvx_end
end