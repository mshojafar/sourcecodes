%Plot figures for all folders with name '__'
%lets start
function PlotResults_AllSubFoldersOf(FolderAddres)
    if size(FolderAddres,1)==0
        FolderAddres='C:\Users\Mahdi\Desktop\SFC\';
    else
        FolderAddres=[FolderAddres,'\'];
    end
    folders=dir(FolderAddres);
    %for each folder with starting name '__'
    for iFolder=1:size(folders,1)
        if strcmp(folders(iFolder).name,'.')==0 && strcmp(folders(iFolder).name,'..')==0 && folders(iFolder).isdir==1 && strcmp(folders(iFolder).name(1:2),'__')
            readFrom=[FolderAddres,folders(iFolder).name,'\'];

            files=dir(readFrom);
            %for each file in the folder
            for i=1:size(files,1)
                if strcmp(files(i).name,'.')==0 && strcmp(files(i).name,'..')==0 && files(i).isdir==0 && strcmp(files(i).name,'Notation.txt')==0 && strcmp(files(i).name,'Notation.pdf')==0
                    [A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                        avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                        bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                        energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0] ...
                        =LoadResult([readFrom,files(i).name]);
                    %setting the parameters: link utilization, node utilization,
                    %delay, etc.
                    for tmpItr=1:1
                    if strcmp(files(i).name(1:4),'SFRA')
                        NameOfFile=files(i).name(6:findstr(files(i).name,' -Time'));
                        [SFRA_linkUtilization]=LinkUtilization(n,p,A,C,B);
                        [SFRA_nodeUtilization]=NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC);
                        [SFRA_powerConsumption]=PowerConsumption(n,WN,EC);
                        [SFRA_netSideEffect]=NetworkSideEffect(n,p,A,A0);
                        [SFRA_averagePathLength]=AveragePathLength(p,A,s,d);
                        [SFRA_avgDelay,RA_numberOfDelayedFlow]=Delay(p,A,s,D,T);
                    elseif strcmp(files(i).name(1:7),'ST_GRR_')
                        ST_GRR_ind=str2double(files(i).name(12));
                        [ST_GRR_linkUtilization(ST_GRR_ind)]=AverageOverNaN(LinkUtilization(n,p,A,C,B));
                        [ST_GRR_nodeUtilization(ST_GRR_ind)]=mean(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [ST_GRR_MlinkUtilization(ST_GRR_ind)]=MaxOverNaN(LinkUtilization(n,p,A,C,B));
                        [ST_GRR_MnodeUtilization(ST_GRR_ind)]=max(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [ST_GRR_powerConsumption(ST_GRR_ind)]=PowerConsumption(n,WN,EC);
                        [ST_GRR_netSideEffect(ST_GRR_ind)]=NetworkSideEffect(n,p,A,A0);
                        [ST_GRR_averagePathLength(ST_GRR_ind)]=AveragePathLength(p,A,s,d);
                        [ST_GRR_avgDelay(ST_GRR_ind),RR_numberOfDelayedFlow(ST_GRR_ind)]=Delay(p,A,s,D,T);
                    elseif strcmp(files(i).name(1:4),'NSFF')
                        [NSFF_RA_linkUtilization]=LinkUtilization(n,p,A,C,B);
                        [NSFF_RA_nodeUtilization]=NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC);
                        [NSFF_RA_powerConsumption]=PowerConsumption(n,WN,EC);
                        [NSFF_RA_netSideEffect]=NetworkSideEffect(n,p,A,A0);
                        [NSFF_RA_averagePathLength]=AveragePathLength(p,A,s,d);
                        [NSFF_RA_avgDelay,NSFF_RA_numberOfDelayedFlow]=Delay(p,A,s,D,T);
                    elseif strcmp(files(i).name(1:6),'ST_3R_')
                        NEW_RR_ind=str2double(files(i).name(11));
                        [ST_3R_linkUtilization(NEW_RR_ind)]=AverageOverNaN(LinkUtilization(n,p,A,C,B));
                        [ST_3R_nodeUtilization(NEW_RR_ind)]=mean(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [ST_3R_MlinkUtilization(NEW_RR_ind)]=MaxOverNaN(LinkUtilization(n,p,A,C,B));
                        [ST_3R_MnodeUtilization(NEW_RR_ind)]=max(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [ST_3R_powerConsumption(NEW_RR_ind)]=PowerConsumption(n,WN,EC);
                        [ST_3R_netSideEffect(NEW_RR_ind)]=NetworkSideEffect(n,p,A,A0);
                        [ST_3R_averagePathLength(NEW_RR_ind)]=AveragePathLength(p,A,s,d);
                        [ST_3R_avgDelay(NEW_RR_ind),NEW_RR_numberOfDelayedFlow(NEW_RR_ind)]=Delay(p,A,s,D,T);
                    elseif strcmp(files(i).name(1:8),'ST_ENSF_')
                        ENSFF_S_ind=str2double(files(i).name(13));
                        [ST_ENSF_linkUtilization(ENSFF_S_ind)]=AverageOverNaN(LinkUtilization(n,p,A,C,B));
                        [ST_ENSF_nodeUtilization(ENSFF_S_ind)]=mean(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [ST_ENSF_MlinkUtilization(ENSFF_S_ind)]=MaxOverNaN(LinkUtilization(n,p,A,C,B));
                        [ST_ENSF_MnodeUtilization(ENSFF_S_ind)]=max(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [ST_ENSF_powerConsumption(ENSFF_S_ind)]=PowerConsumption(n,WN,EC);
                        [ST_ENSF_netSideEffect(ENSFF_S_ind)]=NetworkSideEffect(n,p,A,A0);
                        [ST_ENSF_averagePathLength(ENSFF_S_ind)]=AveragePathLength(p,A,s,d);
                        [ST_ENSF_avgDelay(ENSFF_S_ind),ENSFF_S_numberOfDelayedFlow(ENSFF_S_ind)]=Delay(p,A,s,D,T);
                    end
                    end
                end
            end   

            addrsToSaveFigures='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Simulation\Figures\';

            %plot figures
            for iTemp=1:1
            NewPlot4InputMatrix(1,ST_GRR_linkUtilization*100,ST_3R_linkUtilization*100,ST_ENSF_linkUtilization*100,...
                'Average Link Utilization [%]','Iteration',addrsToSaveFigures,['lnkUtl',NameOfFile]);
            NewPlot4InputMatrix(5,ST_GRR_MlinkUtilization*100,ST_3R_MlinkUtilization*100,ST_ENSF_MlinkUtilization*100,...
                'Maximum Link Utilization [%]','Iteration',addrsToSaveFigures,['mlnkUtl',NameOfFile]);
            
%             Plot6InputMatrix(1,ST_GRR_linkUtilization*100,ST_3R_linkUtilization*100,ST_ENSF_linkUtilization*100,...
%                 ST_GRR_MlinkUtilization*100,ST_3R_MlinkUtilization*100,ST_ENSF_MlinkUtilization*100,...
%                 'Link Utilization [%]','Iteration',addrsToSaveFigures,['lnkUtl',NameOfFile]);
            
            NewPlot4InputMatrix(2,ST_GRR_nodeUtilization*100,ST_3R_nodeUtilization*100,ST_ENSF_nodeUtilization*100,...
                'Average Server Utilization [%]','Iteration',addrsToSaveFigures,['ndeUtl',NameOfFile]);
            NewPlot4InputMatrix(6,ST_GRR_MnodeUtilization*100,ST_3R_MnodeUtilization*100,ST_ENSF_MnodeUtilization*100,...
                'Maximum Server Utilization [%]','Iteration',addrsToSaveFigures,['mndeUtl',NameOfFile]);
            NewPlot4InputMatrix(3,ST_GRR_powerConsumption,ST_3R_powerConsumption,ST_ENSF_powerConsumption,...
                'Power Consumption [J]','Iteration',addrsToSaveFigures,['pwrCns',NameOfFile]);
            NewPlot4InputMatrix(4,ST_GRR_averagePathLength,ST_3R_averagePathLength,ST_ENSF_averagePathLength,...
                'Average Path Length','Iteration',addrsToSaveFigures,['pthLen',NameOfFile]);
            end
        end
    end
end
function [linkUtilization]=LinkUtilization(n,p,A,C,B)
    linkLoad=LinkLoad(n,p,A,C);
    linkUtilization=linkLoad./B;
end
function [nodeUtilization]=NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC)
    %NC: nodes processing capacity,
    nodeLoad=NodeLoad(n,p,numbrOfFunctions,U,C,FP);
    nodeUtilization=nodeLoad./NC;
end
function [linkLoad]=LinkLoad(n,p,A,C)
    linkLoad=zeros(n,n);
    for i=1:n
        for j=1:n
            for f=1:p
                linkLoad(i,j)=linkLoad(i,j)+(A(i,j,f)>0)*C(f);
            end
        end
    end
end
function [nodeLoad]=NodeLoad(n,p,numberOfFunction,U,C,FP)
    %FP: required processing power of funtionss, 
    nodeLoad=zeros(1,n);
    for i=1:n
        for f=1:p
            for m=1:numberOfFunction
                nodeLoad(i)=nodeLoad(i)+U(i,m,f)*C(f)*FP(m);
            end
        end
    end
end
function [powerConsumption]=PowerConsumption(n,WN,EC)
    %EC: nodes' energy consumption
    %WN: state of switches(On/Off),    
    powerConsumption=0;
    for i=1:n
        powerConsumption=powerConsumption+WN(i)*EC(i);
    end
end
function [netSideEffect]=NetworkSideEffect(n,p,A,A0)
    netSideEffect=0;
    for i=1:n
        for j=1:n
            for f=1:p
                netSideEffect=netSideEffect+abs(A(i,j,f)-A0(i,j,f));
            end
        end
    end
end
function [averagePathLength]=AveragePathLength(p,A,s,d)
    averagePathLength=0;
    for i=1:p
        averagePathLength=averagePathLength+PathLength(i,A,s(i),d(i));
    end
    averagePathLength=averagePathLength/p;
end
function [pathLength]=PathLength(flowIndex,A,s,d)
%     pathLength=0;
%     maxAllowedLength=100;
%     while sum(A(s,:,flowIndex)) && maxAllowedLength    
%         pathLength=pathLength+1;
%         s1=find(A(s,:,flowIndex));
%         %in NSFF loops are not forbiden but instead if a flow return to a
%         %switch then when it exit the number is increased
%         %e.g., A(1,2,3)=1, A(1,3,3)=2
%         s1=find(A(s,:,flowIndex)==min(A(s,s1,flowIndex)));
%         A(s,s1,flowIndex)=0;
%         s=s1;
%         maxAllowedLength=maxAllowedLength-1;
%     end
%     if maxAllowedLength==0
%         disp('************error in analysis #1***************');
%     end
    pathLength=sum(sum(A(:,:,flowIndex)>0));

end
function [res]=AverageOverNaN(input)
    res=0;
    num=0;
    for i=1:size(input,1)
        for j=1:size(input,2)
            if ~isnan(input(i,j))
                res=res+input(i,j);
                num=num+1;
            end
        end
    end
    res= res/num;
end
function [res]=MaxOverNaN(input)
    res=0;
    for i=1:size(input,1)
        for j=1:size(input,2)
            if ~isnan(input(i,j)) && res<input(i,j)
                res=input(i,j);
            end
        end
    end
end
function [avgDelay,numberOfDelayedFlow]=Delay(p,A,src,D,T)
    avgDelay=0;numberOfDelayedFlow=0;
    for f=1:p
        tmpDly=FlowDelay(A,src(f),D,f);
        avgDelay=avgDelay+tmpDly;
        if tmpDly>T(f)
            numberOfDelayedFlow=numberOfDelayedFlow+1;
        end
    end
    avgDelay=avgDelay/p;
end
function [delay]=FlowDelay(A,src,D,flowIndex)
    delay=0;
    maxAllowedLength=100;
    while sum(A(src,:,flowIndex)) && maxAllowedLength    
        s1=find(A(src,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
        A(src,s1,flowIndex)=0;
        delay=delay+D(src,s1);
        src=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #2***************');
    end


end
function [avgHops]=AvgHops(p,A,src)
    avgHops=0;
    for f=1:p
        tmpDly=FlowHops(A,src(f),f);
        avgHops=avgHops+tmpDly;
    end
    avgHops=avgHops/p;
end
function [hops]=FlowHops(A,src,flowIndex)
    hops=0;
    maxAllowedLength=100;
    while sum(A(src,:,flowIndex)) && maxAllowedLength    
        s1=find(A(src,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
        A(src,s1,flowIndex)=0;
        hops=hops+1;
        src=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #3***************');
    end


end
function NewPlot5InputMatrix(figNumber, A, B, C, D, E, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(1:size(A,2),[A;B;C;D],'MarkerSize',15,'LineWidth',2);
    hold on;
    plot(1:size(A,2),E,'MarkerSize',15,'LineWidth',2,'Marker','^','DisplayName','ENSFF_S');
%     set(plot1(1),'Marker','square','MarkerFaceColor','r');
    set(plot1(1),'Marker','s');
    set(plot1(2),'Marker','o');
    set(plot1(3),'Marker','*');
    set(plot1(4),'Marker','d');
%     set(plot1(5),'Marker','^');
    
    %Create Legend
    set(plot1(1),'DisplayName','RR');
    set(plot1(2),'DisplayName','NSFF');
    set(plot1(3),'DisplayName','RRR');
    set(plot1(4),'DisplayName','ECSPF');
%     set(plot1(5),'DisplayName','ENSFF');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
%     set(axes1,'FontSize',40,'XTick',1:size(A,2));
    set(axes1,'XTick',1:size(A,2));
    
    Leg1=legend('RR','NSFF','RRR','ENSF','ENSFF_S');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    %Save to file
    savefig([AddrToSaveFig,FigName,'.fig']);
    saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
    saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
    NewFigName='fig';
    tmpIndN=strfind(FigName,'p=');
    NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
    NewFigName=[NewFigName,FigName(1:2)];
    saveas(gcf,[AddrToSaveFig,NewFigName,'.eps']);
end
function OLDNewPlot4InputMatrix(figNumber, A, B, C, D, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(1:size(A,2),[A;B;C;D],'MarkerSize',15,'LineWidth',2);
%     set(plot1(1),'Marker','square','MarkerFaceColor','r');
    set(plot1(1),'Marker','s','MarkerFaceColor','r','MarkerEdgeColor','r','color','r','LineStyle',':');
    set(plot1(2),'Marker','o','MarkerFaceColor','y','MarkerEdgeColor','y','color','y','LineStyle','--');
    set(plot1(3),'Marker','d','MarkerFaceColor','g','MarkerEdgeColor','g','color','g');
    set(plot1(4),'Marker','*','MarkerFaceColor','b','MarkerEdgeColor','b','color','b','LineStyle','-.');
    
    %Create Legend
    set(plot1(1),'DisplayName','GRR');
    set(plot1(2),'DisplayName','NSF');
    set(plot1(3),'DisplayName','3R');
    set(plot1(4),'DisplayName','ENSF');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',19,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
    Leg1=legend('RR','NSFF','RRR','ENSF');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    

    %remove white space from the pdf file
    %     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];



    %Save to file
    savefig([AddrToSaveFig,FigName,'.fig']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
    NewFigName='fig';
    tmpIndN=strfind(FigName,'p=');
    NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
    NewFigName=[NewFigName,FigName(1:2)];
    saveas(gcf,[AddrToSaveFig,NewFigName,'.pdf']);
end
function NewPlot4InputMatrix(figNumber, A, C, D, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(1:size(A,2),[A;C;D],'MarkerSize',15,'LineWidth',2);
%     set(plot1(1),'Marker','square','MarkerFaceColor','r');
    set(plot1(1),'Marker','s','MarkerFaceColor','r','MarkerEdgeColor','r','color','r','LineStyle',':');
    set(plot1(2),'Marker','d','MarkerFaceColor','g','MarkerEdgeColor','g','color','g');
    set(plot1(3),'Marker','*','MarkerFaceColor','b','MarkerEdgeColor','b','color','b','LineStyle','-.');
    
    %Create Legend
    set(plot1(1),'DisplayName','ST-GRR');
    set(plot1(2),'DisplayName','ST-3R');
    set(plot1(3),'DisplayName','ST-ENSF');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',19,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
%     Leg1=legend('RR','NSFF','RRR','ENSF');
    Leg1=legend('ST-GRR','ST-3R','ST-ENSF');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    

    %remove white space from the pdf file
    %     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];



    %Save to file
    savefig([AddrToSaveFig,FigName,'.fig']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
    NewFigName='fig';
    tmpIndN=strfind(FigName,'p=');
    NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
    NewFigName=[NewFigName,FigName(1:2)];
    saveas(gcf,[AddrToSaveFig,NewFigName,'.pdf']);
end
function Plot6InputMatrix(figNumber, A, C, D, E, F, G, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
    % Create figure
    fig1=figure(figNumber);
%     set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(1:size(A,2),[A;C;D],'MarkerSize',15,'LineWidth',2);
%     set(plot1(1),'Marker','s','MarkerFaceColor','r','MarkerEdgeColor','r','color','r','LineStyle',':');
%     set(plot1(2),'Marker','d','MarkerFaceColor','g','MarkerEdgeColor','g','color','g');
%     set(plot1(3),'Marker','*','MarkerFaceColor','b','MarkerEdgeColor','b','color','b','LineStyle','-.');
    
    %Create Legend
    set(plot1(1),'DisplayName','ST-GRR');
    set(plot1(2),'DisplayName','ST-3R');
    set(plot1(3),'DisplayName','ST-ENSF');
    
    % Create labels
    ylabel(['Average ', YlabelText]);
    xlabel(XlabelText);
    
    yyaxis right;
    plot(1:size(A,2),[E;F;G],'MarkerSize',15,'LineWidth',2);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',19,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
%     Leg1=legend('RR','NSFF','RRR','ENSF');
    Leg1=legend('ST-GRR','ST-3R','ST-ENSF');
    Leg2=legend('ST-GRR','ST-3R','ST-ENSF');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','southoutside',...
    'Orientation','horizontal');
    set(Leg2,...
    'location','northoutside',...
    'Orientation','horizontal');

    %remove white space from the pdf file
    %     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];



    %Save to file
    savefig([AddrToSaveFig,FigName,'.fig']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
    NewFigName='fig';
    tmpIndN=strfind(FigName,'p=');
    NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
    NewFigName=[NewFigName,FigName(1:2)];
    saveas(gcf,[AddrToSaveFig,NewFigName,'.pdf']);
end





