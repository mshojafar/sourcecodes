function BarEnergyConsumptionAndPathLength(FolderAddresToReadFrom,addrsToSaveFigures)
    if size(FolderAddresToReadFrom,1)==0
        FolderAddresToReadFrom='C:\Users\Mahdi\Desktop\SFC\';
    else
        FolderAddresToReadFrom=[FolderAddresToReadFrom,'\'];
    end
    folders=dir(FolderAddresToReadFrom);
    %for each folder with starting name '__'
    indexTmp=0;
    NameOfFile='';
    for iFolder=1:size(folders,1)
        if strcmp(folders(iFolder).name,'.')==0 && strcmp(folders(iFolder).name,'..')==0 && folders(iFolder).isdir==1 && strcmp(folders(iFolder).name(1:2),'__')
            readFrom=[FolderAddresToReadFrom,folders(iFolder).name,'\'];
            files=dir(readFrom);
            indexTmp=indexTmp+1;
            NameOfFile=[NameOfFile,'p=',folders(iFolder).name(11:12)];
            %for each file in the folder
            for i=1:size(files,1)
                if strcmp(files(i).name,'.')==0 && strcmp(files(i).name,'..')==0 && files(i).isdir==0 && strcmp(files(i).name,'Notation.txt')==0
                    
                    [A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                        avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                        bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                        energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0] ...
                        =LoadResult([readFrom,files(i).name]);
                    
                    EC=MapEnergyConsumptionBetween200_400(EC);
                    
                    if strcmp(files(i).name(1:12),'ST_GRR_itr=1')
                        [ST_GRR_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC,0);
                        [ST_GRR_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,NA);
                        [ST_GRR_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    elseif strcmp(files(i).name(1:12),'LT_GRR_itr=1')
                        [LT_GRR_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC,1);
                        [LT_GRR_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,NA);
                        [LT_GRR_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    elseif strcmp(files(i).name(1:4),'SFRA')
                        [SFRA_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC,0);
                        [SFRA_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,NA);
                        [SFRA_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    elseif strcmp(files(i).name(1:5),'OSFRA')
                        [OSFRA_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC,0);
                        [OSFRA_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,NA);
                        [OSFRA_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    elseif strcmp(files(i).name(1:4),'NSFF')
                        [NSF_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC,0);
                        [NSF_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,NA);
                        [NSF_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    elseif strcmp(files(i).name(1:13),'ST_ENSF_itr=1')
                        [ST_ENSF_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC,0);
                        [ST_ENSF_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,NA);
                        [ST_ENSF_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    elseif strcmp(files(i).name(1:13),'LT_ENSF_itr=1')
                        [LT_ENSF_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC,1);
                        [LT_ENSF_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,NA);
                        [LT_ENSF_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    elseif strcmp(files(i).name(1:11),'LT_3R_itr=1')
                        [LT_3R_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC,1);
                        [LT_3R_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,NA);
                        [LT_3R_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    elseif strcmp(files(i).name(1:11),'ST_3R_itr=1')
                        [ST_3R_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC,0);
                        [ST_3R_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,NA);
                        [ST_3R_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    end
                end
            end
        end
    end

%     NameOfFile=replace(NameOfFile,' ','');
    if size(addrsToSaveFigures,1)==0, addrsToSaveFigures='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Simulation\Figures\';end
%     addrsToSaveFigures='C:\Users\mahdi\Desktop\SFC Figures\';
    %plot figures  
    
    %Short Term Resource Reallocation
    ST_GRR_powerConsumption([1 2])=ST_GRR_powerConsumption([2 1]);
    ST_3R_powerConsumption([1 2])=ST_3R_powerConsumption([2 1]);
    ST_ENSF_powerConsumption([1 2])=ST_ENSF_powerConsumption([2 1]);
    ST_GRR_averagePathLength([1 2])=ST_GRR_averagePathLength([2 1]);
    ST_3R_averagePathLength([1 2])=ST_3R_averagePathLength([2 1]);
    ST_ENSF_averagePathLength([1 2])=ST_ENSF_averagePathLength([2 1]);
    ST_GRR_netSideEffect([1 2])=ST_GRR_netSideEffect([2 1]);
    ST_3R_netSideEffect([1 2])=ST_3R_netSideEffect([2 1]);
    ST_ENSF_netSideEffect([1 2])=ST_ENSF_netSideEffect([2 1]);
    
    NewBar3InputMatrix(1,ST_GRR_powerConsumption,ST_3R_powerConsumption,ST_ENSF_powerConsumption,...
        'Power Consumption [J]','Scenario Label',addrsToSaveFigures,['Bar-ST-PWR',NameOfFile],'ST-GRR','ST-3R','ST-ENSF');
    NewBar3InputMatrix(2,ST_GRR_averagePathLength,ST_3R_averagePathLength,ST_ENSF_averagePathLength,...
        'Average Path Length','Scenario Label',addrsToSaveFigures,['Bar-ST-PthLen',NameOfFile],'ST-GRR','ST-3R','ST-ENSF');
    NewBar3InputMatrix(3,ST_GRR_netSideEffect,ST_3R_netSideEffect,ST_ENSF_netSideEffect,...
        'Forwarding Table Elements','Scenario Label',addrsToSaveFigures,['Bar-ST-NetSid',NameOfFile],'ST-GRR','ST-3R','ST-ENSF');
    
    %Long Term Resource Reallocation
    tmp=LT_GRR_powerConsumption(1);LT_GRR_powerConsumption(1)=LT_GRR_powerConsumption(2);LT_GRR_powerConsumption(2)=tmp;
    tmp=LT_3R_powerConsumption(1);LT_3R_powerConsumption(1)=LT_3R_powerConsumption(2);LT_3R_powerConsumption(2)=tmp;
    tmp=LT_ENSF_powerConsumption(1);LT_ENSF_powerConsumption(1)=LT_ENSF_powerConsumption(2);LT_ENSF_powerConsumption(2)=tmp;
    tmp=LT_GRR_averagePathLength(1);LT_GRR_averagePathLength(1)=LT_GRR_averagePathLength(2);LT_GRR_averagePathLength(2)=tmp;
    tmp=LT_3R_averagePathLength(1);LT_3R_averagePathLength(1)=LT_3R_averagePathLength(2);LT_3R_averagePathLength(2)=tmp;
    tmp=LT_ENSF_averagePathLength(1);LT_ENSF_averagePathLength(1)=LT_ENSF_averagePathLength(2);LT_ENSF_averagePathLength(2)=tmp;
    tmp=LT_GRR_netSideEffect(1);LT_GRR_netSideEffect(1)=LT_GRR_netSideEffect(2);LT_GRR_netSideEffect(2)=tmp;
    tmp=LT_3R_netSideEffect(1);LT_3R_netSideEffect(1)=LT_3R_netSideEffect(2);LT_3R_netSideEffect(2)=tmp;
    tmp=LT_ENSF_netSideEffect(1);LT_ENSF_netSideEffect(1)=LT_ENSF_netSideEffect(2);LT_ENSF_netSideEffect(2)=tmp;
    
    NewBar3InputMatrix(4,LT_GRR_powerConsumption,LT_3R_powerConsumption,LT_ENSF_powerConsumption,...
        'Power Consumption [J]','Scenario Label',addrsToSaveFigures,['Bar_LT_PWR',NameOfFile],'LT-GRR','LT-3R','LT-ENSF');
    NewBar3InputMatrix(5,LT_GRR_averagePathLength,LT_3R_averagePathLength,LT_ENSF_averagePathLength,...
        'Average Path Length','Scenario Label',addrsToSaveFigures,['Bar_LT_PthLen',NameOfFile],'LT-GRR','LT-3R','LT-ENSF');
    NewBar3InputMatrix(6,LT_GRR_netSideEffect,LT_3R_netSideEffect,LT_ENSF_netSideEffect,...
        'Forwarding Table Elements','Scenario Label',addrsToSaveFigures,['Bar_LT_NetSid',NameOfFile],'LT-GRR','LT-3R','VP-ENSF');
    
    %resource allocation
    tmp=OSFRA_powerConsumption(1);OSFRA_powerConsumption(1)=OSFRA_powerConsumption(2);OSFRA_powerConsumption(2)=tmp;
    tmp=SFRA_powerConsumption(1);SFRA_powerConsumption(1)=SFRA_powerConsumption(2);SFRA_powerConsumption(2)=tmp;
    tmp=NSF_powerConsumption(1);NSF_powerConsumption(1)=NSF_powerConsumption(2);NSF_powerConsumption(2)=tmp;
    OSFRA_averagePathLength([1 2])=OSFRA_averagePathLength([2 1]);
    SFRA_averagePathLength([1 2])=SFRA_averagePathLength([2 1]);
    NSF_averagePathLength([1 2])=NSF_averagePathLength([2 1]);
    OSFRA_netSideEffect([1 2])=OSFRA_netSideEffect([2 1]);
    SFRA_netSideEffect([1 2])=SFRA_netSideEffect([2 1]);
    NSF_netSideEffect([1 2])=NSF_netSideEffect([2 1]);
    
    NewBar3InputMatrix(7,OSFRA_powerConsumption,SFRA_powerConsumption,NSF_powerConsumption,...
        'Power Consumption (J)','Scenario Label',addrsToSaveFigures,['Bar_RA_PWR',NameOfFile],'Energy-aware SFRA','SFRA','NSF');
    NewBar3InputMatrix(8,OSFRA_averagePathLength,SFRA_averagePathLength,NSF_averagePathLength,...
        'Average Path Length','Scenario Label',addrsToSaveFigures,['Bar_RA_PthLen',NameOfFile],'Energy-aware SFRA','SFRA','NSF');
    NewBar3InputMatrix(9,OSFRA_netSideEffect,SFRA_netSideEffect,NSF_netSideEffect,...
        'Forwarding Table Elements','Scenario Label',addrsToSaveFigures,['Bar_RA_NetSid',NameOfFile],'Energy-aware SFRA','SFRA','NSF');
end
function [powerConsumption]=PowerConsumption(n,WN,EC,LongTermMode)
    %EC: nodes' energy consumption
    %WN: state of switches(On/Off),    
    powerConsumption=0;
%     LongTermMode=1;
    if LongTermMode
        for i=1:n
                powerConsumption=powerConsumption+WN(i)*EC(i);
        end
    else
        for i=1:n
            if WN(i)
                powerConsumption=powerConsumption+WN(i)*EC(i);
            else
                powerConsumption=powerConsumption+0.6*EC(i);
            end
        end
    end
end
function [averagePathLength]=AveragePathLength(p,A,s,d,NA)
    averagePathLength=0;
    for i=1:p
        averagePathLength=averagePathLength+PathLength(i,A,s(i),d(i),NA);
    end
    averagePathLength=averagePathLength/p;
end
function [pathLength]=PathLength(flowIndex,A,s,d,NA)
    pathLength=sum(sum(A(:,:,flowIndex)>0));
%     if NA(d,d)~=pathLength
%         disp(['NA= ', int2str(NA(d,d)),' pth= ',int2str(pathLength)]);
%     end

%     pathLength=0;
%     maxAllowedLength=100;
%     while sum(A(s,:,flowIndex)) && maxAllowedLength    
%         pathLength=pathLength+1;
%         s1=find(A(s,:,flowIndex));
%         %in NSFF loops are not forbiden but instead if a flow return to a
%         %switch then when it exit the number is increased
%         %e.g., A(1,2,3)=1, A(1,3,3)=2
%         s1=find(A(s,:,flowIndex)==min(A(s,s1,flowIndex)));
%         A(s,s1,flowIndex)=0;
%         s=s1;
%         maxAllowedLength=maxAllowedLength-1;
%     end
%     if maxAllowedLength==0
%         disp('************error in analysis #1***************');
%     end
end
function [netSideEffect]=NumberOfForwardingTableElements(A)
    netSideEffect=sum(sum(sum(A>0)));
end
function [netSideEffect]=NetworkSideEffect(n,p,A,A0)
    netSideEffect=0;
    for i=1:n
        for j=1:n
            for f=1:p
                netSideEffect=netSideEffect+abs(A(i,j,f)-A0(i,j,f));
            end
        end
    end
end
function [EC]=MapEnergyConsumptionBetween200_400(EC)
    EC=(EC-min(EC))/(max(EC)-min(EC));
    EC=EC*200+200;
end
function NewBar4InputMatrix(figNumber, A, B, C, D, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    for i=1:size(A,2)
        BarMatrix(i,1)=A(i);
%         BarMatrix(i,4)=B(i);
        BarMatrix(i,2)=C(i);
        BarMatrix(i,3)=D(i);
    end
    bar1=bar(BarMatrix);
    

    %Create Legend    
    set(bar1(1),'DisplayName','GRR','FaceColor','r');
%     set(bar1(4),'DisplayName','NSFF','FaceColor','y');
    set(bar1(2),'DisplayName','3R','FaceColor','g');
    set(bar1(3),'DisplayName','ENSF','FaceColor','b');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',16.5,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
%     Leg1=legend('GRR','3R','ENSF','NSF');
    Leg1=legend('GRR','3R','ENSF');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    
    %remove white space from the pdf file
%     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];


    %Save to file
%     savefig([AddrToSaveFig,FigName,'.fig']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);

    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.epsc']);
end
function NewBar3InputMatrix(figNumber, A, C, D, YlabelText, XlabelText, AddrToSaveFig, FigName, NameOfFirstPlot,NameOfSecondPlot,NameOfThirdPlot)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    for i=1:size(A,2)
        BarMatrix(i,1)=A(i);
        BarMatrix(i,2)=C(i);
        BarMatrix(i,3)=D(i);
    end
    bar1=bar(BarMatrix);
    

    %Create Legend    
    set(bar1(1),'DisplayName',NameOfFirstPlot,'FaceColor','r');
    set(bar1(2),'DisplayName',NameOfSecondPlot,'FaceColor','g');
    set(bar1(3),'DisplayName',NameOfThirdPlot,'FaceColor','b');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',16.5,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
%     Leg1=legend('GRR','3R','ENSF','NSF');
    Leg1=legend(NameOfFirstPlot,NameOfSecondPlot,NameOfThirdPlot);
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    
    %remove white space from the pdf file
%     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];


    %Save to file
%     savefig([AddrToSaveFig,FigName,'.fig']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);

    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.epsc']);
end
function NewBar2InputMatrix(figNumber, A, B, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    for i=1:size(A,2)
        BarMatrix(i,1)=A(i);
        BarMatrix(i,2)=B(i);
    end
    bar1=bar(BarMatrix);
    

    %Create Legend    
    set(bar1(1),'DisplayName','SFRA','FaceColor','r');
    set(bar1(2),'DisplayName','NSF','FaceColor','b');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',16.5,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
    Leg1=legend('SFRA','NSF');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    
    %remove white space from the pdf file
%     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];


    %Save to file
%     savefig([AddrToSaveFig,FigName,'.fig']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);

    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.epsc']);
end
function NewBar5InputMatrix(figNumber, A, B, C, D, E, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    for i=1:size(A,2)
        BarMatrix(i,1)=A(i);
        BarMatrix(i,4)=B(i);
        BarMatrix(i,5)=E(i);
        BarMatrix(i,2)=C(i);
        BarMatrix(i,3)=D(i);
    end
    bar1=bar(BarMatrix);
    

    %Create Legend    
    set(bar1(1),'DisplayName','GRR','FaceColor','r');
    set(bar1(4),'DisplayName','NSF','FaceColor','y');
    set(bar1(5),'DisplayName','NSF','FaceColor','y');
    set(bar1(2),'DisplayName','3R','FaceColor','g');
    set(bar1(3),'DisplayName','ENSF','FaceColor','b');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',16.5,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
%     Leg1=legend('GRR','3R','ENSF','NSF');
    Leg1=legend('GRR','3R','ENSF');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    
    %remove white space from the pdf file
%     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];


    %Save to file
%     savefig([AddrToSaveFig,FigName,'.fig']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);

    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.epsc']);
end