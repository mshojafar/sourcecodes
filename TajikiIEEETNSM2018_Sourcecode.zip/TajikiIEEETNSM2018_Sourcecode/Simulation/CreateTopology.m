function [n,B,D] = CreateTopology(bandwidth,topologyName)%B: matrix of links' bandwidth, D: Links' propagation delay
    if strcmp(topologyName,'Abilene')
        [n,B,D]=CreateTopology_Abilent(bandwidth);
    elseif strcmp(topologyName,'NSFNET')
        [n,B,D]=CreateTopology_NSFNET(bandwidth);
    end
end

function [n,B,D] = CreateTopology_NSFNET(bandwidth)%B: matrix of links' bandwidth, D: Links' propagation delay 
    n=13;
    B=zeros(n,n);
%     if Type=='BLP'
        D=ones(n,n)*100;
%     elseif Type=='SPF'
%         D=1./zeros(13,13);
%     end
    
    B(1,2)=1;
    B(1,5)=1;
    B(2,1)=1;
    B(2,4)=1;
    B(2,9)=1;
    B(3,5)=1;
    B(4,2)=1;
    B(4,7)=1;
    B(5,1)=1;
    B(5,3)=1;
    B(5,8)=1;
    B(6,8)=1;
    B(7,4)=1;
    B(7,8)=1;
    B(7,11)=1;
    B(8,6)=1;
    B(8,7)=1;
    B(8,9)=1;
    B(9,2)=1;
    B(9,8)=1;
    B(9,10)=1;
    B(9,12)=1;
    B(10,9)=1;
    B(11,7)=1;
    B(11,13)=1;
    B(12,9)=1;
    B(12,13)=1;
    B(13,11)=1;
    B(13,12)=1;
    B=B*bandwidth;%must be in form of MB/s

    D(1,2)=1;
    D(1,5)=1;
    D(2,1)=1;
    D(2,4)=1;
    D(2,9)=1;
    D(3,5)=1;
    D(4,2)=1;
    D(4,7)=1;
    D(5,1)=1;
    D(5,3)=1;
    D(5,8)=1;
    D(6,8)=1;
    D(7,4)=1;
    D(7,8)=1;
    D(7,11)=1;
    D(8,6)=1;
    D(8,7)=1;
    D(8,9)=1;
    D(9,2)=1;
    D(9,8)=1;
    D(9,10)=1;
    D(9,12)=1;
    D(10,9)=1;
    D(11,7)=1;
    D(11,13)=1;
    D(12,9)=1;
    D(12,13)=1;
    D(13,11)=1;
    D(13,12)=1;
       
end

function [n,B,D] = CreateTopology_Abilent(bandwidth)%B: matrix of links' bandwidth, D: Links' propagation delay 
    n=11;
    B=zeros(n,n);
%     if Type=='BLP'
        D=ones(n,n)*100;
%     elseif Type=='SPF'
%         D=1./zeros(11,11);
%     end
    
    B(1,2)=1;
    B(1,3)=1;
    B(2,1)=1;
    B(2,3)=1;
    B(2,4)=1;
    B(3,1)=1;
    B(3,2)=1;
    B(3,6)=1;
    B(4,2)=1;
    B(4,5)=1;
    B(5,4)=1;
    B(5,6)=1;
    B(5,7)=1;
    B(6,3)=1;
    B(6,5)=1;
    B(6,8)=1;
    B(7,5)=1;
    B(7,8)=1;
    B(7,10)=1;
    B(8,6)=1;
    B(8,7)=1;
    B(8,9)=1;
    B(9,8)=1;
    B(9,11)=1;
    B(10,7)=1;
    B(10,11)=1;
    B(11,9)=1;
    B(11,10)=1;   
    B=B*bandwidth;%must be in form of MB/s

    D(1,2)=6;
    D(1,3)=8;
    D(2,1)=6;
    D(2,3)=6;
    D(2,4)=2.5;
    D(3,1)=8;
    D(3,2)=6;
    D(3,6)=3.5;
    D(4,2)=2.5;
    D(4,5)=8.5;
    D(5,4)=8.5;
    D(5,6)=4.2;
    D(5,7)=4;
    D(6,3)=3.5;
    D(6,5)=4.2;
    D(6,8)=3;
    D(7,5)=4;
    D(7,8)=3;
    D(7,10)=3.2;
    D(8,6)=3;
    D(8,7)=3;
    D(8,9)=1;
    D(9,8)=1;
    D(9,11)=5;
    D(10,7)=3.2;
    D(10,11)=1.1;
    D(11,9)=5;
    D(11,10)=1.1;
    
    for i=1:n
        for j=1:n
            if D(i,j)~=max(max(D))
                D(i,j)=D(i,j)/D(i,j);
            end
        end
    end
       
end