function [WN0,CL,SL] = CurrentState(numberOfSwitches,numberOfFunction)
    %WN0: current state of switches(On/Off),
    %CL: current bandwidth load on links, 
    %SL: current processing load per function on each link
    WN0=zeros(1,numberOfSwitches);
    CL=zeros(numberOfSwitches,numberOfSwitches);
    SL=zeros(numberOfSwitches,numberOfFunction);
end