function [s,d,C,StartIPOfFlow,EndIPOfFlow] = ReadFlows_AllSwitchesAreSimilar(numberOfFlows, numberOfSwitches)
    fid=fopen('univ1_pt1.txt');
    C(numberOfFlows)=0;
        
    s=zeros(1,numberOfFlows);d=zeros(1,numberOfFlows);
    StartIPOfFlow=zeros(1,numberOfFlows);EndIPOfFlow=zeros(1,numberOfFlows);
    
    %Read Flows From File
    for i=1:numberOfFlows
        t=fscanf(fid,'%s,');
        t2(12)=length(t);%it will contain all comma(,) indexes
        j=1;
        for p=1:11
            while t(j)~=','
                j=j+1;
            end
            t2(p)=j-1;
            j=j+1;
        end
        StartIPOfFlow(i,1:t2(1))=t(1:t2(1));
        EndIPOfFlow(i,1:t2(2)-t2(1)-1)=t(t2(1)+2:t2(2));
        C(i)=(str2double(t(t2(10)+2:t2(11)))+(str2double(t(t2(11)+2:t2(12)))))/(1024*2); %Kb
        if C(i)==0 
            C(i)=1;
        end
    end    
    
    fclose(fid);
    
    
    %assign ip to switch
    S2=ones(1,numberOfFlows);%S2(i) specify whether IP i is assigneded to a switches or not (for flow start). value 1 means it is not assigned
    E2=ones(1,numberOfFlows);%E2(i) specify whether IP i is assigneded to a switches or not (for flow end)
    j=1;%selected switch number (the first ip will assing to switch 1, the second ip will assign to switch 2 and so on
    for i=1:numberOfFlows
        if S2(i)
            S2(i)=0;
            s(i)=j;
            for x=i+1:numberOfFlows
                if S2(x) && strcmp(StartIPOfFlow(x,:),StartIPOfFlow(i,:))
                    S2(x)=0;
                    s(x)=j;
                end
                if E2(x) && strcmp(EndIPOfFlow(x,:),StartIPOfFlow(i,:))
                    E2(x)=0;
                    d(x)=j;
                end
            end
            if j==numberOfSwitches
                j=1;
            else
                j=j+1;
            end
        end
         
        if E2(i)
            E2(i)=0;
            d(i)=j;
            for x=i+1:numberOfFlows
                if S2(x) && strcmp(StartIPOfFlow(x,:),EndIPOfFlow(i,:))
                    S2(x)=0;
                    s(x)=j;
                end
                if E2(x) && strcmp(EndIPOfFlow(x,:),EndIPOfFlow(i,:))
                    E2(x)=0;
                    d(x)=j;
                end
            end
            if j==numberOfSwitches
                j=1;
            else
                j=j+1;
            end
        end
    end
    
    %to satisfy startOfFlow ~= EndOfFlow
    for i=1:numberOfFlows
        while d(i)==s(i)
            if d(i) == numberOfSwitches
                d(i)=d(i)-1;
                Display('+++++++++++++********************* ERROR In ReadFlow***********************+++++++++++++++++++++');
            else
                d(i)=d(i)+1;
                Display('+++++++++++++********************* ERROR In ReadFlow***********************+++++++++++++++++++++');
            end
        end
    end
end