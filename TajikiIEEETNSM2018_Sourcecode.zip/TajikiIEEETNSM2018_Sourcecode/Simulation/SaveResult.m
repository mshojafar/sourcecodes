function SaveResult(Type,A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
        avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
        bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
        energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0,postFix)
    % save to file
%     if strcmp(Type,'CSPF_RA') || strcmp(Typ(1:size(Type,2)-1),'CSPF_RR_itr=')
    if size(postFix,1)~=0
        fileNameDisp = strcat([Type,postFix]);
    else
        fileNameDisp = strcat([Type,'_n=',num2str(n),' p=',num2str(p),' b=',num2str(prcntOfAvgBandDmnd),...
           ' k=',num2str(avgPrcntNmbrFlwFrmASrc), ' e=',num2str(avgPrcntOfNmbrOfFuncPerFlw),' df=',num2str(prcntOfDestPerFlow),...
           ' mf=',num2str(minNmbrFuncPerFlw),' d=',num2str(minTolrblDly),',',num2str(maxTolrbDly),...
           ' np=',num2str(nodeProcessingPowerToBandwidhRatio),' fp=',num2str(funcProcessingPowerToBandwidthRatio),...
           ' ep=',num2str(energyToProcessingPowerRatio),' hf=',num2str(prcntNodThtCanHstFunc),postFix,'.txt']);
    end
    save(fileNameDisp,'A','U','WN','NA','p','B','D','C','T','s','d','R','K','FP','NC','F','EC','WN0','CL','SL','n','miu','miu2','prcntOfEdgeNode',...
        'prcntOfSrcNode', 'prcntOfDestPerFlow','avgPrcntNmbrFlwFrmASrc','maxNmbrFlwFrmASrc', 'avgPrcntOfNmbrOfFuncPerFlw','minNmbrFuncPerFlw',...
        'maxNmbrFuncPerFlw','numbrOfFunctions','prcntOfAvgBandDmnd','bandwidth','minTolrblDly','maxTolrbDly', 'nodeProcessingPowerToBandwidhRatio',...
        'prcntNodThtCanHstFunc','prcntFncThatHostedByANode','energyToProcessingPowerRatio', 'funcProcessingPowerToBandwidthRatio',...
        'flowDemandIncreamentFactor','A0','U0','NA0');
    fclose('all');    
%     
%     avgPrcntOfNmbrOfFuncPerFlw=2; %1.5, 2, 2.5   %$R^f$ & Ratio of functions that a flow needs\\\hline %e
%     prcntOfAvgBandDmnd=0.05; %0.02, 0.05         %$B^f$ & Ratio of flow size to link bandwidth\\\hline %b
%     avgPrcntNmbrFlwFrmASrc=0.4; %k=2, 4          %$F_s$ & Coefficient of number of generated flows per source\\\hline %k %avgPrcntNmbrFlwFrmASrc 
%     prcntNodThtCanHstFunc=0.8; %0.5, 0.7, 1      %$\gamma$ & Ratio of nodes that can host functions\\\hline %hf
%     prcntOfDestPerFlow=1;%0.5, 1                 %$\tau_d$ & Ratio of edge switches $\tau$ that are destination of a flow\\\hline %df
%     minNmbrFuncPerFlw=2;                         %$R^f_{min}$ & Minimum number of requested functions per flow\\\hline %mf
%     minTolrblDly=70;maxTolrbDly=150;             %$T_{max}$ & Maximum tolerable delay in $ms$\\\hline
%     maxNmbrFuncPerFlw=5;                         %$R^f_{max}$ & Maximum number of requested functions per flow\\\hline 
%     numbrOfFunctions=10;                         %$X$ & Number of functions
%     prcntOfEdgeNode=1;                           %$\tau$ & Edge switches ratio\\\hline 
%     prcntOfSrcNode=1;                            %$\tau_s$ & Ratio of edge switches $\tau$ that are source of a flow\\\hline
%     maxNmbrFlwFrmASrc=10; 
%     bandwidth=1024*1024/8; 
%     prcntFncThatHostedByANode=0.7;               %$X_\gamma$ & Ratio of functions hosted by a node\\\hline
end