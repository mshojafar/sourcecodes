function [prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow, avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,...
    minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,...
    prcntNodThtCanHstFunc,prcntFncThatHostedByANode,energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,miu,miu2,...
    flowDemandIncreamentFactor]= SetParameter_RA()
    
    %Select One
    avgPrcntOfNmbrOfFuncPerFlw=2; %1.5, 2, 2.5   %$R^f$ & Ratio of functions that a flow needs\\\hline %e
    prcntOfAvgBandDmnd=0.02; %0.02, 0.05         %$B^f$ & Ratio of flow size to link bandwidth\\\hline %b
    avgPrcntNmbrFlwFrmASrc=0.4; %k=2, 4          %$F_s$ & Coefficient of number of generated flows per source\\\hline %k %avgPrcntNmbrFlwFrmASrc 
    prcntNodThtCanHstFunc=1; %0.5, 0.7, 1      %$\gamma$ & Ratio of nodes that can host functions\\\hline %hf
    prcntOfDestPerFlow=1;%0.5, 1                 %$\tau_d$ & Ratio of edge switches $\tau$ that are destination of a flow\\\hline %df
    minNmbrFuncPerFlw=2;                         %$R^f_{min}$ & Minimum number of requested functions per flow\\\hline %mf
    minTolrblDly=70;maxTolrbDly=150;             %$T_{max}$ & Maximum tolerable delay in $ms$\\\hline
    maxNmbrFuncPerFlw=5;                         %$R^f_{max}$ & Maximum number of requested functions per flow\\\hline 
    numbrOfFunctions=10;                         %$X$ & Number of functions
    prcntOfEdgeNode=1;                           %$\tau$ & Edge switches ratio\\\hline 
    prcntOfSrcNode=1;                            %$\tau_s$ & Ratio of edge switches $\tau$ that are source of a flow\\\hline
    maxNmbrFlwFrmASrc=10; 
    bandwidth=1024*1024/8; 
    prcntFncThatHostedByANode=0.7;               %$X_\gamma$ & Ratio of functions hosted by a node\\\hline
    miu=0.8; miu2=0.8;
    
    flowDemandIncreamentFactor=0.3;
    
    
    nodeProcessingPowerToBandwidhRatio=1;        
    funcProcessingPowerToBandwidthRatio=0.1;%Check the line 23 in CreateVMs file: FP(i)=rand()*2*funcProcessingPowerToBandwidthRatio;
    energyToProcessingPowerRatio=0.1;
    
end