function [WN0,CL,SL]=ChangeCurrentState_RA(CL,SL,A,C,U,tWN,WN,n,numbrOfFunctions)
    %Setting CL
    for i=1:n
        for j=1:n
            CL(i,j)=CL(i,j)+A(i,j)*C;
        end
    end
    %Setting WN0
    WN0=(WN+tWN)>0;
    %Setting SL
    for m=1:numbrOfFunctions
        for i=1:n
            SL(i,m)=SL(i,m)+U(i,m)*C;
        end
    end
end