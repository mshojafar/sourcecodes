function NSFF(readFrom,LoopAllowed_Mode)
    if size(readFrom,1)==0
        readFrom='/Users/mohammadshojafar/Dropbox/Mahdi_SFC_Simulation/New/';
    else
        readFrom=[readFrom,'\'];
    end
    files=dir(readFrom);
    for j=1:size(files,1)
        if strcmp(files(j).name,'.')==0 && strcmp(files(j).name,'..')==0 && files(j).isdir==0 && strcmp(files(j).name(1:4),'SFRA')
            [A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0]= LoadResult([readFrom,files(j).name]);
            %B: matrix of links' bandwidth, 
            %D: Links' propagation delay
            %C: flow bandwidth requirement, 
            %T: maximum tolerable propagation delay,
            %s: source switches, 
            %d: destination switches, 
            %R: functions requirements of flows, 
            %K: sequence of required functions
            %p:number of flows
            %FP: required processing power of funtionss, 
            %NC: nodes processing capacity, 
            %F: functions associated withe nodes,
            %EC: nodes' energy consumption
            tic
            [D]=ConvertCommonDToCSPFCompatibleD(D);
            tB=B;

            A=zeros(n,n,p);
            U=zeros(n,numbrOfFunctions,p);
            for f=1:p
                if LoopAllowed_Mode
                    [tA,tU,tB,NC]=NSFF_RA_Solver_LoopAllowed(n,numbrOfFunctions,ConvertZeroToInf(tB),D,median(C(1:f)),s(f),d(f),K(f,:),FP,NC,F,0);
                else
                    [tA,tU,tB,NC]=NSFF_RA_Solver_NoLoop(n,numbrOfFunctions,ConvertZeroToInf(tB),D,median(C(1:f)),s(f),d(f),K(f,:),FP,NC,F,0);
                end
                A(:,:,f)=tA;
                U(:,:,f)=tU;
            end

            for i=1:n
                WN(i)=(sum(sum(U(i,:,:)))>0);
            end
            toc
            tmpName=files(j).name; 
            if strcmp(tmpName(1:13),'SFRA_RdFrmFle'),tmpName=tmpName(14:size(tmpName,2));else, tmpName=tmpName(5:size(tmpName,2)); end
            A0=zeros(n,n,p);U0=zeros(n,numbrOfFunctions,p);WN0=zeros(1,n);NA0=A0;
            if LoopAllowed_Mode, prefixName='NSFF_WithLoop'; else, prefixName='NSFF'; end
            SaveResult(prefixName,A,U,WN,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,CL,SL,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,NA0,tmpName);
        end
    end
end

function [B]=ConvertZeroToInf(B)
    for i=1:size(B,1)
        for j=1:size(B,2)
            if B(i,j)==0
                B(i,j)=inf;
            end
        end
    end
end

function [A,U,B,NC]=NSFF_RA_Solver_NoLoop(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD)
    BFactor=ones(n,n);
    A=zeros(n,n);
    U=zeros(n,numbrOfFunctions);
    G=BRatioToD*B+(1-BRatioToD)*D;
    %fix the NaN value (devisioned by zero )
    for i=1:n
        for j=1:n
            if isnan(G(i,j))
                G(i,j)=0;
            end
        end
    end
    %find the proper path from s to d with respect to SFC -- to this end
    %in each step find the shortest path from current node to the next required function
    step=0;
    for i=1:size(K,2)
        if K(i)~=0
            %Eliminate links that has a free bandwidth less than the flow required
            %capacity
            for i2=1:n
                for j2=1:n
                    if (BFactor(i2,j2)*B(i2,j2))<C
                        G(i2,j2)=0;
                    end
                end
            end
            %find shortest path from source to all nodes
            [dist, path, pred] = graphshortestpath(sparse(G), s);
            %remove nodes that are doesn't support the required function
            for j=1:n
                if F(j,K(i))==0
                    dist(j)=inf;
                end
            end
            %remove nodes that doesn't have neough processing power
            for j=1:n
                if NC(j)< C*FP(K(i))
                    dist(j)=inf;
                end
            end
            
            %do not enter to destination
            dist(d)=inf;
            
            if min(dist==inf)
                disp('*****************error in NSFF_RA, cannot find the result #2**********************');
            end
            %Select the nearest node that support the required function
            ind=find(dist==min(dist));
            %maybe two nodes has similar cost
            ind=ind(1);
            U(ind,K(i))=1;
            NC(ind)=NC(ind)-C*FP(K(i));
            %calculate the path
            tmpInd=ind;
            if ind~=s
                step=step+1;
            end
            while ind~=s
                A(pred(ind),ind)=step;
                B(pred(ind),ind)=B(pred(ind),ind)-C;
                
                BFactor(pred(ind),:)=BFactor(pred(ind),:)*inf;
                BFactor(:,pred(ind))=BFactor(:,pred(ind))*inf;
                
                ind=pred(ind);
            end
            %change the source to the node we are in currently
            s=tmpInd;
        end
    end
    %Eliminate links that has a free bandwidth less than the flow required
    %capacity
    for i2=1:n
        for j2=1:n
            if (BFactor(i2,j2)*B(i2,j2))<C
                G(i2,j2)=0;
            end
        end
    end
    %go to destination
    [dist, path, pred] = graphshortestpath(sparse(G), s);
    if d~=s
        step=step+1;
    end
    while d~=s
        A(pred(d),d)=step;
        B(pred(d),d)=B(pred(d),d)-C;
        d=pred(d);
    end
    B=ConvertInfToZero(B);
end

function [A,U,B,NC]=NSFF_RA_Solver_LoopAllowed(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD)
    A=zeros(n,n);
    U=zeros(n,numbrOfFunctions);
    G=BRatioToD*B+(1-BRatioToD)*D;
    %fix the NaN value (devisioned by zero )
    for i=1:n
        for j=1:n
            if isnan(G(i,j))
                G(i,j)=0;
            end
        end
    end
    %find the proper path from s to d with respect to SFC -- to this end
    %in each step find the shortest path from current node to the next required function
    step=0;
    for i=1:size(K,2)
        if K(i)~=0
            %Eliminate links that has a free bandwidth less than the flow required
            %capacity
            for i2=1:n
                for j2=1:n
                    if B(i2,j2)<C
                        G(i2,j2)=0;
                    end
                end
            end
            %find shortest path from source to all nodes
            [dist, path, pred] = graphshortestpath(sparse(G), s);
            %remove nodes that are doesn't support the required function
            for j=1:n
                if F(j,K(i))==0
                    dist(j)=inf;
                end
            end
            if min(dist==inf)
                disp('*****************error in NSFF_RA, cannot find the result #2**********************');
            end
            %Select the nearest node that support the required function
            ind=find(dist==min(dist));
            %maybe two nodes has similar cost
            ind=ind(1);
            U(ind,K(i))=1;
            NC(ind)=NC(ind)-C*FP(K(i));
            %calculate the path
            tmpInd=ind;
            if ind~=s
                step=step+1;
            end
            while ind~=s
                A(pred(ind),ind)=step;
                B(pred(ind),ind)=B(pred(ind),ind)-C;
                ind=pred(ind);
            end
            %change the source to the node we are in currently
            s=tmpInd;
        end
    end
    %Eliminate links that has a free bandwidth less than the flow required
    %capacity
    for i2=1:n
        for j2=1:n
            if B(i2,j2)<C
                G(i2,j2)=0;
            end
        end
    end
    %go to destination
    [dist, path, pred] = graphshortestpath(sparse(G), s);
    if d~=s
        step=step+1;
    end
    while d~=s
        A(pred(d),d)=step;
        B(pred(d),d)=B(pred(d),d)-C;
        d=pred(d);
    end
    B=ConvertInfToZero(B);
end
        
function [B]=ConvertInfToZero(B)
    for i=1:size(B,1)
        for j=1:size(B,2)
            if B(i,j)==inf
                B(i,j)=0;
            end
        end
    end
end
        
        
