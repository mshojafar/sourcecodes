clc
close all
clear all
iter=2;
resultf=zeros(iter,1);
for i=1:iter
constraint();
x0=1.5.*ones(30,1);
[x,fval,exitflag,output]=fmincon(@objfun,x0,A,b,Aeq,beq,lb,ub);
resultf(i)=fval;
end
fvalaverage=resultf/iter;


