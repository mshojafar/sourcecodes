function f=objfun(x)
f_max=105;
k_e=0.005;
zeta=0.2;
w=1;
E_max=60;
f_zero=0;
Delta=0.1;
l_b=0;
T_tot=5;
R_tot=100;
m=10;
f=0;
for i=1: m
    f1=((x(3*i-1)/f_max)^2)*w*E_max;
    f2=k_e*(x(3*i-1)-f_zero)^2;
    f3=2*zeta*2^((x(3*i-2)/w)-1)*(x(3*i)/x(3*i-2));
    f=f1+f2+f3+f;
end
end

    