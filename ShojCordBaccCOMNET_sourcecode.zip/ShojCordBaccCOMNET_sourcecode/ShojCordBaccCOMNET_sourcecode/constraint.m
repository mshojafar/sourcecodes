%function constraint()
clc
close all
clear all
iter=5;

m=10;

f_zero=zeros(m,1);
resultf=zeros(iter,1);
x0=zeros(3*m,1);
for ii=1:m 
        x0(3*ii,1)=0;    %for L_i
        x0(3*ii-1,1)=0;  %for f_opt
        x0(3*ii-2,1)=1;  %for R_opt
end
for j=1:iter

    
Delta=0.1;
T_tot=5;
R_tot=100;
L_b=0;
f_max=105;
L_tot=8+1.25;
%lower and upper bound
lb=zeros(3*m,1);
ub=Inf(3*m,1);

% linear inequalityies (2*m+1 inequations); %  AX <= b;

%m inequalities for L_i+l_b <=f_opt*Delta for i=1..m  , 
% m inequalities for 2*L_opt/R_opt+Delta <= T_tot for i=1..m , and 
% one inequality for sum(R_opt, m)<= R_tot

A=zeros(2*m+1,3*m);
b=zeros(2*m+1,1);
for i=1:m
A(i,[3*i,3*i-1])=[1,-Delta];
A(m+i,[3*i,3*i-2])=[2,Delta-T_tot];
A(2*m+1,3*i-2)=1;
b(i)=L_b;
end
b(2*m+1)=R_tot;

% linear equalities (+1 equation);  AeqX=beq
% sum(L_opt, m)= L_tot;
Aeq=zeros(1,3*m);
beq=zeros(1,1);
beq=L_tot;
%x0=zeros(3*m,1);
for i=1:m
Aeq(1,[3*i])=1;
ub(3*i-1)=f_max;
%x0(i)=i;
end
%options = optimset('Algorithm','interior-point');
%x0[i]=m;

%[x,fval,exitflag,output]=fmincon(@objfun,x0,A,b,Aeq,beq,lb,ub);
[x,fval,exitflag,output]=fmincon(@(x)objfun1(x,f_zero),x0,A,b,Aeq,beq,lb,ub);
x0=x;
for jj=1:m 
 f_zero(jj)=x0(3*jj-1,1);  %for f_opt
 end
%end
resultf(j)=fval;

end
%fvalaverage=sum(resultf)/m;