function f=objfun1(x,f_zero)
f_max=105;
k_e=0.5;
zeta=0.5;
w=1;
E_max=60;
%f_zero=x0;
Delta=0.1;
l_b=0;
T_tot=5;
R_tot=100;
m=2;
f=0;
for i=1: m
    f1=((x(3*i-1)/f_max)^2)*w*E_max;
    f2=k_e*(x(3*i-1)-f_zero(i))^2;
    f3=2*zeta*2^((x(3*i-2)/w)-1)*(x(3*i)/x(3*i-2));
    f=f1+f2+f3+f;
end
end

    