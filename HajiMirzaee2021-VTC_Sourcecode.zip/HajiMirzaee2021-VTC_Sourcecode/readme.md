# A Two-layer Collaborative Vehicle-Edge Intrusion Detection System for Vehicular Communications

This project runs experiments on Python 3.7.11

## Install libraries

Run the following command to install required python libraries for this project.

```bash
pip install -r requirements.txt
```

## Execution

1. Create two new folders "Data" and "plots" in same directory of the source file.
2. Put all data source files into "Data" folder
3. Execute all cells in the Jupyter notebook.
