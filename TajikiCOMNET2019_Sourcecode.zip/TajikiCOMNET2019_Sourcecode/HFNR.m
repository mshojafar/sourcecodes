%Heuristic for Fault-aware Network Reconfiguration (heuristic for FNR)
%LoopMode= 'NoLoop' 'LoopAllowed'
function HFNR(readFrom,SortFlows,LoopMode)
%   A0 is the string format of selected paths: e.g., A0(1)= 1->3 3->5 5->4     where s=1 and d=4
    for itmp=1:1
        %B: matrix of links' bandwidth, 
        %D: Links' propagation delay
        %C: flow bandwidth requirement, 
        %T: maximum tolerable propagation delay,
        %s: source switches, 
        %d: destination switches, 
        %R: functions requirements of flows, 
        %K: sequence of required functions
        %p:number of flows
        %FP: required processing power of funtionss, 
        %NC: nodes processing capacity, 
        %F: functions associated withe nodes,
        %EC: nodes' energy consumption
        %WN: current state of switches
        if size(readFrom,1)==0
            readFrom='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Fault-aware No-Ordering SFC\simulation\results\';
        else
            readFrom=[readFrom,'\'];
        end
    end
    files=dir(readFrom);
    for j=1:size(files,1)
        if strcmp(files(j).name,'.')==0 && strcmp(files(j).name,'..')==0 && files(j).isdir==0 && strcmp(files(j).name(1:4),'FNR_')
            [A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0]= LoadResult([readFrom,files(j).name]);
        
            [D]=ConvertCommonDToCSPFCompatibleD(D);
            tB=ConvertZeroToInf(B*miu);
            tNC=NC*miu2;
            A=zeros(n,n,p);
            U=zeros(n,numbrOfFunctions,p);
            tic
            
            if SortFlows, ind=SortFlowsBasedOnTheirSize(C); else, ind=1:p;end
            
            [nodesFaultProb,MT,switchFailProb]=FailurProbForDifferentPath(n);
            
            WN=zeros(1,n);
            TxtPath(1,p)=string;
            %invoke the HFNR_RR_Solver function. If the problem is not solvable with current miu and miu2, then these values are increased to one
            for f=1:p
                [tA,tU,tB,tNC,WN,error,TxtPath(f)]=FindSolution(n,numbrOfFunctions,0,tB,D,C(ind(f)),FP,tNC,F,WN,EC,...
                    R(:,ind(f))',nodesFaultProb,(1-nodesFaultProb(s(ind(f)))),MT,s(ind(f)),d(ind(f)),zeros(1,n),LoopMode);                               
                if error
                    disp('************HFNR_Solver cannot solve the problem***************');
                    return;
                else
                    disp(['flow ',num2str(f),' is routed']);
                    A(:,:,ind(f))=tA;
                    U(:,:,ind(f))=tU;
                end
            end
            toc
            display(['for p= ',num2str(p)]);
            tmpName=files(j).name;
            SaveResult(['HFNR_itr=',tmpName(8)],A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode,prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,TxtPath,U0,tmpName(9:size(tmpName,2)));
            clear('TxtPath');
        end
    end
end

function [tA,tU,tB,NC,WN,error,TxtPath]=FindSolution(n,numbrOfFunctions,BRatioToD,B,D,C,FP,NC,F,WN,EC,R,nodesFaultProb,pathFaultProb,MT,currentNode,...
    destinationNode,CrossedNodes,LoopMode)
    A=zeros(n,n); U=zeros(n,numbrOfFunctions);
%     for i=-1:10
    if strcmp(LoopMode,'NoLoop')==0
        [tA,tU,tB,NC,WN,error,TxtPath]=HFNR_Solver_NoLoop(n,numbrOfFunctions,BRatioToD,B,D,C,FP,NC,F,WN,EC,R,...
            A,U,nodesFaultProb,pathFaultProb,MT,currentNode,destinationNode,CrossedNodes);
    elseif strcmp(LoopMode,'LoopAllowed')==0
        [tA,tU,tB,NC,WN,error,TxtPath]=HFNR_Solver_LoopAllowed(n,numbrOfFunctions,BRatioToD,B,D,C,FP,NC,F,WN,EC,R,...
            A,U,nodesFaultProb,pathFaultProb,MT,currentNode,destinationNode);
    end
%         if ~error
%             return;
%         end
%     end
end

function [B]=ConvertZeroToInf(B)
    for i=1:size(B,1)
        for j=1:size(B,2)
            if B(i,j)==0
                B(i,j)=inf;
            end
        end
    end
end

function [A,U,B,NC,WN,error,TxtPath]=HFNR_Solver_NoLoop(n,numbrOfFunctions,BRatioToD,B,D,C,FP,NC,F,WN,EC,R,...
    A,U,nodesFaultProb,pathFaultProb,MT,currentNode,destinationNode,CrossedNodes)
    %if the fault probability of the path is more than the maximum tolerable one
    if pathFaultProb < 1-MT 
        error=1;TxtPath=''; return; 
    % if all functions are met and we are in the destination
    elseif currentNode==destinationNode && sum(R)==0
        error=0;TxtPath=''; return;
    %if all functions are met but we are not in the destination
    elseif sum(R)==0
        %Prevent Loops
        tB=B;
        tB(:,find(CrossedNodes==1))=Inf;tB(find(CrossedNodes==1),:)=Inf;
        CrossedNodes(currentNode)=1;
        G=BRatioToD*ConvertZeroToInf(tB)+(1-BRatioToD)*D;
       [dist, path, pred] = graphshortestpath(sparse(G), currentNode);
        if dist(destinationNode)==inf || FailureProbOfPathIsNotAcceptable(pred,nodesFaultProb,pathFaultProb,MT,currentNode,destinationNode)
            error=1;TxtPath=''; return;
        else
            TxtPath='';
            while destinationNode~=currentNode
                TxtPath=[int2str(pred(destinationNode)),'->',int2str(destinationNode),' ', TxtPath];
                A(pred(destinationNode),destinationNode)=1;
                B(pred(destinationNode),destinationNode)=B(pred(destinationNode),destinationNode)-C;
                destinationNode=pred(destinationNode);
            end
            error=0;return;
        end
    %if none of the above is true
    else
        tB=B;
        %don't enter to the destination (till all required functions are met)
%          tB(:,destinationNode)=Inf;tB(destinationNode,:)=Inf;
        %Prevent Loops
        tB(:,find(CrossedNodes==1))=Inf;tB(find(CrossedNodes==1),:)=Inf;
        CrossedNodes(currentNode)=1;
        G=BRatioToD*ConvertZeroToInf(tB)+(1-BRatioToD)*D;
        %fix the NaN value (devisioned by zero )
        for i=1:n
            for j=1:n
                if isnan(G(i,j))
                    G(i,j)=0;
                end
            end
        end
        %Select Next node to go
        sortedNodes=SortNodesBasedOnTheirEnergyConsumption(currentNode,B,WN,EC,n,CrossedNodes);
        for i=1:size(sortedNodes,2)
            nextNode=sortedNodes(i);
            tR=R;tU=U;tWN=WN;tNC=NC;
            %check if there is any function to deliver to the flow in the next node
            for x=1:numbrOfFunctions
                if tR(x)~=0 && F(nextNode,x) && tNC(nextNode)>=FP(x)*C
                    tNC(nextNode)=tNC(nextNode)-FP(x)*C;
                    tR(x)=0;
                    tU(nextNode,x)=1;
                    tWN(nextNode)=1;
                end
            end
            %go to next node
            B(currentNode,nextNode)=B(currentNode,nextNode)-C;
            [tA,tU,tB,tNC,tWN,error,TxtPath]=HFNR_Solver_NoLoop(n,numbrOfFunctions,BRatioToD,B,D,C,FP,tNC,F,tWN,EC,tR,...
                A,tU,nodesFaultProb,pathFaultProb*(1-nodesFaultProb(nextNode)),MT,nextNode,destinationNode,CrossedNodes);
            B(currentNode,nextNode)=B(currentNode,nextNode)+C;
            %if there is no error, the problem is solved, otherwise, previouse next node wasn't a good node
            if error==0
                A=tA;U=tU;B=tB;NC=tNC;WN=tWN;
                A(currentNode,nextNode)=1;
%                 B(currentNode,nextNode)=B(currentNode,nextNode)-C;
                TxtPath=[num2str(currentNode),'->',num2str(nextNode),' ',TxtPath]; 
                return; 
            end
        end
        %if the problem reach this place, it means that it couldn't find a proper solution
        TxtPath='';
        error=1;  
    end
end

function [A,U,B,NC,WN,error,TxtPath]=HFNR_Solver_LoopAllowed(n,numbrOfFunctions,BRatioToD,B,D,C,FP,NC,F,WN,EC,R,...
    A,U,nodesFaultProb,pathFaultProb,MT,currentNode,destinationNode)
    %if the fault probability of the path is more than the maximum tolerable one
    if pathFaultProb < 1-MT 
        error=1;TxtPath=''; return; 
    % if all functions are met and we are in the destination
    elseif currentNode==destinationNode && sum(R)==0
        error=0;TxtPath=''; return;
    %if all functions are met but we are not in the destination
    elseif sum(R)==0
        %Prevent Loops
        tB=B;
        G=BRatioToD*ConvertZeroToInf(tB)+(1-BRatioToD)*D;
       [dist, path, pred] = graphshortestpath(sparse(G), currentNode);
        if dist(destinationNode)==inf || FailureProbOfPathIsNotAcceptable(pred,nodesFaultProb,pathFaultProb,MT,currentNode,destinationNode)
            error=1;TxtPath=''; return;
        else
            TxtPath='';
            while destinationNode~=currentNode
                TxtPath=[int2str(pred(destinationNode)),'->',int2str(destinationNode),' ', TxtPath];
                A(pred(destinationNode),destinationNode)=1;
                B(pred(destinationNode),destinationNode)=B(pred(destinationNode),destinationNode)-C;
                destinationNode=pred(destinationNode);
            end
            error=0;return;
        end
    %if none of the above is true
    else
        tB=B;
        %don't enter to the destination (till all required functions are met)
%          tB(:,destinationNode)=Inf;tB(destinationNode,:)=Inf;
        %Prevent Loops
        G=BRatioToD*ConvertZeroToInf(tB)+(1-BRatioToD)*D;
        %fix the NaN value (devisioned by zero )
        for i=1:n
            for j=1:n
                if isnan(G(i,j))
                    G(i,j)=0;
                end
            end
        end
        %Select Next node to go
        sortedNodes=SortNodesBasedOnTheirEnergyConsumption(currentNode,B,WN,EC,n,0);
        for i=1:size(sortedNodes,2)
            nextNode=sortedNodes(i);
            tR=R;tU=U;tWN=WN;tNC=NC;
            %check if there is any function to deliver to the flow in the next node
            for x=1:numbrOfFunctions
                if tR(x)~=0 && F(nextNode,x) && tNC(nextNode)>=FP(x)*C
                    tNC(nextNode)=tNC(nextNode)-FP(x)*C;
                    tR(x)=0;
                    tU(nextNode,x)=1;
                    tWN(nextNode)=1;
                end
            end
            %go to next node
            B(currentNode,nextNode)=B(currentNode,nextNode)-C;
            [tA,tU,tB,tNC,tWN,error,TxtPath]=HFNR_Solver_NoLoop(n,numbrOfFunctions,BRatioToD,B,D,C,FP,tNC,F,tWN,EC,tR,...
                A,tU,nodesFaultProb,pathFaultProb*(1-nodesFaultProb(nextNode)),MT,nextNode,destinationNode);
            B(currentNode,nextNode)=B(currentNode,nextNode)+C;
            %if there is no error, the problem is solved, otherwise, previouse next node wasn't a good node
            if error==0
                A=tA;U=tU;B=tB;NC=tNC;WN=tWN;
                A(currentNode,nextNode)=1;
%                 B(currentNode,nextNode)=B(currentNode,nextNode)-C;
                TxtPath=[num2str(currentNode),'->',num2str(nextNode),' ',TxtPath]; 
                return; 
            end
        end
        %if the problem reach this place, it means that it couldn't find a proper solution
        TxtPath='';
        error=1;  
    end
end

function [sortedNodes]=SortNodesBasedOnTheirEnergyConsumption(currentNode,B,WN,EC,n,CrossedNodes)
    for i=1:n
        %if the node is ON then the energy consumption is considered as zero
        if WN, EC(i)=0; end
        %if there is no link between the currentNode and selected node, then the energy consumption is considered as Inf
        if isinf(B(currentNode,i)), EC(i)=Inf; end
        %if the node is previously met, the flow cannot cross it, therefore, the energy consumption is Inf
        EC(find(CrossedNodes==1))=Inf;
    end
    sortedNodes=[];
    while ~isinf(min(EC))
        minEnergy=find(EC==min(EC));
        sortedNodes=[sortedNodes,minEnergy];
        EC(minEnergy)=Inf;
    end
    
end
        
function [IndMinE_MinDist]=Find_MinEnergy_MinDist(E,dist)
    IndMinE=find(E==min(E));
    IndMinDist=find(dist==min(dist(IndMinE)));
    for j=1:size(IndMinE,2)
        i=IndMinE(j);
        if dist(i)==dist(IndMinDist)
            IndMinE_MinDist=i;
            return;
        end
    end
end

function [U,SN,SF,B,NC,A,step,CrossedNodes,WN,K,TxtPath]=SelectNodeWithMinEnergyConsumption(E,dist,C,FP,pred,B,s,A,step,U,maxNmbrFuncPerFlw,K,F,NC,CrossedNodes,WN,miu2,TxtPath)
    IndMinE_MinDist=Find_MinEnergy_MinDist(E,dist);
    %select one of nodes with similar energy consumption and distance
    %SN: selected node
    SN=IndMinE_MinDist(1);
    WN(SN)=1;
    %if this node is not crossed befor, then move to it
    if ~CrossedNodes(SN)
        %move to the selected node
        if SN~=s
            step=step+1;
        end
        d=SN;
        while d~=s
            TxtPath=[int2str(pred(d)),'->',int2str(d),' ', TxtPath];
            A(pred(d),d)=step;
            B(pred(d),d)=B(pred(d),d)-C;
            d=pred(d);
            CrossedNodes(d)=1;
        end
    end
    %SF: Selected Functions to be delivered in the Selected Node
    SF=zeros(1,maxNmbrFuncPerFlw);
    tmpIndx=1;
    for m=1:maxNmbrFuncPerFlw
        if K(m)>0 && F(SN,K(m))~=0
            if NC(SN)*miu2>C*FP(K(m))
                U(SN,K(m))=1;
                NC(SN)=NC(SN)-C*FP(K(m));
                SF(tmpIndx)=K(m);
                tmpIndx=tmpIndx+1;
                K(m)=0;
            end
        end
    end
end

function [E]=EnergyConsumption(dist,WN,EC,n)
    E=inf(1,n);
    for i=1:n
        if dist(i)~=inf 
            if WN(i)==1
                E(i)=0;
            else
                E(i)=EC(i);
            end
        end
    end
end

function [G]=PruneLinks(G,B,C,miu,n,OriginalB)
    %Eliminate links that has a free bandwidth less than the flow required capacity
    for i=1:n
        for j=1:n
            if (B(i,j)- (OriginalB(i,j)*(1-miu)) )<C
                G(i,j)=0;
            end
        end
    end
end

function [dist]=PruneNodes(F,dist,n,miu2,C,NC,maxNmbrFuncPerFlw,K,FP)
    %eliminate nodes that (have not enough processing power) or (support non of required functions)
    for i=1:n 
       ind=0;
        for m=1:maxNmbrFuncPerFlw
            %support one of required functions 
            if K(m)>0 && F(i,K(m))~=0
                %has enough processing power
                if NC(i)*miu2>C*FP(K(m))
                    ind=1;
                end
            end
        end
        if ind==0
            dist(i)=inf;
        end
    end    
%     if min(dist==inf)
%             disp('*****************error in HNR_RR, cannot find the result #3**********************');
%     end
end

function [B]=ConvertInfToZero(B)
    for i=1:size(B,1)
        for j=1:size(B,2)
            if B(i,j)==inf
                B(i,j)=0;
            end
        end
    end
end

function [ind]=SortFlowsBasedOnTheirSize(C)
    ind=zeros(1,size(C,2));
    for i=1:size(C,2)
        tmp=find(C==max(C));
        ind(i)=tmp(1);
        C(ind(i))=-1;
    end
end

function [error] = FailureProbOfPathIsNotAcceptable(pred,nodesFaultProb,pathFaultProb,MT,currentNode,destinationNode)
    while destinationNode~=currentNode
        pathFaultProb=pathFaultProb*(1-nodesFaultProb(destinationNode));
        destinationNode=pred(destinationNode);
    end
    if pathFaultProb < 1-MT
        error=1; 
    else
        error=0; 
    end
end










