%Plot figures for all folders with name '__'
function PlotResults_AllSubFoldersOf(FolderAddres)
    if size(FolderAddres,1)==0
        FolderAddres='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Failure-Recovery SFC No-Energy-aware Fog-Support\Simulation\results\';
    else
        FolderAddres=[FolderAddres,'\'];
    end
%     UseAbileneTopology=input('use Abilene as the network? Or take the topology from file?(A Or F)');
    folders=dir(FolderAddres);indexOfFig=1;
    %for each folder with starting name '__'
    for iFolder=1:size(folders,1)
        if strcmp(folders(iFolder).name,'.')==0 && strcmp(folders(iFolder).name,'..')==0 && folders(iFolder).isdir==1 && strcmp(folders(iFolder).name(1:2),'__')
            readFrom=[FolderAddres,folders(iFolder).name,'\'];
            
            files=dir(readFrom);
            %for each file in the folder
            for i=1:size(files,1)
                if strcmp(files(i).name,'.')==0 && strcmp(files(i).name,'..')==0 && files(i).isdir==0 && strcmp(files(i).name,'Notation.txt')==0 && strcmp(files(i).name,'Notation.pdf')==0
                    [A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0] ...
                =LoadResult([readFrom,files(i).name]);
                
                [nodesFaultProb,MT,switchFailProb]=FailurProbForDifferentPath(n);
%                 [EC]=MapVMEnergyConsumptionBetween200And400(EC);
                
                
%                 if strcmp(UseAbileneTopology,'A'),[n,B,D]=CreateTopology(bandwidth,'Abilene');end
                    %setting the parameters: link utilization, node utilization,
                    %delay, etc.
                    for tmpItr=1:1                     
                     if strcmp(files(i).name(1:4),'OFES')
                        NameOfFile=files(i).name(6:findstr(files(i).name,'.txt'));
                        OFES_ind=str2double(files(i).name(10));
                        [OFES_linkUtilization(indexOfFig,OFES_ind)]=AverageOverNaN(LinkUtilization(n,p,A,C,B));
                        [OFES_nodeUtilization(indexOfFig,OFES_ind)]=mean(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [OFES_MlinkUtilization(indexOfFig,OFES_ind)]=MaxOverNaN(LinkUtilization(n,p,A,C,B));
                        [OFES_MnodeUtilization(indexOfFig,OFES_ind)]=max(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [OFES_powerConsumption(OFES_ind)]=PowerConsumption(n,WN,EC);
                        [OFES_averagePathLength(OFES_ind)]=AveragePathLength(p,A,s,d);
                        [OFES_avgDelay(OFES_ind),RR_numberOfDelayedFlow(OFES_ind)]=Delay(p,A,s,D,T);
                        [OFES_averageFaultProb(OFES_ind),OFES_numberOfViolatedConstraint(OFES_ind)]=FaultProb(A,s,switchFailProb,MT,p);
                    elseif strcmp(files(i).name(1:4),'HFES')
                        HFES_ind=str2double(files(i).name(12));
                        [HFES_linkUtilization(indexOfFig,HFES_ind)]=AverageOverNaN(LinkUtilization(n,p,A,C,B));
                        [HFES_nodeUtilization(indexOfFig,HFES_ind)]=mean(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [HFES_MlinkUtilization(indexOfFig,HFES_ind)]=MaxOverNaN(LinkUtilization(n,p,A,C,B));
                        [HFES_MnodeUtilization(indexOfFig,HFES_ind)]=max(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                        [HFES_powerConsumption(HFES_ind)]=PowerConsumption(n,WN,EC);
                        [HFES_averagePathLength(HFES_ind)]=AveragePathLength(p,A,s,d);
                        [HFES_avgDelay(HFES_ind),NEW_RR_numberOfDelayedFlow(HFES_ind)]=Delay(p,A,s,D,T);
                        [HFES_averageFaultProb(HFES_ind),HFES_numberOfViolatedConstraint(HFES_ind)]=FaultProb(A,s,switchFailProb,MT,p);
                    end
                    end
                end
            end   

            addrsToSaveFigures='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Failure-Recovery SFC No-Energy-aware Fog-Support\Simulation\Figures\';

            display(['ploting ', NameOfFile]);
            NewPlot4InputMatrix(1,100*OFES_MlinkUtilization(indexOfFig,:),100*HFES_MlinkUtilization(indexOfFig,:),100*OFES_linkUtilization(indexOfFig,:),100*HFES_linkUtilization(indexOfFig,:),...
                'Maximum Link Utilization [%]','Iteration','Average Link Utilization [%]', addrsToSaveFigures,['Link',num2str(indexOfFig)],1,1);
            NewPlot4InputMatrix(2,100*OFES_MnodeUtilization(indexOfFig,:),100*HFES_MnodeUtilization(indexOfFig,:),round(100*OFES_nodeUtilization(indexOfFig,:),3),round(100*HFES_nodeUtilization(indexOfFig,:),3),...
                'Maximum Server Utilization [%]','Iteration','Average Server Utilization [%]', addrsToSaveFigures,['Server',num2str(indexOfFig)],1,1);
            
            NewPlot2InputMatrix(3, OFES_averageFaultProb, HFES_averageFaultProb, 'Average Failure Probability', 'Time Slot', addrsToSaveFigures,['Failure',num2str(indexOfFig)])
            NewPlot2InputMatrix(4, OFES_averagePathLength, HFES_averagePathLength, 'Average Path Length', 'Time Slot', addrsToSaveFigures,['PathLength',num2str(indexOfFig)])
            
            indexOfFig=indexOfFig+1;
%             NewPlot4InputMatrix(1,100*OFES_averagePathLength,100*HFES_averagePathLength,100*OFES_linkUtilization,100*HFES_linkUtilization,...
%                 'Maximum Link Utilization [%]','Iteration','Average Link Utilization [%]', addrsToSaveFigures,['Link',NameOfFile]);
%             NewPlot4InputMatrix(2,100*OFES_MlinkUtilization,100*HFES_MlinkUtilization,100*OFES_nodeUtilization,100*HFES_nodeUtilization,...
%                 'Maximum Server Utilization [%]','Iteration','Average Server Utilization [%]', addrsToSaveFigures,['Server',NameOfFile]);
            %plot figures
%             NewPlot2InputMatrix(1,100*OFES_linkUtilization,100*HFES_linkUtilization,...
%                 'Average Link Utilization [%]','Iteration',addrsToSaveFigures,['lnkUtl',NameOfFile]);
%             NewPlot2InputMatrix(2,100*OFES_nodeUtilization,100*HFES_nodeUtilization,...
%                 'Average Server Utilization [%]','Iteration',addrsToSaveFigures,['ndeUtl',NameOfFile]);
%             NewPlot2InputMatrix(3,100*OFES_powerConsumption,100*HFES_powerConsumption,...
%                 'Power Consumption','Iteration',addrsToSaveFigures,['pwrCns',NameOfFile]);
%         %     NewPlot4InputMatrix(4,RR_netSideEffect,NSFF_RR_netSideEffect,NEW_RR_netSideEffect,ENSFF_RR_netSideEffect,...
%         %         'Network Side-Effect','Iteration',addrsToSaveFigures,['netSid',NameOfFile]);
%             NewPlot2InputMatrix(5,100*OFES_averagePathLength,100*HFES_averagePathLength,...
%                 'Average Path Length','Iteration',addrsToSaveFigures,['pthLen',NameOfFile]);
%             NewPlot2InputMatrix(6,100*OFES_MlinkUtilization,100*HFES_MlinkUtilization,...
%                 'Maximum Link Utilization [%]','Iteration',addrsToSaveFigures,['mlnkUtl',NameOfFile]);
%             NewPlot2InputMatrix(7,100*OFES_MnodeUtilization,100*HFES_MnodeUtilization,...
%                 'Maximum Server Utilization [%]','Iteration',addrsToSaveFigures,['mndeUtl',NameOfFile]);
%             
%             NewPlot2InputMatrix(8,OFES_averageFaultProb,HFES_averageFaultProb,...
%                 'Average Fault Prob','Iteration',addrsToSaveFigures,['falprb',NameOfFile]);
%             NewPlot2InputMatrix(9,OFES_numberOfViolatedConstraint,HFES_numberOfViolatedConstraint,...
%                 'Constraint Violation','Iteration',addrsToSaveFigures,['cnstVio',NameOfFile]);
        end
    end
%     display('ploting aggregated figures, average utilization');
%     NewPlot6InputMatrix(indexOfFig,100*OFES_linkUtilization(1,:),100*OFES_linkUtilization(2,:),100*OFES_linkUtilization(3,:),...
%         100*HFES_linkUtilization(1,:),100*HFES_linkUtilization(2,:),100*HFES_linkUtilization(3,:),...
%         'Avg. Link Utilization [%]','Time Slot', addrsToSaveFigures,['Link',num2str(indexOfFig)],'S1 OFES','S2 OFES','S3 OFES','S1 HFES','S2 HFES','S3 HFES');
%     NewPlot6InputMatrix(indexOfFig,100*OFES_nodeUtilization(1,:),100*OFES_nodeUtilization(2,:),100*OFES_nodeUtilization(3,:),...
%         100*HFES_nodeUtilization(1,:),100*HFES_nodeUtilization(2,:),100*HFES_nodeUtilization(3,:),...
%         'Avg. Fog Node Utilization [%]','Time Slot', addrsToSaveFigures,['Server',num2str(indexOfFig)],'S1 OFES','S2 OFES','S3 OFES','S1 HFES','S2 HFES','S3 HFES');
%     
%     indexOfFig=indexOfFig+1;        
%     NewPlot6InputMatrix(indexOfFig,100*OFES_linkUtilization(4,:),100*OFES_linkUtilization(5,:),100*OFES_linkUtilization(6,:),...
%         100*HFES_linkUtilization(4,:),100*HFES_linkUtilization(5,:),100*HFES_linkUtilization(6,:),...
%         'Avg. Link Utilization [%]','Time Slot', addrsToSaveFigures,['Link',num2str(indexOfFig)],'S4 OFES','S5 OFES','S6 OFES','S4 HFES','S5 HFES','S6 HFES');
%     NewPlot6InputMatrix(indexOfFig,100*OFES_nodeUtilization(4,:),100*OFES_nodeUtilization(5,:),100*OFES_nodeUtilization(6,:),...
%         100*HFES_nodeUtilization(4,:),100*HFES_nodeUtilization(5,:),100*HFES_nodeUtilization(6,:),...
%         'Avg. Fog Node Utilization [%]','Time Slot', addrsToSaveFigures,['Server',num2str(indexOfFig)],'S4 OFES','S5 OFES','S6 OFES','S4 HFES','S5 HFES','S6 HFES');
%     
%     indexOfFig=indexOfFig+1;        
%     NewPlot6InputMatrix(indexOfFig,100*OFES_linkUtilization(7,:),100*OFES_linkUtilization(8,:),100*OFES_linkUtilization(9,:),...
%         100*HFES_linkUtilization(7,:),100*HFES_linkUtilization(8,:),100*HFES_linkUtilization(9,:),...
%         'Avg. Link Utilization [%]','Time Slot', addrsToSaveFigures,['Link',num2str(indexOfFig)],'S7 OFES','S8 OFES','S9 OFES','S7 HFES','S8 HFES','S9 HFES');
%     NewPlot6InputMatrix(indexOfFig,100*OFES_nodeUtilization(7,:),100*OFES_nodeUtilization(8,:),100*OFES_nodeUtilization(9,:),...
%         100*HFES_nodeUtilization(7,:),100*HFES_nodeUtilization(8,:),100*HFES_nodeUtilization(9,:),...
%         'Avg. Fog Node Utilization [%]','Time Slot', addrsToSaveFigures,['Server',num2str(indexOfFig)],'S7 OFES','S8 OFES','S9 OFES','S7 HFES','S8 HFES','S9 HFES');
%     indexOfFig=indexOfFig+1; 
    
    display('ploting aggregated figures, maximum utilization');
    NewPlot4InputMatrix(indexOfFig,100*OFES_MlinkUtilization(:,4)',100*HFES_MlinkUtilization(:,4)',100*OFES_MnodeUtilization(:,4)',100*HFES_MnodeUtilization(:,4)',...
                'Max Link Utilization [%]','Scenario','Max Fog Node Utilization [%]', addrsToSaveFigures,['MaxUtilization',num2str(indexOfFig)],2,1);
end
function [linkUtilization]=LinkUtilization(n,p,A,C,B)
    linkLoad=LinkLoad(n,p,A,C);
    for i=1:n
        for j=1:n
            if linkLoad(i,j)>B(i,j)
                disp(['error in LinkUtilization Checker, the link load of the follwoing link is higher than the link capacity: ',num2str(i),' ',num2str(j)]);
            end
        end
    end
    linkUtilization=linkLoad./B;
end
function [nodeUtilization]=NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC)
    %NC: nodes processing capacity,
    nodeLoad=NodeLoad(n,p,numbrOfFunctions,U,C,FP);
    nodeUtilization=nodeLoad./NC;
end
function [linkLoad]=LinkLoad(n,p,A,C)
    linkLoad=zeros(n,n);
    for i=1:n
        for j=1:n
            for f=1:p
                linkLoad(i,j)=linkLoad(i,j)+(A(i,j,f)>0)*C(f);
            end
        end
    end
end
function [nodeLoad]=NodeLoad(n,p,numberOfFunction,U,C,FP)
    %FP: required processing power of funtionss, 
    nodeLoad=zeros(1,n);
    for i=1:n
        for f=1:p
            for m=1:numberOfFunction
                nodeLoad(i)=nodeLoad(i)+U(i,m,f)*C(f)*FP(m);
            end
        end
    end
end
function [powerConsumption]=PowerConsumption(n,WN,EC)
    %EC: nodes' energy consumption
    %WN: state of switches(On/Off),    
    powerConsumption=0;
    for i=1:n
        powerConsumption=powerConsumption+WN(i)*EC(i);
    end
end
function [netSideEffect]=NetworkSideEffect(n,p,A,A0)
    netSideEffect=0;
    for i=1:n
        for j=1:n
            for f=1:p
                netSideEffect=netSideEffect+abs(A(i,j,f)-A0(i,j,f));
            end
        end
    end
end
function [averagePathLength]=AveragePathLength(p,A,s,d)
    averagePathLength=0;
    for i=1:p
        averagePathLength=averagePathLength+PathLength(i,A,s(i),d(i));
    end
    averagePathLength=averagePathLength/p;
end
function [pathLength]=PathLength(flowIndex,A,s,d)
    pathLength=0;
    maxAllowedLength=100;
    while sum(A(s,:,flowIndex)) && maxAllowedLength    
        pathLength=pathLength+1;
        s1=find(A(s,:,flowIndex));
        %in NSFF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(s,:,flowIndex)==min(A(s,s1,flowIndex)));
        A(s,s1,flowIndex)=0;
        s=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #1***************');
    end
end
function [res]=AverageOverNaN(input)
    res=0;
    num=0;
    for i=1:size(input,1)
        for j=1:size(input,2)
            if ~isnan(input(i,j))
                res=res+input(i,j);
                num=num+1;
            end
        end
    end
    res= res/num;
end
function [res]=MaxOverNaN(input)
    res=0;
    for i=1:size(input,1)
        for j=1:size(input,2)
            if ~isnan(input(i,j)) && res<input(i,j)
                res=input(i,j);
            end
        end
    end
end
function [avgDelay,numberOfDelayedFlow]=Delay(p,A,src,D,T)
    avgDelay=0;numberOfDelayedFlow=0;
    for f=1:p
        tmpDly=FlowDelay(A,src(f),D,f);
        avgDelay=avgDelay+tmpDly;
        if tmpDly>T(f)
            numberOfDelayedFlow=numberOfDelayedFlow+1;
        end
    end
    avgDelay=avgDelay/p;
end
function [delay]=FlowDelay(A,src,D,flowIndex)
    delay=0;
    maxAllowedLength=100;
    while sum(A(src,:,flowIndex)) && maxAllowedLength    
        s1=find(A(src,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
        A(src,s1,flowIndex)=0;
        delay=delay+D(src,s1);
        src=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #2***************');
    end


end
function [avgHops]=AvgHops(p,A,src)
    avgHops=0;
    for f=1:p
        tmpDly=FlowHops(A,src(f),f);
        avgHops=avgHops+tmpDly;
    end
    avgHops=avgHops/p;
end
function [hops]=FlowHops(A,src,flowIndex)
    hops=0;
    maxAllowedLength=100;
    while sum(A(src,:,flowIndex)) && maxAllowedLength    
        s1=find(A(src,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
        A(src,s1,flowIndex)=0;
        hops=hops+1;
        src=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #3***************');
    end


end
function NewPlot5InputMatrix(figNumber, A, B, C, D, E, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(1:size(A,2),[A;B;C;D],'MarkerSize',15,'LineWidth',2);
    hold on;
    plot(1:size(A,2),E,'MarkerSize',15,'LineWidth',2,'Marker','^','DisplayName','ENSFF_S');
%     set(plot1(1),'Marker','square','MarkerFaceColor','r');
    set(plot1(1),'Marker','s');
    set(plot1(2),'Marker','o');
    set(plot1(3),'Marker','*');
    set(plot1(4),'Marker','d');
%     set(plot1(5),'Marker','^');
    
    %Create Legend
    set(plot1(1),'DisplayName','RR');
    set(plot1(2),'DisplayName','NSFF');
    set(plot1(3),'DisplayName','RRR');
    set(plot1(4),'DisplayName','ECSPF');
%     set(plot1(5),'DisplayName','ENSFF');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
%     set(axes1,'FontSize',40,'XTick',1:size(A,2));
    set(axes1,'XTick',1:size(A,2));
    
    Leg1=legend('RR','NSFF','RRR','ENSF','ENSFF_S');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    %Save to file
    savefig([AddrToSaveFig,FigName,'.fig']);
    saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
    saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
    NewFigName='fig';
    tmpIndN=strfind(FigName,'p=');
    NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
    NewFigName=[NewFigName,FigName(1:2)];
    saveas(gcf,[AddrToSaveFig,NewFigName,'.eps']);
end
function NewPlot2InputMatrix(figNumber, A, B, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(1:size(A,2),[A;B],'MarkerSize',15,'LineWidth',2);
%     set(plot1(1),'Marker','square','MarkerFaceColor','r');
    set(plot1(1),'Marker','s','MarkerFaceColor','r','MarkerEdgeColor','r','color','r','LineStyle',':');
    set(plot1(2),'Marker','o','MarkerFaceColor','b','MarkerEdgeColor','b','color','b');
    
    %Create Legend
    set(plot1(1),'DisplayName','OFES');
    set(plot1(2),'DisplayName','HFES');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',19,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
    Leg1=legend('OFES','HFES');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    %remove white space from the pdf file
    %     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];



    %Save to file
%     savefig([AddrToSaveFig,FigName,'.fig']);
    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
%     NewFigName='fig';
%     tmpIndN=strfind(FigName,'p=');
%     NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
%     NewFigName=[NewFigName,FigName(1:2)];
%     saveas(gcf,[AddrToSaveFig,NewFigName,'.pdf']);
end
function [EC]=MapVMEnergyConsumptionBetween200And400(EC)
    EC=EC-min(EC);
    EC=EC/max(EC);
    EC=200+EC*2000;
end
function [faultProb]=PathFaultProb(A,src,flowIndex,switchFailProb,p)
    faultProb=1-switchFailProb(src);
    for i=1:size(A,1)
        xtemp=sum(A(i,:,flowIndex));
        if xtemp
            faultProb=xtemp*faultProb*(1-switchFailProb(i));
        end
    end
%     maxAllowedLength=100;
%     while (sum(A(src,:,flowIndex))>0) && (maxAllowedLength>0)
%         s1=find(A(src,:,flowIndex));
%         %in CSPF loops are not forbiden but instead if a flow return to a
%         %switch then when it exit the number is increased
%         %e.g., A(1,2,3)=1, A(1,3,3)=2
%         s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
%         A(src,s1,flowIndex)=0;
%         faultProb=faultProb*(1-switchFailProb(s1));
%         src=s1;
%         maxAllowedLength=maxAllowedLength-1;
%     end
%     if maxAllowedLength==0
%         disp('************error in analysis #2***************');
%     end
    faultProb=1-faultProb;
end
function [averageFaultProb,numberOfViolatedConstraint]=FaultProb(A,src,switchFailProb,MT,p)
    numberOfViolatedConstraint=0;
    for f=1:p
        FaultProb(f)=PathFaultProb(A,src(f),f,switchFailProb);
        if FaultProb(f)>MT
            numberOfViolatedConstraint=numberOfViolatedConstraint+1;
        end
    end
    averageFaultProb=sum(FaultProb)/p;
end
function NewPlot4InputMatrix(figNumber, A, B, C,D, Y1labelText, X1labelText,Y2labelText, AddrToSaveFig, FigName,FigrueWidthIncrementFactor,FigrueHeighIncrementFactor)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');

    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(1:size(A,2),[A;B],'MarkerSize',15,'LineWidth',2);
%     set(plot1(1),'Marker','square','MarkerFaceColor','r');
%     set(plot1(1),'Marker','s','MarkerFaceColor','r','MarkerEdgeColor','r','color','r','LineStyle',':');
%     set(plot1(2),'Marker','o','MarkerFaceColor','b','MarkerEdgeColor','b','color','b');
    set(plot1(1),'Marker','s','MarkerFaceColor','k','MarkerEdgeColor','k','color','k','LineStyle',':');
    set(plot1(2),'Marker','o','MarkerFaceColor','k','MarkerEdgeColor','k','color','k');

    %Create Legend
    set(plot1(1),'DisplayName','OFES');
    set(plot1(2),'DisplayName','HFES');
    
    % Create labels
    ylabel(Y1labelText);
    xlabel(X1labelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',19,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
%     Leg1=legend('OFES','HFES');
% %     Leg1.Orientation = 'horizontal';
%     set(Leg1,...
%     'location','northoutside',...
%     'Orientation','horizontal');
    
    
    yyaxis right
    plot1=plot(1:size(A,2),[C;D],'MarkerSize',15,'LineWidth',2);
%     set(plot1(1),'Marker','square','MarkerFaceColor','r');
%     set(plot1(1),'Marker','s','MarkerFaceColor','b','MarkerEdgeColor','b','color','b','LineStyle',':');
%     set(plot1(2),'Marker','o','MarkerFaceColor','b','MarkerEdgeColor','b','color','b');
    set(plot1(1),'Marker','s','MarkerEdgeColor','r','color','r','LineStyle',':');
    set(plot1(2),'Marker','o','MarkerEdgeColor','r','color','r');
    
    %change the color yaxis
    ax=gca;
    ax.YColor='r';
    
    
    ylabel(Y2labelText);
    set(plot1(1),'DisplayName','OFES');
    set(plot1(2),'DisplayName','HFES');
    Leg1=legend('OFES','HFES','OFES','HFES');
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    %increasing the figure width: twice of normal  [leftMargin rigthMargin width heigth]
    fig_pos = fig1.Position;
    set(fig1,'pos',[fig_pos(1) fig_pos(2) FigrueWidthIncrementFactor*fig_pos(3) FigrueHeighIncrementFactor*fig_pos(4)]);

    %remove white space from the pdf file
    %     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    paper_pos = fig1.PaperPosition;
    fig1.PaperSize = [paper_pos(3) paper_pos(4)];


    %Save to file
%     savefig([AddrToSaveFig,FigName,'.fig']);
    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
%     NewFigName='fig';
%     tmpIndN=strfind(FigName,'p=');
%     NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
%     NewFigName=[NewFigName,FigName(1:2)];
%     saveas(gcf,[AddrToSaveFig,NewFigName,'.pdf']);
end
function NewPlot6InputMatrix(figNumber,A, B, C, D, E, F, YlabelText, XlabelText, AddrToSaveFig, FigName,P1Name,P2Name,P3Name,P4Name,P5Name,P6Name)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(1:size(A,2),[A;B;C;D;E;F],'MarkerSize',10,'LineWidth',3);
    hold on;
%     plot(1:size(A,2),E,'MarkerSize',10,'LineWidth',2,'Marker','^','DisplayName','ENSFF_S');
%     set(plot1(1),'Marker','square','MarkerFaceColor','r');
    set(plot1(1),'Marker','s','MarkerEdgeColor','k','color','k','LineStyle',':');
    set(plot1(2),'Marker','o','MarkerEdgeColor','k','color','k','LineStyle','-.');
    set(plot1(3),'Marker','*','MarkerEdgeColor','k','color','k','LineStyle','-');
    set(plot1(4),'Marker','d','MarkerEdgeColor','r','color','r','LineStyle',':');
    set(plot1(5),'Marker','^','MarkerEdgeColor','r','color','r','LineStyle','-.');
    set(plot1(6),'Marker','x','MarkerEdgeColor','r','color','r','LineStyle','-');
    
    %Create Legend
    set(plot1(1),'DisplayName',P1Name);
    set(plot1(2),'DisplayName',P2Name);
    set(plot1(3),'DisplayName',P3Name);
    set(plot1(4),'DisplayName',P4Name);
    set(plot1(5),'DisplayName',P5Name);
    set(plot1(6),'DisplayName',P6Name);
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
%     set(axes1,'FontSize',40,'XTick',1:size(A,2));
    set(axes1,'FontSize',19,'XTick',1:size(A,2));
    
    Leg1=legend(P1Name,P2Name,P3Name,P4Name,P5Name,P6Name);
%     Leg1.Orientation = 'horizontal';
%     set(Leg1,...
%     'location','westoutside',...
%     'Orientation','horizontal');
    
    %remove white space from the pdf file
    %     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];



    %Save to file
%     savefig([AddrToSaveFig,FigName,'.fig']);
    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
%     NewFigName='fig';
%     tmpIndN=strfind(FigName,'p=');
%     NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
%     NewFigName=[NewFigName,FigName(1:2)];
%     saveas(gcf,[AddrToSaveFig,NewFigName,'.pdf']);
end



