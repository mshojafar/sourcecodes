%if readFrom=='' ---> generate traffic
%ifReadFromFile_miu=0 means that ignor ifReadFromFile_miu
%n: number of switches, miu: maximum link utilization
function OFES(strtOfTimeSlot,endOfTimeSlots,readFrom,ifReadFromFile_DemandIncrementRatio,ifReadFromFile_miu,ifReadFromFile_miu2,LinksForFailureI,LinksForFailureJ)
    %variable definition
    for i=1:1 
    %B: matrix of links' bandwidth, 
    %D: Links' propagation delay
    %C: flow bandwidth requirement, 
    %T: maximum tolerable propagation delay,
    %s: source switches, 
    %d: destination switches, 
    %R: functions requirements of flows, 
    %K: sequence of required functions
    %p:number of flows
    %FP: required processing power of funtionss, 
    %NC: nodes processing capacity, 
    %F: functions associated withe nodes,
    %EC: nodes' energy consumption
    %WN0: current state of switches(On/Off),
    end
    if size(readFrom,1)==0
        [prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow, avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,...
        minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,...
        prcntNodThtCanHstFunc,prcntFncThatHostedByANode,energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,miu,miu2,...
        flowDemandIncreamentFactor]= SetParameter_RA();
    
         [n,B,D]=CreateTopology(bandwidth,'Abilene');
%         [n,B,D]=CreateTopology(bandwidth,'NSFNET');   
        %[n,B,D]=CreateTopology(bandwidth,'Simple');
%         [n,B,D]=CreateTopology(bandwidth,'VerySimple');
        [C,T,s,d,R,K,p]=ReadFlows(n, prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow, avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc,...
            avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,bandwidth,minTolrblDly,maxTolrbDly);
        
        [FP,NC,F,EC]=CreateVMs(n,nodeProcessingPowerToBandwidhRatio, numbrOfFunctions,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio, bandwidth,B);
%         EC=MapVMEnergyConsumptionBetween150And300(EC);
        
        [failurProb,MT,switchFailProb]=FailurProbForDifferentPath(n);
    else
        [A,U,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0]= LoadResult(readFrom);
        [failurProb,MT,switchFailProb]=FailurProbForDifferentPath(n);
        if ifReadFromFile_DemandIncrementRatio~=0
            flowDemandIncreamentFactor=ifReadFromFile_DemandIncrementRatio; end
        if ifReadFromFile_miu~=0
            miu=ifReadFromFile_miu; end
        if ifReadFromFile_miu2~=0
            miu2=ifReadFromFile_miu2; end
    end
    input(['p=',num2str(p),' press any key to continue']);

    A0=zeros(n,n,p);U0=zeros(n,numbrOfFunctions,p);WN0=zeros(1,n);
    for i=strtOfTimeSlot:endOfTimeSlots
        tic
        [A,U,NA]=SolverForOSFR(n,p,numbrOfFunctions,miu,miu2,B,MT,C,s,d,R,FP,NC,F,failurProb,K);
        [A,U,NA]=RecoveryFromCVXBug(A,U,NA);
        toc
        if sum(sum(sum(A)))==n*n*p, display('*****************OFES could not solve the problem******************');end
        display(['for p=',num2str(p),' itr=',num2str(i)]);
        SaveResult(['OFES_itr=',num2str(i)],A,U,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0,'');
        
        %Failure in a link
        if sum(LinksForFailureI)==0 && i~=endOfTimeSlots
            IndexTemp=find(B);
            randIndex=randi(size(IndexTemp,1),1,1);
            B(IndexTemp(randIndex))=0;
        elseif i~=endOfTimeSlots
            B(LinksForFailureI(i),LinksForFailureJ(i))=0;
            B(LinksForFailureJ(i),LinksForFailureI(i))=0;
        end
%         C=IncreaseFlowDemands(C,flowDemandIncreamentFactor);
    end
end

function [EC]=MapVMEnergyConsumptionBetween150And300(EC)
    EC=EC-min(EC);
    EC=EC/max(EC);
    EC=150+EC*150;
end

function [failurProb,MT]=FailurProbForDifferentPath2Dim(n,numberOfFlows)
    MT=0.4;
    switchFailProb=0.001*ones(1,n);
    failurProb = zeros(2^n, numberOfFlows);
    failurProb=ones(1,2^n);
    for i=1:n
        for j=2^(i-1):2^i:2^n
            for z=0:2^(i-1)-1
                failurProb(j+z)=failurProb(j+z)*(1-switchFailProb(i));
            end
        end
    end
    failurProb=1-failurProb;
end

% function [A,U,WN]=SolverForOSFR(n,numberOfFlows,numberOfFunctions,miu,miu2,B,MT,C,s,d,R,FP,NC,F,EC,failurProb) % for energy consideration
function [A,U,NA]=SolverForOSFR(n,numberOfFlows,numberOfFunctions,miu,miu2,B,MT,flowRate,s,d,R,FP,NC,F,failurProb,K)
    numberOfDifferentPaths=2^n;
    L=(1:numberOfDifferentPaths);
    
    cvx_begin quiet
        cvx_solver MOSEK 
%         cvx_solver_settings('TIMELIMIT', 100)
%         cvx_solver_settings('MSK_DPAR_MIO_MAX_TIME', 1000)

        variable A(n,n,numberOfFlows) binary;
        variable U(n,numberOfFunctions,numberOfFlows) binary;
%         variable WN(n) binary;
        variable Z(numberOfFlows) integer;
        variable J(numberOfDifferentPaths,numberOfFlows) binary
        variable NA(n,n,numberOfFlows) integer;
                 
        subject to        
            %Eq. 6
            for i=1:n
                tmpEq6=sum(U(i,:,1).*FP)*flowRate(1);
                for f=2:numberOfFlows
                    tmpEq6=tmpEq6+sum(U(i,:,f).*FP)*flowRate(f);
                end
                tmpEq6<=miu2*NC(i);
            end
            %Eq. 7
            for i=1:n
                for j=1:n
                    tmpEq7=A(i,j,1)*flowRate(1);
                    for f=2:numberOfFlows
                        tmpEq7=tmpEq7+A(i,j,f)*flowRate(f);
                    end
                    tmpEq7<=miu*B(i,j);
                end
            end
        
            %Routing
            %Eq. 8
            for f=1:numberOfFlows
                sum(A(:,s(f),f))==0;
                sum(A(d(f),:,f))==0;
            end
            %Eq. 9
            for f=1:numberOfFlows
                sum(A(s(f),:,f))==1;
                sum(A(:,d(f),f))==1;
            end
            %Eq. 10
            for f=1:numberOfFlows
                for i=1:n
                    if(i~=d(f) && i~=s(f))
                        sum(A(i,:,f))==sum(A(:,i,f));
                    end
                end
            end
            %Eq. 11
            for f=1:numberOfFlows
                for i=1:n
                    sum(A(i,:,f))<=1;
                end
            end
            
            %Service Function Chaining No Ordering
            %Eq. 2
            for m=1:numberOfFunctions
                for f=1:numberOfFlows
                    sum(U(:,m,f))==R(m,f);
                end
            end
            %Eq. 3
            for m=1:numberOfFunctions
                for f=1:numberOfFlows
                    for j=1:n
                        if j~=s(f)
                            sum(A(:,j,f))>=U(j,m,f);
                        end
                    end
                end
            end
            %Eq. 4
            for f=1:numberOfFlows
                for i=1:n
                    for m=1:numberOfFunctions
                        U(i,m,f)<=F(i,m);
                    end
                end
            end
            %Eq. 5
            for f=1:numberOfFlows
                for m=1:numberOfFunctions
                    sum(U(:,m,f))<=1;
                end
            end
            
            %Service Function Chaining With Ordering
            %Eq. 13
            for i=1:n
                for j=1:n
                    for f=1:numberOfFlows
                        NA(i,j,f)>=A(i,j,f);
                    end
                end
            end
            %Eq. 14
            for f=1:numberOfFlows
                for i=1:n
                    if i~=d(f)
                        for j=1:n
                            NA(i,j,f)<=n*A(i,j,f);
                        end
                    end
                end
            end
            %Eq. 14+
            for f=1:numberOfFlows
                for i=1:n
                    if i~=d(f)
                        NA(d(f),i,f)==0;
                    end
                end
            end
            %Eq. 15
            for f=1:numberOfFlows
                for i=1:n
                    if(i~=d(f) && i~=s(f))
                        tmpNAIJ=NA(i,1,f);
                        tmpNAJI=NA(1,i,f);
                        tmpAJI=A(1,i,f);
                        for j=2:n
                            tmpNAIJ=tmpNAIJ+NA(i,j,f);
                            tmpNAJI=tmpNAJI+NA(j,i,f);
                            tmpAJI=tmpAJI+A(j,i,f);
                        end
                        tmpNAIJ==tmpNAJI+tmpAJI;
                    end
                end
            end
            %Eq. 15+
            for f=1:numberOfFlows
                if(d(f)==1)
                    NA(d(f),d(f),f)==sum(NA(2:size(NA,2),d(f),f))+1;
                elseif(d(f)==size(NA,2))
                    NA(d(f),d(f),f)==sum(NA(1:d(f)-1,d(f),f))+1;
                else
                    NA(d(f),d(f),f)==sum(NA(1:d(f)-1,d(f),f))+sum(NA(d(f)+1:size(NA,2),d(f),f))+1;
                end
            end
            %Eq. 16
            for f=1:numberOfFlows
                sum(NA(s(f),:,f))==1;
            end
            %Eq. 17
            for f=1:numberOfFlows
                for i=1:n
                    for I=1:n
                        for v=1:size(find(K(f,:)),2)
                            if(K(f,v)~=0)
                                for z=1:v-1
                                    (1-U(i,K(f,v),f))*(2*n+1)+sum(NA(i,:,f))>=(U(I,K(f,z),f)-1)*(2*n+1)+sum(NA(I,:,f));
                                end
                            end
                        end
                    end
                end
            end
            
%             %Energy Efficiency
%             %Eq. 19
%             for i=1:n
%                 tmp_SFC_RR6=sum(U(i,:,1));
%                 for f=2:numberOfFlows
%                     tmp_SFC_RR6=tmp_SFC_RR6+sum(U(i,:,f));
%                 end
%                 WN(i)<=tmp_SFC_RR6;
%             end
%             %Eq. 20
%             for i=1:n
%                 tmp_SFC_RR7=sum(U(i,:,1));
%                 for f=2:numberOfFlows
%                     tmp_SFC_RR7=tmp_SFC_RR7+sum(U(i,:,f));
%                 end
% %                 WN(i)*tmp_SFC_RR7==tmp_SFC_RR7;
%                 WN(i)*(1+numberOfFlows*numberOfFunctions)>=tmp_SFC_RR7;
%             end      
            
            %Failure Probability
            %Eq. 12
            for f=1:numberOfFlows
                TmpZ=sum(A(1,:,f));
                for i=1:n-1
                    TmpZ=TmpZ+sum(A(i+1,:,f))*2^i;
                end
                Z(f)==TmpZ;
            end
            
            %Eq. 13
            for f=1:numberOfFlows
                sum(J(:,f))==1;
            end
            
            %Eq. 14
            for f=1:numberOfFlows
                sum(J(:,f).*L')==Z(f);
            end
            
            %Eq. 15
            for f=1:numberOfFlows
                sum(J(:,f).*failurProb')<=MT;
            end


        %Objective Function Eq.s 1, 18
        Obj = sum(J(:,1).*failurProb');
        for f=2:numberOfFlows
            Obj = Obj+sum(J(:,f).*failurProb');
        end
        minimize(Obj);
            
    cvx_end
end