function PlotResults(readFrom)
    if size(readFrom,1)==0
        readFrom='C:\Users\Mahdi\Desktop\SFC\Conference\';
    else
        readFrom=[readFrom,'\'];
    end
    files=dir(readFrom);
    %for each file in the folder
    for i=1:size(files,1)
        if strcmp(files(i).name,'.')==0 && strcmp(files(i).name,'..')==0 && files(i).isdir==0 && strcmp(files(i).name,'Notation.txt')==0 && strcmp(files(i).name,'Notation.pdf')==0
            [A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0] ...
                =LoadResult([readFrom,files(i).name]);
            %setting the parameters: link utilization, node utilization,
            %delay, etc.
            for tmpItr=1:1
            if strcmp(files(i).name(1:2),'RR')
                NameOfFile=files(i).name(4:findstr(files(i).name,' -Time'));
                RR_ind=str2double(files(i).name(8));
                [RR_linkUtilization(RR_ind)]=AverageOverNaN(LinkUtilization(n,p,A,C,B));
                [RR_nodeUtilization(RR_ind)]=mean(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                [RR_MlinkUtilization(RR_ind)]=MaxOverNaN(LinkUtilization(n,p,A,C,B));
                [RR_MnodeUtilization(RR_ind)]=max(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                [RR_powerConsumption(RR_ind)]=PowerConsumption(n,WN,EC);
                [RR_netSideEffect(RR_ind)]=NetworkSideEffect(n,p,A,A0);
                [RR_averagePathLength(RR_ind)]=AveragePathLength(p,A,s,d);
                [RR_avgDelay(RR_ind),RR_numberOfDelayedFlow(RR_ind)]=Delay(p,A,s,D,T);
            elseif strcmp(files(i).name(1:6),'HNR_RR')
                NEW_RR_ind=str2double(files(i).name(12));
                [NEW_RR_linkUtilization(NEW_RR_ind)]=AverageOverNaN(LinkUtilization(n,p,A,C,B));
                [NEW_RR_nodeUtilization(NEW_RR_ind)]=mean(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                [NEW_RR_MlinkUtilization(NEW_RR_ind)]=MaxOverNaN(LinkUtilization(n,p,A,C,B));
                [NEW_RR_MnodeUtilization(NEW_RR_ind)]=max(NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC));
                [NEW_RR_powerConsumption(NEW_RR_ind)]=PowerConsumption(n,WN,EC);
                [NEW_RR_netSideEffect(NEW_RR_ind)]=NetworkSideEffect(n,p,A,A0);
                [NEW_RR_averagePathLength(NEW_RR_ind)]=AveragePathLength(p,A,s,d);
                [NEW_RR_avgDelay(NEW_RR_ind),NEW_RR_numberOfDelayedFlow(NEW_RR_ind)]=Delay(p,A,s,D,T);
            end
            end
        end
    end   

    addrsToSaveFigures='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Conference\Figures\';

    %plot figures
    for iTemp=1:1
    NewPlot4InputMatrix(1,RR_linkUtilization,NEW_RR_linkUtilization,...
        'Average Link Utilization (%)','Iteration',addrsToSaveFigures,['lnkUtl',NameOfFile]);
    NewPlot4InputMatrix(2,RR_nodeUtilization,NEW_RR_nodeUtilization,...
        'Average Node Utilization (%)','Iteration',addrsToSaveFigures,['ndeUtl',NameOfFile]);
    NewPlot4InputMatrix(3,RR_powerConsumption,NEW_RR_powerConsumption,...
        'Power Consumption','Iteration',addrsToSaveFigures,['pwrCns',NameOfFile]);
%     NewPlot4InputMatrix(4,RR_netSideEffect,NSFF_RR_netSideEffect,NEW_RR_netSideEffect,ENSFF_RR_netSideEffect,...
%         'Network Side-Effect','Iteration',addrsToSaveFigures,['netSid',NameOfFile]);
    NewPlot4InputMatrix(5,RR_averagePathLength,NEW_RR_averagePathLength,...
        'Average Path Length','Iteration',addrsToSaveFigures,['pthLen',NameOfFile]);
    NewPlot4InputMatrix(6,RR_MlinkUtilization,NEW_RR_MlinkUtilization,...
        'Maximum Link Utilization (%)','Iteration',addrsToSaveFigures,['mlnkUtl',NameOfFile]);
    NewPlot4InputMatrix(7,RR_MnodeUtilization,NEW_RR_MnodeUtilization,...
        'Maximum Node Utilization (%)','Iteration',addrsToSaveFigures,['mndeUtl',NameOfFile]);
    end
end
function [linkUtilization]=LinkUtilization(n,p,A,C,B)
    linkLoad=LinkLoad(n,p,A,C);
    linkUtilization=linkLoad./B;
end
function [nodeUtilization]=NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC)
    %NC: nodes processing capacity,
    nodeLoad=NodeLoad(n,p,numbrOfFunctions,U,C,FP);
    nodeUtilization=nodeLoad./NC;
end
function [linkLoad]=LinkLoad(n,p,A,C)
    linkLoad=zeros(n,n);
    for i=1:n
        for j=1:n
            for f=1:p
                linkLoad(i,j)=linkLoad(i,j)+(A(i,j,f)>0)*C(f);
            end
        end
    end
end
function [nodeLoad]=NodeLoad(n,p,numberOfFunction,U,C,FP)
    %FP: required processing power of funtionss, 
    nodeLoad=zeros(1,n);
    for i=1:n
        for f=1:p
            for m=1:numberOfFunction
                nodeLoad(i)=nodeLoad(i)+U(i,m,f)*C(f)*FP(m);
            end
        end
    end
end
function [powerConsumption]=PowerConsumption(n,WN,EC)
    %EC: nodes' energy consumption
    %WN: state of switches(On/Off),    
    powerConsumption=0;
    for i=1:n
        powerConsumption=powerConsumption+WN(i)*EC(i);
    end
end
function [netSideEffect]=NetworkSideEffect(n,p,A,A0)
    netSideEffect=0;
    for i=1:n
        for j=1:n
            for f=1:p
                netSideEffect=netSideEffect+abs(A(i,j,f)-A0(i,j,f));
            end
        end
    end
end
function [averagePathLength]=AveragePathLength(p,A,s,d)
    averagePathLength=0;
    for i=1:p
        averagePathLength=averagePathLength+PathLength(i,A,s(i),d(i));
    end
    averagePathLength=averagePathLength/p;
end
function [pathLength]=PathLength(flowIndex,A,s,d)
    pathLength=0;
    maxAllowedLength=100;
    while sum(A(s,:,flowIndex)) && maxAllowedLength    
        pathLength=pathLength+1;
        s1=find(A(s,:,flowIndex));
        %in NSFF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(s,:,flowIndex)==min(A(s,s1,flowIndex)));
        A(s,s1,flowIndex)=0;
        s=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #1***************');
    end
end
function [res]=AverageOverNaN(input)
    res=0;
    num=0;
    for i=1:size(input,1)
        for j=1:size(input,2)
            if ~isnan(input(i,j))
                res=res+input(i,j);
                num=num+1;
            end
        end
    end
    res= res/num;
end
function [res]=MaxOverNaN(input)
    res=0;
    for i=1:size(input,1)
        for j=1:size(input,2)
            if ~isnan(input(i,j)) && res<input(i,j)
                res=input(i,j);
            end
        end
    end
end
function [avgDelay,numberOfDelayedFlow]=Delay(p,A,src,D,T)
    avgDelay=0;numberOfDelayedFlow=0;
    for f=1:p
        tmpDly=FlowDelay(A,src(f),D,f);
        avgDelay=avgDelay+tmpDly;
        if tmpDly>T(f)
            numberOfDelayedFlow=numberOfDelayedFlow+1;
        end
    end
    avgDelay=avgDelay/p;
end
function [delay]=FlowDelay(A,src,D,flowIndex)
    delay=0;
    maxAllowedLength=100;
    while sum(A(src,:,flowIndex)) && maxAllowedLength    
        s1=find(A(src,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
        A(src,s1,flowIndex)=0;
        delay=delay+D(src,s1);
        src=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #2***************');
    end


end
function [avgHops]=AvgHops(p,A,src)
    avgHops=0;
    for f=1:p
        tmpDly=FlowHops(A,src(f),f);
        avgHops=avgHops+tmpDly;
    end
    avgHops=avgHops/p;
end
function [hops]=FlowHops(A,src,flowIndex)
    hops=0;
    maxAllowedLength=100;
    while sum(A(src,:,flowIndex)) && maxAllowedLength    
        s1=find(A(src,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
        A(src,s1,flowIndex)=0;
        hops=hops+1;
        src=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #3***************');
    end


end
function NewPlot4InputMatrix(figNumber, A, B, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    plot1=plot(1:size(A,2),[A;B],'MarkerSize',15,'LineWidth',2);
    
    set(plot1(1),'Marker','s','MarkerFaceColor','r','MarkerEdgeColor','r','color','r','LineStyle',':');
    set(plot1(2),'Marker','o','MarkerFaceColor','b','MarkerEdgeColor','b','color','b');
    
    %Create Legend
    set(plot1(1),'DisplayName','NR');
    set(plot1(2),'DisplayName','HNR');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',19,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
    Leg1=legend('NR','HNR');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    %Save to file
    savefig([AddrToSaveFig,FigName,'.fig']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
    NewFigName='fig';
    tmpIndN=strfind(FigName,'p=');
    NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
    tmpIndN=strfind(FigName,'alpha=');
    NewFigName=[NewFigName,' alpha=',FigName(tmpIndN+6:tmpIndN+8)];
    NewFigName=[NewFigName,FigName(1:2)];
%     saveas(gcf,[AddrToSaveFig,NewFigName,'.eps']);
    saveas(gcf,[AddrToSaveFig,NewFigName,'.png']);
end







