%Heuristic for Network Reconfiguration (Heuristic for NR)
%LoopMode could be one of {'NoLoop', 'NoRepetetiveLink', 'LoopAllowed'}
function HNR(readFrom,SortFlows,LoopMode)
%   A0 is the string format of selected paths: e.g., A0(1)= 1->3 3->5 5->4     where s=1 and d=4
    for itmp=1:1
        %B: matrix of links' bandwidth, 
        %D: Links' propagation delay
        %C: flow bandwidth requirement, 
        %T: maximum tolerable propagation delay,
        %s: source switches, 
        %d: destination switches, 
        %R: functions requirements of flows, 
        %K: sequence of required functions
        %p:number of flows
        %FP: required processing power of funtionss, 
        %NC: nodes processing capacity, 
        %F: functions associated withe nodes,
        %EC: nodes' energy consumption
        %WN: current state of switches
        if size(readFrom,1)==0
            readFrom='C:\Users\Mahdi\Desktop\SFC\Conference\';
        else
            readFrom=[readFrom,'\'];
        end
    end
    files=dir(readFrom);
    for j=1:size(files,1)
        if strcmp(files(j).name,'.')==0 && strcmp(files(j).name,'..')==0 && files(j).isdir==0 && strcmp(files(j).name(1:4),'NR_i')
            [A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0]= LoadResult([readFrom,files(j).name]);
        
%             [A0,U0,WN0]=FindPerivousState(readFrom,files(j).name,n,numbrOfFunctions,p);
            [D]=ConvertCommonDToCSPFCompatibleD(D);
            tB=B;
            A=zeros(n,n,p);
            U=zeros(n,numbrOfFunctions,p);
            tic

            if SortFlows, ind=SortFlowsBasedOnTheirSize(C); else, ind=1:p;end
            
            WN=zeros(1,n);
            TxtPath(1,p)=string;
            %invoke the HNR_RR_Solver function. If the problem is not solvable with current miu and miu2, then these values are increased to one
            for f=1:p
                [tA,tU,tB,NC,WN,error,TxtPath(f)]=FindSolution(n,numbrOfFunctions,ConvertZeroToInf(tB),D,C(ind(f)),s(ind(f)),d(ind(f)),K(ind(f),:),FP,NC,F,0,WN,EC,...
                    miu,miu2,maxNmbrFuncPerFlw,R(:,ind(f))',B,LoopMode);
                if error
                    disp('************HNR_Solver cannot solve the problem***************');
                    return;
                else
                    A(:,:,ind(f))=tA;
                    U(:,:,ind(f))=tU;
                end
            end
            toc
            display(['for p= ',num2str(p)]);
            tmpName=files(j).name;
            SaveResult(['HNR_itr=',tmpName(8)],A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode,prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,TxtPath,U0,tmpName(9:size(tmpName,2)));
        end
    end
end

function [tA,tU,tB,NC,WN,error,TxtPath]=FindSolution(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD,WN,EC,miu,miu2,maxNmbrFuncPerFlw,R,OriginalB,LoopMode)
    for i=-1:10
         if strcmp(LoopMode,'NoRepetetiveLink')==0
            [tA,tU,tB,NC,WN,error,TxtPath]=HNR_Solver_NoRepetetiveLink(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD,WN,EC, min(miu+miu*i*0.2,1) ,min(miu2+miu2*i*0.2,1),...
                maxNmbrFuncPerFlw,R,OriginalB,'NoLoop');
         elseif strcmp(LoopMode,'')==0
             [tA,tU,tB,NC,WN,error,TxtPath]=HNR_Solver_NoLoop(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD,WN,EC, min(miu+miu*i*0.2,1) ,min(miu2+miu2*i*0.2,1),...
                maxNmbrFuncPerFlw,R,OriginalB,'');
         elseif strcmp(LoopMode,'LoopAllowed')==0
             [tA,tU,tB,NC,WN,error,TxtPath]=HNR_Solver_LoopAllowed(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD,WN,EC, min(miu+miu*i*0.2,1) ,min(miu2+miu2*i*0.2,1),...
                maxNmbrFuncPerFlw,R,OriginalB,'');
         end
        if ~error
            return;
        end
    end
end

function [B]=ConvertZeroToInf(B)
    for i=1:size(B,1)
        for j=1:size(B,2)
            if B(i,j)==0
                B(i,j)=inf;
            end
        end
    end
end

function [A,U,B,NC,WN,error,TxtPath]=HNR_Solver_NoRepetetiveLink(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD,WN,EC,miu,miu2,maxNmbrFuncPerFlw,R,OriginalB,TxtPath)
    A=zeros(n,n);
    error=0;
    U=zeros(n,numbrOfFunctions);
    G=BRatioToD*B+(1-BRatioToD)*D;
    %fix the NaN value (devisioned by zero )
    for i=1:n
        for j=1:n
            if isnan(G(i,j))
                G(i,j)=0;
            end
        end
    end
    
    CrossedNodes=zeros(1,n);
    CrossedNodes(s)=1;
    
    step=1;
    
    while sum(R)~=0
        %remove links that has a free bandwidth less than the flow required capacity
        G=PruneLinks(G,B,C,miu,n,OriginalB);
        %find shortest path from source to all nodes
        [dist, path, pred] = graphshortestpath(sparse(G), s);
        %remove nodes that support non of the required functions
        dist=PruneNodes(F,dist,n,miu2,C,NC,maxNmbrFuncPerFlw,K,FP);
        if min(dist)==inf
            error=1;
            return;
        end
        %Energy Consumption of each node
        E=EnergyConsumption(dist,WN,EC,n);
        %selected node to go, SN:selected Node, SF: selected Functions
        [U,SN,SF,B,NC,A,step,CrossedNodes,WN,K,tTxtPath]=SelectNodeWithMinEnergyConsumption(E,dist,C,FP,pred,B,s,A,step,U,maxNmbrFuncPerFlw,K,F,NC,...
            CrossedNodes,WN,miu2);
        TxtPath=[TxtPath,tTxtPath];
        %RemoveReceivedFunctionFromChain
        for i=1:size(SF,2)
            if SF(i)>0
                R(SF(i))=0;
            end
        end
%         [R,WN]=CheckCrossedNodes(R,WN);
        %Move to the selected node
        s=SN;
    end
    
    %go to destination
    if d~=s
        step=step+1;
        [dist, path, pred] = graphshortestpath(sparse(G), s);
        if dist(d)==inf
            error=1;
            return;
        end
    end
    tmpTxtPath='';
    while d~=s
        tmpTxtPath=[int2str(pred(d)),'->',int2str(d),' ',tmpTxtPath];
        A(pred(d),d)=step;
        B(pred(d),d)=B(pred(d),d)-C;
        d=pred(d);
    end
    TxtPath=[TxtPath,' ', tmpTxtPath];
    B=ConvertInfToZero(B);
end

function [A,U,B,NC,WN,error,TxtPath]=HNR_Solver_NoLoop(n,numbrOfFunctions,B,D,C,s,d,K,FP,NC,F,BRatioToD,WN,EC,miu,miu2,maxNmbrFuncPerFlw,R,OriginalB,TxtPath)
    A=zeros(n,n);
    error=0;
    U=zeros(n,numbrOfFunctions);
    tB=B;
    B(d,:)=0;B(:,d)=0;
    G=BRatioToD*B+(1-BRatioToD)*D;
    %fix the NaN value (devisioned by zero )
    for i=1:n
        for j=1:n
            if isnan(G(i,j))
                G(i,j)=0;
            end
        end
    end
    
    CrossedNodes=zeros(1,n);
    CrossedNodes(s)=1;
    
    step=1;
    
    while sum(R)~=0
        %remove links that has a free bandwidth less than the flow required capacity
        G=PruneLinks(G,B,C,miu,n,OriginalB);
        %find shortest path from source to all nodes
        [dist, path, pred] = graphshortestpath(sparse(G), s);
        %remove nodes that support non of the required functions
        dist=PruneNodes(F,dist,n,miu2,C,NC,maxNmbrFuncPerFlw,K,FP);
        if min(dist)==inf
            error=1;
            return;
        end
        %Energy Consumption of each node
        E=EnergyConsumption(dist,WN,EC,n);
        %selected node to go, SN:selected Node, SF: selected Functions
        [U,SN,SF,B,NC,A,step,CrossedNodes,WN,K,tTxtPath]=SelectNodeWithMinEnergyConsumption(E,dist,C,FP,pred,B,s,A,step,U,maxNmbrFuncPerFlw,K,F,NC,...
            CrossedNodes,WN,miu2);
        TxtPath=[TxtPath,tTxtPath];
        %RemoveReceivedFunctionFromChain
        for i=1:size(SF,2)
            if SF(i)>0
                R(SF(i))=0;
            end
        end
%         [R,WN]=CheckCrossedNodes(R,WN);
        %Move to the selected node
        s=SN;
        B(CrossedNodes,:)=0;B(:,CrossedNodes)=0;
    end
    
    %go to destination
    B(d,:)=tB(d,:);B(:,d)=tB(:,d);
    G=BRatioToD*B+(1-BRatioToD)*D;
    if d~=s
        step=step+1;
        [dist, path, pred] = graphshortestpath(sparse(G), s);
        if dist(d)==inf
            error=1;
            return;
        end
    end
    tmpTxtPath='';
    while d~=s
        tmpTxtPath=[int2str(pred(d)),'->',int2str(d),' ',tmpTxtPath];
        A(pred(d),d)=step;
        B(pred(d),d)=B(pred(d),d)-C;
        d=pred(d);
    end
    TxtPath=[TxtPath,' ', tmpTxtPath];
    B=ConvertInfToZero(B);
end
        
function [IndMinE_MinDist]=Find_MinEnergy_MinDist(E,dist)
    IndMinE=find(E==min(E));
    IndMinDist=find(dist==min(dist(IndMinE)));
    for j=1:size(IndMinE,2)
        i=IndMinE(j);
        if dist(i)==dist(IndMinDist)
            IndMinE_MinDist=i;
            return;
        end
    end
end

function [U,SN,SF,B,NC,A,step,CrossedNodes,WN,K,TxtPath]=SelectNodeWithMinEnergyConsumption(E,dist,C,FP,pred,B,s,A,step,U,maxNmbrFuncPerFlw,K,F,NC,CrossedNodes,WN,miu2)
    TxtPath='';
    IndMinE_MinDist=Find_MinEnergy_MinDist(E,dist);
    %select one of nodes with similar energy consumption and distance
    %SN: selected node
    SN=IndMinE_MinDist(1);
    WN(SN)=1;
    %if this node is not crossed befor, then move to it
    if ~CrossedNodes(SN)
        %move to the selected node
        if SN~=s
            step=step+1;
        end
        d=SN;
        while d~=s
            if size(TxtPath,1)~=0, TxtPath=[int2str(pred(d)),'->',int2str(d),' ', TxtPath];
            else, TxtPath=[int2str(pred(d)),'->',int2str(d)]; end
            
            A(pred(d),d)=step;
            B(pred(d),d)=B(pred(d),d)-C;
            d=pred(d);
            CrossedNodes(d)=1;
        end
    end
    %SF: Selected Functions to be delivered in the Selected Node
    SF=zeros(1,maxNmbrFuncPerFlw);
    tmpIndx=1;
    for m=1:maxNmbrFuncPerFlw
        if K(m)>0 && F(SN,K(m))~=0
            if NC(SN)*miu2>C*FP(K(m))
                U(SN,K(m))=1;
                NC(SN)=NC(SN)-C*FP(K(m));
                SF(tmpIndx)=K(m);
                tmpIndx=tmpIndx+1;
                K(m)=0;
            end
        end
    end
end

function [E]=EnergyConsumption(dist,WN,EC,n)
    E=inf(1,n);
    for i=1:n
        if dist(i)~=inf 
            if WN(i)==1
                E(i)=0;
            else
                E(i)=EC(i);
            end
        end
    end
end

function [G]=PruneLinks(G,B,C,miu,n,OriginalB)
    %Eliminate links that has a free bandwidth less than the flow required capacity
    for i=1:n
        for j=1:n
            if (B(i,j)- (OriginalB(i,j)*(1-miu)) )<C
                G(i,j)=0;
            end
        end
    end
end

function [dist]=PruneNodes(F,dist,n,miu2,C,NC,maxNmbrFuncPerFlw,K,FP)
    %eliminate nodes that (have not enough processing power) or (support non of required functions)
    for i=1:n 
       ind=0;
        for m=1:maxNmbrFuncPerFlw
            %support one of required functions 
            if K(m)>0 && F(i,K(m))~=0
                %has enough processing power
                if NC(i)*miu2>C*FP(K(m))
                    ind=1;
                end
            end
        end
        if ind==0
            dist(i)=inf;
        end
    end    
%     if min(dist==inf)
%             disp('*****************error in HNR_RR, cannot find the result #3**********************');
%     end
end

function [B]=ConvertInfToZero(B)
    for i=1:size(B,1)
        for j=1:size(B,2)
            if B(i,j)==inf
                B(i,j)=0;
            end
        end
    end
end

function [ind]=SortFlowsBasedOnTheirSize(C)
    ind=zeros(1,size(C,2));
    for i=1:size(C,2)
        tmp=find(C==max(C));
        ind(i)=tmp(1);
        C(ind(i))=-1;
    end
end












