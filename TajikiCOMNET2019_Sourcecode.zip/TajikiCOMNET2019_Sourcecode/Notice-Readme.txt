How to run the code

Please follow the steps below:


The code is done using CVX solver on MATLAB.

First, you are requested to download and install CVX solver from http://cvxr.com/cvx/doc/solver.html

Then, you can easily access the model file for all the scenarios of the published paper in Wiley CPE in the ‘Simulation’ folder.

1. ’CreateTopology.m’ is used to establish the topology of the network, e.g., Abilene topology
2. ‘CreateVMs.m’ is used to establish VMs riding on each server/node of the designed topology
3. ‘SolverForONR.m’ and ‘SFC_ONR.m’ are the solver code (CVX) for ONR algorithm for without SFC and with SFC, respectively.  
4. ‘HNR-RR.m’ is used to address the relaxation of HNR algorithm. 
5. The rest m files are used to plot the results and make analytics of the results.

I will be glad to cite our paper with the following details in your research papers:

Elsevier Computer Network:

M.M. Tajiki, M. Shojafar, S. Salsano, M. Conti, M. Singhal, "Joint Failure Recovery, Fault Prevention, and Energy-efficient Resource Management for Real-time SFC in Fog-supported SDN", Elsevier, Computer Networks, (COMNET), Vol. 162, pp. 1-16, October 2019. DOI: https://doi.org/10.1016/j.comnet.2019.07.006


The papers are supported and fully funded by the H2020 EU project named:

SUPERFLUIDITY

Project Link: http://superfluidity.eu/

(grant agreement No. 671566)

If you need any help on the code, feel free to drop a message to

Dr. Mohammad Shojafar <mohammad.shojafar@gmail.com> or <m.shojafar@ieee.org> or
Dr. Mohammad Mahdi Tajiki <mohammad59mt@gmail.com> 
