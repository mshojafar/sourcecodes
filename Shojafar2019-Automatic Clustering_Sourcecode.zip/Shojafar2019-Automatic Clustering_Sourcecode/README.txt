README.txt

Help file to run the project written in Matlab.

Dr. Rahim Taheri and Dr. Mohammad Shojafar did this implementation. 
Dr. Mohammad Shojafar, Dr. Rahim Taheri, Dr. Zahra Pooranian helped on idea brainstorming and documentation. 
Dr. Reza Javidan, Prof. Ali Miri, Prof. Yaser Jararweh helped in English correction and leading the team.

Contact: Dr. Mohammad Shojafar / Dr. Rahim Taheri
Email: m.shojafar@surrey.ac.uk; m.shojafar@ieee.org/ r.taheri@sutech.ac.ir; tahery.rahim@gmail.com 

Step of the running project:

1.	Open this project in your Matlab. the NLS-KDD 10% dataset is preprocessed and saved in ‘KDD.mat’
2.	You can run ‘abc.m’ to run abc algorithm.
3.	You can run ‘abc2.m’ to run abc2 algorithm.
4.	You can run ‘de.m’ to run deferential evaluation algorithm.
5.	You can run ‘pso.m’ to particle swarm optimization algorithm.
6.	You can run ‘hs.m’ to run hs algorithm.
7.	Since we use two indexes for the analyzing of the cost of each method, you can set line 7 of each algorithm code (default, ``Method = 'DB';	% DB or CS``) to DB representing DBindex.m and CS representing CSindex.m
8.	You can uncomment the figure instruction to see the result of each algorithm result at the end of each algorithm.

If you use this code, we will be happy to cite this paper (original published work):

M. Shojafar, R. Taheri, Z. Pooranian, R. Javidan, A. Miri, Y. Jararweh, "Automatic Clustering of Attacks in Intrusion Detection Systems", The 16th ACS/IEEE International Conference on Computer Systems and Applications, (ACS/IEEE 2019), Abu Dhabi, UAE, 3-7 November 2019.