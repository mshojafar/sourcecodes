import pandas as pd
import numpy as np
frm = pd.read_csv("D:\\dataset\\CSV-03-11\\03-11\portmap.csv")
flowIds = frm['Flow ID'].unique()

data = []
dataPortmap = []

for idx, val in enumerate(flowIds[:10]): 
  cols = frm.loc[frm['Flow ID'] == val,[' Source IP', ' Destination Port', ' Label']]
  srcIP = cols[' Source IP'].unique()[0]
  dstprt = cols[' Destination Port'].unique()[0]
  lbl = cols[' Label'].unique()[0]
  if (lbl=="BENIGN"):
     row = [srcIP, dstprt]
     data.append(row) 
  elif (lbl=="Portmap"):
     row2 = [srcIP, dstprt]
     dataPortmap.append(row2)     
##############################################################     
for i in data:
    print("Benign " , i)
for i in dataPortmap:
    print("Portmap" , i)
    


output = {}  
outputPortmap = {}  
######################################################### 
for i in data:
    if i[0] not in output:
        output[i[0]] = [i[1]]
    elif i[1] not in output[i[0]]:
        output[i[0]] += [i[1]]

for i in dataPortmap:
    if i[0] not in outputPortmap:
        outputPortmap[i[0]] = [i[1]]
    elif i[1] not in outputPortmap[i[0]]:
        outputPortmap[i[0]] += [i[1]]
 ######################################################       
        
for k, v in output.items():
    output[k] = len(v) 
    data2 = list(output.items())        
    an_array = np.array(data2)
print (output)


for k, v in outputPortmap.items():
    outputPortmap[k] = len(v) 
    data3 = list(outputPortmap.items())        
    an_array2 = np.array(data3)
print (outputPortmap)


#################################################
df = pd.DataFrame(an_array, columns=["Source IP", "Number of ports scanned"])
df.to_csv( "D:\\dataset\\CSV-03-11\\03-11\portmapBenign.csv", index=False, encoding='utf-8-sig')

df = pd.DataFrame(an_array2, columns=["Source IP", "Number of ports scanned"])
df.to_csv( "D:\\dataset\\CSV-03-11\\03-11\portmapAttack.csv", index=False, encoding='utf-8-sig')   

     

  
  

        
        
 