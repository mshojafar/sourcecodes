import pandas as pd
import numpy as np
frm = pd.read_csv("D:\\dataset\Rate.csv")
flowIds = frm['timestamp'].unique()
data = []
output = {} 

######################################
for idx, val in enumerate(flowIds[102747:215942]): 
  cols = frm.loc[frm['timestamp'] == val,['src_ip', 'label']]
  srcIP = cols['src_ip'].unique()[0]
 # dstprt = cols[' Destination Port'].unique()[0]
  lbl = cols['label'].unique()[0]
  if (lbl=="UDP_flood_attack"):
     row = [srcIP]
     data.append(row)   
    


#########################################################    
for i in data:
    if i[0] not in output:
        output[i[0]] = 1
    else:
        output[i[0]] += 1

       
######################################################
for k, v in output.items():
    output[k] = v 
    datatempt = list(output.items())        
    an_array = np.array(datatempt)



#################################################     
    
df = pd.DataFrame(an_array, columns=["src_ip", "Connection attempts"])
df.to_csv( "D:\\dataset\RateAttack.csv", index=False, encoding='utf-8-sig')

