#!/bin/bash

STARTDIR=$1

export VMperS=3

function dataVectorInit() {
	t=$1
	outfile=$2
	infile=$3
	paramname=$4
	# find line with the right timestamp
	line=`grep "^${t} " $infile`
	# remove first element form the line
	line=`echo $line | cut -d " " -f 2-`
	#echo "found line $line for t=$t"
	newline="param $paramname :="
	c=1
	for i in $line
	do
		newline="$newline $c $i"
		(( c=c+1 ))
	done
	echo "$newline ;"> $outfile
}

function dataMatrixInit() {
	t=$1
	outfile=$2
	infile=$3
	paramname=$4
	# find line with the right timestamp
	line=`grep "^${t} " $infile`
	# remove first element form the line
	line=`echo $line | cut -d " " -f 2-`
	nelem=`echo $line | wc -w`
	ncol=`echo "sqrt($nelem)" | bc`
	nrow=$ncol
	echo "line has $nelem elements, ncol=$ncol"
	#echo "found line $line for t=$t"
	newline="param $paramname : \\n `seq -s ' ' 1 $ncol ` := \\n 1"
	x=1
	y=1
	for i in $line
	do
		newline="$newline $i"
		(( x=x+1 ))
		if [ $x -gt $ncol ]
		then 
			x=1
			(( y=y+1 ))
			if [ $y -le $nrow ]
			then 
				newline="$newline \\n $y"
			fi
		fi
	done
	echo -e "$newline \\n ;"> $outfile
}

function dataMatrixInit_old() {
	t=$1
	outfile=$2
	infile=$3
	paramname=$4
	# FIXME: nrow and ncol can be inferred form the number of elements
	ncol=$5
	nrow=$6
	# find line with the right timestamp
	line=`grep "^${t} " $infile`
	# remove first element form the line
	line=`echo $line | cut -d " " -f 2-`
	#echo "found line $line for t=$t"
	newline="param $paramname := "
	x=1
	y=1
	for i in $line
	do
		newline="$newline  $x $y  $i"
		(( x=x+1 ))
		if [ $x -gt $ncol ]
		then 
			x=1
			(( y=y+1 ))
		fi
	done
	echo "$newline ;"> $outfile
}


function dataInit() {
	t=$1
	echo "initializing data for run $t"
	echo "param runnumber := $t ;" > DC_Mig_runnumber.dat
	dataVectorInit $t DC_Mig_c_VM.dat CPU_timeseries.data c_VM
	dataVectorInit $t DC_Mig_m_VM.dat Mem_timeseries.data m_VM
	dataMatrixInit $t DC_Mig_d.dat Net_timeseries.data d 
}

get_nslot() {
	tail -n1 Net_timeseries.data | cut -d " " -f 1
}

get_nVM() {
	tail -n1 Mem_timeseries.data | cut -d " " -f 2- | wc -w
}
function fcompequal() {
    awk -v n1=$1 -v n2=$2 'BEGIN{ if (n1=n2) exit 0; exit 1}'
}

function printMaxVector() {
	paramname=$1
	max=$2
	nVM=$3
	newline="param $paramname :="
	for i in `seq 1 $nVM`
	do
		newline="$newline $i $max"
	done
	echo -e "$newline ;"
}

function printMaxMatrix() {
	paramname=$1
	max=$2
	min=$3
	nVM=$4
	newline="param $paramname : \\n `seq -s ' ' 1 $nVM` :="
	for i in `seq 1 $nVM`
	do
		newline="$newline \\n $i"
		for j in `seq 1 $nVM`
		do
			v=$max
			((hi=$i * 2 / ($nVM+1)))
			((hj=$j * 2 / ($nVM+1)))
			if [ $hi -eq $hj ]
			then
				v=$min
			fi
			if [ $i -eq $j ]
			then
				v=0
			fi
			newline="$newline $v"
			#echo "$i, $j --> $hi, $hj --> $v"
		done
	done
	echo -e "$newline ;"
}


function maxInit() {
	MAXVALFILE="DC_Mig_maxval.dat"
	MAXCPUVM=100 #Utilization of each VM in the server
	MAXMEMVM=26666667 # packets; size of each VM=40GByte,packet size=1.5Kbyte
	MAXNETVM=1000000000 #(packets/second); PS:we are able to transmit whole VM size in T second (slot size) 
	nVM=`get_nVM`
	((nSrv=nVM/VMperS +1 ))
	# number of servers
	echo "param M_size := $nSrv ;" > $MAXVALFILE
	# number of VMs
	echo "param N_size := $nVM ;" >> $MAXVALFILE
	# max server power
	printMaxVector "P_m" "328.2" $nSrv >> $MAXVALFILE
	# network interface power
	printMaxVector "P_d" "42.7" $nSrv >> $MAXVALFILE
	# max to min power ratio for server
	printMaxVector "K_C" "0.6020" $nSrv >> $MAXVALFILE
	# CPU overhead during migration
	printMaxVector "K_M" "0.01" $nSrv >> $MAXVALFILE
	# CPU
	((max=MAXCPUVM * VMperS))
	printMaxVector "c_m" $max $nSrv >> $MAXVALFILE
	# Memory
	((max=MAXMEMVM * VMperS))
	printMaxVector "m_m" $max $nSrv >> $MAXVALFILE
	# Network
	((max=MAXNETVM * VMperS))
	printMaxVector "d_m" $max $nSrv >> $MAXVALFILE
	# Communication energy
	# 6 mW 
	printMaxMatrix "E" "0.006" "0.003" $nSrv >> $MAXVALFILE
	#cat $MAXVALFILE
}


#cleanup code
rm -f *.log
# safe initialization. should be overwritten 
cp DC_Mig_x_old.dat.init DC_Mig_x_old.dat
cp DC_Mig_gamma.dat.init DC_Mig_gamma.dat

if [ -n "$STARTDIR" ]
then 
	cp $STARTDIR/*timeseries.data .
else
	echo "working on local files"
fi
# initialize
maxInit
dataInit 0
teta=0.005
DELTA=0.05
gamma=0.5
gamma_next=$gamma
gamma_plus=$(bc <<< "scale=4;$gamma+$DELTA")
gamma_minus=$(bc <<< "scale=4;$gamma-$DELTA")


#echo -e "\n" >>$GAMMAFILELOG4
#exit
# first run using gamma_minus= value

GAMMAFILELOG1=DC_Mig_gamma1.log
GAMMAFILEDAT1=DC_Mig_gamma1.dat

# second run using gamma= value

GAMMAFILELOG2=DC_Mig_gamma2.log
GAMMAFILEDAT2=DC_Mig_gamma2.dat

# third run using gamma_plus=primary value

GAMMAFILELOG3=DC_Mig_gamma3.log
GAMMAFILEDAT3=DC_Mig_gamma3.dat

GAMMAFILEDAT=DC_Mig_gamma.dat
GAMMAFILELOG4=DC_Mig_newton.log

echo "runnumber:= 0" >>$GAMMAFILELOG4

echo "gamma_Minus= $gamma_minus" >>$GAMMAFILELOG4
 #echo -e "\n" >>$GAMMAFILELOG4
 echo "gamma= $gamma" >>$GAMMAFILELOG4
 #echo -e "\n" >>$GAMMAFILELOG4
echo "gamma_plus= $gamma_plus" >>$GAMMAFILELOG4
echo "runnumber= 0" >>$GAMMAFILELOG4
#*****************************************************************gamma_Minus

echo "param gamma:= $gamma_minus;" > $GAMMAFILEDAT #output for next slot
echo "runnumber= 0" >>$GAMMAFILELOG1
#echo -e "\n" >>$GAMMAFILELOG1

# first run with no migration
/usr/optimization/ampl/ampl DC_NoMig.run
#echo "solution after run N. 0"
sed -i~ -e's/x/param x_old/' DC_Mig_x_old.dat
sed -i~ -e's/x/param gamma/' DC_Mig_gamma.dat

echo "gamma= $gamma_minus" >> $GAMMAFILELOG1 #output for next slot
echo -e "\n" >>$GAMMAFILELOG1

grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C1=$1} END {print "E_C = " E_C1 "\n"}' >> $GAMMAFILELOG1
grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C=$1} END {print "E_C = " E_C "\n"}' > $GAMMAFILEDAT1


grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D1=$1} END {print "E_D = " E_D1 "\n"}' >> $GAMMAFILELOG1
grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D=$1} END {print "E_D = " E_D "\n"}' >> $GAMMAFILEDAT1

grep 'overall_energy'  DC_Mig_temp.log | cut -d= -f2 | awk '{overall=$1} END {print "Overall_energy = " overall "\n"}' >> $GAMMAFILELOG1

#grep 'g_plus\[i,j\]' DC_Mig_temp.log | cut -d= -f2  | awk '{mig=$1} END {print "Migrations = " mig "\n"}' >> $GAMMAFILELOG1


E_C=$(grep 'E_C ='  $GAMMAFILEDAT1 | cut -d= -f2)
E_D=$(grep 'E_D ='  $GAMMAFILEDAT1 | cut -d= -f2)

E_tot_gamma_minus=$(bc <<< "scale=4;$E_C+$E_D")

echo "E_tot_gamma_minus= $E_tot_gamma_minus" >> $GAMMAFILELOG1 #output for next slot
echo -e "\n" >>$GAMMAFILELOG1

#*****************************************************************gamma

echo "param gamma:= $gamma;" > $GAMMAFILEDAT #output for next slot
echo "runnumber= 0" >>$GAMMAFILELOG2
#echo -e "\n" >>$GAMMAFILELOG2
# second run with no migration
/usr/optimization/ampl/ampl DC_NoMig.run
#echo "solution after run N. 0"
sed -i~ -e's/x/param x_old/' DC_Mig_x_old.dat
sed -i~ -e's/x/param gamma/' DC_Mig_gamma.dat


echo "gamma= $gamma" >> $GAMMAFILELOG2 #output for next slot
echo -e "\n" >>$GAMMAFILELOG2

grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C2=$1} END {print "E_C = " E_C2 "\n"}' >> $GAMMAFILELOG2
grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C=$1} END {print "E_C = " E_C "\n"}' > $GAMMAFILEDAT2

grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_2=$1} END {print "E_D = " E_D2 "\n"}' >> $GAMMAFILELOG2
grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D=$1} END {print "E_D = " E_D "\n"}' >> $GAMMAFILEDAT2

grep 'overall_energy'  DC_Mig_temp.log | cut -d= -f2 |awk '{overall=$1} END {print "Overall_energy = " overall "\n"}' >> $GAMMAFILELOG2

#grep 'g_plus\[i,j\]' DC_Mig_temp.log | cut -d= -f2  | awk '{mig=$1} END {print "Migrations = " mig "\n"}' >> $GAMMAFILELOG2


E_C=$(grep 'E_C ='  $GAMMAFILEDAT2 | cut -d= -f2)
E_D=$(grep 'E_D ='  $GAMMAFILEDAT2 | cut -d= -f2)

E_tot_gamma=$(bc <<< "scale=4;$E_C+$E_D")

echo "E_tot_gamma:= $E_tot_gamma" >> $GAMMAFILELOG2 #output for next slot
echo -e "\n" >>$GAMMAFILELOG2

#*****************************************************************gamma_plus

echo "param gamma:= $gamma_plus;" > $GAMMAFILEDAT #output for next slot
echo "runnumber= 0" >>$GAMMAFILELOG3
#echo -e "\n" >>$GAMMAFILELOG3


# third run with no migration
/usr/optimization/ampl/ampl DC_NoMig.run
#echo "solution after run N. 0"
sed -i~ -e's/x/param x_old/' DC_Mig_x_old.dat
sed -i~ -e's/x/param gamma/' DC_Mig_gamma.dat

echo "gamma= $gamma_plus" >> $GAMMAFILELOG3 #output for next slot
echo -e "\n" >>$GAMMAFILELOG3

grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C1=$1} END {print "E_C = " E_C3 "\n"}' >> $GAMMAFILELOG3
grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C=$1} END {print "E_C = " E_C "\n"}' > $GAMMAFILEDAT3

grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D1=$1} END {print "E_D = " E_D3 "\n"}' >> $GAMMAFILELOG3
grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D=$1} END {print "E_D = " E_D "\n"}' >> $GAMMAFILEDAT3

grep 'overall_energy'  DC_Mig_temp.log | cut -d= -f2 | awk '{overall=$1} END {print "Overall_energy = " overall "\n"}' >> $GAMMAFILELOG3

#grep 'g_plus\[i,j\]' DC_Mig_temp.log | cut -d= -f2  | awk '{mig=$1} END {print "Migrations = " mig "\n"}' >> $GAMMAFILELOG3


E_C=$(grep 'E_C ='  $GAMMAFILEDAT3 | cut -d= -f2)
E_D=$(grep 'E_D ='  $GAMMAFILEDAT3 | cut -d= -f2)

E_tot_gamma_plus=$(bc <<< "scale=4;$E_C+$E_D")

echo "E_tot_gamma_plus= $E_tot_gamma_plus" >> $GAMMAFILELOG3 #output for next slot
echo -e "\n" >>$GAMMAFILELOG3

#*****************************************************************updating process of Newton's method
E_prim_gamma=$(echo "scale=6;${E_tot_gamma_plus}-(${E_tot_gamma_minus})/(2*${DELTA})" | bc)
E_zegon_gamma1=$(echo "scale=6;${E_tot_gamma_plus}-(2*${E_tot_gamma})+${E_tot_gamma_minus}"| bc)
E_zegon_gamma2=$(echo "scale=6;${DELTA}*${DELTA}" | bc)
E_zegon_gamma=$(echo "scale=6;${E_zegon_gamma1}/${E_zegon_gamma2}" | bc)
maxi="1"
mini="0"
#if [ $E_prim_gamma = 0 ];	
#if fcompequal ${E_prim_gamma} ${mini} ; then
if [ 1 -eq "$(echo "scale=4;${E_prim_gamma} == ${mini}" | bc)" ] &&  [ 1 -ne "$(echo "scale=4;${E_zegon_gamma} == ${mini}" | bc)" ]; then 	
#if (( $(echo "${test2} < ${maxi}" | bc -l) )); then
		gamma_next=$(echo "scale=4;$gamma" | bc)
		echo "KEEEPING GAMMA_MINIMUM" >>$GAMMAFILELOG4
elif [ 1 -eq "$(echo "scale=4;${E_prim_gamma} == ${mini}" | bc)" ] &&  [ 1 -eq "$(echo "scale=4;${E_zegon_gamma} == ${mini}" | bc)" ]; then 	
#if (( $(echo "${test2} < ${maxi}" | bc -l) )); then
		gamma_next=$(echo "scale=4;$gamma" | bc)
		echo "KEEEPING GAMMA" >>$GAMMAFILELOG4
elif [ 1 -ne "$(echo "scale=4;${E_prim_gamma} == ${mini}" | bc)" ] && [ 1 -eq "$(echo "scale=4;${E_zegon_gamma} == ${mini}" | bc)" ]; then 	
#if fcompequal ${E_zegon_gamma} ${mini} ; then
#else if [ $E_zegon_gamma = 0 ]; then
		DELTA=$(echo "scale=4;$DELTA+$teta" | bc)
		gamma_next=$(echo "scale=4;$gamma+$DELTA" | bc)
	    echo "DELTA_new= $DELTA" >> $GAMMAFILELOG4
else
	gamma_next=$(echo "scale=4;${gamma}-(${E_prim_gamma}/${E_zegon_gamma})" | bc)
	    echo "gammabefore= $gamma_next" >>$GAMMAFILELOG4
       
fi

#check the next gamma should be between [DELTA, 1-DELTA]
	
if [ 1 -eq "$(echo "scale=4;${gamma_next} > ${maxi}" | bc)" ];	
#if [ $gamma_next > 1 ];
			then
		    gamma_next=$(echo "scale=4;1-(${DELTA})" | bc)
		    echo "DECREASE GAMMA FROM 1" >>$GAMMAFILELOG4

fi
if [ 1 -eq "$(echo "scale=4;${gamma_next} < ${mini}" | bc)" ];	
#elif [ $gamma_next < 0 ];
			then
		    gamma_next=$(echo "scale=4;$DELTA" | bc)
		    echo "INCREASE GAMMA FROM NEGETIVE" >>$GAMMAFILELOG4

fi

echo "E_prim_gamma= $E_prim_gamma" >>$GAMMAFILELOG4
#echo -e "\n" >>$GAMMAFILELOG4
echo "E_zegon_gamma1= $E_zegon_gamma1" >>$GAMMAFILELOG4
#echo -e "\n" >>$GAMMAFILELOG4
echo "E_zegon_gamma2= $E_zegon_gamma2" >>$GAMMAFILELOG4
#echo -e "\n" >>$GAMMAFILELOG4
echo "E_zegon_gamma= $E_zegon_gamma" >>$GAMMAFILELOG4
echo -e "\n" >>$GAMMAFILELOG4
#*****************************************************************go to loop for Migration model
#search 
migrationNo=0
#cat DC_Mig_x_old.dat
nslots=`get_nslot`
#exit
echo "gamma_next= $gamma_next" >>$GAMMAFILELOG4
echo -e "\n" >>$GAMMAFILELOG4
for runnumber in `seq 1 $nslots`
do
    
   dataInit $runnumber
   gamma=$gamma_next
   gamma_plus=$(bc <<< "scale=4;$gamma+$DELTA")
   gamma_minus=$(bc <<< "scale=4;$gamma-$DELTA")
    echo "runnumber= $runnumber" >>$GAMMAFILELOG4
    #echo -e "\n" >>$GAMMAFILELOG4
    echo "gamma_Minus= $gamma_minus" >>$GAMMAFILELOG4
    #echo -e "\n" >>$GAMMAFILELOG4
    echo "gamma= $gamma" >>$GAMMAFILELOG4
    #echo -e "\n" >>$GAMMAFILELOG4
    echo "gamma_plus= $gamma_plus" >>$GAMMAFILELOG4
#*****************************************************************gamma_Minus

echo "param gamma:= $gamma_minus;" > $GAMMAFILEDAT #output for next slot


/usr/optimization/ampl/ampl DC_Mig.run
    # prepare old solution for next run
    sed -i~ -e's/x/param x_old/' DC_Mig_x_old.dat
    sed -i~ -e's/x/param gamma/' DC_Mig_gamma.dat

echo "runnumber= $runnumber " >>$GAMMAFILELOG1
#echo -e "\n" >>$GAMMAFILELOG1

echo "gamma= $gamma_minus" >> $GAMMAFILELOG1 #output for next slot
echo -e "\n" >>$GAMMAFILELOG1

grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C1=$1} END {print "E_C = " E_C1 "\n"}' >> $GAMMAFILELOG1
grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C=$1} END {print "E_C = " E_C "\n"}' > $GAMMAFILEDAT1


grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D1=$1} END {print "E_D = " E_D1 "\n"}' >> $GAMMAFILELOG1
grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D=$1} END {print "E_D = " E_D "\n"}' >> $GAMMAFILEDAT1


grep 'i2\]) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M11=$1} END {print "E_M1 = " E_M11 "\n"}' >> $GAMMAFILELOG1
grep 'i2\]) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M1=$1} END {print "E_M1 = " E_M1 "\n"}' >> $GAMMAFILEDAT1


grep  '\+ (1 \- K_C\[i2\])\*P_m\[i2\]\*K_M\[i2\]\*T) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M21=$1} END {print "E_M2 = " E_M21 "\n"}' >> $GAMMAFILELOG1
grep  '\+ (1 \- K_C\[i2\])\*P_m\[i2\]\*K_M\[i2\]\*T) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M2=$1} END {print "E_M2 = " E_M2 "\n"}' >> $GAMMAFILEDAT1

grep 'overall_energy'  DC_Mig_temp.log | cut -d= -f2 | awk '{overall=$1} END {print "Overall_energy = " overall "\n"}' >> $GAMMAFILELOG1

grep 'g_plus\[i,j\]' DC_Mig_temp.log | cut -d= -f2  | awk '{mig=$1} END {print "Migrations = " mig "\n"}' >> $GAMMAFILELOG1


E_C=$(grep 'E_C ='  $GAMMAFILEDAT1 | cut -d= -f2)
E_D=$(grep 'E_D ='  $GAMMAFILEDAT1 | cut -d= -f2)
E_M1=$(grep 'E_M1 ='  $GAMMAFILEDAT1 | cut -d= -f2)
E_M2=$(grep 'E_M2 ='  $GAMMAFILEDAT1 | cut -d= -f2)
E_tot_gamma_minus=$(bc <<< "scale=4;$E_C+$E_D+$E_M1+$E_M2")

echo "E_tot_gamma_minus= $E_tot_gamma_minus" >> $GAMMAFILELOG1 #output for next slot
echo -e "\n" >>$GAMMAFILELOG1
#*****************************************************************gamma

echo "param gamma:= $gamma;" > $GAMMAFILEDAT #output for next slot

/usr/optimization/ampl/ampl DC_Mig.run
    # prepare old solution for next run
    sed -i~ -e's/x/param x_old/' DC_Mig_x_old.dat
    sed -i~ -e's/x/param gamma/' DC_Mig_gamma.dat

echo "runnumber:= $runnumber " >>$GAMMAFILELOG2

echo "gamma= $gamma" >> $GAMMAFILELOG2 #output for next slot
echo -e "\n" >>$GAMMAFILELOG2

grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C2=$1} END {print "E_C = " E_C2 "\n"}' >> $GAMMAFILELOG2
grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C=$1} END {print "E_C = " E_C "\n"}' > $GAMMAFILEDAT2

grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D2=$1} END {print "E_D = " E_D2 "\n"}' >> $GAMMAFILELOG2
grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D=$1} END {print "E_D = " E_D "\n"}' >> $GAMMAFILEDAT2


grep 'i2\]) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M12=$1} END {print "E_M1 = " E_M12 "\n"}' >> $GAMMAFILELOG2
grep 'i2\]) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M1=$1} END {print "E_M1 = " E_M1 "\n"}' >> $GAMMAFILEDAT2


grep  '\+ (1 \- K_C\[i2\])\*P_m\[i2\]\*K_M\[i2\]\*T) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M22=$1} END {print "E_M2 = " E_M22 "\n"}' >> $GAMMAFILELOG2
grep  '\+ (1 \- K_C\[i2\])\*P_m\[i2\]\*K_M\[i2\]\*T) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M2=$1} END {print "E_M2 = " E_M2 "\n"}' >> $GAMMAFILEDAT2

grep 'overall_energy'  DC_Mig_temp.log | cut -d= -f2 | awk '{overall=$1} END {print "Overall_energy = " overall "\n"}' >> $GAMMAFILELOG2

grep 'g_plus\[i,j\]' DC_Mig_temp.log | cut -d= -f2  | awk '{mig=$1} END {print "Migrations = " mig "\n"}' >> $GAMMAFILELOG2


E_C=$(grep 'E_C ='  $GAMMAFILEDAT2 | cut -d= -f2)
E_D=$(grep 'E_D ='  $GAMMAFILEDAT2 | cut -d= -f2)
E_M1=$(grep 'E_M1 ='  $GAMMAFILEDAT2 | cut -d= -f2)
E_M2=$(grep 'E_M2 ='  $GAMMAFILEDAT2 | cut -d= -f2)
E_tot_gamma=$(bc <<< "scale=4;$E_C+$E_D+$E_M1+$E_M2")

echo "E_tot_gamma:= $E_tot_gamma"  >> $GAMMAFILELOG2 #output for next slot
echo -e "\n" >>$GAMMAFILELOG2

#*****************************************************************gamma_plus

echo "param gamma:= $gamma_plus;" > $GAMMAFILEDAT #output for next slot

/usr/optimization/ampl/ampl DC_Mig.run
    # prepare old solution for next run
    sed -i~ -e's/x/param x_old/' DC_Mig_x_old.dat
    sed -i~ -e's/x/param gamma/' DC_Mig_gamma.dat

echo "runnumber= $runnumber " >>$GAMMAFILELOG3
#echo -e "\n" >>$GAMMAFILELOG3

echo "gamma= $gamma_plus" >> $GAMMAFILELOG3 #output for next slot
echo -e "\n" >>$GAMMAFILELOG3

grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C3=$1} END {print "E_C = " E_C3 "\n"}' >> $GAMMAFILELOG3
grep 'c_m\[i\])) =' DC_Mig_temp.log  | cut -d= -f2 | awk '{E_C=$1} END {print "E_C = " E_C "\n"}' > $GAMMAFILEDAT3


grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D3=$1} END {print "E_D = " E_D3 "\n"}' >> $GAMMAFILELOG3
grep 'E\[i1,i2\] =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_D=$1} END {print "E_D = " E_D "\n"}' >> $GAMMAFILEDAT3


grep 'i2\]) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M13=$1} END {print "E_M1 = " E_M13 "\n"}' >> $GAMMAFILELOG3
grep 'i2\]) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M1=$1} END {print "E_M1 = " E_M1 "\n"}' >> $GAMMAFILEDAT3


grep  '\+ (1 \- K_C\[i2\])\*P_m\[i2\]\*K_M\[i2\]\*T) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M23=$1} END {print "E_M2 = " E_M23 "\n"}' >> $GAMMAFILELOG3
grep  '\+ (1 \- K_C\[i2\])\*P_m\[i2\]\*K_M\[i2\]\*T) =' DC_Mig_temp.log | cut -d= -f2 | awk '{E_M2=$1} END {print "E_M2 = " E_M2 "\n"}' >> $GAMMAFILEDAT3

grep 'overall_energy'  DC_Mig_temp.log | cut -d= -f2 | awk '{overall=$1} END {print "Overall_energy = " overall "\n"}' >> $GAMMAFILELOG3

grep 'g_plus\[i,j\]' DC_Mig_temp.log | cut -d= -f2  | awk '{mig=$1} END {print "Migrations = " mig "\n"}' >> $GAMMAFILELOG3


E_C=$(grep 'E_C ='  $GAMMAFILEDAT3 | cut -d= -f2)
E_D=$(grep 'E_D ='  $GAMMAFILEDAT3 | cut -d= -f2)
E_M1=$(grep 'E_M1 ='  $GAMMAFILEDAT3 | cut -d= -f2)
E_M2=$(grep 'E_M2 ='  $GAMMAFILEDAT3 | cut -d= -f2)
E_tot_gamma_plus=$(bc <<< "scale=4;$E_C+$E_D+$E_M1+$E_M2")

echo "E_tot_gamma_plus= $E_tot_gamma_plus" >> $GAMMAFILELOG3 #output for next slot
echo -e "\n" >>$GAMMAFILELOG3

#*****************************************************************updating process of Newton's method in LOOP
E_prim_gamma=$(echo "scale=6;${E_tot_gamma_plus}-(${E_tot_gamma_minus})/(2*${DELTA})" | bc)
E_zegon_gamma1=$(echo "scale=6;${E_tot_gamma_plus}-(2*${E_tot_gamma})+${E_tot_gamma_minus}"| bc)
E_zegon_gamma2=$(echo "scale=6;${DELTA}*${DELTA}" | bc)
E_zegon_gamma=$(echo "scale=6;${E_zegon_gamma1}/${E_zegon_gamma2}" | bc)
maxi="1"
mini="0"
#if [ $E_prim_gamma = 0 ];	
#if fcompequal ${E_prim_gamma} ${mini} ; then
if [ 1 -eq "$(echo "scale=4;${E_prim_gamma} == ${mini}" | bc)" ] &&  [ 1 -ne "$(echo "scale=4;${E_zegon_gamma} == ${mini}" | bc)" ]; then 	
#if (( $(echo "${test2} < ${maxi}" | bc -l) )); then
		gamma_next=$(echo "scale=4;$gamma" | bc)
		echo "KEEEPING GAMMA_MINIMUM" >>$GAMMAFILELOG4
elif [ 1 -eq "$(echo "scale=4;${E_prim_gamma} == ${mini}" | bc)" ] &&  [ 1 -eq "$(echo "scale=4;${E_zegon_gamma} == ${mini}" | bc)" ]; then 	
#if (( $(echo "${test2} < ${maxi}" | bc -l) )); then
		gamma_next=$(echo "scale=4;$gamma" | bc)
		echo "KEEEPING GAMMA" >>$GAMMAFILELOG4
elif [ 1 -ne "$(echo "scale=4;${E_prim_gamma} == ${mini}" | bc)" ] && [ 1 -eq "$(echo "scale=4;${E_zegon_gamma} == ${mini}" | bc)" ]; then 	
#if fcompequal ${E_zegon_gamma} ${mini} ; then
#else if [ $E_zegon_gamma = 0 ]; then
		DELTA=$(echo "scale=4;$DELTA+$teta" | bc)
		gamma_next=$(echo "scale=4;$gamma+$DELTA" | bc)
	    echo "DELTA_new= $DELTA" >> $GAMMAFILELOG4
else
	gamma_next=$(echo "scale=4;${gamma}-(${E_prim_gamma}/${E_zegon_gamma})" | bc)
	    echo "gammabefore= $gamma_next" >>$GAMMAFILELOG4
       
fi

#check the next gamma should be between [DELTA, 1-DELTA]
	
if [ 1 -eq "$(echo "scale=4;${gamma_next} > ${maxi}" | bc)" ];	
#if [ $gamma_next > 1 ];
			then
		    gamma_next=$(echo "scale=4;1-2*(${DELTA})" | bc)
		    echo "DECREASE GAMMA FROM 1" >>$GAMMAFILELOG4

fi
if [ 1 -eq "$(echo "scale=4;${gamma_next} < ${mini}" | bc)" ];	
#elif [ $gamma_next < 0 ];
			then
		    gamma_next=$(echo "scale=4;$DELTA" | bc)
		    echo "INCREASE GAMMA FROM NEGETIVE" >>$GAMMAFILELOG4

fi

    echo "E_prim_gamma= $E_prim_gamma" >>$GAMMAFILELOG4
    #echo -e "\n" >>$GAMMAFILELOG4
    echo "E_zegon_gamma1= $E_zegon_gamma1" >>$GAMMAFILELOG4
    #echo -e "\n" >>$GAMMAFILELOG4
    echo "E_zegon_gamma2= $E_zegon_gamma2" >>$GAMMAFILELOG4
    #echo -e "\n" >>$GAMMAFILELOG4
    echo "E_zegon_gamma= $E_zegon_gamma" >>$GAMMAFILELOG4
    #echo -e "\n" >>$GAMMAFILELOG4
    echo "gamma_next= $gamma_next" >>$GAMMAFILELOG4
    echo -e "\n" >>$GAMMAFILELOG4
done
#run the results for calculate gamma  and save in "results_tot" in the ./ folder

echo "`/bin/sh ./analyze.sh`" 
