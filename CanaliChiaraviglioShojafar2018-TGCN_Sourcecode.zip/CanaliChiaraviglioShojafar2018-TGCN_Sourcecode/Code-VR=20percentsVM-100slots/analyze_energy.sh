#!/bin/bash
#INFILE=DC_Mig.log

#for 40 slots

#MIGRFILE=Scenario5_7_10VMs2VR_40slots_results_tot
#MIGRFILE=Scenario5_8_10VMs2VR_40slots_results_tot

#MIGRFILE=Scenario5_9_10VMs2VR_40slots_teta025_results-tot
#MIGRFILE=Scenario5_9_10VMs2VR_40slots_teta05_results_tot
#MIGRFILE=Scenario5_9_10VMs2VR_40slots_teta075_results-tot

#for 100 slots

MIGRFILE=Scenario5_7_10VMs2VR_100slots_results_tot
#MIGRFILE=Scenario5_8_10VMs2VR_100slots_results_tot

#MIGRFILE=Scenario5_9_10VMs2VR_100slots_teta025_results-tot
#MIGRFILE=Scenario5_9_10VMs2VR_100slots_teta05_results_tot
#MIGRFILE=Scenario5_9_10VMs2VR_100slots_teta075_results-tot

rm -f $MIGRFILE

#for i in Scenario1_4*
#for i in Scenario2_4*
#for i in Scenario1_7_8VMs*
#for i in Scenario2_7_8VMs*

#for 40 slots

#for i in Scenario5_7_10VMs2VR_40slots_gam*-KN
#for i in Scenario5_8_10VMs2VR_40slots_gam*-KN

#for i in Scenario5_9_10VMs2VR_40slots_teta025_gam*-KN
#for i in Scenario5_9_10VMs2VR_40slots_teta05_gam*-KN
#for i in Scenario5_9_10VMs2VR_40slots_teta075_gam*-KN

#for 100 slots
for i in Scenario5_7_10VMs2VR_100slots_gam*-KN
#for i in Scenario5_8_10VMs2VR_100slots_gam*-KN

#for i in Scenario5_9_10VMs2VR_100slots_teta025_gam*-KN
#for i in Scenario5_9_10VMs2VR_100slots_teta05_gam*-KN
#for i in Scenario5_9_10VMs2VR_100slots_teta075_gam*-KN

do
  #  if [ $i -eq 11 ] # for droping first 10 slots due to fluctuations
  #   then
      #statements 
        echo -e "\n" >> $MIGRFILE
        #grep "$i" $INFILE | cut -d= -f2 > "$i.data"
        echo -n "$i" >> $MIGRFILE
        echo -e "\n" >> $MIGRFILE
        #N=`grep 'runnumber ='  ${i}/DC_Mig.log` | tail -n1 | cut -d= -f2`
        #N=39 #for 40 slots
        N=99  #for 100 slots
        (( N=N+1 ))
        echo -e "slot_number = $N \\n"  >> $MIGRFILE

       # if [$(grep 'runnumber=' ${i}/DC_Mig.log | cut -d= -f2)>9]; then
          #statements

        grep 'overall_energy ='  ${i}/DC_Mig.log | cut -d= -f2 | tail -n+11 |awk '{overall+=$1} END {print "Overall_energy = " overall "\n" "AVG_energy_perslot= " overall/90}' >> $MIGRFILE

        grep 'on\[i\] =' ${i}/DC_Mig.log | cut -d= -f2 | tail -n+11  | awk '{on+=$1} END {print "total_ON_servers = " on "\n" "AVG_ON_servers_perslot = " on/90}' >> $MIGRFILE

        grep 'g_plus\[i,j\]' ${i}/DC_Mig.log | cut -d= -f2  | tail -n+11 | awk '{mig+=$1} END {print "Overall_Migrations = " mig "\n" "AVG_Migrations_perslot = " mig/90}' >> $MIGRFILE

        grep 'c_m\[i\])) =' ${i}/DC_Mig.log  | cut -d= -f2 | tail -n+11  | awk '{E_C+=$1} END {print "Overall_Computation_Cost = " E_C "\n" "AVG_Computation_perslot = " E_C/90}' >> $MIGRFILE

        grep 'E\[i1,i2\] =' ${i}/DC_Mig.log | cut -d= -f2 | tail -n+11  | awk '{E_D+=$1} END {print "Overall_Datatransfer_Cost = " E_D "\n" "AVG_Datatransfer_perslot = " E_D/90}' >> $MIGRFILE

        grep 'i2\]) =' ${i}/DC_Mig.log | cut -d= -f2 | tail -n+11  | awk '{E_M1+=$1} END {print "Overall_Mig_DataTransfer_Cost = " E_M1 "\n" "AVG_Mig_Datatransfer_perslot = " E_M1/90}' >> $MIGRFILE

        grep  '\+ (1 \- K_C\[i2\])\*P_m\[i2\]\*K_M\[i2\]\*T) =' ${i}/DC_Mig.log | cut -d= -f2 | tail -n+11   | awk '{E_M2+=$1} END {print "Overall_Mig_CPUoverhead_Cost = " E_M2 "\n" "AVG_Mig_CPUoverhead_perslot = " E_M2/90}' >> $MIGRFILE
echo -e "\n" >> $MIGRFILE
  #  fi
    # fi
done
cat $MIGRFILE
