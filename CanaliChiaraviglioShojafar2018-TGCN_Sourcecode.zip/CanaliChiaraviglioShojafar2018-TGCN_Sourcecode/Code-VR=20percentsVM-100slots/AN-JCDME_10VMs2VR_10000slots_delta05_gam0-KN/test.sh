#!/bin/bash
#INFILE=DC_Mig.log
test2="-10.5"
test3="11.00001"
test5="0.001555"
mini="0"
maxi="-10.50"

echo "${test3}-(${test2})" 

 test4=$(echo "scale=2;${test3}-(${test2})" | bc)


#DELTA=$(bc <<< "scale=4;${test5}-${test2}")

 #test4=$(echo "${test3} ${test2}" | awk '{print $1-$2}')

test5=$(echo "scale=6;${test3}-(${test2})/(2*${test4})" | bc)

echo "test 5: $test5"
 #test4=$(bc <<< "scale=4; (( ${test3}-${test2} ))")


#function fcompequal() {
#    awk -v n1=$1 -v n2=$2 'BEGIN{ if (n1=n2) exit 0; exit 1}'
#}

# OK  Negetive < , > positive p=or negetive value: if (( $(echo "${test2} < ${maxi}" | bc -l) )); then

#if fcompequal ${test4} ${maxi} ; then

if [ 1 -eq "$(echo "scale=4;${test4} == ${maxi}" | bc)" ] && [ 1 -eq "$(echo "scale=4;${test2} == ${maxi}" | bc)" ]; then 	

	echo -e " ${test4}==${maxi} AND  ${test2} == ${maxi}"  "\n"
elif [ 1 -eq "$(echo "scale=4;${test4} == ${maxi}" | bc)" ] && [ 1 -ne "$(echo "scale=4;${test2} == ${maxi}" | bc)" ]; then 	

	echo -e " ${test4} == ${maxi} AND ${test2} NO equal ${maxi}" "\n"
elif [ 1 -ne "$(echo "scale=4;${test4} == ${maxi}" | bc)" ] && [ 1 -eq "$(echo "scale=4;${test2} == ${maxi}" | bc)" ]; then 	

	echo -e " ${test4} NO EQUAL ${maxi} AND ${test2}==${maxi}" "\n"
else 
	echo -e " ${test4} NO EQUAL ${maxi} AND ${test2} NO equal ${maxi}" "\n"
fi



#if fcompequal ${test2} ${mini} ; then
if [ 1 -eq "$(echo "scale=4;${test2} == ${mini}" | bc)" ]; then 	

	echo -e " ${test2} is equal ${mini}" "\n"
else
	echo -e " ${test2} is NO-equal ${mini}" "\n"
fi


if [ $(echo "${test2} < ${maxi}" | bc) -eq 1 ]; then
#if [ 1 -eq "$(echo "${test2} > ${maxi}" | bc)" ]; then	
    test4=$(bc <<< "scale=4;${test3}-${test2}")
 	echo "loop 000 works >>>>${test4}"
 fi
 if [ 1 -eq "$(echo "${test3} > ${mini}" | bc)" ];
then
 	echo "loop 000 works but in  ${test3}"
 	#statements
 fi



 if [ 0.001 = 0.001 ]; then
 	test4=$(bc <<< "scale=4;(${test3}-${test2})")
 	echo "loop one works  ${test4}"
 else
 	echo "loop one works but in  ${test4}"
 	#statements
 fi


E_zegon_gamma2=10.1


  if [ $E_zegon_gamma2 = 0 ]; 
then
test4=$(bc <<< "scale=4;1-${test3}")
 	echo "loop 3 works:  ${test4}"
 else
 	echo "loop 3 works but in  ${test4}"
 	#statements
 fi