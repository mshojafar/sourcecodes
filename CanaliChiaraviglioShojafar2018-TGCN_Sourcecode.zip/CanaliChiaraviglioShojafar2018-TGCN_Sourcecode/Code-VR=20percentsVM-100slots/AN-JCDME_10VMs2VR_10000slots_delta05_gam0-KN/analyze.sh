#!/bin/bash
#INFILE=DC_Mig.log
MIGRFILE=results_tot
rm -f $MIGRFILE
N=100 # slot numbers
echo -e "slot_number = 100 \\n"  >> $MIGRFILE

((N=N-10))

echo -e  "*******************gamma_minus***************"  >> $MIGRFILE
echo -e "\n" >>$MIGRFILE

grep 'gamma=' DC_Mig_gamma1.log | cut -d= -f2 | tail -n+11 >> $MIGRFILE

echo -e  "*******************gamma_minus_details*************** \\n"  >> $MIGRFILE

grep 'Overall_energy'  DC_Mig_gamma1.log | cut -d= -f2 | tail -n+11 |awk '{overall+=$1} END {print "Overall_energy = " overall "\n" "AVG_overal_energy_perslot= " overall/90}' >> $MIGRFILE

grep 'Migrations' DC_Mig_gamma1.log | cut -d= -f2  | tail -n+11 | awk '{mig+=$1} END {print "Overall_Migrations = " mig "\n" "AVG_Migrations_perslot = " mig/90}' >> $MIGRFILE


grep 'E_tot_gamma_minus' DC_Mig_gamma1.log | cut -d= -f2 | tail -n+11 |awk '{E_tot_minus+=$1} END {print "E_tot_minus = " E_tot_minus "\n" "AVG_tot_perslot= " E_tot_minus/90}' >> $MIGRFILE

grep 'E_C' DC_Mig_gamma1.log | cut -d= -f2 | tail -n+11 |awk '{E_C+=$1} END {print "E_C = " E_C "\n" "AVG_CPU_perslot= " E_C/90}' >> $MIGRFILE

grep 'E_D' DC_Mig_gamma1.log | cut -d= -f2 | tail -n+11 |awk '{E_D+=$1} END {print "E_D = " E_D "\n" "AVG_DATA_perslot= " E_D/90}' >> $MIGRFILE

grep 'E_M1' DC_Mig_gamma1.log | cut -d= -f2 | tail -n+11 |awk '{E_M1+=$1} END {print "E_M1 = " E_M1 "\n" "AVG_Mig1_perslot= " E_M1/90}' >> $MIGRFILE

grep 'E_M2' DC_Mig_gamma1.log | cut -d= -f2 | tail -n+11 |awk '{E_M2+=$1} END {print "E_M2 = " E_M2 "\n" "AVG_Mig2_perslot= " E_M2/90}' >> $MIGRFILE

echo -e  "******************gamma***************** \\n"  >> $MIGRFILE
grep 'gamma=' DC_Mig_gamma2.log | cut -d= -f2 | tail -n+11 >> $MIGRFILE

echo -e  "******************gamma_details***************** \\n"  >> $MIGRFILE

grep 'Overall_energy'  DC_Mig_gamma2.log | cut -d= -f2 | tail -n+11 |awk '{overall+=$1} END {print "Overall_energy = " overall "\n" "AVG_overal_energy_perslot= " overall/90}' >> $MIGRFILE

grep 'Migrations' DC_Mig_gamma2.log | cut -d= -f2  | tail -n+11 | awk '{mig+=$1} END {print "Overall_Migrations = " mig "\n" "AVG_Migrations_perslot = " mig/90}' >> $MIGRFILE


grep 'E_tot_gamma:' DC_Mig_gamma2.log | cut -d= -f2 | tail -n+11 |awk '{E_tot_gamma+=$1} END {print "E_tot_gamma = " E_tot_gamma "\n" "AVG_tot_perslot= " E_tot_gamma/90}' >> $MIGRFILE

grep 'E_C' DC_Mig_gamma2.log | cut -d= -f2 | tail -n+11 |awk '{E_C+=$1} END {print "E_C = " E_C "\n" "AVG_CPU_perslot= " E_C/90}' >> $MIGRFILE

grep 'E_D' DC_Mig_gamma2.log | cut -d= -f2 | tail -n+11 |awk '{E_D+=$1} END {print "E_D = " E_D "\n" "AVG_DATA_perslot= " E_D/90}' >> $MIGRFILE

grep 'E_M1' DC_Mig_gamma2.log | cut -d= -f2 | tail -n+11 |awk '{E_M1+=$1} END {print "E_M1 = " E_M1 "\n" "AVG_Mig1_perslot= " E_M1/90}' >> $MIGRFILE

grep 'E_M2' DC_Mig_gamma2.log | cut -d= -f2 | tail -n+11 |awk '{E_M2+=$1} END {print "E_M2 = " E_M2 "\n" "AVG_Mig2_perslot= " E_M2/90}' >> $MIGRFILE


echo -e  "*****************gamma_plus****************\\n"  >> $MIGRFILE

grep 'gamma=' DC_Mig_gamma3.log | cut -d= -f2 | tail -n+11 >> $MIGRFILE

echo -e  "*****************gamma_plus_details****************\\n"  >> $MIGRFILE

grep 'Overall_energy'  DC_Mig_gamma3.log | cut -d= -f2 | tail -n+11 |awk '{overall+=$1} END {print "Overall_energy = " overall "\n" "AVG_overal_energy_perslot= " overall/90}' >> $MIGRFILE

grep 'Migrations' DC_Mig_gamma3.log | cut -d= -f2  | tail -n+11 | awk '{mig+=$1} END {print "Overall_Migrations = " mig "\n" "AVG_Migrations_perslot = " mig/90}' >> $MIGRFILE


grep 'E_tot_gamma_plus' DC_Mig_gamma3.log | cut -d= -f2 | tail -n+11 |awk '{E_tot_plus+=$1} END {print "E_tot_plus = " E_tot_plus "\n" "AVG_tot_perslot= " E_tot_plus/90}' >> $MIGRFILE

grep 'E_C' DC_Mig_gamma3.log | cut -d= -f2 | tail -n+11 |awk '{E_C+=$1} END {print "E_C = " E_C "\n" "AVG_CPU_perslot= " E_C/90}' >> $MIGRFILE

grep 'E_D' DC_Mig_gamma3.log | cut -d= -f2 | tail -n+11 |awk '{E_D+=$1} END {print "E_D = " E_D "\n" "AVG_DATA_perslot= " E_D/90}' >> $MIGRFILE

grep 'E_M1' DC_Mig_gamma3.log | cut -d= -f2 | tail -n+11 |awk '{E_M1+=$1} END {print "E_M1 = " E_M1 "\n" "AVG_Mig1_perslot= " E_M1/90}' >> $MIGRFILE

grep 'E_M2' DC_Mig_gamma3.log | cut -d= -f2 | tail -n+11 |awk '{E_M2+=$1} END {print "E_M2 = " E_M2 "\n" "AVG_Mig2_perslot= " E_M2/90}' >> $MIGRFILE

