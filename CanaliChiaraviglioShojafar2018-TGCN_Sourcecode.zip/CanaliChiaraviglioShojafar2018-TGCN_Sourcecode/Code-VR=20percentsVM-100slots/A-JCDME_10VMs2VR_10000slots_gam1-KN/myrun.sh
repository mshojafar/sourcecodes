#!/bin/bash

STARTDIR=$1

export VMperS=3

function dataVectorInit() {
	t=$1
	outfile=$2
	infile=$3
	paramname=$4
	# find line with the right timestamp
	line=`grep "^${t} " $infile`
	# remove first element form the line
	line=`echo $line | cut -d " " -f 2-`
	#echo "found line $line for t=$t"
	newline="param $paramname :="
	c=1
	for i in $line
	do
		newline="$newline $c $i"
		(( c=c+1 ))
	done
	echo "$newline ;"> $outfile
}

function dataMatrixInit() {
	t=$1
	outfile=$2
	infile=$3
	paramname=$4
	# find line with the right timestamp
	line=`grep "^${t} " $infile`
	# remove first element form the line
	line=`echo $line | cut -d " " -f 2-`
	nelem=`echo $line | wc -w`
	ncol=`echo "sqrt($nelem)" | bc`
	nrow=$ncol
	echo "line has $nelem elements, ncol=$ncol"
	#echo "found line $line for t=$t"
	newline="param $paramname : \\n `seq -s ' ' 1 $ncol ` := \\n 1"
	x=1
	y=1
	for i in $line
	do
		newline="$newline $i"
		(( x=x+1 ))
		if [ $x -gt $ncol ]
		then 
			x=1
			(( y=y+1 ))
			if [ $y -le $nrow ]
			then 
				newline="$newline \\n $y"
			fi
		fi
	done
	echo -e "$newline \\n ;"> $outfile
}

function dataMatrixInit_old() {
	t=$1
	outfile=$2
	infile=$3
	paramname=$4
	# FIXME: nrow and ncol can be inferred form the number of elements
	ncol=$5
	nrow=$6
	# find line with the right timestamp
	line=`grep "^${t} " $infile`
	# remove first element form the line
	line=`echo $line | cut -d " " -f 2-`
	#echo "found line $line for t=$t"
	newline="param $paramname := "
	x=1
	y=1
	for i in $line
	do
		newline="$newline  $x $y  $i"
		(( x=x+1 ))
		if [ $x -gt $ncol ]
		then 
			x=1
			(( y=y+1 ))
		fi
	done
	echo "$newline ;"> $outfile
}


function dataInit() {
	t=$1
	echo "initializing data for run $t"
	echo "param runnumber := $t ;" > DC_Mig_runnumber.dat
	dataVectorInit $t DC_Mig_c_VM.dat CPU_timeseries.data c_VM
	dataVectorInit $t DC_Mig_m_VM.dat Mem_timeseries.data m_VM
	dataMatrixInit $t DC_Mig_d.dat Net_timeseries.data d 
}

get_nslot() {
	tail -n1 Net_timeseries.data | cut -d " " -f 1
}

get_nVM() {
	tail -n1 Mem_timeseries.data | cut -d " " -f 2- | wc -w
}

function printMaxVector() {
	paramname=$1
	max=$2
	nVM=$3
	newline="param $paramname :="
	for i in `seq 1 $nVM`
	do
		newline="$newline $i $max"
	done
	echo -e "$newline ;"
}

function printMaxMatrix() {
	paramname=$1
	max=$2
	min=$3
	nVM=$4
	newline="param $paramname : \\n `seq -s ' ' 1 $nVM` :="
	for i in `seq 1 $nVM`
	do
		newline="$newline \\n $i"
		for j in `seq 1 $nVM`
		do
			v=$max
			((hi=$i * 2 / ($nVM+1)))
			((hj=$j * 2 / ($nVM+1)))
			if [ $hi -eq $hj ]
			then
				v=$min
			fi
			if [ $i -eq $j ]
			then
				v=0
			fi
			newline="$newline $v"
			#echo "$i, $j --> $hi, $hj --> $v"
		done
	done
	echo -e "$newline ;"
}


function maxInit() {
	MAXVALFILE="DC_Mig_maxval.dat"
	MAXCPUVM=100 #Utilization of each VM in the server
	MAXMEMVM=26666667 # packets; size of each VM=40GByte,packet size=1.5Kbyte
	MAXNETVM=1000000000 #(packets/second); PS:we are able to transmit whole VM size in T second (slot size) 
	nVM=`get_nVM`
	((nSrv=nVM/VMperS +1 ))
	# number of servers
	echo "param M_size := $nSrv ;" > $MAXVALFILE
	# number of VMs
	echo "param N_size := $nVM ;" >> $MAXVALFILE
	# max server power
	printMaxVector "P_m" "328.2" $nSrv >> $MAXVALFILE
	# network interface power
	printMaxVector "P_d" "42.7" $nSrv >> $MAXVALFILE
	# max to min power ratio for server
	printMaxVector "K_C" "0.6020" $nSrv >> $MAXVALFILE
	# CPU overhead during migration
	printMaxVector "K_M" "0.01" $nSrv >> $MAXVALFILE
	# CPU
	((max=MAXCPUVM * VMperS))
	printMaxVector "c_m" $max $nSrv >> $MAXVALFILE
	# Memory
	((max=MAXMEMVM * VMperS))
	printMaxVector "m_m" $max $nSrv >> $MAXVALFILE
	# Network
	((max=MAXNETVM * VMperS))
	printMaxVector "d_m" $max $nSrv >> $MAXVALFILE
	# Communication energy
	# 6 mW 
	printMaxMatrix "E" "0.006" "0.003" $nSrv >> $MAXVALFILE
	#cat $MAXVALFILE
}


#cleanup code
rm -f *.log
# safe initialization. should be overwritten 
cp DC_Mig_x_old.dat.init DC_Mig_x_old.dat
cp DC_Mig_gamma.dat.init DC_Mig_gamma.dat

if [ -n "$STARTDIR" ]
then 
	cp $STARTDIR/*timeseries.data .
else
	echo "working on local files"
fi
# initialize
maxInit
dataInit 0
#exit
GAMMAFILELOG=DC_Mig_gamma.log
# first run with no migration
/usr/optimization/ampl/ampl DC_NoMig.run
#echo "solution after run N. 0"
sed -i~ -e's/x/param x_old/' DC_Mig_x_old.dat
sed -i~ -e's/x/param gamma/' DC_Mig_gamma.dat
gamma=1
gamma_cur=0

teta=0 # for scenario *.8
echo -n "Old G: G(0)= 0" >> $GAMMAFILELOG
echo -e "\n" >>$GAMMAFILELOG
echo -n "New G: G(1)= 0" >> $GAMMAFILELOG
echo -e "\n" >>$GAMMAFILELOG
echo -e "Old gamma(0)= 0" >> $GAMMAFILELOG
echo -e "\n" >>$GAMMAFILELOG
echo -e "New gamma(1)= $gamma" >> $GAMMAFILELOG
echo -e "\n" >>$GAMMAFILELOG
echo -e "*****************" >>$GAMMAFILELOG
echo -e "\n" >>$GAMMAFILELOG


#search 
migrationNo=0
#cat DC_Mig_x_old.dat
nslots=`get_nslot`
#exit
GAMMAFILEDAT=DC_Mig_gamma.dat
for runnumber in `seq 1 $nslots`
do
	((runprev=runnumber-1))
    ((runnext=runnumber+1))
	#rm migrationNo
	#gamma_old=$(bc <<<"scale=2;$gamma/10")
	#G(t-1)/N=gamma_old  , G(t)/N=gamma
    gamma_old=$gamma
    gamma_cur_old=$gamma_cur
    G_old=$(bc <<< "scale=4; $gamma_cur*12")
	dataInit $runnumber
	/usr/optimization/ampl/ampl DC_Mig.run
	# prepare old solution for next run
	sed -i~ -e's/x/param x_old/' DC_Mig_x_old.dat
    sed -i~ -e's/x/param gamma/' DC_Mig_gamma.dat
    #gamma is G(t)/N
    gamma_cur=$(grep 'g_plus\[i,j\]' DC_Mig_g_plus.log | cut -d= -f2)

    #gamma=migrationNo;
    #gamma=$(echo "scale=2;$gamma_old* 0.25+0.75 * $gamma" | bc)
    #gamma=$(bc <<< "scale=2;$gamma_old* 0.25+0.75 * $gamma")


    #((gamma=(gamma_old* 0.25)+0.75 * gamma))

    #if [ -f $GAMMAFILEDAT ]
    #	then
    

    G=$(bc <<< "scale=4;$gamma_cur*12")

    g2=$(bc <<< "scale=4;$gamma_cur_old*(1-0)")
    g1=$(bc <<< "scale=4;$gamma_old*0")
    gamma=$(bc <<< "scale=4;$g1+$g2")

   # gamma=$(bc <<< "scale=1;($gamma_old*teta)+(1-teta)* $gamma_cur")

        echo "param gamma:= $gamma;" > $GAMMAFILEDAT #output for next slot


    #((G_old=gamma_old*10))

    echo -n "Old G: G($runnumber)= $G_old" >> $GAMMAFILELOG
    echo -e "\n" >>$GAMMAFILELOG
    echo -n "New G: G($runnext)= $G" >> $GAMMAFILELOG
    echo -e "\n" >>$GAMMAFILELOG
    echo -n "g1= $g1" >> $GAMMAFILELOG
    echo -e "\n" >>$GAMMAFILELOG
    echo -n "g2= $g2" >> $GAMMAFILELOG
    echo -e "\n" >>$GAMMAFILELOG
    echo -e "Old gamma ($runnumber)= $gamma_old" >> $GAMMAFILELOG
    echo -e "\n" >>$GAMMAFILELOG
    echo -n "New gamma($runnext)= $gamma" >> $GAMMAFILELOG
    echo -e "\n" >>$GAMMAFILELOG
    echo -e "*****************" >>$GAMMAFILELOG
    echo -e "\n" >>$GAMMAFILELOG


    #fi

    #echo"*************************" >> $DC_Mig_gamma.log
    #echo"Slot Number := $runnumber ;" >> $DC_Mig_gamma.log
    #echo"ON Server := $on ;" >> $DC_Mig_gamma.log
    #echo"gamma in slot $runnumber:= $gamma ;" >> $DC_Mig_gamma.log
    #echo"*************************" >> $DC_Mig_gamma.log
	#echo "solution after run N. $runnumber"
	#cat DC_Mig_x_old.dat
done
