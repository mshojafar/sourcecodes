clc
clear all
close all
CPU_timeseries2=dlmread('CPU_timeseries.data');
Net_timeseries2=dlmread('Net_timeseries.data');
Mem_timeseries2=dlmread('Mem_timeseries.data');
%T=27497;
%autonumber=(0:T-1)';
%CPU_timeseries2=[autonumber CPU_timeseries2(:,2:end)];
CPU_timeseries_set1=[CPU_timeseries2(:,2)];
CPU_timeseries_set2=[CPU_timeseries2(:,3)];
%CPU_timeseries2=sum(CPU_timeseries2,2);
%Net_timeseries2=[autonumber Net_timeseries2(:,2:end)];

Net_timeseries_set1=[Net_timeseries2(:,2)];
Net_timeseries_set2=[Net_timeseries2(:,3)];

%Net_timeseries2=[Net_timeseries2(:,2:end)];
%Net_timeseries2=sum(Net_timeseries2,2);
%Mem_timeseries2=[autonumber Mem_timeseries2(:,2:end)];

Mem_timeseries_set1=[Mem_timeseries2(:,2)];
Mem_timeseries_set2=[Mem_timeseries2(:,3)];


x_list=[1:1:100]';

figure(1)
h1=plot(x_list,CPU_timeseries_set1,'b','LineWidth',2);
hold on
plot(x_list,CPU_timeseries_set2,'--r','LineWidth',2);
xlabel('TS','FontSize',12);
ylabel('CPU Utilization [%]','FontSize',12);
legend('VE_1','VE_2');
set(gca,'FontSize',10);
set(h1,'MarkerSize',2,'LineWidth',3);
grid on

figure (2)
plot(x_list,Mem_timeseries_set1/10^6,'b','LineWidth',2);
hold on
h1=plot(x_list,Mem_timeseries_set2/10^6,'--r','LineWidth',2);
xlabel('TS','FontSize',12);
ylabel('Memory Utilization [GB]','FontSize',12);
legend('VE_1','VE_2');
set(gca,'FontSize',10);
set(h1,'MarkerSize',2,'LineWidth',3);
grid on



%figure (3)
%plot(x_list,Net_timeseries_set1,'-sb');
%hold on
%h1=plot(x_list,Net_timeseries_set2,'-sr');
%xlabel('\#Slot','Interpreter','latex','FontSize',10);
%ylabel('\#Network','Interpreter','latex','FontSize',10);
%legend('Network');
%set(gca,'FontSize',10);
%set(h1,'MarkerSize',2,'LineWidth',3);
%grid on
%  set(gca, 'XTickLabel', {'150','250','350','450','550','650', '750'},...
%      'XTick',[150 250 350 450 550 650 750]);
%  set(gca, 'XTickLabel', {'10','20','30','40'},...
%      'XTick',[10 20 30 40]);


X
