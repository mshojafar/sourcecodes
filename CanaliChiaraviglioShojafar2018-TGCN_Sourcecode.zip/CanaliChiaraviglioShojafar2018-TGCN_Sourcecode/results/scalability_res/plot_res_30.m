clear all
close all
clc


load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0.1-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0.2-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0.3-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0.4-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0.5-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0.6-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0.7-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0.8-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam0.9-results.txt
load SCALABILITY_TOT_ENERGY_JCDME-10VMs3VR_100slots_gam1-results.txt

load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0.1-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0.2-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0.3-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0.4-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0.5-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0.6-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0.7-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0.8-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam0.9-results.txt
load SCALABILITY_TOT_TIME_JCDME-10VMs3VR_100slots_gam1-results.txt


load S_T_E_ASJCDME-Newton10VMs3VR_100slots_gam0.7-results.txt
load S_T_E_ASJCDME-Newton10VMs3VR_100slots_gam0-results.txt
load S_T_E_ASJCDME-Newton10VMs3VR_100slots_gam1-results.txt

load S_T_C_ASJCDME-Newton10VMs3VR_100slots_gam0.7-results.txt
load S_T_C_ASJCDME-Newton10VMs3VR_100slots_gam0-results.txt
load S_T_C_ASJCDME-Newton10VMs3VR_100slots_gam1-results.txt

tot_gamma_values=11;
tot_datasets=50;

tot_JCDME_energy=zeros(tot_datasets,tot_gamma_values);

tot_JCDME_energy(:,1)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_results(:,2); 
tot_JCDME_energy(:,2)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_1_results(:,2); 
tot_JCDME_energy(:,3)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_2_results(:,2); 
tot_JCDME_energy(:,4)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_3_results(:,2); 
tot_JCDME_energy(:,5)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_4_results(:,2); 
tot_JCDME_energy(:,6)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_5_results(:,2); 
tot_JCDME_energy(:,7)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_6_results(:,2); 
tot_JCDME_energy(:,8)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_7_results(:,2); 
tot_JCDME_energy(:,9)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_8_results(:,2); 
tot_JCDME_energy(:,10)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam0_9_results(:,2); 
tot_JCDME_energy(:,11)=SCALABILITY_TOT_ENERGY_JCDME_10VMs3VR_100slots_gam1_results(:,2); 

tot_JCDME_time=zeros(tot_datasets,tot_gamma_values);

tot_JCDME_time(:,1)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_results(:,2); 
tot_JCDME_time(:,2)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_1_results(:,2); 
tot_JCDME_time(:,3)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_2_results(:,2); 
tot_JCDME_time(:,4)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_3_results(:,2); 
tot_JCDME_time(:,5)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_4_results(:,2); 
tot_JCDME_time(:,6)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_5_results(:,2); 
tot_JCDME_time(:,7)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_6_results(:,2); 
tot_JCDME_time(:,8)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_7_results(:,2); 
tot_JCDME_time(:,9)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_8_results(:,2); 
tot_JCDME_time(:,10)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam0_9_results(:,2); 
tot_JCDME_time(:,11)=SCALABILITY_TOT_TIME_JCDME_10VMs3VR_100slots_gam1_results(:,2); 



for i=1:tot_datasets
    tot_JCDME_time_ALL(i)=sum(tot_JCDME_time(i,:));
end

for i=1:tot_datasets 
   [max_tot_JCDME_energy(i) index_max(i)]=max(tot_JCDME_energy(i,:));
   [min_tot_JCDME_energy(i) index_min(i)]=min(tot_JCDME_energy(i,:)); 
end

area_tot_energy=[min_tot_JCDME_energy' max_tot_JCDME_energy'-min_tot_JCDME_energy'];

figure

xvar=[10:10:500];

h=area(xvar,10*area_tot_energy/1000);
hold on
h(1).FaceAlpha = 0;
h(1).FaceColor = [0.8 0.8 0.8];
h(1).EdgeColor = [1 1 1];

h(2).FaceAlpha = 0.5;
h(2).FaceColor = [0 0 1];
h(2).EdgeColor = [0 0 1];


p=plot(xvar,10*S_T_E_ASJCDME_Newton10VMs3VR_100slots_gam0_7_results(:,2)/1000,'k','LineWidth',2);

xlabel('Number of VMs')
ylabel('Total Energy per TS [kJ]');

hleglines = [h(2) p(1)];

legend(hleglines, 'JCDME','AN-JCDME','Location','northwest')

xlim([10 500])
grid on 

set(gca,'FontSize',16);

hold off

tot_comp_time_ASJCDME=3*S_T_C_ASJCDME_Newton10VMs3VR_100slots_gam0_7_results(:,2)/100;

figure

plot(xvar',tot_JCDME_time_ALL/100','b--','LineWidth',2);
hold on
plot(xvar',tot_comp_time_ASJCDME','k','LineWidth',2);

legend('JCDME','AN-JCDME','Location','northwest')

set(gca,'FontSize',16);

xlabel('Number of VMs')
ylabel('Tot. Computation Time per TS [s]');

xlim([10 500])
grid on 


hold off

figure


gamma=[0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0];

load AVG_GAMMA_ASJCDME-Newton10VMs3VR_100slots_gam0.7-results.txt

plot(xvar,gamma(index_min),'b','LineWidth',2);
hold on
plot(xvar,AVG_GAMMA_ASJCDME_Newton10VMs3VR_100slots_gam0_7_results,'k','LineWidth',2);


xlabel('Number of VMs')
ylabel('\gamma');
legend('JCDME (Best Value)', 'AN-JCDME (Average Value)');
xlim([10 500])
ylim([0 1])
set(gca,'FontSize',16);
grid on
hold off


%figure


yvar=[0:1:10];

numlevels=200;
figure
%[currentcont,hcont]=
s=surf(tot_JCDME_energy/1000');

s.EdgeColor = 'none';

hold on
%text_handle = clabel(currentcont,hcont,'FontSize',16,'Rotation',0);
%text_handle = clabel(currentcont,hcont,'FontSize',15);
%set(text_handle,'BackgroundColor',[1 1 .6],'Edgecolor',[.7 .7 .7])
%set(text_handle,'BackgroundColor',[1 1 1],'Edgecolor',[.7 .7 .7])
%colormap('Gray')
colormap(parula)
%set(get(t,'ylabel'),'String', '[dB]','FontSize',16);
%ylabel(t, 'Tot Energy [kJ]','FontSize',16);
set(gca,'FontSize',16);
axis square
xlabel '\gamma'
ylabel 'Number of VMs'
%plot3(vfLX, vfLY, vfLZ, 'r-');

figure
plot(tot_JCDME_energy(50,:),'b');
