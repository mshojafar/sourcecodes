gnuplot << EOF
reset 
clear

set terminal postscript eps enhanced color solid "Helvetica,24"
set style data histograms
set style fill solid 1.00 border
#set style fill pattern border
set bmargin 5

#######################################################################################
#######################################################COMMUNICATION COST#############
#######################################################################################

############################################################ sh Communication cost - 128

set grid ytics
# key/legend
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 3
set key width +1
set key outside horizontal                         

#plot 1
set pointsize 1
set output "sh-Communication-128.eps"
set ylabel "Communication Cost (Mbit)" offset 0,0,0
set xlabel "(Short Hash, Probability)" offset 0,0,0
set ytics nomirror
set xtics("(8,0.3)" 1, "(16,0.3)" 2, "(8,0.8)" 3, "(16,0.8)" 4) textcolor rgbcolor "black" font "Times-Roman,24"
set term post eps "Times-Roman" 24
set key font "Times-Roman,24"

plot [] []\
"sh-Communication.data" using 1:2 t "LEVER-128"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"sh-Communication.data" using 1:4 t "O-DD-128"  w lp lw 5 ps 2 pt 3 lt rgb "black"


############################################################ sh Communication cost - 4k

#plot 2

set grid ytics
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 3
set key width +1
set key outside horizontal                         


set pointsize 1
set output "sh-Communication-4k.eps"
set ylabel "Communication Cost (Mbit)" offset 0,0,0
set xlabel "(Short Hash, Probability)" offset 0,0,0
set ytics nomirror
set xtics("(8,0.3)" 1, "(16,0.3)" 2, "(8,0.8)" 3, "(16,0.8)" 4) textcolor rgbcolor "black" font "Times-Roman,24"
set term post eps "Times-Roman" 24
set key font "Times-Roman,24"

plot [] []\
"sh-Communication.data" using 1:3 t "LEVER-4K"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"sh-Communication.data" using 1:5 t "O-DD-4K"  w lp lw 5 ps 2 pt 3 lt rgb "black"



#######################################################################################
#######################################################DEDUPLICATION COST#############
#######################################################################################

############################################################ sh dedubplication cost - 128

set grid ytics
# key/legend
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 3
set key width +1
set key outside horizontal                         

#plot 1
set pointsize 1
set output "sh-Deduplication-128.eps"
set ylabel "Deduplication (%)" offset 0,0,0
set xlabel "(Short Hash, Probability)" offset 0,0,0
set ytics nomirror
set xtics("(8,0.3)" 1, "(16,0.3)" 2, "(8,0.8)" 3, "(16,0.8)" 4) textcolor rgbcolor "black" font "Times-Roman,24"
set term post eps "Times-Roman" 24
set key font "Times-Roman,24"


plot [] []\
"sh-Deduplication.data" using 1:2 t "LEVER-128"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"sh-Deduplication.data" using 1:4 t "O-DD-128"  w lp lw 5 ps 2 pt 3 lt rgb "black"

############################################################ sh dedubplication cost - 4k

set grid ytics
# key/legend
set key box
set key center top
#set key bmargin 
set key spacing 1
set rmargin 3
set key width +1
set key outside horizontal                         

#plot 1
set pointsize 1
set output "sh-Deduplication-4k.eps"
set ylabel "Deduplication (%)" offset 0,0,0
set xlabel "(Short Hash, Probability)" offset 0,0,0
set ytics nomirror
set xtics("(8,0.3)" 1, "(16,0.3)" 2, "(8,0.8)" 3, "(16,0.8)" 4) textcolor rgbcolor "black" font "Times-Roman,24"
set term post eps "Times-Roman" 24
set key font "Times-Roman,24"


plot [] []\
"sh-Deduplication.data" using 1:3 t "LEVER-128"  w lp lw 5 ps 2 pt 6 lt rgb "blue", \
"sh-Deduplication.data" using 1:5 t "O-DD-128"  w lp lw 5 ps 2 pt 3 lt rgb "black"

EOF

