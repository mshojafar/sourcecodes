
clear all;
close all;
clc;
%% Loading and assignments

load('X');
load('EPS');
load('DELTA_IP');

%% %PARAMETRI GENERALI
n=1000;                                                                    %numero of slot
nclient=1;                                                                 % number of clients
Ts = 2;                                                                    %time slot (sec)
kappa=1000;

% X=rand(1,2*n);
% save('X');
% EPS=rand(1,2*n);
% save('EPS');
%DELTA_IP=rand(1,n);
 %save('DELTA_IP');


%Ew =(-1.732+25)+(2*1.732*EW(1:N));
%Ew =(7)+(EW(1:n));
E_W=zeros(nclient,n);                                                       %TCP/IP energy consumption for each slot
%E_TOT=zeros(nclient,n);                                                         %TOT energy consumption for each slot
Mu=zeros(nclient,n);  %[ones(nclient,1) zeros(nclient,n)];                                      %moltiplicatore
E_TOT=zeros(1,n);                                                         %TOT energy consumption for each slot


avg_r=zeros(nclient,n);
q=zeros(nclient,n);                                                        %service rate OUT-queue sistema
s=zeros(nclient,n);                                                        %service rate IN-queue sistema
a=zeros(nclient,n);                                                        %incoming rate IN-queue sistema
Jobs=a;
r=zeros(nclient,n);                                                        %arrival rate in INPUT queue
%L_tot_vect = 6+ round((10-6) * rand(1,n));
%% PMR=1.25, L_tot=8+-2   L_tot=12+-3
%save('workloads8PMR125No100000Journal.mat', 'L_tot_vect');                  %loading 100 fixed random workloads
L_tot_vect=load('workloads8PMR125No100000Journal.mat','L_tot_vect');                %loading 2000 fixed random workloads
L_tot_vect = L_tot_vect.L_tot_vect;
L_tot_vect=L_tot_vect(1:n);
a=L_tot_vect;

L_tot=zeros(1,n);                                                          %workload per slot of the sistema
lambda=zeros(nclient,n);                                                   %arrival rate in INPUT queue

%% Critical parameter%s
%energy_ave=0.25;
%energy_ave_vector=[20, 10,1,0.5,0.25,0.125,0.0625,0.03125,0.01, 0.005];   % first test
energy_ave_vector=[10, 0.25];   % second test
%energy_ave_vector=[0.08];   % third test
N_O=240;       %old=240000                                                         %MAXIMUM CAPACITY of OUT-queue(byte)
N_I=240;       %old=240000                                                           %MAXIMUM CAPACITY of IN-queue(byte)
%r_min=3.5; %we suppose average of a=8                                                             %(byte/slot)
r_max=16;                                                                %(byte/slot)
%a_min=r_min;
%a_max=r_max;

%% PARAMETRI DI CANALE
DELTA_IP_MAX = 10;                                                         %max ip layer delay = 10*Ts(time slot)
%DELTA_IP1 = Ts*(round(DELTA_IP_MAX * DELTA_IP(1:n)));
DELTA_IP1 = ((DELTA_IP_MAX * DELTA_IP(1:n)));

RTT = zeros(nclient,n);
b = 2;
MSS = 120;
beta=1;
%teta=0.5;
sigma = zeros(nclient,n);
v = 13;                                                                    %speed m/s (13 m/s is the v of the paper: h=0.95)
h = 0.82^(v*Ts/100);                                                       %correlation coefficient

A = 90.2514;
B = 3.4998;
C = 10^0.10942;
% A = 274.7229;
% B = 7.9932;
% C = 10^(-0.15331);
x = X(1:2*n);
esp = EPS(1:2*n);
for k = 2:2*n
    x(1,k) = (h^0.5)*x(1,k-1) + ((1-h)^0.5)*esp(1,k);
end
x = x(n+1:2*n);
% x = x - mean(x);
x = x - min(x);
% x = x - mean(x);
x = (1/max(x)) * x;%normalization
x = -3^0.5 + 2*(3^0.5)*x;


a_0 = exp(-0.5*(0.1*log(10))^2);
z = a_0*10.^(0.1*x);
%Pl = (C + (A/((C*B)^2)) * gammainc(1,C*B)) * (z./E_W);
% Pl = (0.7*10^-2)*ones(1,N);


K_0 = 1*( ((3/(2*b))^0.5) * MSS ) / (C+(A/(C*B^2)) * gammainc(1,C*B))^-0.5;

sigma_min_anal=K_0*((a_0*(10^(-0.1*sqrt(3))))^(1/2))/(DELTA_IP_MAX);
%r_min_vector=sigma_min.*sqrt(energy_ave_vector);
r_min_anal=sigma_min_anal.*sqrt(energy_ave);
% r_min_vector1=sigma_min.*sqrt(energy_ave);
% r_min_vector=[0.01, 0.1, 1, r_min_vector1, 4, 5];
% K_0 = 39124;

% K_0 = ( ((3/(2*b))^0.5) * MSS ) / (C+(A/(C*B^2)) * gamma(C*B))^-0.5;
% K_0 = ( ((3/(2*b))^0.5) * MSS ) / (C+((A * gammainc(1,C*B)^-0.5))/(C*B^2)) 
%
%% DVFS Block definitions

%VM=[3:1:5];%numero Macchine Virtuali
VM=[5,7,10];%numero Macchine Virtuali

NumSimulazioni=length(VM);

costo_tot_VM=zeros(1,NumSimulazioni);
costo_tot_VM_f_succ=zeros(1,NumSimulazioni);
costo_tot_VM_f_prec=zeros(1,NumSimulazioni);
costo_tot_VM_TS=zeros(1,NumSimulazioni);
costo_VM_TS_switch=zeros(1,NumSimulazioni);
costo_tot_VM_TSpiuSwitch=zeros(1,NumSimulazioni);


f_VM_prima=zeros(1,NumSimulazioni);
f_VM_ultima=zeros(1,NumSimulazioni);


iter_VM=zeros(1,NumSimulazioni);

L_VM_prima=zeros(1,NumSimulazioni);
L_VM_ultima=zeros(1,NumSimulazioni);

%SET UTILIZZATO PER FIG.2
%chi_completo=[0.5:0.25:100]; %1000 - BLU
%chi_completo=0.5.*ones(1,100);%2000 - VERDE
%chi_completo=0.2*ones(1,100);%3000 - ROSSO
%chi_completo=[0.5:0.5:100];%4000 - NERO

%chi_completo=[0.5:0.25:100];% heterogenous
chi_completo=0.5.*ones(1,1000);% hemogenous

%inizializzazione variabili

k_e=0.05; %0.005; %0.05; ke grande e piccolo
R_tot=100; %C_max=15; %(Mb/s)
T_tot=5; %(s)


%rand('twister',0);
%Jobs=8.*ones(1,1000);  %carico deterministico
%Jobs=6 + (10-6).*rand(1,1000); %carico uniformemente distribuito   8+-2   %UTILIZZATO PER FIG.2, FIG.6 e FIG.7
%Jobs=2 + (14-2).*rand(1,1000); %carico uniformemente distribuito   8+-6
%Jobs=(16).*rand(1,1000); %carico uniformemente distribuito   8+-8
%% Sigma/RTT calculation block
RTT(nclient,1)=0;
sigma(nclient,1)=0;
for i=2:n
 RTT(nclient,i) = (0.75 * RTT(nclient,i-1) + 0.25 * DELTA_IP1(nclient,i));
   
 sigma(nclient,i) = ( K_0 * ((z(nclient,i))^0.5) ) / RTT(nclient,i);

end
sigma_min_simulation=min(sigma(nclient,2:n));
RTT_max_simulation=max(RTT(nclient,:));

%% MINIBOOK MAIN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% test 5 parameters
%q0_vector1=[1, 2, 4, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 50, 100, 150, 200, N_O];  %third test
q0_vector1=[240];  %third test
s0_vector1=[240];  %third test
%s0_vector1=[10^-2, N_I];  %third test
%teta_vector1=[0.01, 0.5, ]; %third test
teta_vector1=[0.5]; %8th test

% E_W_vector=zeros(NumSimulazioni, length(energy_ave_vector), length(q0_vector1), length(s0_vector1), length(teta_vector1));
% E_TOT_vector=zeros(NumSimulazioni, length(energy_ave_vector), length(q0_vector1), length(s0_vector1), length(teta_vector1));
% Muinf_vector=zeros(NumSimulazioni,length(energy_ave_vector), length(q0_vector1), length(s0_vector1), length(teta_vector1));
% s_vector=zeros(NumSimulazioni, length(energy_ave_vector), length(q0_vector1), length(s0_vector1), length(teta_vector1));
% q_vector=zeros(NumSimulazioni, length(energy_ave_vector), length(q0_vector1), length(s0_vector1), length(teta_vector1));
% r_vector=zeros(NumSimulazioni, length(energy_ave_vector), length(q0_vector1), length(s0_vector1), length(teta_vector1));
% L_tot_vector=zeros(NumSimulazioni, length(energy_ave_vector), length(q0_vector1), length(s0_vector1), length(teta_vector1));
% lambda_vector=zeros(NumSimulazioni, length(energy_ave_vector), length(q0_vector1), length(s0_vector1), length(teta_vector1));
% Utility_vector=zeros(NumSimulazioni, length(energy_ave_vector), length(q0_vector1), length(s0_vector1), length(teta_vector1));
% 
% 
E_W_vector=zeros(NumSimulazioni,length(energy_ave_vector));
E_TOT_vector=zeros(NumSimulazioni,length(energy_ave_vector));
Muinf_vector=zeros(NumSimulazioni,length(energy_ave_vector));
s_vector=zeros(NumSimulazioni,length(energy_ave_vector));
q_vector=zeros(NumSimulazioni,length(energy_ave_vector));
r_vector=zeros(NumSimulazioni,length(energy_ave_vector));
L_tot_vector=zeros(NumSimulazioni,length(energy_ave_vector));
lambda_vector=zeros(NumSimulazioni,length(energy_ave_vector));
Utility_vector=zeros(NumSimulazioni,length(energy_ave_vector));


% E_W_vector=zeros(1,length(r_min_vector));
% E_TOT_vector=zeros(1,length(r_min_vector));
% Muinf_vector=zeros(1,length(r_min_vector));
% s_vector=zeros(1,length(r_min_vector));
% q_vector=zeros(1,length(r_min_vector));
% r_vector=zeros(1,length(r_min_vector));
% L_tot_vector=zeros(1,length(r_min_vector));
% lambda_vector=zeros(1,length(r_min_vector));
% Utility_vector=zeros(1,length(r_min_vector));
% 
% E_TOT_vector=zeros(1,NumSimulazioni);

for k=1:NumSimulazioni
             tic
    k
    M=VM(k);
    %INIZIALIZZAZIONE PARAMETRI %%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ni_opt=zeros(1,M);
    f_opt=zeros(1,M);
    L_opt=zeros(1,M);
    mu_opt=0;
    iter_VM=zeros(1,M);
    alpha_step=0.01; %<==  N.B. Parametro utilizzato all'interno della funzione di tracking - settare in modo congruo
    V_step=0;
  
f_max=10.*ones(1,M);  %(Mb/s)


%f_zero=f_max;
f_zero=zeros(1,M);  % (Mb/s)
chi=chi_completo(1:M);
W=ones(1,M);
%N0=ones(1,M);
%g=ones(1,M);
Th=2.*log(2).*(chi./W);

E_max=40.*ones(1,M);  % (mJ)

omega=1.*ones(1,M);
Delta=1; %caso OMOGENEO: delta uguale per tutti i canali
L_b=zeros(1,M);  % NB. il codice funziona bene per L_b=0, altrimenti aggiungere modifica su f_opt.

temp=2.*k_e+(2.*E_max.*omega./(f_max.^2));
alpha_zero=2.*k_e./temp;
alpha_mu=Delta./temp;
f_ibernazione=alpha_zero.*f_zero;


%FREQUENZE DISCRETE INIZIALIZZAZIONE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q=6; %numero frequenze discrete;
f_discrete=zeros(M,Q);
for conta=1:M
    f_discrete(conta,:)=[0:f_max(conta)./(Q-1):f_max(conta)];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    test 2 parametrs
%q0_vector1=[1, 5, 8, 10, 25, 50, 100];  %first test
% q0_vector1=[1, 5, 8, 10, 25, 50, 100, 150, 200, 240];  %second test
% E_W_vector=zeros(length(energy_ave_vector), length(q0_vector1));
% Muinf_vector=zeros(length(energy_ave_vector), length(q0_vector1));
% s_vector=zeros(length(energy_ave_vector), length(q0_vector1));
% q_vector=zeros(length(energy_ave_vector), length(q0_vector1));
% r_vector=zeros(length(energy_ave_vector), length(q0_vector1));
% L_tot_vector=zeros(length(energy_ave_vector), length(q0_vector1));
% lambda_vector=zeros(length(energy_ave_vector), length(q0_vector1));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for test1=1:length(energy_ave_vector)
      test1

%for test10=1:length(r_min_vector)
  % test10
  %r_min=r_min_vector(test10);
  %r_min=sigma_min_simulation*sqrt(energy_ave);
    r_min=sigma_min_simulation*sqrt(energy_ave_vector(test1));

   
   % for test2=1:length(q0_vector1)
      % q(nclient,1)=q0_vector1(test2);
      q(nclient,1)=240;


       %q(nclient,1)=100;
%for test3=1:length(s0_vector1)
        %s(nclient,1)=s0_vector1(test3);
        s(nclient,1)=240;
        %s(nclient,1)=r_min;
  %      for test31=1:length(teta_vector1)
          %  teta=teta_vector1(test31);
             teta=0.5;

            avg_r(nclient,1)=r_min;
          
            iter_mat=zeros(1,n);                    % number of converagence iteration for each lost
            
          for i=1:n                                                                   % SLOT
                
                if (mod(i,9999)==0)
                    i
                end
                
                if  (i>1)
                    avg_r(nclient,i)= mean(r(nclient,1:1:i-1));                         %\overline(r)(t-1)
                    %prev_r=r(nclient,i-1);
                   % avg_r(nclient,i)= (1-J_P)*avg_r(nclient,i-1)+J_P*prev_r;        %Jacoupson formula
                end
                
                %%%%%%% calculate L_opt
                if (q(nclient,i)<=N_O+r_min-r_max)
                    L_tot(i)= min(s(nclient,i),max(r_min,avg_r(nclient,i)));                         %L_opt^(*)(t)
                else
                    L_tot(i)= 0;
                end
                % calculate lambda
                %XXXXXXXX
                lambda(nclient,i)=min(a(nclient,i),N_I-s(nclient,i)+L_tot(i));
                
                % calculate r (t)
                Mu_temp=(beta*(1-teta))./Mu(nclient,i);
                sigma_temp=((sigma(nclient,i).^2)./2).*Mu_temp;
                r(nclient,i)=min(max(sigma_temp,r_min),min(r_max,q(nclient,i)));
                
                % calculate E_W (t)
                if i>1
                    E_W(nclient,i)=(r(nclient,i).^2)./(sigma(nclient,i).^2);
                else
                    E_W(nclient,1)=0;
                end
                % calculate RTT (t+1)
                % RTT(nclient,i) = (0.75 * RTT(nclient,i-1) + 0.25 * DELTA_IP1(nclient,i));
                
                % calculate Sigma (t+1)
                %  sigma(nclient,i) = ( K_0 * ((z(nclient,i))^0.5) ) / RTT(nclient,i);
                
                % calculate Mu(t+1)
                %Mu(nclient,i+1)=max(0,Mu(nclient,i)+(kappa./i)*(E_W(nclient,i)-energy_ave));      %  min(limSupMu,max(0,Mu(nclient,i) + (energy_irradiata(nclient,i)-energy_ave)));
                Mu(nclient,i+1)=max(0,Mu(nclient,i)+(kappa./i)*(E_W(nclient,i)-energy_ave_vector(test1)));      %  min(limSupMu,max(0,Mu(nclient,i) + (energy_irradiata(nclient,i)-energy_ave)));
                % calculate q(t+1)
                q(nclient,i+1)=max(0,q(nclient,i)-r(nclient,i))+L_tot(i);
                
                % calculate s(t+1)
                s(nclient,i+1)=max(0,s(nclient,i)-L_tot(i))+lambda(nclient,i);
                
                % COMNET or DVFS approach
           % end % n
               
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% massimo core code
           %CHECK FEASIBILITY - controllare funzionamento operatori %%%%%%%%%%%%%%%%%%
            epsilon = 0.01;                     %tolerance 2nd & 3rd condition
            iterations = 5000;                 %max number of iteration
            tol_workload_allocated = 0.01;      %tolerance 1st condition
            gamma = 0.5;

            beta1 = (Delta/(T_tot-Delta))/((10*Delta^2)+(T_tot-Delta)^(Delta));%time out
            %betapippo = (0.00001+(k_e/(Delta*1000)))/Delta^2;
            betapippo = 0.0001;

            if (L_tot(i)==0)
                mu_opt=0;
                L_opt=zeros(1,M);
                f_opt=f_zero;
                iter_mat(i)=0;
            else
                              
            
            
                    condizione_feas_carico=(sum(f_max.*Delta-L_b)>=L_tot(i));
                    condizione_feas_tempo=(L_tot(i)<=R_tot.*(T_tot-Delta)./2);
                    condizione_feas_back=min(Delta.*f_max>=L_b); 


                    feasibility=condizione_feas_carico && condizione_feas_tempo && condizione_feas_back;

                if ~feasibility
                        'VM='
                        M
                        error('Problem unfeasible')
                else
                                        
                    %fprintf('Problem feasibile for the workload %d\n',l);
                    Delta_load = zeros(1,iterations);
                    L = zeros(iterations,M);
                    alpha = zeros(1,iterations);
                    pippo = zeros(1,iterations);
                    V = zeros(1,iterations);
                    V_pippo = zeros(1,iterations);
                    mu_iter = zeros(1,iterations);
                    ni = zeros(iterations,M);
                    y = zeros(iterations,M);
                    f_opt_itr = zeros(iterations,M);
                    ii = 2;
                    %MatrixRis = zeros(1+M+M,n);                 %matrix of results, row: 1=final_iter 2=final_alpha 3=tot_cost 4=final_ni 5=2nd_condition 6=(ni<esp & g(.)<esp)
%                     L_allocated = zeros(n,iterations);          %matrix of total allocation for each iteration fon each workload 
%                     f_opt_mat = zeros(n,iterations);            %matrix of frequency allocation for each iteretion for each workload FOR THE 1ST VM
%                     L_mat = zeros(n,iterations);                %matrix of  allocation for each iteretion for each workload FOR THE 1ST VM
%                     ni_mat = zeros(n,iterations);               %matrix of "ni" value for each iteretion for each workload FOR THE 1ST VM
%                     mu_mat = zeros(n,iterations);               %matrix of "mu" value for each iteretion for each workload
%                     alpha_mat = zeros(n,iterations);            %matrix of "alpha" value for each iteretion for each workload
%                     pippo_mat = zeros(n,iterations);            %matrix of "pippo" value for each iteretion for each workload FOR THE 1ST VM

                    while ii <= iterations
                        bandierina = 0;
                        kj=0;
                        cond3 = zeros(1,M);
                        cond2 = zeros(1,M);
                        %calculate of MU
                        mu_iter(ii) = max(0,(mu_iter(ii-1) - ((alpha(ii-1))) * (sum(L(ii-1,:)) - L_tot(i)) ) );
                        
                        %calculate of temp variable
                        y(ii,:) = max(0,( ((T_tot-Delta)/2) .* W .* log2(mu_iter(ii) ./ Th) ) );
                        
                        %calculate of ni; the old was: ni(i,:) = max(0,( ni(i-1,:) + (alpha(i-1) * ( L(i-1,:) - (Delta.*f_opt(i-1,:))))))
                        ni(ii,:) = max(0, (ni(ii-1,:) + (pippo(ii-1) * (y(ii,:) - Delta.*f_opt_itr(ii-1,:)))));
                        
                        %calculate of f_opt
                        f_star = (2*k_e*f_zero + ni(ii,:).*Delta)./ temp;
                        f_opt_itr(ii,:) = max(L_b/Delta,min(f_star,f_max));
                        
                        %calculate of L
                        L(ii,:) = min(f_opt_itr(ii,:) .* Delta,y(ii,:));
                        
                        
                        % 2nd and 3rd condition
                        for x = 1:M
                            cond3(1,x) = (((abs(ni(ii,x)))<=epsilon)||((abs(L(ii,x)-f_opt_itr(ii,x)*Delta))<=epsilon));
                            cond2(1,x) = L(ii,x)<=f_opt_itr(ii,x)*Delta;
                        end
                        
                        
                        %if (bandierina == 0 && kj<100)
                            alpha(ii) = max(0,min(beta1,alpha(ii-1) - gamma * V(ii-1) * (sum(L(ii-1,:)) - L_tot(i))));
                            V(ii) = (1 - alpha(ii-1)) * V(ii-1) - (sum(L(ii-1,:)) - L_tot(i));
                            pippo(ii) = max(0,min(betapippo,pippo(ii-1) - gamma * V_pippo(ii-1) *(Delta*f_opt_itr(ii-1,1)- y(ii,1))));
                            V_pippo(ii) = (1 - pippo(ii-1)) * V_pippo(ii-1) - (Delta*f_opt_itr(ii-1,1)- y(ii,1));
                            Delta_load(ii)=sum(L(ii,:))-L_tot(i);
                            %speed_cost(l,ii) = sum(((f_opt(ii,:)./f_max).^2).*omega.*E_max);                                % Computing (11.1)
                            %switch_cost(l,ii) = sum(k_e.*(f_opt(ii,:)-f_zero).^2);                                          % Switching (11.1)
                            %channel_cost(l,ii) = (T_tot-Delta(1)).*sum(Zeta .* (2.^(2*L(ii,:)./((T_tot-Delta).*W))-1));     % Networking
                            %tot_cost(l,ii) = speed_cost(l,ii) + switch_cost(l,ii) + channel_cost(l,ii);                       % Overall
                            
                            %L_allocated(l,ii) = sum(L(ii,:));
                            
                            
                            %L_mat(i,ii) = L(ii,1);
%                             f_opt_mat(l,ii) = f_opt_itr(ii,1);
%                             ni_mat(i,ii) = ni(ii,1);
%                             mu_mat(i,ii) = mu(ii);
%                             alpha_mat(i,ii) = alpha(ii);
%                             pippo_mat(i,ii) = pippo(ii);
                            cond_car_all = abs(Delta_load(ii)/L_tot(i))>=tol_workload_allocated;
                            for x = 1:M
                               cond3(1,x) = (((abs(ni(ii-1,x)))<=epsilon)||((abs(L(ii-1,x)-f_opt_itr(ii-1,x)*Delta))<=epsilon));
                            end
                            if cond_car_all%||sum(cond3(1,:))< M
                                iter_mat(i) = ii;
                                %MatrixRis(1:M,i) = L(ii,:);
                               % MatrixRis(M+1:M+M,i) = f_opt_itr(ii,:);
                                mu_opt=mu_iter(ii);
                                L_opt(:)=L(ii,:);
                                f_opt(:)=f_opt_itr(ii,:);
                                %MatrixRis(M+M+1,i) = tot_cost(i,ii);
                            else
                                %fprintf('correct allocation for workload n: %d (%d) at iteration %d\n',i,L_tot(l),ii);
                                iter_mat(i) = ii;
                                %MatrixRis(1:M,i) = L(ii,:);
                               % MatrixRis(M+1:M+M,i) = f_opt_itr(ii,:);
                                mu_opt=mu_iter(ii);
                                L_opt(:)=L(ii,:);
                                f_opt(:)=f_opt_itr(ii,:);
                                %MatrixRis(M+M+1,i) = tot_cost(i,ii);
                                break;
                            end
                            ii = ii + 1;
                       % end
                    end  % while internal iteraion 
                end  % feasibility
                
            end % if

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
               

            
                     
                     
                   R_opt=2.*L_opt./(T_tot-Delta);



                     L_VM_prima(k)=L_VM_prima(k)+L_opt(1);
                     L_VM_ultima(k)=L_VM_ultima(k)+L_opt(M);
                     f_VM_prima(k)=f_VM_prima(k)+f_opt(1);
                     f_VM_ultima(k)=f_VM_ultima(k)+f_opt(M);
                     
                     
                     
                     %Calcolo f_precedente e f_successiva a partire da
                     %f_opt %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                            f_precedente=zeros(1,M);
                            f_successiva=zeros(1,M);
                            x=zeros(1,M);

                            for conta=1:M

                                delta_f_discrete=f_discrete(conta,:)-f_opt(conta);
                                [ff,ind_ff]=min(abs(delta_f_discrete));
                                if ff==0
                                    f_precedente(conta)=f_discrete(conta,ind_ff);
                                    f_successiva(conta)=f_discrete(conta,ind_ff);
                                    x(conta)=1; %qualsiasi valore � indifferente
                                elseif ind_ff==1
                                    f_precedente(conta)=f_discrete(conta,1);
                                    f_successiva(conta)=f_discrete(conta,2);
                                    x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
                                elseif ind_ff==Q
                                    f_precedente(conta)=f_discrete(conta,Q-1);
                                    f_successiva(conta)=f_discrete(conta,Q);
                                    x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
                                elseif delta_f_discrete(ind_ff)>0
                                    f_precedente(conta)=f_discrete(conta,ind_ff-1);
                                    f_successiva(conta)=f_discrete(conta,ind_ff);
                                    x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
                                else 
                                    f_precedente(conta)=f_discrete(conta,ind_ff);
                                    f_successiva(conta)=f_discrete(conta,ind_ff+1);
                                    x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
                                end

                            end
                            
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %%%%%%%%%%  costo  %%%%%%%%%%%%%%%%%%
%                     if (~conv)
%                         error('Errore: Carico non correttamente allocato')
%                     end

                    costo_speed=sum(((f_opt./f_max).^2).*omega.*E_max);
                    costo_switch=sum(k_e.*(f_opt-f_zero).^2);
                    %costo_channel=sum(2.*P_net.*L_opt./C_max);
                    costo_channel=(T_tot-Delta).*sum(chi.*((2.^(R_opt./W))-1));
                    %costo_tot=costo_speed+costo_switch+costo_channel+E_W(i);
                    costo_tot=costo_speed+costo_switch+costo_channel;
                    
                    
                    
                    %%%%%%%%%%%%%%%%%%   COSTI FREQUENZE DISCRETE  %%%%%%%%%


                        % Costo frequenza_successiva
                        costo_speed_f_succ=sum(((f_successiva./f_max).^2).*omega.*E_max);
                        costo_switch_f_succ=sum(k_e.*(f_successiva-f_zero).^2);
                        costo_channel_f_succ=(T_tot-Delta).*sum(chi.*((2.^(R_opt./W))-1));
                        %costo_tot_f_prec=costo_speed_f_succ+costo_switch_f_succ+costo_channel_f_succ+E_W(i);
                        costo_tot_f_succ=costo_speed_f_succ+costo_switch_f_succ+costo_channel_f_succ;

                        % Costo frequenza_precedente
                        costo_speed_f_prec=sum(((f_precedente./f_max).^2).*omega.*E_max);
                        costo_switch_f_prec=sum(k_e.*(f_precedente-f_zero).^2);
                        costo_channel_f_prec=(T_tot-Delta).*sum(chi.*((2.^(R_opt./W))-1));
                        %costo_tot_f_prec=costo_speed_f_prec+costo_switch_f_prec+costo_channel_f_prec+E_W(i);
                        costo_tot_f_prec=costo_speed_f_prec+costo_switch_f_prec+costo_channel_f_prec;

                        % Costo Time-sharing
                        costo_speed_TS=sum((((f_precedente./f_max).^2).*omega.*E_max).*(1-x)+(((f_successiva./f_max).^2).*omega.*E_max).*x);
                        costo_switch_TS=sum((k_e.*(f_precedente-f_zero).^2).*(1-x)+(k_e.*(f_successiva-f_zero).^2).*x);
                        costo_channel_TS=(T_tot-Delta).*sum(chi.*((2.^(R_opt./W))-1));
                        %costo_tot_TS=costo_speed_TS+costo_switch_TS+costo_channel_TS+E_W(i);
                        costo_tot_TS=costo_speed_TS+costo_switch_TS+costo_channel_TS;


                        %Costo Time-sharing-switch for heterogenous case
                        %costo_TS_switch=sum(k_e.*(f_successiva-f_precedente).^2);
                        %costo_tot_TSpiuSwitch1=costo_tot_TS+costo_TS_switch;
                        costo_tot_TSpiuSwitch1=costo_tot_TS;



                        %%%%%%%%%%%%%%%%%%   FINE  COSTI FREQUENZE DISCRETE  %%%%%%%%%


                    
                    costo_tot_VM(k)=costo_tot_VM(k)+costo_tot;
                    costo_tot_VM_f_succ(k)=costo_tot_VM_f_succ(k)+costo_tot_f_prec;
                    costo_tot_VM_f_prec(k)=costo_tot_VM_f_prec(k)+costo_tot_f_prec;
                    costo_tot_VM_TS(k)=costo_tot_VM_TS(k)+costo_tot_TS;
                    %costo_VM_TS_switch(k)=costo_VM_TS_switch(k)+costo_TS_switch;
                    costo_tot_VM_TSpiuSwitch(k)=costo_tot_VM_TSpiuSwitch(k)+costo_tot_TSpiuSwitch1;
                    %E_TOT(nclient,i)=costo_tot_TSpiuSwitch1;
                    E_TOT(i)=costo_tot_TSpiuSwitch1;
                    
                    f_zero=f_opt;
            
          end       %for each slot
         
%         E_W_vector(k,test1,test2,test3,test31)=mean(E_W(nclient,:));
%         E_TOT_vector(k,test1,test2,test3,test31)=mean(E_TOT(nclient,:));
%         E_TOT=zeros(nclient,n);
%         Muinf_vector(k,test1,test2,test3,test31)=Mu(nclient,n+1);
%         s_vector(k,test1,test2,test3,test31)=mean(s(nclient,:));
%         q_vector(k,test1,test2,test3,test31)=mean(q(nclient,:));
%         r_vector(k,test1,test2,test3,test31)=mean(r(nclient,:));
%         L_tot_vector(k,test1,test2,test3,test31)=mean(L_tot(nclient,:));
%         lambda_vector(k,test1,test2,test3,test31)=mean(lambda(nclient,:));
%         Utility_vector(k,test1,test2,test3,test31)=((test31.*E_TOT_vector(k,test1,test2,test3,test31))-(beta.*(1-test31).*r_vector(k,test1,test2,test3,test31)));
%        end  % test31 various teta 
% end % test3 various s
% 
%     end % test2 various q0

         E_W_vector(k,test1)=mean(E_W(nclient,:));
        E_TOT_vector(k,test1)=mean(E_TOT(:));
        E_TOT=zeros(1,n);
        %Muinf_vector(k,test1, test11)=Mu(nclient,n+1);
        s_vector(k,test1)=mean(s(nclient,:));
        q_vector(k,test1)=mean(q(nclient,:));
        r_vector(k,test1)=mean(r(nclient,:));
        L_tot_vector(k,test1)=mean(L_tot(nclient,:));
        lambda_vector(k,test1)=mean(lambda(nclient,:));
        Utility_vector(k,test1)=((teta.*E_TOT_vector(k,test1))-(beta.*(1-teta).*r_vector(k,test1)));



 end % test1 various E_ave                   
            


            % E_TOT_vector(k)=mean(E_TOT(:));
             costo_tot_VM(k)=costo_tot_VM(k)./length(Jobs);
             costo_tot_VM_f_succ(k)=costo_tot_VM_f_succ(k)./length(Jobs);
             costo_tot_VM_f_prec(k)=costo_tot_VM_f_prec(k)./length(Jobs);
             costo_tot_VM_TS(k)=costo_tot_VM_TS(k)./length(Jobs);
             %costo_VM_TS_switch(k)=costo_VM_TS_switch(k)./length(Jobs);
             costo_tot_VM_TSpiuSwitch(k)=costo_tot_VM_TSpiuSwitch(k)./length(Jobs);
            
             
        iter_VM(k)=iter_VM(k)./length(Jobs);
       
        L_VM_prima(k)=L_VM_prima(k)./length(Jobs);
        L_VM_ultima(k)=L_VM_ultima(k)./length(Jobs);
        f_VM_prima(k)=f_VM_prima(k)./length(Jobs);
        f_VM_ultima(k)=f_VM_ultima(k)./length(Jobs);
        
      clear f_max f_zero Th E_max omega Delta L_b temp alpha_zero alpha_mu chi W ni_opt f_opt L_opt mu_opt alpha_step V_step f_precedente f_successiva delta_f_discrete x;

        toc
        
 end       
 %       
 %% Results
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%testing
% r for 5 selected VMS types, for E_ave=0.75
% x11=[r_vector(1,1,1,1,1),r_vector(1,1,1,1,2),r_vector(1,1,1,1,3),r_vector(1,1,1,1,4),r_vector(1,1,1,1,5)];% VM=2
% x12=[r_vector(4,1,1,1,1),r_vector(4,1,1,1,2),r_vector(4,1,1,1,3),r_vector(4,1,1,1,4),r_vector(4,1,1,1,5)];% VM=5
% x13=[r_vector(9,1,1,1,1),r_vector(9,1,1,1,2),r_vector(9,1,1,1,3),r_vector(9,1,1,1,4),r_vector(9,1,1,1,5)];%VM=10
% x14=[r_vector(14,1,1,1,1),r_vector(14,1,1,1,2),r_vector(14,1,1,1,3),r_vector(14,1,1,1,4),r_vector(14,1,1,1,5)];%VM=15
% x15=[r_vector(19,1,1,1,1),r_vector(19,1,1,1,2),r_vector(19,1,1,1,3),r_vector(19,1,1,1,4),r_vector(19,1,1,1,5)];%VM=20
% r for 5 selected VMS types, for E_ave=0.5
% x21=[r_vector(1,2,1,1,1),r_vector(1,2,1,1,2),r_vector(1,2,1,1,3),r_vector(1,2,1,1,4),r_vector(1,2,1,1,5)];% VM=2
% x22=[r_vector(4,2,1,1,1),r_vector(4,2,1,1,2),r_vector(4,2,1,1,3),r_vector(4,2,1,1,4),r_vector(4,2,1,1,5)];% VM=5
% x23=[r_vector(9,2,1,1,1),r_vector(9,2,1,1,2),r_vector(9,2,1,1,3),r_vector(9,2,1,1,4),r_vector(9,2,1,1,5)];%VM=10
% x24=[r_vector(14,2,1,1,1),r_vector(14,2,1,1,2),r_vector(14,2,1,1,3),r_vector(14,2,1,1,4),r_vector(14,2,1,1,5)];%VM=15
% x25=[r_vector(19,2,1,1,1),r_vector(19,2,1,1,2),r_vector(19,2,1,1,3),r_vector(19,2,1,1,4),r_vector(19,2,1,1,5)];%VM=20
% 
% 
% r for 5 selected VMS types, for E_ave=0.25
% x31=[r_vector(1,3,1,1,1),r_vector(1,3,1,1,2),r_vector(1,3,1,1,3),r_vector(1,3,1,1,4),r_vector(1,3,1,1,5)];% VM=2
% x32=[r_vector(4,3,1,1,1),r_vector(4,3,1,1,2),r_vector(4,3,1,1,3),r_vector(4,3,1,1,4),r_vector(4,3,1,1,5)];% VM=5
% x33=[r_vector(9,3,1,1,1),r_vector(9,3,1,1,2),r_vector(9,3,1,1,3),r_vector(9,3,1,1,4),r_vector(9,3,1,1,5)];%VM=10
% x34=[r_vector(14,3,1,1,1),r_vector(14,3,1,1,2),r_vector(14,3,1,1,3),r_vector(14,3,1,1,4),r_vector(14,3,1,1,5)];%VM=15
% x35=[r_vector(19,3,1,1,1),r_vector(19,3,1,1,2),r_vector(19,3,1,1,3),r_vector(19,3,1,1,4),r_vector(19,3,1,1,5)];%VM=20
% 
% r for 5 selected VMS types, for E_ave=0.125
% x41=[r_vector(1,4,1,1,1),r_vector(1,4,1,1,2),r_vector(1,4,1,1,3),r_vector(1,4,1,1,4),r_vector(1,4,1,1,5)];% VM=2
% x42=[r_vector(4,4,1,1,1),r_vector(4,4,1,1,2),r_vector(4,4,1,1,3),r_vector(4,4,1,1,4),r_vector(4,4,1,1,5)];% VM=5
% x43=[r_vector(9,4,1,1,1),r_vector(9,4,1,1,2),r_vector(9,4,1,1,3),r_vector(9,4,1,1,4),r_vector(9,4,1,1,5)];%VM=10
% x44=[r_vector(14,4,1,1,1),r_vector(14,4,1,1,2),r_vector(14,4,1,1,3),r_vector(14,4,1,1,4),r_vector(14,4,1,1,5)];%VM=15
% x45=[r_vector(19,4,1,1,1),r_vector(19,4,1,1,2),r_vector(19,4,1,1,3),r_vector(19,4,1,1,4),r_vector(19,4,1,1,5)];%VM=20
% 
% 
% E_tot for 5 selected VMS types, for E_ave=20
% y11=[E_TOT_vector(1,1,1,1,1),E_TOT_vector(1,1,1,1,2),E_TOT_vector(1,1,1,1,3),E_TOT_vector(1,1,1,1,4),E_TOT_vector(1,1,1,1,5)];% VM=2
% y12=[E_TOT_vector(4,1,1,1,1),E_TOT_vector(4,1,1,1,2),E_TOT_vector(4,1,1,1,3),E_TOT_vector(4,1,1,1,4),E_TOT_vector(4,1,1,1,5)];% VM=5
% y13=[E_TOT_vector(2,1,1,1,1),E_TOT_vector(2,1,1,1,2),E_TOT_vector(2,1,1,1,3),E_TOT_vector(2,1,1,1,4),E_TOT_vector(2,1,1,1,5)];%VM=10
% y14=[E_TOT_vector(14,1,1,1,1),E_TOT_vector(14,1,1,1,2),E_TOT_vector(14,1,1,1,3),E_TOT_vector(14,1,1,1,4),E_TOT_vector(14,1,1,1,5)];%VM=15
% y15=[E_TOT_vector(12,1,1,1,1),E_TOT_vector(12,1,1,1,2),E_TOT_vector(12,1,1,1,3),E_TOT_vector(12,1,1,1,4),E_TOT_vector(12,1,1,1,5)];%VM=20
% E_tot for 5 selected VMS types, for E_ave=10
% y21=[E_TOT_vector(1,2,1,1,1),E_TOT_vector(1,2,1,1,2),E_TOT_vector(1,2,1,1,3),E_TOT_vector(1,2,1,1,4),E_TOT_vector(1,2,1,1,5)];% VM=2
% y22=[E_TOT_vector(4,2,1,1,1),E_TOT_vector(4,2,1,1,2),E_TOT_vector(4,2,1,1,3),E_TOT_vector(4,2,1,1,4),E_TOT_vector(4,2,1,1,5)];% VM=5
% y23=[E_TOT_vector(9,2,1,1,1),E_TOT_vector(9,2,1,1,2),E_TOT_vector(9,2,1,1,3),E_TOT_vector(9,2,1,1,4),E_TOT_vector(9,2,1,1,5)];%VM=10
% y24=[E_TOT_vector(14,2,1,1,1),E_TOT_vector(14,2,1,1,2),E_TOT_vector(14,2,1,1,3),E_TOT_vector(14,2,1,1,4),E_TOT_vector(14,2,1,1,5)];%VM=15
% y25=[E_TOT_vector(19,2,1,1,1),E_TOT_vector(19,2,1,1,2),E_TOT_vector(19,2,1,1,3),E_TOT_vector(19,2,1,1,4),E_TOT_vector(19,2,1,1,5)];%VM=20
% 
% 
% E_tot for 5 selected VMS types, for E_ave=1
% y31=[E_TOT_vector(1,3,1,1,1),E_TOT_vector(1,3,1,1,2),E_TOT_vector(1,3,1,1,3),E_TOT_vector(1,3,1,1,4),E_TOT_vector(1,3,1,1,5)];% VM=2
% y32=[E_TOT_vector(4,3,1,1,1),E_TOT_vector(4,3,1,1,2),E_TOT_vector(4,3,1,1,3),E_TOT_vector(4,3,1,1,4),E_TOT_vector(4,3,1,1,5)];% VM=5
% y33=[E_TOT_vector(9,3,1,1,1),E_TOT_vector(9,3,1,1,2),E_TOT_vector(9,3,1,1,3),E_TOT_vector(9,3,1,1,4),E_TOT_vector(9,3,1,1,5)];%VM=10
% y34=[E_TOT_vector(14,3,1,1,1),E_TOT_vector(14,3,1,1,2),E_TOT_vector(14,3,1,1,3),E_TOT_vector(14,3,1,1,4),E_TOT_vector(14,3,1,1,5)];%VM=15
% y35=[E_TOT_vector(19,3,1,1,1),E_TOT_vector(19,3,1,1,2),E_TOT_vector(19,3,1,1,3),E_TOT_vector(19,3,1,1,4),E_TOT_vector(19,3,1,1,5)];%VM=20
% 
% E_tot for 5 selected VMS types, for E_ave=0.75
% y41=[E_TOT_vector(1,4,1,1,1),E_TOT_vector(1,4,1,1,2),E_TOT_vector(1,4,1,1,3),E_TOT_vector(1,4,1,1,4),E_TOT_vector(1,4,1,1,5)];% VM=2
% y42=[E_TOT_vector(4,4,1,1,1),E_TOT_vector(4,4,1,1,2),E_TOT_vector(4,4,1,1,3),E_TOT_vector(4,4,1,1,4),E_TOT_vector(4,4,1,1,5)];% VM=5
% y43=[E_TOT_vector(9,4,1,1,1),E_TOT_vector(9,4,1,1,2),E_TOT_vector(9,4,1,1,3),E_TOT_vector(9,4,1,1,4),E_TOT_vector(9,4,1,1,5)];%VM=10
% y44=[E_TOT_vector(14,4,1,1,1),E_TOT_vector(14,4,1,1,2),E_TOT_vector(14,4,1,1,3),E_TOT_vector(14,4,1,1,4),E_TOT_vector(14,4,1,1,5)];%VM=15
% y45=[E_TOT_vector(19,4,1,1,1),E_TOT_vector(19,4,1,1,2),E_TOT_vector(19,4,1,1,3),E_TOT_vector(19,4,1,1,4),E_TOT_vector(19,4,1,1,5)];%VM=20
% 
% 
% figure(12000)
% subplot(2,2,1);
% plot(x11,y11,'--+',x12,y12,'--*',x13,y13,'--o',x14,y14,'--+',x15,y15,'--*');
% xlabel('$\overline{r}$ $(byte/slot)$','Interpreter','latex','FontSize',14);
% ylabel('$\overline{E}_{TOT}$ (Joule)','Interpreter','latex','FontSize',14);
% legend('M=2','M=5','M=10','M=15','M=20');
% title('$q_0=N_O=240$, $s_{0}=0.01$, $E_{ave}=0.75$, $\theta=\{0.01, 0.1, 0.25,0.5, 0.75, 0.9, 0.99\}$','Interpreter','latex','FontSize',12);
% grid on
% 
% subplot(2,2,2);
% plot(x21,y21,'--+',x22,y22,'--*',x23,y23,'--o',x24,y24,'--+',x25,y25,'--*');
% xlabel('$\overline{r}$ $(byte/slot)$','Interpreter','latex','FontSize',14);
% ylabel('$\overline{E}_{TOT}$ (Joule)','Interpreter','latex','FontSize',14);
% legend('M=2','M=5','M=10','M=15','M=20');
% title('$q_0=N_O=240$, $s_{0}=0.01$, $E_{ave}=0.5$, $\theta=\{0.01, 0.1, 0.25,0.5, 0.75, 0.9, 0.99\}$','Interpreter','latex','FontSize',12);
% grid on
% 
% subplot(2,2,3);
% plot(x31,y31,'--+',x32,y32,'--*',x33,y33,'--o',x34,y34,'--+',x35,y35,'--*');
% xlabel('$\overline{r}$ $(byte/slot)$','Interpreter','latex','FontSize',14);
% ylabel('$\overline{E}_{TOT}$ (Joule)','Interpreter','latex','FontSize',14);
% legend('M=2','M=5','M=10','M=15','M=20');
% title('$q_0=N_O=240$, $s_{0}=0.01$, $E_{ave}=0.25$, $\theta=\{0.01, 0.1, 0.25,0.5, 0.75, 0.9, 0.99\}$','Interpreter','latex','FontSize',12);
% grid on
% 
% subplot(2,2,4);
% plot(x41,y41,'--+',x42,y42,'--*',x43,y43,'--o',x44,y44,'--+',x45,y45,'--*');
% xlabel('$\overline{r}$ $(byte/slot)$','Interpreter','latex','FontSize',14);
% ylabel('$\overline{E}_{TOT}$ (Joule)','Interpreter','latex','FontSize',14);
% legend('M=2','M=5','M=10','M=15','M=20');
% title('$q_0=N_O=240$, $s_{0}=0.01$, $E_{ave}=0.125$, $\theta=\{0.01, 0.1, 0.25,0.5, 0.75, 0.9, 0.99\}$','Interpreter','latex','FontSize',12);
% grid on
% 
% figure(1)
% plot(VM,E_TOT_vector(:),'r');
% xlabel('$VMs$','Interpreter','latex','FontSize',14);
% ylabel('$\overline{E_{TOT}}$ (Joule)','Interpreter','latex','FontSize',14);
% grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(7000)
subplot(2,2,1);
plot(r_min_vector,E_TOT_vector(:),'r');
xlabel('$r_{min}$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_{TOT}}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.125, \theta=0.5');
title('$q_0=N_O=240$, $s_{0}=240$, $\sigma_{min}=4.8$, $r^{anal}_{min}=1.71$, $r_{min}=\sigma_{min}\sqrt{E_{ave}}$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(r_min_vector,E_W_vector(:),'r');
xlabel('$r_{min}$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_{W}}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.125, \theta=0.5');
title('$q_0=N_O=240$, $s_{0}=240$, $\sigma_{min}=4.8$, $r^{anal}_{min}=1.71$, $r_{min}=\sigma_{min}\sqrt{E_{ave}}$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(r_min_vector,r_vector(:),'r');
xlabel('$r_{min}$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.125, \theta=0.5');
title('$q_0=N_O=240$, $s_{0}=240$, $\sigma_{min}=4.8$, $r^{anal}_{min}=1.71$, $r_{min}=\sigma_{min}\sqrt{E_{ave}}$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(r_min_vector,Utility_vector(:),'r');
xlabel('$r_{min}$','Interpreter','latex','FontSize',14);
ylabel('$Utility$','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.125, \theta=0.5');
title('$q_0=N_O=240$, $s_{0}=240$, $\sigma_{min}=4.8$, $r^{anal}_{min}=1.71$, $r_{min}=\sigma_{min}\sqrt{E_{ave}}$','Interpreter','latex','FontSize',14);
grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(10055)
subplot(2,2,1);
plot(VM,E_TOT_vector(:,1,length(q0_vector1),1,1),'r',VM,E_TOT_vector(:,1,length(q0_vector1),1,3),'g',VM,E_TOT_vector(:,1,length(q0_vector1),1,7),'b',...
     VM,E_TOT_vector(:,2,length(q0_vector1),1,1),'--+',VM,E_TOT_vector(:,2,length(q0_vector1),1,3),'--*',VM,E_TOT_vector(:,2,length(q0_vector1),1,7),'--o');
xlabel('$VMs$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_{TOT}}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20, \theta=0.01','E_{ave}=20, \theta=0.25','E_{ave}=20, \theta=0.99',...
       'E_{ave}=10, \theta=0.01','E_{ave}=10, \theta=0.25','E_{ave}=10, \theta=0.99');
title('$q_0=N_O=240$, $s_{0}=0.01$, $Hemogenous VMs$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(VM,E_W_vector(:,1,length(q0_vector1),1,1),'r',VM,E_W_vector(:,1,length(q0_vector1),1,3),'g',VM,E_W_vector(:,1,length(q0_vector1),1,7),'b',...
     VM,E_W_vector(:,2,length(q0_vector1),1,1),'--+',VM,E_W_vector(:,2,length(q0_vector1),1,3),'--*',VM,E_W_vector(:,2,length(q0_vector1),1,7),'--o');
xlabel('$VMs$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_{W}}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20, \theta=0.01','E_{ave}=20, \theta=0.25','E_{ave}=20, \theta=0.99',...
       'E_{ave}=10, \theta=0.01','E_{ave}=10, \theta=0.25','E_{ave}=10, \theta=0.99');
title('$q_0=N_O=240$, $s_{0}=0.01$, $Hemogenous VMs$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(VM,r_vector(:,1,length(q0_vector1),1,1),'r',VM,r_vector(:,1,length(q0_vector1),1,3),'g',VM,r_vector(:,1,length(q0_vector1),1,7),'b',...
     VM,r_vector(:,2,length(q0_vector1),1,1),'--+',VM,r_vector(:,2,length(q0_vector1),1,3),'--*',VM,r_vector(:,2,length(q0_vector1),1,7),'--o');
xlabel('$VMs$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20, \theta=0.01','E_{ave}=20, \theta=0.25','E_{ave}=20, \theta=0.99',...
       'E_{ave}=10, \theta=0.01','E_{ave}=10, \theta=0.25','E_{ave}=10, \theta=0.99');
title('$q_0=N_O=240$, $s_{0}=0.01$, $Hemogenous VMs$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(VM,E_TOT_vector(:,1,length(q0_vector1),1,1),'r',VM,E_TOT_vector(:,1,length(q0_vector1),1,3),'g',VM,E_TOT_vector(:,1,length(q0_vector1),1,7),'b',...
     VM,E_TOT_vector(:,2,length(q0_vector1),1,1),'--+',VM,E_TOT_vector(:,2,length(q0_vector1),1,3),'--*',VM,E_TOT_vector(:,2,length(q0_vector1),1,7),'--o');
xlabel('$VMs$','Interpreter','latex','FontSize',14);
ylabel('$UTILITY$','Interpreter','latex','FontSize',14);
legend('E_{ave}=20, \theta=0.01','E_{ave}=20, \theta=0.25','E_{ave}=20, \theta=0.99',...
       'E_{ave}=10, \theta=0.01','E_{ave}=10, \theta=0.25','E_{ave}=10, \theta=0.99');
title('$q_0=N_O=240$, $s_{0}=0.01$, $Hemogenous VMs$','Interpreter','latex','FontSize',14);
grid on

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%results
figure(100)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(1,:,1,1),'--o',q0_vector1,E_W_vector(2,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20','E_{ave}=10');
title('$\overline{E_W}$ (Joule), $\theta=0.5$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(1,:,1,1),'--o',q0_vector1,r_vector(2,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20','E_{ave}=10');
title('$\overline{r}$ (byte/slot), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(1,:,1,1),'--o',q0_vector1,q_vector(2,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20','E_{ave}=10');
title('$\overline{q}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(1,:,1,1),'--o',q0_vector1,s_vector(2,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20','E_{ave}=10');
title('$\overline{s}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

%      %%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(101)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(3,:,1,1),'--o',q0_vector1,E_W_vector(4,:,1,1),'--+',q0_vector1,E_W_vector(5,:,1,1),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=1','E_{ave}=0.75', 'E_{ave}=0.5');
title('$\overline{E_W}$ (Joule) , $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(3,:,1,1),'--o',q0_vector1,r_vector(4,:,1,1),'--+',q0_vector1,E_W_vector(5,:,1,1),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=1','E_{ave}=0.75', 'E_{ave}=0.5');
title('$\overline{r}$ (byte/slot), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(3,:,1,1),'--o',q0_vector1,q_vector(4,:,1,1),'--+',q0_vector1,E_W_vector(5,:,1,1),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=1','E_{ave}=0.75', 'E_{ave}=0.5');
title('$\overline{q}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(3,:,1,1),'--o',q0_vector1,s_vector(4,:,1,1),'--+',q0_vector1,E_W_vector(5,:,1,1),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=1','E_{ave}=0.75', 'E_{ave}=0.5');
title('$\overline{s}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(102)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(6,:,1,1),'--o',q0_vector1,E_W_vector(7,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.25','E_{ave}=0.125');
title('$\overline{E_W}$ (Joule), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(6,:,1,1),'--o',q0_vector1,r_vector(7,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.25','E_{ave}=0.125');
title('$\overline{r}$ (byte/slot), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(6,:,1,1),'--o',q0_vector1,q_vector(7,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.25','E_{ave}=0.125');
title('$\overline{q}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(6,:,1,1),'--o',q0_vector1,s_vector(7,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.25','E_{ave}=0.125');
title('$\overline{s}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(103)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(8,:,1,1),'--o',q0_vector1,E_W_vector(9,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.0650','E_{ave}=0.0325');
title('$\overline{E_W}$ (Joule), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(8,:,1,1),'--o',q0_vector1,r_vector(9,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.0650','E_{ave}=0.0325');
title('$\overline{r}$ (byte/slot), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(8,:,1,1),'--o',q0_vector1,q_vector(9,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.0650','E_{ave}=0.0325');
title('$\overline{q}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(8,:,1,1),'--o',q0_vector1,s_vector(9,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.0650','E_{ave}=0.0325');
title('$\overline{s}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(104)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(10,:,1,1),'--o',q0_vector1,E_W_vector(11,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\overline{E_W}$ (Joule), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(10,:,1,1),'--o',q0_vector1,r_vector(11,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\overline{r}$ (byte/slot), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(10,:,1,1),'--o',q0_vector1,q_vector(11,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\overline{q}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(10,:,1,1),'--o',q0_vector1,s_vector(11,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\overline{s}$ (byte), $\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Muinf
figure(1000)
subplot(2,2,1);
plot(q0_vector1,Muinf_vector(1,:,1,1),'--o',q0_vector1,Muinf_vector(2,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('Mu_{inf}');
legend('E_{ave}=20','E_{ave}=10');
title('$\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,Muinf_vector(3,:,1,1),'--o',q0_vector1,Muinf_vector(4,:,1,1),'--+', q0_vector1,Muinf_vector(5,:,1,1),'--o', q0_vector1,Muinf_vector(6,:,1,1),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('Mu_{inf}');
legend('E_{ave}=1', 'E_{ave}=0.75','E_{ave}=0.5', 'E_{ave}=0.25');
title('$\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,Muinf_vector(7,:,1,1),'--o',q0_vector1,Muinf_vector(8,:,1,1),'--+', q0_vector1,Muinf_vector(9,:,1,1),'--o');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('Mu_{inf}');
legend('E_{ave}=0.125','E_{ave}=0.0650', 'E_{ave}=0.0325');
title('$\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,Muinf_vector(10,:,1,1),'--o',q0_vector1,Muinf_vector(11,:,1,1),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('Mu_{inf}');
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\theta=0.01$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(105)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(1,:,1,2),'--o',q0_vector1,E_W_vector(2,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20','E_{ave}=10');
title('$\overline{E_W}$ (Joule), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(1,:,1,2),'--o',q0_vector1,r_vector(2,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20','E_{ave}=10');
title('$\overline{r}$ (byte/slot), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(1,:,1,2),'--o',q0_vector1,q_vector(2,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20','E_{ave}=10');
title('$\overline{q}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(1,:,1,2),'--o',q0_vector1,s_vector(2,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=20','E_{ave}=10');
title('$\overline{s}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

%      %%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(106)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(3,:,1,2),'--o',q0_vector1,E_W_vector(4,:,1,2),'--+',q0_vector1,E_W_vector(5,:,1,2),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=1', 'E_{ave}=0.75','E_{ave}=0.5');
title('$\overline{E_W}$ (Joule), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(3,:,1,2),'--o',q0_vector1,r_vector(4,:,1,2),'--+',q0_vector1,E_W_vector(5,:,1,2),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=1', 'E_{ave}=0.75','E_{ave}=0.5');
title('$\overline{r}$ (byte/slot), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(3,:,1,2),'--o',q0_vector1,q_vector(4,:,1,2),'--+',q0_vector1,E_W_vector(5,:,1,2),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=1', 'E_{ave}=0.75','E_{ave}=0.5');
title('$\overline{q}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(3,:,1,2),'--o',q0_vector1,s_vector(4,:,1,2),'--+',q0_vector1,E_W_vector(5,:,1,2),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=1', 'E_{ave}=0.75','E_{ave}=0.5');
title('$\overline{s}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(107)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(6,:,1,2),'--o',q0_vector1,E_W_vector(7,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.25','E_{ave}=0.125');
title('$\overline{E_W}$ (Joule), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(6,:,1,2),'--o',q0_vector1,r_vector(7,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.25','E_{ave}=0.125');
title('$\overline{r}$ (byte/slot), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(6,:,1,2),'--o',q0_vector1,q_vector(7,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.25','E_{ave}=0.125');
title('$\overline{q}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(6,:,1,2),'--o',q0_vector1,s_vector(7,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.25','E_{ave}=0.125');
title('$\overline{s}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(108)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(8,:,1,2),'--o',q0_vector1,E_W_vector(9,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.0650','E_{ave}=0.0325');
title('$\overline{E_W}$ (Joule), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(8,:,1,2),'--o',q0_vector1,r_vector(9,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.0650','E_{ave}=0.0325');
title('$\overline{r}$ (byte/slot), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(8,:,1,2),'--o',q0_vector1,q_vector(9,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.0650','E_{ave}=0.0325');
title('$\overline{q}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(8,:,1,2),'--o',q0_vector1,s_vector(9,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.0650','E_{ave}=0.0325');
title('$\overline{s}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(109)
subplot(2,2,1);
plot(q0_vector1,E_W_vector(10,:,1,2),'--o',q0_vector1,E_W_vector(11,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{E_W}$ (Joule)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\overline{E_W}$ (Joule), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,r_vector(10,:,1,2),'--o',q0_vector1,r_vector(11,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{r}$ (byte/slot)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\overline{r}$ (byte/slot), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,q_vector(10,:,1,2),'--o',q0_vector1,q_vector(11,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{q}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\overline{q}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,s_vector(10,:,1,2),'--o',q0_vector1,s_vector(11,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('$\overline{s}$ (byte)','Interpreter','latex','FontSize',14);
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\overline{s}$ (byte), $\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Muinf
figure(1001)
subplot(2,2,1);
plot(q0_vector1,Muinf_vector(1,:,1,2),'--o',q0_vector1,Muinf_vector(2,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('Mu_{inf}');
legend('E_{ave}=20','E_{ave}=10');
title('$\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,2);
plot(q0_vector1,Muinf_vector(3,:,1,2),'--o',q0_vector1,Muinf_vector(4,:,1,2),'--+', q0_vector1,Muinf_vector(5,:,1,2),'--o', q0_vector1,Muinf_vector(6,:,1,2),'--*');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('Mu_{inf}');
legend('E_{ave}=1','E_{ave}=0.75','E_{ave}=0.5', 'E_{ave}=0.25');
title('$\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,3);
plot(q0_vector1,Muinf_vector(7,:,1,2),'--o',q0_vector1,Muinf_vector(8,:,1,2),'--+', q0_vector1,Muinf_vector(9,:,1,2),'--o');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('Mu_{inf}');
legend('E_{ave}=0.125','E_{ave}=0.0650', 'E_{ave}=0.0325');
title('$\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

subplot(2,2,4);
plot(q0_vector1,Muinf_vector(10,:,1,2),'--o',q0_vector1,Muinf_vector(11,:,1,2),'--+');
xlabel('$q_0$','Interpreter','latex','FontSize',14);
ylabel('Mu_{inf}');
legend('E_{ave}=0.01','E_{ave}=0.005');
title('$\theta=0.99$, $s_0=240$','Interpreter','latex','FontSize',14);
grid on

