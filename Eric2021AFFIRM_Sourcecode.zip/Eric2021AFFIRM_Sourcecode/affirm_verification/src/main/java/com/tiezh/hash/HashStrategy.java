package com.tiezh.hash;

/** tag a hash strategy */
public interface HashStrategy extends java.io.Serializable{
}
