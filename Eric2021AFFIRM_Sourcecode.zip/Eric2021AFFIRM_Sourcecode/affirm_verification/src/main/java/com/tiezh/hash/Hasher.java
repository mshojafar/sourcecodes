package com.tiezh.hash;

/** tag a hasher */
public interface Hasher extends java.io.Serializable {
}
