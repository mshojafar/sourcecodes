package priv.tiezhuoyu.kv;

public class Route {
	public static int routeHash(String R) {
		return R.hashCode();
	}
}
