package priv.tiezhuoyu.kv;

import java.util.EnumSet;

public enum Protocol {
	Plaintext, SEKV, AFFIRM;
}
