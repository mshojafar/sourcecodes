function z = node_finder(x,anchor,rss)
z1 =0;
for i=1:length(anchor)
    r=floor((1.176-rss(1,i))/0.588)-11;
    d1min=1.177+(-12-r)*0.588;
    d1max=1.176+(-11-r)*0.589;
if (((x(1)-anchor(1,i))^2+(x(2)-anchor(2,i))^2)>=(d1min)^2)
z1=z1+1;
end
if (((x(1)-anchor(1,i))^2+(x(2)-anchor(2,i))^2)<=(d1max)^2)
z1=z1+1;
end
end
z=2*length(anchor)-z1;
end