clc;
clear;
close all;
n=4; %Number of reference nodes
m=30; %Number of transmitter nodes
%nodes=[0 0 0 0 0 0 0 0 0;-30 -24 -18 -12 -6 6 12 18 24];
%anchor=[0 0.6 -0.6; 0.6 0 0 ];
spacelenght=40;
anchor=zeros(2,n);
nodes=zeros(2,m);
%% Initialization of random reference nodes
for i=1:n
   anchor(1,i)=-1*spacelenght+2*spacelenght*rand(1); 
   anchor(2,i)=-1*spacelenght+2*spacelenght*rand(1);
end
%% Initialize random transmitter nodes
for i=1:m
   nodes(1,i)=-1*spacelenght+2*spacelenght*rand(1); 
   nodes(2,i)=-1*spacelenght+2*spacelenght*rand(1);
end
%Optimization parameters (most of the following parts are downloaded from www.yarpiz.com)
CostFunction = @(x,anchor,rss) node_finder(x,anchor,rss);
nVar = 2;          % Number of Unknown Variables
VarSize = [1 nVar]; % Unknown Variables Matrix Size

VarMin = -1*spacelenght;       % Unknown Variables Lower Bound
VarMax =  spacelenght;       % Unknown Variables Upper Bound

%% TLBO Parameters

MaxIt = 10000;        % Maximum Number of Iterations

nPop = 50;           % Population Size

%% Initialization 

% Empty Structure for Individuals
esti=zeros(2,m);
for ii=1:m
    rss=zeros(1,n);
    for jj=1:n
      rss(1,jj)=sqrt((nodes(1,ii)-anchor(1,jj))^2+(nodes(2,ii)-anchor(2,jj))^2); 
    end
empty_individual.Position = [];
empty_individual.Cost = [];

% Initialize Population Array
pop = repmat(empty_individual, nPop, 1);

% Initialize Best Solution
BestSol.Cost = inf;

% Initialize Population Members
for i=1:nPop
    pop(i).Position = unifrnd(VarMin, VarMax, VarSize);
    pop(i).Cost = CostFunction(pop(i).Position,anchor,rss);
    
    if pop(i).Cost < BestSol.Cost
        BestSol = pop(i);
    end
end

% Initialize Best Cost Record
BestCosts = zeros(MaxIt,1);

%% TLBO Main Loop

for it=1:MaxIt
    
    % Calculate Population Mean
    Mean = 0;
    for i=1:nPop
        Mean = Mean + pop(i).Position;
    end
    Mean = Mean/nPop;
    
    % Select Teacher
    Teacher = pop(1);
    for i=2:nPop
        if pop(i).Cost < Teacher.Cost
            Teacher = pop(i);
        end
    end
    
    % Teacher Phase
    for i=1:nPop
        % Create Empty Solution
        newsol = empty_individual;
        
        % Teaching Factor
        TF = randi([1 2]);
        
        % Teaching (moving towards teacher)
        newsol.Position = pop(i).Position ...
            + rand(VarSize).*(Teacher.Position - TF*Mean);
        
        % Clipping
        newsol.Position = max(newsol.Position, VarMin);
        newsol.Position = min(newsol.Position, VarMax);
        
        % Evaluation
        newsol.Cost = CostFunction(newsol.Position,anchor,rss);
        
        % Comparision
        if newsol.Cost<pop(i).Cost
            pop(i) = newsol;
            if pop(i).Cost < BestSol.Cost
                BestSol = pop(i);
            end
        end
    end
    
    % Learner Phase
    for i=1:nPop
        
        A = 1:nPop;
        A(i)=[];
        j = A(randi(nPop-1));
        
        Step = pop(i).Position - pop(j).Position;
        if pop(j).Cost < pop(i).Cost
            Step = -Step;
        end
        
        % Create Empty Solution
        newsol = empty_individual;
        
        % Teaching (moving towards teacher)
        newsol.Position = pop(i).Position + rand(VarSize).*Step;
        
        % Clipping
        newsol.Position = max(newsol.Position, VarMin);
        newsol.Position = min(newsol.Position, VarMax);
        
        % Evaluation
        newsol.Cost = CostFunction(newsol.Position,anchor,rss);
        
        % Comparision
        if newsol.Cost<pop(i).Cost
            pop(i) = newsol;
            if pop(i).Cost < BestSol.Cost
                BestSol = pop(i);
            end
        end
    end
    
    % Store Record for Current Iteration
    BestCosts(it) = BestSol.Cost;
    
    % Show Iteration Information
    
    if BestCosts(it)==0
        break
    end
end
esti(1,ii)=BestSol.Position(1);
esti(2,ii)=BestSol.Position(2);
disp(ii);
end
%% Results
anchor=anchor';
nodes=nodes';
esti=esti';
hold on;
scatter(anchor(:,1),anchor(:,2),'filled');
scatter(nodes(:,1),nodes(:,2));
scatter(esti(:,1),esti(:,2),'*');
