package org.fog.scheduler;

import java.util.ArrayList;
import java.util.List;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletScheduler;
import org.cloudbus.cloudsim.Consts;
import org.cloudbus.cloudsim.ResCloudlet;
import org.cloudbus.cloudsim.core.CloudSim;
import org.fog.entities.Tuple;
import org.fog.utils.Logger;
import org.fog.utils.TimeKeeper;



public class SJFScheduler2 extends CloudletScheduler {
	
	/** The Tuples execution list. */
	private List<ResCloudlet> cloudletExecList;
	
	//private List<ResCloudlet> cloudletCopyComingList;
	
	/** The Tuples which are finished list. */
	private List<ResCloudlet> cloudletFinishedList;

	/** The cloudlet queued list. i.e waiting for VM allocation */
	private List<ResCloudlet> cloudletWaitingList;
	
	//private List<ResCloudlet> cloudletFinishListCopy;
	
	/** The current cp us. */
	protected int currentCPUs;
	
	/**
	 * Creates a new CloudletScheduler object. This method must be invoked before starting the
	 * actual simulation.
	 * 
	 * @pre $none
	 * @post $none
	 */
	public SJFScheduler2(double mips, int numberOfPes) {
		super();
		cloudletExecList = new ArrayList<ResCloudlet>();
		cloudletFinishedList = new ArrayList<ResCloudlet>();
		//cloudletFinishListCopy  = new ArrayList<ResCloudlet>();
		cloudletWaitingList  = new ArrayList<ResCloudlet>();
		//cloudletCopyComingList = new ArrayList<ResCloudlet>();
		currentCPUs = 0;
	}
	

	@Override
	public double updateVmProcessing(double currentTime, List<Double> mipsShare) {
		
		setCurrentMipsShare(mipsShare);
		double timeSpam = currentTime - getPreviousTime();

		for (ResCloudlet rcl : getCloudletExecList()) {
						
			rcl.updateCloudletFinishedSoFar((long) (getCapacity(mipsShare) * timeSpam * rcl.getNumberOfPes() * Consts.MILLION));
			//System.out.println(getTotalCurrentAllocatedMipsForCloudlet(rcl, getPreviousTime()));
			//System.out.println(CloudSim.clock()+ " : Remaining length of tuple ID "+rcl.getCloudletId()+" = "+rcl.getRemainingCloudletLength());
			
		}

		if (getCloudletExecList().size() == 0) {
			setPreviousTime(currentTime);
			return 0.0;
		}

		// check finished cloudlets
		double nextEvent = Double.MAX_VALUE;
		List<ResCloudlet> toRemove = new ArrayList<ResCloudlet>();
		for (ResCloudlet rcl : getCloudletExecList()) {
			long remainingLength = rcl.getRemainingCloudletLength();
			if (remainingLength == 0) {// finished: remove from the list
				toRemove.add(rcl);
			}
		}
		
		getCloudletExecList().removeAll(toRemove);
		for(int k=0; k < toRemove.size(); k++) {
			cloudletFinish(toRemove.get(k));
		}
			

		// estimate finish time of cloudlets
		for (ResCloudlet rcl : getCloudletExecList()) {
			double estimatedFinishTime = currentTime
					+ (rcl.getRemainingCloudletLength() / (getCapacity(mipsShare) * rcl.getNumberOfPes()));
			if (estimatedFinishTime - currentTime < CloudSim.getMinTimeBetweenEvents()) {
				estimatedFinishTime = currentTime + CloudSim.getMinTimeBetweenEvents();
			}

			if (estimatedFinishTime < nextEvent) {
				nextEvent = estimatedFinishTime;
			}
		}

		setPreviousTime(currentTime);
		return nextEvent;
	}

	@Override
	public double cloudletSubmit(Cloudlet cloudlet, double fileTransferTime) {
		// TODO Auto-generated method stub
		Tuple t= (Tuple) cloudlet;
		double extraSize = getCapacity(getCurrentMipsShare()) * fileTransferTime;
		long length = (long) (cloudlet.getCloudletLength() + extraSize);
		cloudlet.setCloudletLength(length);
		//TimeKeeper.getInstance().getMyEmitTimes().put(t.getCloudletId(), CloudSim.clock());
				
		ResCloudlet rcl = new ResCloudlet(cloudlet);
		
		//add to copyList for just displaying order of incoming tuples
		//cloudletCopyComingList.add(rcl);
		
		
		Logger.debug("coming new Tuple: id:", rcl.getCloudletId() +" src:"+ t.getSrcModuleName() + " dest:"+
		t.getDestModuleName()+ " "  + rcl.getCloudlet().getCloudletLength());
		//System.out.println("==========List start: showing tuples incoming order.===========");
		/*for(int i=0;i<cloudletCopyComingList.size();i++) {
			Tuple t2= (Tuple) cloudletCopyComingList.get(i).getCloudlet();
			System.out.println("TipleId:" + t2.getCloudletId()+" source:"+t2.getSrcModuleName() +" dest:"+ t2.getDestModuleName()+" mipsReq: "+t2.getCloudletLength());
		}*/
		//System.out.println("==========List end: showing tuples incoming order end=============");
		
		//add coming event into wait queue
		cloudletWaitingList.add(rcl);
		// sort tuples according to MIPS length, so we can schedule shortest first
		cloudletWaitingList.sort(rcl);
		/*System.out.println("");
		System.out.println("");
		System.out.println("==========List start: showing tuples waiting for EXECUTION, after sorting tuples ===========");
		for(int h=0;h<cloudletWaitingList.size(); h++) {
			Tuple t2= (Tuple) cloudletWaitingList.get(h).getCloudlet();
			System.out.println("TipleId:" + t2.getCloudletId()+" source:"+t2.getSrcModuleName() +" dest:"+ t2.getDestModuleName()+" mipsReq: "+t2.getCloudletLength());
		}
		System.out.println("==========List end: showing tuples waiting for EXECUTION, after sorting tuples ===========");
		System.out.println("");
		System.out.println("");*/
		// if its first incoming tuple schedule it, because 1 tuple is shortest in itself
		if( getCloudletExecList().size() ==0) {
			cloudletWaitingList.remove(0);
			getCloudletExecList().add(rcl);
			rcl.setCloudletStatus(Cloudlet.INEXEC);
		//	TimeKeeper.getInstance().getMyexecTimes().put(t.getCloudletId(), CloudSim.clock());
			for (int i = 0; i < cloudlet.getNumberOfPes(); i++) {
				rcl.setMachineAndPeId(0, i);
			
			}
		}else {
			//if CloudletExecList is != 0 , its mean VM is already running a process.
			//wait to finish first tuple . OnFinish of tuple we will schedule next tuple
		}
		
		
						
		return cloudlet.getCloudletLength() / getCapacity(getCurrentMipsShare());
	}
	
	public void schudleNextTuple() {
		if(cloudletWaitingList.size() >=1 && getCloudletExecList().size() ==0) {
			ResCloudlet rcl = cloudletWaitingList.get(0);
			cloudletWaitingList.remove(0);
			Cloudlet cloudlet = rcl.getCloudlet();
			getCloudletExecList().add(rcl);
			rcl.setCloudletStatus(Cloudlet.INEXEC);
			Tuple t= (Tuple) cloudlet;
		//	TimeKeeper.getInstance().getMyexecTimes().put(t.getCloudletId(), CloudSim.clock());
			for (int i = 0; i < cloudlet.getNumberOfPes(); i++) {
				rcl.setMachineAndPeId(0, i);
			}
		}
	}

	@Override
	public double cloudletSubmit(Cloudlet cloudlet) {
		return cloudletSubmit(cloudlet, 0.0);
	}

	@Override
	public Cloudlet cloudletCancel(int clId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean cloudletPause(int clId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double cloudletResume(int clId) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void cloudletFinish(ResCloudlet rcl) {
		
		//onFinish , schulde next tuple to Run
		schudleNextTuple();
		
		
		Tuple t= (Tuple) rcl.getCloudlet();
		rcl.setCloudletStatus(Cloudlet.SUCCESS);
		rcl.finalizeCloudlet();
		getCloudletFinishedList().add(rcl);
		//cloudletFinishListCopy.add(rcl);
		
		/*System.out.println(">>==========List start: showing tuples finished ==========<<");
		for(int i=0; i<getCloudletFinishedList().size(); i ++) {
			System.out.println("Id:"+ getCloudletFinishedList().get(i).getCloudletId() + " Src:"+
					t.getSrcModuleName() + " Dest:"+ t.getDestModuleName()+ " Mips:"  + getCloudletFinishedList().get(i).getCloudletLength());
		}
		System.out.println(">>==========List end: showing tuples finished =========<<");
		System.out.println("");
		System.out.println("");*/
		
	}
	public void deleteCompletedTupleFromExecutionList(ResCloudlet rcl) {
		for(int i=0; i<getCloudletExecList().size(); i++) {
			if(getCloudletExecList().get(i).getCloudlet().getCloudletId() == rcl.getCloudlet().getCloudletId()) {
				cloudletWaitingList.remove(i);
				break;
			}
		}
		
	}
	@Override
	public int getCloudletStatus(int cloudletId) {
		// TODO Auto-generated method stub
		for (ResCloudlet rcl : getCloudletExecList()) {
			if (rcl.getCloudletId() == cloudletId) {
				return Cloudlet.INEXEC;
			}
		}
		for (ResCloudlet rcl : getCloudletFinishedList()) {
			if (rcl.getCloudletId() == cloudletId) {
				return Cloudlet.SUCCESS;
			}
		}
		return -1;
	}

	@Override
	public boolean isFinishedCloudlets() {
		// TODO Auto-generated method stub
		return getCloudletFinishedList().size() > 0;
	}

	@Override
	public Cloudlet getNextFinishedCloudlet() {
		// TODO Auto-generated method stub
		if (getCloudletFinishedList().size() > 0) {
			return getCloudletFinishedList().remove(0).getCloudlet();
		}
		return null;
	}

	@Override
	public int runningCloudlets() {
		// TODO Auto-generated method stub
		return getCloudletExecList().size();
	}

	@Override
	public Cloudlet migrateCloudlet() {
		// TODO Auto-generated method stub
		ResCloudlet rgl = getCloudletExecList().remove(0);
		rgl.finalizeCloudlet();
		return rgl.getCloudlet();
	}

	@Override
	public double getTotalUtilizationOfCpu(double time) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Double> getCurrentRequestedMips() {
		// TODO Auto-generated method stub
		List<Double> mipsShare = new ArrayList<Double>();
		return mipsShare;
	}

	@Override
	public double getTotalCurrentAvailableMipsForCloudlet(ResCloudlet rcl, List<Double> mipsShare) {
		// TODO Auto-generated method stub
		return getCapacity(getCurrentMipsShare());
	}

	@Override
	public double getTotalCurrentRequestedMipsForCloudlet(ResCloudlet rcl, double time) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getTotalCurrentAllocatedMipsForCloudlet(ResCloudlet rcl, double time) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getCurrentRequestedUtilizationOfRam() {
		// TODO Auto-generated method stub
		double ram = 0;
		for (ResCloudlet cloudlet : cloudletExecList) {
			ram += cloudlet.getCloudlet().getUtilizationOfRam(CloudSim.clock());
		}
		return ram;
	}

	@Override
	public double getCurrentRequestedUtilizationOfBw() {
		// TODO Auto-generated method stub
		double bw = 0;
		for (ResCloudlet cloudlet : cloudletExecList) {
			bw += cloudlet.getCloudlet().getUtilizationOfBw(CloudSim.clock());
		}
		return bw;
	}
	// returns the Tuples finished list
	protected List<ResCloudlet>  getCloudletFinishedList() {
		return   cloudletFinishedList;
	}
	protected List<ResCloudlet> getCloudletExecList() {
		return cloudletExecList;
	}
	protected double getCapacity(List<Double> mipsShare) {
		double capacity = 0.0;
		int cpus = 0;
		for (Double mips : mipsShare) {
			capacity += mips;
			if (mips > 0.0) {
				cpus++;
			}
		}
		currentCPUs = cpus;

		int pesInUse = 0;
		for (ResCloudlet rcl : getCloudletExecList()) {
			pesInUse += rcl.getNumberOfPes();
		}

		if (pesInUse > currentCPUs) {
			capacity /= pesInUse;
		} else {
			capacity /= currentCPUs;
		}
		return capacity;
	}




	

}
