package org.fog.scheduler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletScheduler;
import org.cloudbus.cloudsim.Consts;
import org.cloudbus.cloudsim.ResCloudlet;
import org.cloudbus.cloudsim.core.CloudSim;
import org.fog.entities.Tuple;
import org.fog.utils.Config;

// ======= Pre-emptive Two Queue SJF Tuple Scheduler =========
public class TupleScheduler_MQP extends CloudletScheduler {
	
	// The tuple in execution 
	private ResCloudlet cloudletInExe;
	private List<ResCloudlet> cloudletCopyComingList;
	private List<ResCloudlet> cloudletLongTupleQue;
	private List<ResCloudlet> cloudletShortTupleQue;
	
	// The Tuples which are finished list. 
	private List<ResCloudlet> cloudletFinishedList;
	private List<ResCloudlet> cloudletFinishListCopy;
	
	int threshold = 1200;
	boolean SJfEnable= true;
	boolean PremptionEnable = true;
	public int numberOfTuplesToExecuteFromShortQueue = 4;
	public float PercentOfTuple = (float) 10.0;
	/** The current cp us. */
	protected int currentCPUs;
	long sumOfAllCloudletLengths = 0;
	long numberOfCloudletsSubmitted = 0;
	
	// maintain total time which has been passed for current running tuple
	private double timeSlicePassedForTuple;
	private double divisorForTimeSlice;
	
	// time quantum for tuple, after which it will be pre-empted
	private double timeSliceForTuple;
	
	// we want to execute 2 short tuple, so this variable will help 
	private int shortTuplesExecutionCount=0;

	public  boolean CURRENT_EXECUTING_TUPLE_SHORT=false;
	public  boolean CURRENT_EXECUTING_TUPLE_LONG=false;
	

	public static int printOnce = 0;
                                               
	/**
	 * Creates a new CloudletScheduler object. This method must be invoked before starting the
	 * actual simulation.
	 * 
	 * @pre $none
	 * @post $none
	 */
	public TupleScheduler_MQP() {
		super();
		
		String schedulerName="MQ";
		if(printOnce < 1)
		{

			if(SJfEnable==true) {schedulerName+="S";} else {schedulerName+="F";}
			if(PremptionEnable==true) {schedulerName+="P";} else {schedulerName+="N";}
				
			System.out.println("Scheduler= " + schedulerName);
			System.out.println("PercentOfTuple= " + PercentOfTuple);
			System.out.println("Threshold= "+ threshold);
			System.out.println("numberOfTuplesToExecuteFromShortQueue= " + numberOfTuplesToExecuteFromShortQueue);

			printOnce++;
		}
		
		cloudletInExe = null;
		
		cloudletFinishedList = new ArrayList<ResCloudlet>();
		cloudletFinishListCopy  = new ArrayList<ResCloudlet>();
		cloudletLongTupleQue  = new ArrayList<ResCloudlet>();
		cloudletShortTupleQue  = new ArrayList<ResCloudlet>();
		cloudletCopyComingList = new ArrayList<ResCloudlet>();
		currentCPUs = 0;
	}
		

	@Override
	public double updateVmProcessing(double currentTime, List<Double> mipsShare) 
	{
		setCurrentMipsShare(mipsShare);
		
		double timeSpan = currentTime - getPreviousTime();
		if(cloudletInExe != null) 
		{				
			cloudletInExe.updateCloudletFinishedSoFar((long) (getCapacity(mipsShare) * timeSpan * cloudletInExe.getNumberOfPes() * Consts.MILLION));		
		}

		if(timeSpan > 0 && CURRENT_EXECUTING_TUPLE_LONG) 
		{
			setPreviousTime(currentTime);
			if(cloudletInExe != null)
			{	
				timeSlicePassedForTuple = timeSlicePassedForTuple + timeSpan;
			}
		}
		double nextEvent = Double.MAX_VALUE;
			
		// check finished cloudlets
		if (cloudletInExe != null) 
		{		
		//	System.out.println("cloudletInExe.getRemainingCloudletLength() --------------" + cloudletInExe.getRemainingCloudletLength() );

			// if tuple execution is complete
			if(cloudletInExe.getRemainingCloudletLength() == 0) 
			{
				this.timeSlicePassedForTuple=0;
				cloudletFinish(cloudletInExe);
				
				// if current tuple is from long queue then enable next tuple selection from short queue
				if(CURRENT_EXECUTING_TUPLE_LONG) 
				{
					shortTuplesExecutionCount = 0;
				}
			}
			// if tuple execution is not complete
			else 
			{
				if(PremptionEnable==true) {
					if(CURRENT_EXECUTING_TUPLE_LONG == true && timeSlicePassedForTuple >= timeSliceForTuple)
					{
						schudleNextShortTupleAndPreEmptionCurrentLongTuple();
					}
				}
			}
		}

		
		if (cloudletInExe == null) {
			setPreviousTime(currentTime);
			return 0.0;
		}

		// estimate finish time of cloudlets
		if (cloudletInExe != null) 
		{
			double estimatedFinishTime = currentTime
					+ (cloudletInExe.getRemainingCloudletLength() / (getCapacity(mipsShare) * cloudletInExe.getNumberOfPes()));
			if (estimatedFinishTime - currentTime < CloudSim.getMinTimeBetweenEvents()) 
			{
				estimatedFinishTime = currentTime + CloudSim.getMinTimeBetweenEvents();
			}

			if (estimatedFinishTime < nextEvent) 
			{
				nextEvent = estimatedFinishTime;
			}
			
			divisorForTimeSlice = (getCapacity(mipsShare) * cloudletInExe.getNumberOfPes());
			
		//	System.out.println("getRemainingCloudletLength--------------" + cloudletInExe.getRemainingCloudletLength());
		//	System.out.println("getCapacity--------------" + (getCapacity(mipsShare) * cloudletInExe.getNumberOfPes()));

		//	System.out.println("estimatedFinishTime--------------" + estimatedFinishTime);
		//	System.out.println(getValue(5.00));
		}

		setPreviousTime(currentTime);
		return nextEvent;

	}

	private static double getValue(double min) 
	{
		Random rn = new Random();
		return rn.nextDouble()*10;
		//return rn.nextDouble()*10 + min;
		
	}
	
	
	
	
	@Override
	public double cloudletSubmit(Cloudlet cloudlet, double fileTransferTime)
	{
		Tuple t = (Tuple) cloudlet;
		double extraSize = getCapacity(getCurrentMipsShare()) * fileTransferTime;
		long length = (long) (cloudlet.getCloudletLength() + extraSize);
		cloudlet.setCloudletLength(length);
				
		ResCloudlet rcl = new ResCloudlet(cloudlet);
		
		//add to copyList for just displaying order of incoming tuples
		cloudletCopyComingList.add(rcl);
		
		int type = 0;	// 0 for incoming, 1 for outgoing, 2 for short queue, and 3 for long queue
//		printQueue(rcl, t, type);
						
		// decide tuple queue short/long
		decideTupleQueLongOrShort(rcl);
				
//		printQueue(rcl, t, 2);
//		printQueue(rcl, t, 3);

		//after deciding queue lets schedule tuple
		schudleTuple();
		return cloudlet.getCloudletLength() / getCapacity(getCurrentMipsShare());
	}
	
	
	
	
	public void printQueue(ResCloudlet r, Tuple t, int type)
	{
		
		if(type == 0) {
			System.out.println("---------------------------------------------------------");
			System.out.println("Coming new Tuple | "
					+ "id:" + r.getCloudletId() +" src:"+ t.getSrcModuleName() + " dest:"+
					t.getDestModuleName()+ " "  + r.getCloudlet().getCloudletLength());
			System.out.println("---------------------------------------------------------");
			
			System.out.println(">>>>>> List start: showing tuples incoming order");
			for(int i=0;i<cloudletCopyComingList.size();i++) {
				Tuple temp= (Tuple) cloudletCopyComingList.get(i).getCloudlet();
				printTupleProperties(temp);
			}
			System.out.println("<<<<<< List end: showing tuples incoming order end                               .....");
			System.out.println("");
		}

		else if(type == 1) {
			System.out.println(">>>>>> List start: showing tuples finished");
			for(int i=0; i<cloudletFinishListCopy.size(); i ++) {
				Tuple temp= (Tuple) cloudletCopyComingList.get(i).getCloudlet();
				printTupleProperties(temp);
			}
			System.out.println("<<<<<< List end: showing tuples finished                                         #####");
			System.out.println("");
		}
		
		else if(type == 2) {
			System.out.println(">>>>>> List start: showing tuples in short queue");
			for(int i=0; i<cloudletShortTupleQue.size(); i ++) {
				Tuple temp= (Tuple) cloudletShortTupleQue.get(i).getCloudlet();
				printTupleProperties(temp);
			}
			System.out.println("<<<<<< List end: showing tuples in short queue                                    _____");
			System.out.println("");               
		}
		
		else if(type == 3) {
			System.out.println(">>>>>> List start: showing tuples in long queue");
			for(int i=0; i<cloudletLongTupleQue.size(); i ++) {
				Tuple temp= (Tuple) cloudletLongTupleQue.get(i).getCloudlet();
				printTupleProperties(temp);
			}
			System.out.println("<<<<<< List end: showing tuples in long queue                                    ^^^^^^");
			System.out.println("");
		}
		

	}
	
	
	
	public void printTupleProperties(Tuple t) 
	{
		System.out.println("TupleId:" + t.getCloudletId()
		+ " mipsReq: " + t.getCloudletLength()
		+ " sourceModule:" + t.getSrcModuleName() 
		+ " destModule:"+ t.getDestModuleName() + " [" +  CloudSim.getEntityName(t.getResourceId()) + "] "
//		+ " getResourceId:" + t.getResourceId()
//		+ " getResourceName:" + t.getResourceName(temp.getResourceId())
//		+ " getSourceDeviceId:" + t.getSrcModuleName()
		
//			CloudSim.getEntityName(ev.getSource())+"|Dest : "+CloudSim.getEntityName(ev.getDestination()));
		);
	}
	
	
	
	
	
	
	
	
	
	public void decideTupleQueLongOrShort(ResCloudlet rcl) 
	{
		// implement logic to decide Queue of incoming tuple, in condition give criteria
	
		long cloudletLength = rcl.getCloudlet().getCloudletLength();
		
		sumOfAllCloudletLengths += cloudletLength;
		numberOfCloudletsSubmitted += 1;
	//	System.out.println("numberOfCloudletsSubmitted " + numberOfCloudletsSubmitted);  
		
	//	int avg = (int)(sumOfAllCloudletLengths/numberOfCloudletsSubmitted);
	//	System.out.println("Avg: "+avg);               

		
		if(cloudletLength > threshold) 
		{
			cloudletLongTupleQue.add(rcl);
			if(SJfEnable==true) 
			{
				Collections.sort(cloudletLongTupleQue, new Comparator<ResCloudlet>(){
				@Override
				public int compare(ResCloudlet o1, ResCloudlet o2) {
					Long o1L = o1.getRemainingCloudletLength();
					Long o2L = o2.getRemainingCloudletLength();
			        return o1L.compareTo(o2L);
				}
				});  
			}
		}
		else
		{
			cloudletShortTupleQue.add(rcl);
			if(SJfEnable==true) 
			{
				Collections.sort(cloudletShortTupleQue, new Comparator<ResCloudlet>(){
				@Override
				public int compare(ResCloudlet o1, ResCloudlet o2) {
					Long o1L = o1.getRemainingCloudletLength();
					Long o2L = o2.getRemainingCloudletLength();
			        return o1L.compareTo(o2L);
				}
				}); 
			}
		}
	}
	
	public double decideTupleTimeSlice(ResCloudlet inExe) {
		// give logic of deciding tuple time slice, after which it will be pre-emptived
		double meanValue=0.0;
		long totalMipsOfLongQueTuples=0;
		int longTupleQueueSize=cloudletLongTupleQue.size();

		if(longTupleQueueSize>0) {
			for(int i=0;i<longTupleQueueSize; i++) {
				long tempTupleLength = cloudletLongTupleQue.get(i).getRemainingCloudletLength();
				totalMipsOfLongQueTuples = totalMipsOfLongQueTuples + tempTupleLength;			
			}
			meanValue = (double)totalMipsOfLongQueTuples/longTupleQueueSize;
		}
	//	divisorForTimeSlice = Config.MAX_SIMULATION_TIME;
		double calculatedTimeSlice = (PercentOfTuple/100 * meanValue)/Config.MAX_SIMULATION_TIME;

	//	System.out.println("longTupleQueueSize--------------" + longTupleQueueSize);
	//	System.out.println("totalMipsOfLongQueTuples--------------" + totalMipsOfLongQueTuples);
	//	System.out.println("divisorForTimeSlice--------------" + divisorForTimeSlice);
	//	System.out.println("meanValue--------------" + meanValue);		
	//	System.out.println("TimeSlice--------------" + calculatedTimeSlice);
		
		return calculatedTimeSlice;
	}
	
	
	// ---- Main Entry Point for Schedular ----
	public void schudleTuple() {
		// If there is no tuple in execution, then schedule
		if(cloudletInExe == null) {
			if(schudleShortTuple()) {}
			else {schudleLongTuple();}
		}	
	}
	
	// ---- Schedular for Short Queue ----
	public boolean schudleShortTuple() {
		//to control no.of short tuples execution count , update following condition-number etc 2-->3
		
		if((shortTuplesExecutionCount<numberOfTuplesToExecuteFromShortQueue) && (cloudletShortTupleQue.size()>0))
		{	
			CURRENT_EXECUTING_TUPLE_SHORT = true;
			CURRENT_EXECUTING_TUPLE_LONG = false;
			cloudletInExe = cloudletShortTupleQue.get(0);
			cloudletShortTupleQue.remove(0);
			
			cloudletInExe.setCloudletStatus(3);
			for (int i = 0; i < cloudletInExe.getNumberOfPes(); i++) 
			{
				cloudletInExe.setMachineAndPeId(0, i);
			}			
			shortTuplesExecutionCount++;
			return true;
		}
		else 
		{
			return false;
		}
	}
	
	// ---- Schedular for Long Queue ----
	public boolean schudleLongTuple() {
		
		if(cloudletLongTupleQue.size()>0) 
		{
			shortTuplesExecutionCount = 0;
			CURRENT_EXECUTING_TUPLE_SHORT = false;
			CURRENT_EXECUTING_TUPLE_LONG = true;
			cloudletInExe = cloudletLongTupleQue.get(0);
			cloudletLongTupleQue.remove(0);
			
			// decide tuple slice time
			this.timeSliceForTuple = decideTupleTimeSlice(cloudletInExe);
			
			//Cloudlet.INEXEC = 3  means the Cloudlet is in execution in a Cloud node
			cloudletInExe.setCloudletStatus(3);
			
			for (int i = 0; i < cloudletInExe.getNumberOfPes(); i++)
			{
				cloudletInExe.setMachineAndPeId(0, i);
			}
		}
		return false;		
	}	
	
	
	public void schudleNextShortTupleAndPreEmptionCurrentLongTuple(){
		// If tuple is executing and the short tuple queue is not empty
		if(cloudletInExe !=null && cloudletShortTupleQue.size()>0)
		{				
			// since current long have remaining short, so no need to pre empt this. continue with this.
			//if(cloudletInExe.getRemainingCloudletLength() < cloudletShortTupleQue.get(0).getRemainingCloudletLength()) 
			if(cloudletInExe.getRemainingCloudletLength() < threshold)
			{
			//	System.out.println("**RemainingCloudletLength--------------" + cloudletInExe.getRemainingCloudletLength());
				return;
			}
			else 
			{
				this.timeSlicePassedForTuple = 0;
				shortTuplesExecutionCount = 0;
			}
		}
		
		if(cloudletShortTupleQue.size()>0) 
		{
			// System.out.println("RemainingCloudletLength--------------" + cloudletInExe.getRemainingCloudletLength());

			// schedule next tuple from short queue, and add current running into waiting queue
    		if(cloudletInExe != null) {
    			cloudletInExe.setCloudletStatus(Cloudlet.PAUSED);
    			cloudletInExe.setMachineAndPeId(-1, -1);
    		}
	        	shortTuplesExecutionCount++;
				CURRENT_EXECUTING_TUPLE_SHORT = true;
				CURRENT_EXECUTING_TUPLE_LONG = false;
				
		    	ResCloudlet rcl2 = cloudletShortTupleQue.get(0);
		    	cloudletShortTupleQue.remove(0);
		    	
		    	
		    	if(cloudletInExe.getRemainingCloudletLength() > (threshold)) 
		    	{
		    		cloudletLongTupleQue.add(cloudletInExe);
		    		
		    		if(SJfEnable==true) {
		    			Collections.sort(cloudletLongTupleQue, new Comparator<ResCloudlet>(){
						@Override
						public int compare(ResCloudlet o1, ResCloudlet o2) {
							Long o1L = o1.getRemainingCloudletLength();
							Long o2L = o2.getRemainingCloudletLength();
					        return o1L.compareTo(o2L);
						}
						});	
		    		}
		    	}
		    	else 
		    	{
		    		cloudletShortTupleQue.add(0, cloudletInExe);
		    	}
		    	
		    	
				cloudletInExe = rcl2;
				this.timeSliceForTuple= decideTupleTimeSlice(cloudletInExe);
				cloudletInExe.setCloudletStatus(Cloudlet.INEXEC);
				for (int i = 0; i < cloudletInExe.getNumberOfPes(); i++) {
					cloudletInExe.setMachineAndPeId(0, i);
				}
				
				//System.out.println("=scheduling short in function schudleNextShortTupleAndPreEmptionCurrentLongTuple="); 
		}
			
		else
		{
	        	// we are here after completing time slice, but short queue is empty, so, schudle next long tuple
	        	// schedule next tuple from long queue, and add current running into waiting queue
	        	if(cloudletLongTupleQue.size()>0) {
		        	if(cloudletInExe != null) {
		    			cloudletInExe.setCloudletStatus(Cloudlet.PAUSED);
		    			cloudletInExe.setMachineAndPeId(-1, -1);
		    		}
		        	ResCloudlet rcl2 = cloudletLongTupleQue.get(0);
		        	cloudletLongTupleQue.remove(0);
			    	cloudletLongTupleQue.add(cloudletInExe);
					cloudletInExe = rcl2;
					this.timeSliceForTuple= decideTupleTimeSlice(cloudletInExe);
					cloudletInExe.setCloudletStatus(Cloudlet.INEXEC);
					for (int i = 0; i < cloudletInExe.getNumberOfPes(); i++) {
						cloudletInExe.setMachineAndPeId(0, i);
					}
					//System.out.println("=scheduling long in function schudleNextShortTupleAndPreEmptionCurrentLongTuple=");
	        	}
	        
		}
	}

	@Override
	public double cloudletSubmit(Cloudlet cloudlet) {
		return cloudletSubmit(cloudlet, 0.0);
	}

	@Override
	public Cloudlet cloudletCancel(int clId) {
		return null;
	}

	@Override
	public boolean cloudletPause(int cloudletId) {

		return false;
	}

	@Override
	public double cloudletResume(int clId) {
		return 0;
	}

	@Override
	public void cloudletFinish(ResCloudlet rcl) {
		
		//onFinish , schulde next tuple to Run
		cloudletInExe= null;
		schudleTuple();
		
		Tuple t= (Tuple) rcl.getCloudlet();
		rcl.setCloudletStatus(Cloudlet.SUCCESS);
		rcl.finalizeCloudlet();
		getCloudletFinishedList().add(rcl);
		cloudletFinishListCopy.add(rcl);	
		
		int type = 1;	// 0 for incoming and 1 for outgoing
//		printQueue(rcl, t, type);
		
	}

	@Override
	public int getCloudletStatus(int cloudletId) {
		// TODO Auto-generated method stub
		if(cloudletInExe !=null) {
			return Cloudlet.INEXEC;
		}

		return -1;
	}

	@Override
	public boolean isFinishedCloudlets() {
		// TODO Auto-generated method stub
		return getCloudletFinishedList().size() > 0;
	}

	@Override
	public Cloudlet getNextFinishedCloudlet() {
		// TODO Auto-generated method stub
		if (getCloudletFinishedList().size() > 0) {
			return getCloudletFinishedList().remove(0).getCloudlet();
		}
		return null;
	}

	@Override
	public int runningCloudlets() {
		// TODO Auto-generated method stub
		if(cloudletInExe ==null)
			return 0;
		return 1;
	}

	@Override
	public Cloudlet migrateCloudlet() {
		// TODO Auto-generated method stub
		//ResCloudlet rgl = getCloudletExecList().remove(0);
		if(cloudletInExe ==null)
			return null;
		return cloudletInExe.getCloudlet();
	}

	@Override
	public double getTotalUtilizationOfCpu(double time) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Double> getCurrentRequestedMips() {
		// TODO Auto-generated method stub
		List<Double> mipsShare = new ArrayList<Double>();
		return mipsShare;
	}

	@Override
	public double getTotalCurrentAvailableMipsForCloudlet(ResCloudlet rcl, List<Double> mipsShare) {
		// TODO Auto-generated method stub
		return getCapacity(getCurrentMipsShare());
	}

	@Override
	public double getTotalCurrentRequestedMipsForCloudlet(ResCloudlet rcl, double time) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getTotalCurrentAllocatedMipsForCloudlet(ResCloudlet rcl, double time) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double getCurrentRequestedUtilizationOfRam() {
		// TODO Auto-generated method stub
		double ram = 0;
		if (cloudletInExe != null) {
			ram += cloudletInExe.getCloudlet().getUtilizationOfRam(CloudSim.clock());
		}
		return ram;
	}

	@Override
	public double getCurrentRequestedUtilizationOfBw() {
		// TODO Auto-generated method stub
		double bw = 0;
		if (cloudletInExe != null) {
			bw += cloudletInExe.getCloudlet().getUtilizationOfBw(CloudSim.clock());
		}
		return bw;
	}
	
	// returns the Tuples finished list
	protected List<ResCloudlet>  getCloudletFinishedList() {
		return   cloudletFinishedList;
	}
	protected ResCloudlet getCloudletExecList() {
		return cloudletInExe;
	}
	
	protected double getCapacity(List<Double> mipsShare) {
		double capacity = 0.0;
		int cpus = 0;
		for (Double mips : mipsShare) {
			capacity += mips;
			if (mips > 0.0) {
				cpus++;
			}
		}
		currentCPUs = cpus;

		int pesInUse = 0;
		if (cloudletInExe != null) {
			pesInUse += cloudletInExe.getNumberOfPes();
		}

		if (pesInUse > currentCPUs) {
			capacity /= pesInUse;
		} else {
			capacity /= currentCPUs;
		}
		return capacity;
	}




	

}
