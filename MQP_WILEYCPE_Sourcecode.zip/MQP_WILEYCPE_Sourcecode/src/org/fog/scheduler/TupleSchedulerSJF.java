package org.fog.scheduler;

import org.cloudbus.cloudsim.CloudletScheduler;


public class TupleSchedulerSJF extends TupleScheduler_MQP {
	
//public class TupleSchedulerSJF extends SJFScheduler2{
//public class TupleSchedulerSJF extends TupleSchedulerFCFS{


	
	
	public TupleSchedulerSJF(double mips, int numberOfPes) {
	
	  //super(mips, numberOfPes);
	  super();
	}

}