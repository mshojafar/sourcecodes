package org.fog.scheduler;

import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;

public class TupleSchedulerFCFS extends CloudletSchedulerTimeShared{
	public TupleSchedulerFCFS(double mips, int numberOfPes) {
		//super(mips, numberOfPes);
		super();
	}

}
