#!/bin/bash

function dataVectorInit() {
	t=$1
	outfile=$2
	infile=$3
	paramname=$4
	# find line with the right timestamp
	line=`grep "^${t} " $infile`
	# remove first element form the line
	line=`echo $line | cut -d " " -f 2-`
	#echo "found line $line for t=$t"
	newline="param $paramname :="
	c=1
	for i in $line
	do
		newline="$newline $c $i"
		(( c=c+1 ))
	done
	echo "$newline ;"> $outfile
}

function dataMatrixInit() {
	t=$1
	outfile=$2
	infile=$3
	paramname=$4
	# find line with the right timestamp
	line=`grep "^${t} " $infile`
	# remove first element form the line
	line=`echo $line | cut -d " " -f 2-`
	nelem=`echo $line | wc -w`
	ncol=`echo "sqrt($nelem)" | bc`
	nrow=$ncol
	echo "line has $nelem elements, ncol=$ncol"
	#echo "found line $line for t=$t"
	newline="param $paramname : \\n `seq -s ' ' 1 $ncol ` := \\n 1"
	x=1
	y=1
	for i in $line
	do
		newline="$newline $i"
		(( x=x+1 ))
		if [ $x -gt $ncol ]
		then 
			x=1
			(( y=y+1 ))
			if [ $y -le $nrow ]
			then 
				newline="$newline \\n $y"
			fi
		fi
	done
	echo -e "$newline \\n ;"> $outfile
}


get_nslot() {
	tail -n1 Net_timeseries.data | cut -d " " -f 1
}

function dataInit() {
	t=$1
	echo "initializing data for run $t"
	#echo "param runnumber := $t ;" > DC_Mig_runnumber.dat
	#dataVectorInit $t DC_Mig_c_VM.dat CPU_timeseries.data c_VM
	#dataVectorInit $t DC_Mig_m_VM.dat Mem_timeseries.data m_VM
	dataMatrixInit $t DC_Mig_d-2.dat Net_timeseries.data d
}

export VMperS=4

get_nVM() {
	tail -n1 Mem_timeseries.data | cut -d " " -f 2- | wc -w
}


function maxInit() {
	MAXVALFILE="DC_Mig_maxval.dat"
	MAXCPUVM=100
	MAXMEMVM=500
	MAXNETVM=1000
	nVM=`get_nVM`
	# CPU
	((max=MAXCPUVM * VMperS))
	newline="param c_m :="
	for i in `seq 1 $nVM`
	do
		newline="$newline $i $max"
	done
	echo -e "$newline ;"> $MAXVALFILE
	# Memory
	((max=MAXMEMVM * VMperS))
	newline="param m_m :="
	for i in `seq 1 $nVM`
	do
		newline="$newline $i $max"
	done
	echo -e "$newline ;">> $MAXVALFILE
	# Network
	((max=MAXNETVM * VMperS))
	newline="param d_m :="
	for i in `seq 1 $nVM`
	do
		newline="$newline $i $max"
	done
	echo -e "$newline ;">> $MAXVALFILE
	cat $MAXVALFILE
}

for runnumber in 0
do
	#dataInit $runnumber
	#cat DC_Mig_d-2.dat
	maxInit
done
