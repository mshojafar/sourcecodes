#!/bin/bash
INFILE=DC_Mig.log
for i in "overall_energy"
do
	grep "$i" $INFILE | cut -d= -f2 > "$i.data"
done
