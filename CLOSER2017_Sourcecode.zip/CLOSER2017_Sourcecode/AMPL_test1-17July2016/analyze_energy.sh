#!/bin/bash
#INFILE=DC_Mig.log
MIGRFILE=Scenario2_4_results_tot

rm -f $MIGRFILE

#for i in Scenario1_4*
for i in Scenario2_4*
do
	echo -e "\n" >> $MIGRFILE
	#grep "$i" $INFILE | cut -d= -f2 > "$i.data"
	echo -n "$i" >> $MIGRFILE
	echo -e "\n" >> $MIGRFILE
        #N=`grep 'runnumber ='  ${i}/DC_Mig.log` | tail -n1 | cut -d= -f2`
	N=9
        (( N=N+1 )) 
        echo -e "slot_number = $N \\n"  >> $MIGRFILE
        grep 'overall_energy ='  ${i}/DC_Mig.log | cut -d= -f2 | awk '{overall+=$1} END {print "Overall_energy = " overall "\n" "AVG_energy_perslot= " overall/10}' >> $MIGRFILE
	
	grep 'on\[i\] =' ${i}/DC_Mig.log | cut -d= -f2 | awk '{on+=$1} END {print "total_ON_servers = " on "\n" "AVG_ON_servers_perslot = " on/10}' >> $MIGRFILE
  	
	grep 'g_plus\[i,j\]' ${i}/DC_Mig.log | cut -d= -f2 | awk '{mig+=$1} END {print "Overall_Migrations = " mig "\n" "AVG_Migrations_perslot = " mig/10}' >> $MIGRFILE
      	
	grep 'c_m\[i\])) =' ${i}/DC_Mig.log  | cut -d= -f2 | awk '{E_C+=$1} END {print "Overall_Computation_Cost = " E_C "\n" "AVG_Computation_perslot = " E_C/10}' >> $MIGRFILE
	
	grep 'E\[i1,i2\] =' ${i}/DC_Mig.log | cut -d= -f2 | awk '{E_D+=$1} END {print "Overall_Datatransfer_Cost = " E_D "\n" "AVG_Datatransfer_perslot = " E_D/10}' >> $MIGRFILE
	
	grep 'i2\]) =' ${i}/DC_Mig.log | cut -d= -f2 | awk '{E_M1+=$1} END {print "Overall_Mig_DataTransfer_Cost = " E_M1 "\n" "AVG_Mig_Datatransfer_perslot = " E_M1/10}' >> $MIGRFILE
        
	grep  '\+ (1 \- K_C\[i2\])\*P_m\[i2\]\*K_M\[i2\]\*T) =' ${i}/DC_Mig.log | cut -d= -f2  | awk '{E_M2+=$1} END {print "Overall_Mig_CPUoverhead_Cost = " E_M2 "\n" "AVG_Mig_CPUoverhead_perslot = " E_M2/10}' >> $MIGRFILE
echo -e "\n" >> $MIGRFILE
done
cat $MIGRFILE

