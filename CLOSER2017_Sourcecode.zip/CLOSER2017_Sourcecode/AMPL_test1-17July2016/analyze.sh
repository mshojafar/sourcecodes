#!/bin/bash
INFILE=DC_Mig.log
for i in "overall_energy"
do
	grep "$i" $INFILE | cut -d= -f2 > "$i.data"
done

MIGRFILE=migr_tot
rm -f $MIGRFILE
for i in Scenario2_4*
do 
	echo -n "$i " # >> $MIGRFILE
	grep 'g_plus\[i,j\]' ${i}/DC_Mig.log | cut -d= -f2 | awk '{s+=$1} END {print s}' #>> $MIGRFILE
done 
#cat $MIGRFILE


