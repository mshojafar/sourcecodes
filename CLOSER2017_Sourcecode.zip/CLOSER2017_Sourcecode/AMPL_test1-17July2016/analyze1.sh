#!/bin/bash
#INFILE=DC_Mig.log
#for i in "overall_energy"
#do
#	grep "$i" $INFILE | cut -d= -f2 > "$i.data"
#done

#MIGRFILE=migr_tot
#rm -f $MIGRFILE
#for i in Scenario2_4*
#do 
#	echo -n "$i " # >> $MIGRFILE
#	grep 'g_plus\[i,j\]' ${i}/DC_Mig.log | cut -d= -f2 | awk '{s+=$1} END {print s}' #>> $MIGRFILE
#done
#cat $MIGRFILE
#for i in Scenario1_4_results_tot
for i in Scenario2_4_results_tot
do
       #grep 'AVG_energy_perslot='  ${i} | cut -d= -f2 #| awk '{overall+=$1} END {print "\n"}' >> $MIGRFILE
	echo -e "AVG_ON_servers_perslot=\n " # >> $MIGRFIL
	grep 'AVG_ON_servers_perslot' ${i} | cut -d= -f2 #| awk '{overall+=$1} END {print "\n"}'>> $MIGRFIL

	echo -e "AVG_Migrations_perslot=\n " # >> $MIGRFILE
       	grep 'AVG_Migrations_perslot'  ${i} | cut -d= -f2 #| awk '{overall+=$1} END {print "\n"}' >> $MIGRFILE        

	echo -e "AVG_Computation_perslot=\n " # >> $MIGRFILE
 	grep 'AVG_Computation_perslot' ${i} | cut -d= -f2 #| awk '{overall+=$1} END {print "\n"}'>> $MIGRFIL

	echo -e "AVG_Datatransfer_perslot=\n " # >> $MIGRFILE
       	grep 'AVG_Datatransfer_perslot'  ${i} | cut -d= -f2 #| awk '{overall+=$1} END {print "\n"}' >> $MIGRFILE        

	echo -e "AVG_Mig_Datatransfer_perslot=\n " # >> $MIGRFILE
 	grep 'AVG_Mig_Datatransfer_perslot' ${i} | cut -d= -f2 #| awk '{overall+=$1} END {print "\n"}'>> $MIGRFIL

	echo -e "AVG_Mig_CPUoverhead_perslot=\n " # >> $MIGRFILE
       	grep 'AVG_Mig_CPUoverhead_perslot'  ${i} | cut -d= -f2 #| awk '{overall+=$1} END {print "\n"}' >> $MIGRFILE        




done
