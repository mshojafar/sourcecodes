function [ distance ] = compute_distance(i,j,users,nodes)

        distance=sqrt((users(i,1)-nodes(j,1))^2+(users(i,2)-nodes(j,2))^2);

end

