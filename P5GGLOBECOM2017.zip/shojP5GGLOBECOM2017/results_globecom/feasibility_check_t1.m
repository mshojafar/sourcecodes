function [ t_accept, t_acc1, t_acc2, t_acc3, t] = feasibility_check_t1(num_k, num_nodes, num_users, t, r, u, m, delta_jki_RRH, delta_k_MEC, N_k_RRH, N_k_MEC, num_k_RRH, num_k_BBU, num_k_MEC, M, y)
%%default
%ulim=1;    %max value
%llim=0;    %min value
%rowlim=1;  %max sum for each row
%m=5;    %rows
%n=4;    %columns
%o=3;   %pages
%rowlimvector=[1,4];  %max sum for each page
t_acc1=zeros(num_nodes, num_users, length(N_k_RRH)); % checker for Eq. (23) satisfaction
t_acc2=zeros(num_nodes, num_users); % checker for Eq. (24) satisfaction
t_acc3=zeros(num_nodes, num_users); % checker for Eq. (30) satisfaction
t_accept=zeros(num_nodes, num_users, length(N_k_RRH)); % checker for Eqs. (23)(24)(30) satisfaction
% for i=1:num_nodes

%     for k=1:num_k_MEC
%     m(k,:,i)=m(k,:,i)*y(i);
%     end
%     r(:,i)=r(:,i)*y(i);
%     u(i,:)=u(i,:)*y(i);
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (23)
threshold=0.05; % defualt=1
max_delta_jki_RRH=zeros(num_nodes, num_users);
min_delta_jki_RRH=zeros(num_nodes, num_users);
for k=1:num_k_RRH
 for i=1:num_nodes
     for j=1:num_users
       max_delta_jki_RRH (i,j)=max(delta_jki_RRH(j,:,i));  %max traffic over i-th node
       %min_delta_jki_RRH (i,j)=min(delta_jki_RRH(j,:,i)); %min traffic over i-th node
     end        
 end
end

for i=1:num_nodes
    for j=1:num_users
        for k=1:length(N_k_RRH)
            if (y(i)==0) 
                t(i,:)=0;
                t_acc1(i,:,:)=1;
            end
            
            if (delta_jki_RRH(j,k,i)==0) && (r(k,i)~=0)
                t(i,j)=0;
                t_acc1(i,j,k)=1;
            
            elseif (delta_jki_RRH(j,k,i)~=0) && (r(k,i)~=0)
                   %t(i,j)=delta_jki_RRH(j,k,i)*((1-threshold)*rand+threshold);
                   t(i,j)=max_delta_jki_RRH(i,j); %maximum traffic
                   %t(i,j)=min_delta_jki_RRH(i,j); %minumum traffic
                   t_acc1(i,j,k)=1;
            elseif r(k,i)==0
                  t_acc1(i,j,k)=1;
            end
            
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (24)
for i=1:num_nodes
    for j=1:num_users
        if (u(i,j))==0
            t(i,j)=0;
            t_acc2(i,j)=1;
        elseif (t(i,j)<=M*u(i,j))
            t_acc2(i,j)=1;
        else
            t_acc2(i,j)=0;
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (30)
temp31=zeros(num_k_MEC, num_nodes);
for i=1:num_nodes
    for j=1:num_users
        temp3=sum(delta_k_MEC);
        for k=1:num_k_MEC
            temp31(k,i)=sum(m(k,i,:));
        end
        temp32=sum(temp31);
        if (t(i,j)<=temp32*temp3)
            t_acc3(i,j)=1;
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% integration (24)+(23)+(30)
for i=1:num_nodes
    for j=1:num_users
        for k=1:length(N_k_RRH)
            t_accept(i,j,k)=t_acc1(i,j,k)*t_acc2(i,j)*t_acc3(i,j);
        end
    end
end


% for i=1:num_nodes
%     for k=1:num_k_MEC
%     m(k,:,i)=m(k,:,i)*y(i);
%     end
%     r(:,i)=r(:,i)*y(i);
%     u(i,:)=u(i,:)*y(i);
% end
