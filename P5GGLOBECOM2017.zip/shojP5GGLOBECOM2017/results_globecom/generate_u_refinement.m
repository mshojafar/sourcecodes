function [u]=generate_u_refinement(u, y, num_nodes, num_users)
  %% t== i, j

  for i=1:num_nodes
      for j=1:num_users
          if (u(i,j)>1) && (y(i)==1)
            u(i,j)=1;
          elseif (u(i,j)<0) 
            u(i,j)=0;
          elseif (y(i)==0)
              u(i,:)=0;
          end
          
      end       
  end
     

end
