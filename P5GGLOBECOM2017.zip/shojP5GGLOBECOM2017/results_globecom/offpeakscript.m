clc 
clear all
close all
netmap=load('netmap.mat');
toycaseoffpeak1=load('toy_case_example.mat');

delta_k_MEC=toycaseoffpeak1.delta_k_MEC;
M_ik_BD=toycaseoffpeak1.M_ik_BD;
M_ik_MD=toycaseoffpeak1.M_ik_MD;
M_ik_BS=toycaseoffpeak1.M_ik_BS;
M_ik_MS=toycaseoffpeak1.M_ik_MS;

C_ik_BD=toycaseoffpeak1.C_ik_BD;
C_ik_MD=toycaseoffpeak1.C_ik_MD;
C_ik_BS=toycaseoffpeak1.C_ik_BS;
C_ik_MS=toycaseoffpeak1.C_ik_MS;

B_i_DHW=toycaseoffpeak1.B_i_DHW;
C_i_CHW=toycaseoffpeak1.C_i_CHW;
O_kwz=toycaseoffpeak1.O_kwz;

R_k_max=toycaseoffpeak1.R_k_max;
U_MAX=toycaseoffpeak1.U_MAX;
delta_k_BBU=R_k_max*10;

users=netmap.users;
nodes=netmap.nodes;
nodes_macro=netmap.nodes_macro;
outer_macro=netmap.outer_macro;
nodes_micro=netmap.nodes_micro;
%offpeak num_users=26
toycaseoffpeak=load('toy_case_example_v2_variaz_users.mat');

%%26 users
 delta_jki_RRH=toycaseoffpeak.delta_jki_RRH_0_1;
 cov_jik=toycaseoffpeak.cov_jik_0_1;

%%65 users
%  delta_jki_RRH=toycaseoffpeak.delta_jki_RRH_0_25;
%  cov_jik=toycaseoffpeak.cov_jik_0_25;

%%104 users
% delta_jki_RRH=toycaseoffpeak.delta_jki_RRH_0_4;
% cov_jik=toycaseoffpeak.cov_jik_0_4;

%%142 users
% delta_jki_RRH=toycaseoffpeak.delta_jki_RRH_0_55;
% cov_jik=toycaseoffpeak.cov_jik_0_55;

%%181 users
% delta_jki_RRH=toycaseoffpeak.delta_jki_RRH_0_7;
% cov_jik=toycaseoffpeak.cov_jik_0_7;

%%220 users
%delta_jki_RRH=toycaseoffpeak.delta_jki_RRH_0_85;
%cov_jik=toycaseoffpeak.cov_jik_0_85;

%%260 users
% delta_jki_RRH=toycaseoffpeak.delta_jki_RRH_1;
% cov_jik=toycaseoffpeak.cov_jik_1;

%% initialization
M=10^15;                                                % big coffient number
num_nodes=6;
num_users=length(cov_jik);
num_k=2;

users=users(1:num_users,:);

N_k_RRH=[1,4];
num_k_RRH=length(N_k_RRH);
N_k_BBU=[1,4];
num_k_BBU=length(N_k_BBU);
N_k_MEC=[5];
num_k_MEC=length(N_k_MEC);
k_type=[1,2,2]; % RRH types, BBU types, MEC types
U_k_max=[126, 42];
%U_k_max_pso=[126 42 42 42 42 42];
U_k_max_pso=[126 42 42 42 42 0];
delta_w_BBU=[156 52];
C_i_CHW=[2 2 2 2 4 4];
M_i_CHW=[2 2 2 2 4 4];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% control variables
t=zeros(num_nodes, num_users);                          %traffic per i-th node and j-th user
u=zeros(num_nodes, num_users);                          %boolean indicator, j-th user is connected to the i-th node
r=zeros(num_k_RRH, num_nodes);                              %RRH RFB boolean indicator, if RRH RFB type k installed on node i
b=zeros(num_k_BBU, num_nodes, num_nodes);                   %BBU RFB boolean indicator, b_{kpi}: if BBU RFB type k that is in Node p installed on node i that has any RRH RFB
m=zeros(num_k_MEC, num_nodes, num_nodes);                   %MEC RFB boolean indicator, m_{kpi}: if MEC RFB type k that is in Node p installed on node i that has any RRH RFB and BBU RFB
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Axillary variables
e=zeros(num_nodes, num_k_MEC);                              %Axillary boolean indicator for MEC RFB type k hosted in node i
c=zeros(num_nodes, num_k_MEC);                              %Axillary boolean indicator for MEC RFB type k hosted in node i
d=zeros(num_nodes, num_k_BBU);                              %Axillary boolean indicator for BBU RFB type k hosted in node i
f=zeros(num_nodes, num_k_BBU);                              %Axillary boolean indicator for BBU RFB type k hosted in node i
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
y=randi([0,1],1,num_nodes-1);
y=[1 y];
N_max_used=num_nodes;                                                              %number N_max nodes in the system 
num_swarm=10;                                                              % swarm particle number
maxIt=50;                                                                  % Maximum number of iterations
particle_vector=1:num_swarm;

r=[1 0 0 0 0 0;...
   0 1 1 1 1 0];

N_max_f_val=zeros(N_max_used,num_swarm);
N_max_f_val_old=zeros(N_max_used,num_swarm);
N_max_optimal_vector=zeros(N_max_used,maxIt+1);
N_max_optimal_vector_iter=zeros(1,N_max_used);
N_max_optimal_u=zeros(N_max_used,num_nodes, num_users);
coverag_flag_vector=zeros(N_max_used,num_swarm);
loop_back_counter_vector=zeros(N_max_used,num_swarm);
Tic_toc_vector=zeros(1,N_max_used);
y_ij_N_max_user=zeros(N_max_used,num_nodes, num_swarm);
y_opt=zeros(N_max_used,num_nodes);%%
%% Main body
for N_max_value=1:N_max_used
    tic
% coverag_flag_vector=zeros(1,num_swarm);
% loop_back_counter_vector=zeros(1,num_swarm);
%[ y_ij ] = generate_sumcolequal_N_max(num_nodes-1, num_swarm, N_max_used-1);
[ y_ij ] = generate_sumcolequal_N_max(num_nodes-1, num_swarm, N_max_value-1);
y_ij=[ones(1,num_swarm); y_ij];
y_ij_N_max_user(N_max_value,:,:)=y_ij(:,:);
%[ vel_ij ] = generate_sumcolequal_N_max(num_nodes-1, num_swarm, N_max_used-1);
[ vel_ij ] = generate_sumcolequal_N_max(num_nodes-1, num_swarm, N_max_value-1);
vel_ij=[ones(1,num_swarm); vel_ij];

%mat = randi([0,1],num_swarm,num_nodes);
%rowsum = sum(mat,2);
%mat = bsxfun(@rdivide, mat, rowsum);

U_k_max_pso_des=sort(U_k_max_pso,'descend');

if sum(U_k_max_pso_des(2:N_max_value))<(num_users-U_k_max_pso(1)) % check with the current number of nodes can we cover the users or not! (we assume that the first node is Macro Cell (MC))
    fprintf('The software is infeasible for N_max_used == %i.\n',N_max_value); 
    continue
end

%%% optimize u, r, y 
Particle_value_vector=zeros(num_swarm,num_nodes, num_users);                % normal matrix
Velocity_value_vector=zeros(num_swarm,num_nodes, num_users);                %velocity_vector
Pbest_value_vector=zeros(num_swarm,num_nodes, num_users);                   %Pbest_vector
Gbest_particle=zeros(num_swarm,num_nodes, num_users);                       %Gbest particle
temp=zeros(num_swarm, num_nodes, num_users);
Punishment_Value_vector=zeros(maxIt+1,num_swarm);
fval=zeros(1,num_swarm);                                                      % Save otimizartion for the t+1 loop
fval_old=zeros(1,num_swarm);                                                  % Save otimizartion for the t loop

y_vector=zeros(maxIt+1,num_swarm);
u_vector=zeros(maxIt+1,num_swarm);
optimal_vector=zeros(1,maxIt+1);

objfcn1=zeros(num_users,num_k,num_nodes);
for lpi=1:num_users
    objfcn1(lpi,:,:)=squeeze(delta_jki_RRH(lpi,:,:)).*r;
end

%objfcn =  @(u)(sum(sum(squeeze(delta_jki_RRH(:,1,:)).*r.*u')));           % maxmization
objfcn =  @(u)(sum(sum(squeeze(objfcn1(:,1,:)).*u')));           % maxmization

%% First Heuristic-initialization to catch best u and r
for ii=1:num_swarm
    %%%Swarm particle initialization
    if (sum(y_ij(:,ii))>N_max_value)
    error('Error.\n sum y is more than %s',N_max_used);
    end
u0=zeros(num_nodes, num_users);
    %[val index]=find(y_ij(:,ii)==1);
    [val1 pos1]=ind2sub(size(y_ij(:,ii)),find(ismember(y_ij(:,ii),1))); % to find the proper location of rows in u that should use in the next row formula for the user assignemnts
    U_k_max_pso1=[];
    r1=[];
    cov_jik1=[];
    for tt=1:length(pos1)
        colnum=val1(tt);
        U_k_max_pso1=[U_k_max_pso1 U_k_max_pso(colnum)];
        r1=[r1 r(:,colnum)];    
    end
    for tt=1:length(pos1)
                colnum=val1(tt);
        for kk=1:2
                cov_jik1(:,tt,kk)=cov_jik(:,colnum,kk)*r1(kk,tt); %#ok<SAGROW>
        end
    end
    
[ u , power_state, n_users, n_users_served, flag_user_served, ordered_delta] = generate_u_pso1(cov_jik, num_users, num_k, num_nodes, N_max_value,r, delta_jki_RRH, U_k_max_pso,val1);
% %% present the u on map
% figure(400)
% subplot(1,2,1);
% plot(users(:,1), users(:,2),'.');
% hold on
% plot(nodes_macro(1), nodes_macro(2), 'rO','MarkerSize',8,'MarkerFaceColor','r');
% hold on
% plot(nodes_micro(:,1),nodes_micro(:,2),'ks','MarkerSize',8,'MarkerFaceColor','k');
% legend('Users','Macro Cell','Small Cell');
% xlabel ('[m]','Interpreter','latex','FontSize',20);
% ylabel ('[m]','Interpreter','latex','FontSize',20);
% set(gca,'FontSize',20);
% grid on
% hold off
% 
% subplot(1,2,2);
% plot(users(:,1), users(:,2),'*','MarkerSize',13,'MarkerFaceColor','b');
% hold on
% plot(nodes_macro(1), nodes_macro(2), 'rO','MarkerSize',8,'MarkerFaceColor','r');
% hold on
% plot(nodes_micro(:,1),nodes_micro(:,2),'ks','MarkerSize',8,'MarkerFaceColor','k');
% for j=1:num_users
%     [pos index]=find(u(:,j)==1);
%     if pos==1 % it should connect to macro-cell
%         plot([users(j,1), nodes_macro(1,1)],[users(j,2), nodes_macro(1,2)],'Color','r','LineWidth',3);
%         hold on
%     elseif pos==2 %Microcell1
%         plot([users(j,1), nodes_micro(1,1)],[users(j,2), nodes_micro(1,2)],'Color','g','LineWidth',2);
%         hold on
%     elseif pos==3 %Microcell2
%         plot([users(j,1), nodes_micro(2,1)],[users(j,2), nodes_micro(2,2)],'Color','b','LineWidth',2);
%         hold on
%     elseif pos==4 %microcell3
%         plot([users(j,1), nodes_micro(3,1)],[users(j,2), nodes_micro(3,2)],'Color','k','LineWidth',2);
%         hold on
%     elseif pos==5 %microcell4
%         plot([users(j,1), nodes_micro(4,1)],[users(j,2), nodes_micro(4,2)],'Color','m','LineWidth',2);
%         hold on
%     else
%         continue
%     end
%     
% end
% legend('Users','Macro Cell','Small Cell');
% xlabel ('[m]','Interpreter','latex','FontSize',20);
% ylabel ('[m]','Interpreter','latex','FontSize',20);
% title(['#Users= ' num2str(num_users) ' #nodes= ' num2str(val1') ' #N^{max}_c^*= ' num2str(sum(y_ij(:,ii))) ''],'Interpreter','latex','FontSize',20);
% set(gca,'FontSize',20);
% grid on
% hold off
%% the rest of the heuristic
%u_tempo=zeros(num_nodes,num_users);
%    for i=1:length(pos1)
%        rownum=val1(i);
%        u_tempo(rownum,:)=u(i,:);
%    end
%    u=u_tempo;
    Particle_value_vector(ii,:,:)=u;                                       % particle initialization value
    temporary3=zeros(num_users,num_k,num_nodes);
  for tj=1:num_users
    for tk=1:num_k
        for ti=1:num_nodes
                temporary3(tj,tk,ti)=delta_jki_RRH(tj,tk,ti).*r(tk,ti).*u(ti,tj);
        end 
    end
  end
    fval(ii) =  sum(sum(sum(temporary3)));                % overall Minimize (Pbest)
    u_vector(1,ii)= fval(ii);
    Pbest_value_vector(ii,:,:)=Particle_value_vector(ii,:,:);
    Particle_value_vector_storage=Particle_value_vector;
end
[val index]=max(fval); % find Gbest
Gbest_particle=Pbest_value_vector(index,:,:);
%% First PSO-Main Loop of PSO 


% figure(2+N_max_value)
% subplot(1,2,1);
% plot(1:1:num_swarm, fval(:),'-*r',1:1:num_swarm, fval_old(:),'-*b');
% xlabel('swarm no');
% ylabel('objective');
% legend('\sum_i\delta_{ij} \times u_{ij} (NEW)','\sum_i\delta_{ij} \times u_{ij} (OLD)','Interpreter','latex','FontSize',20);
% grid on
% subplot(2,2,2);
% plot(1:1:maxIt+1, optimal_vector(:),'-b');
% xlabel('PSO iteration loop');
% ylabel('objective');
% legend('\sum_i\delta_{ij} \times u_{ij}','Interpreter','latex','FontSize',20);
% grid on
[value index]=max(fval);

y_opt(N_max_value,:)=squeeze(y_ij_N_max_user(N_max_value,:,index));

N_max_f_val(N_max_value,:)=fval;
N_max_optimal_vector(N_max_value,:)=optimal_vector;
N_max_optimal_u(N_max_value,:,:)=squeeze(Gbest_particle(1,:,1:num_users));
test1=squeeze(Gbest_particle(1,:,1:num_users));
Tic_toc_vector(N_max_value)=toc
end % loop N_max
%time1=toc;
%time1
for t_N_max=1:N_max_used
Max_N_max_f_val(t_N_max)=max(N_max_f_val(t_N_max,:));
end
[value index]=max(Max_N_max_f_val);
if N_max_used==1
u=squeeze(N_max_optimal_u(index,:,1:num_users))';
else
u=squeeze(N_max_optimal_u(index,:,1:num_users));
end
y=y_opt(index,:);

% figure(110)
% plot(1:1:num_swarm,coverag_flag_vector(2,:),'-gd',1:1:num_swarm,coverag_flag_vector(3,:),'-b*',...
%      1:1:num_swarm,coverag_flag_vector(4,:),'--ko',1:1:num_swarm,coverag_flag_vector(5,:),'--gd',1:1:num_swarm,coverag_flag_vector(6,:),'--b*',...
%      'LineWidth', 3,'MarkerSize', 10);
% xlabel('swarm no','Interpreter','latex','FontSize',20);
% ylabel('coverage satisfaction','Interpreter','latex','FontSize',20);
% legend('N_{max}=2 ', 'N_{max}=3 ',...
%        'N_{max}=4 ','N_{max}=5 ', 'N_{max}=6');
% title(['#Users= ' num2str(num_users) ',  #nodes= ' num2str(num_nodes) '']);
% set(gca,'FontSize',20);
% grid on

% figure(120)
% plot(1:1:num_swarm,loop_back_counter_vector(2,:),'-gd',1:1:num_swarm,loop_back_counter_vector(3,:),'-b*',...
%      1:1:num_swarm,loop_back_counter_vector(4,:),'--ko',1:1:num_swarm,loop_back_counter_vector(5,:),'--gd',1:1:num_swarm,loop_back_counter_vector(6,:),'--b*',...
%      'LineWidth', 3,'MarkerSize', 10);
% xlabel('swarm no','Interpreter','latex','FontSize',20);
% ylabel('recursive loop number per swarm','Interpreter','latex','FontSize',20);
% legend('N_{max}=2 ', 'N_{max}=3 ',...
%        'N_{max}=4 ','N_{max}=5 ', 'N_{max}=6');
% title(['#Users= ' num2str(num_users) ',  #nodes= ' num2str(num_nodes) '']);
% set(gca,'FontSize',20);
% grid on


figure(300)
title(['#Users= ' num2str(num_users) ',  #nodes= ' num2str(num_nodes) '']);
%subplot(2,2,1);
plot(1:1:num_swarm, N_max_f_val(2,:),'-ko',1:1:num_swarm, N_max_f_val(3,:),'-b*',1:1:num_swarm, N_max_f_val(4,:),'--kd',...
     1:1:num_swarm, N_max_f_val(5,:),'--gh',1:1:num_swarm, N_max_f_val(6,:),'--rs','LineWidth', 3,'MarkerSize', 10);
 set(gca,'FontSize',20);
xlabel('swarm no','Interpreter','latex','FontSize',20);
ylabel('objective','Interpreter','latex','FontSize',20);
legend('N_{max}=2 ', 'N_{max}=3 ',...
       'N_{max}=4 ','N_{max}=5 ', 'N_{max}=6');
grid on

%subplot(2,2,2);
%plot(2:1:N_max_used, N_max_optimal_vector_iter(2:1:N_max_used),'-b');
% bar(N_max_optimal_vector_iter(1:end));
% set(gca,'FontSize',20);
% xlabel('$N_{Max}$','Interpreter','latex','FontSize',20);
% ylabel('PSO iteration','Interpreter','latex','FontSize',20);
% legend('Iterations');
% grid on

figure(301)
%subplot(2,2,3);
%plot(2:1:N_max_used, N_max_optimal_vector_iter(2:1:N_max_used),'-b');
bar(Max_N_max_f_val(1:end));
set(gca,'FontSize',20);
xlabel('$N_{Max}$','Interpreter','latex','FontSize',20);
ylabel('$\sum_i\delta_{ij} u_{ij}$','Interpreter','latex','FontSize',20);
legend('Objective');
grid on
% UPN=[sum(N_max_optimal_u(1,1,:)), sum(N_max_optimal_u(2,1,:)), sum(N_max_optimal_u(3,1,:)),...
%      sum(N_max_optimal_u(4,1,:)), sum(N_max_optimal_u(5,1,:)), sum(N_max_optimal_u(6,1,:));...Node1=MC
%      sum(N_max_optimal_u(1,2,:)), sum(N_max_optimal_u(2,2,:)), sum(N_max_optimal_u(3,2,:)),...
%      sum(N_max_optimal_u(4,2,:)), sum(N_max_optimal_u(5,2,:)), sum(N_max_optimal_u(6,2,:));...Node2=mc1
%      sum(N_max_optimal_u(1,3,:)), sum(N_max_optimal_u(2,3,:)), sum(N_max_optimal_u(3,3,:)),...
%      sum(N_max_optimal_u(4,3,:)), sum(N_max_optimal_u(5,3,:)), sum(N_max_optimal_u(6,3,:));...Node2=mc2
%      sum(N_max_optimal_u(1,4,:)), sum(N_max_optimal_u(2,4,:)), sum(N_max_optimal_u(3,4,:)),...
%      sum(N_max_optimal_u(4,4,:)), sum(N_max_optimal_u(5,4,:)), sum(N_max_optimal_u(6,4,:));...Node2=mc3
%      sum(N_max_optimal_u(1,5,:)), sum(N_max_optimal_u(2,5,:)), sum(N_max_optimal_u(3,5,:)),...
%      sum(N_max_optimal_u(4,5,:)), sum(N_max_optimal_u(5,5,:)), sum(N_max_optimal_u(6,5,:));...Node2=mc4
%      sum(N_max_optimal_u(1,6,:)), sum(N_max_optimal_u(2,6,:)), sum(N_max_optimal_u(3,6,:)),...
%      sum(N_max_optimal_u(4,6,:)), sum(N_max_optimal_u(5,6,:)), sum(N_max_optimal_u(6,6,:));...Node2=EPC
%      ];
 
figure(302)
UPN=[sum(N_max_optimal_u(1,1,:)),sum(N_max_optimal_u(1,2,:)), sum(N_max_optimal_u(1,3,:)), ... 
    sum(N_max_optimal_u(1,4,:)), sum(N_max_optimal_u(1,5,:)), sum(N_max_optimal_u(1,6,:)); ...N_max=1
    sum(N_max_optimal_u(2,1,:)), sum(N_max_optimal_u(2,2,:)), sum(N_max_optimal_u(2,3,:)), ...
    sum(N_max_optimal_u(2,4,:)), sum(N_max_optimal_u(2,5,:)), sum(N_max_optimal_u(2,6,:)); ...N_max=2
    sum(N_max_optimal_u(3,1,:)), sum(N_max_optimal_u(3,2,:)), sum(N_max_optimal_u(3,3,:)), ...
    sum(N_max_optimal_u(3,4,:)), sum(N_max_optimal_u(3,5,:)), sum(N_max_optimal_u(3,6,:)); ...N_max=3
    sum(N_max_optimal_u(4,1,:)), sum(N_max_optimal_u(4,2,:)), sum(N_max_optimal_u(4,3,:)), ...
    sum(N_max_optimal_u(4,4,:)), sum(N_max_optimal_u(4,5,:)), sum(N_max_optimal_u(4,6,:)); ...N_max=4
    sum(N_max_optimal_u(5,1,:)), sum(N_max_optimal_u(5,2,:)), sum(N_max_optimal_u(5,3,:)), ...
    sum(N_max_optimal_u(5,4,:)), sum(N_max_optimal_u(5,5,:)), sum(N_max_optimal_u(5,6,:)); ...N_max=5
    sum(N_max_optimal_u(6,1,:)), sum(N_max_optimal_u(6,2,:)), sum(N_max_optimal_u(6,3,:)), ...
    sum(N_max_optimal_u(6,4,:)), sum(N_max_optimal_u(6,5,:)), sum(N_max_optimal_u(6,6,:)); ...N_max=6
    ];
%UPN=sum(u,2);
%subplot(2,2,4);
%plot(2:1:N_max_used, N_max_optimal_vector_iter(2:1:N_max_used),'-b');
bar(UPN);
set(gca,'FontSize',20);
xlabel('$N_{max}$','Interpreter','latex','FontSize',20);
ylabel('Users per Node (UpN)','Interpreter','latex','FontSize',20);
legend('MC','mc1','mc2','mc3','mc4','EPC');
grid on

figure(400)
subplot(1,2,1);
plot(users(:,1), users(:,2),'*','MarkerSize',13,'MarkerFaceColor','b');
hold on
plot(nodes_macro(1), nodes_macro(2), 'rO','MarkerSize',8,'MarkerFaceColor','r');
hold on
plot(nodes_micro(:,1),nodes_micro(:,2),'ks','MarkerSize',8,'MarkerFaceColor','k');
title(['#Users= ' num2str(num_users) ' #nodes= ' num2str(num_nodes) ' #N^{max}_c^*= ' num2str(sum(y)) ''],'Interpreter','latex','FontSize',20);
legend('Users','Macro Cell','Small Cell');
xlabel ('[m]','Interpreter','latex','FontSize',20);
ylabel ('[m]','Interpreter','latex','FontSize',20);
set(gca,'FontSize',20);
grid on
hold off


subplot(1,2,2);

plot(users(:,1), users(:,2),'*','MarkerSize',13,'MarkerFaceColor','b');
hold on
plot(nodes_macro(1), nodes_macro(2), 'rO','MarkerSize',8,'MarkerFaceColor','r');
hold on
plot(nodes_micro(:,1),nodes_micro(:,2),'ks','MarkerSize',8,'MarkerFaceColor','k');
for j=1:num_users
[pos index]=find(u(:,j)==1);
if pos==1 % it should connect to macro-cell
plot([users(j,1), nodes_macro(1,1)],[users(j,2), nodes_macro(1,2)],'Color','r','LineWidth',3);
hold on
elseif pos==2 %Microcell1
plot([users(j,1), nodes_micro(1,1)],[users(j,2), nodes_micro(1,2)],'Color','g','LineWidth',2);
hold on
elseif pos==3 %Microcell2
plot([users(j,1), nodes_micro(2,1)],[users(j,2), nodes_micro(2,2)],'Color','b','LineWidth',2);
hold on
elseif pos==4 %microcell3
plot([users(j,1), nodes_micro(3,1)],[users(j,2), nodes_micro(3,2)],'Color','k','LineWidth',2);
hold on
elseif pos==5 %microcell4
plot([users(j,1), nodes_micro(4,1)],[users(j,2), nodes_micro(4,2)],'Color','m','LineWidth',2);
hold on
else
    continue
end

end
legend('Users','Macro Cell','Small Cell');
xlabel ('[m]','Interpreter','latex','FontSize',20);
ylabel ('[m]','Interpreter','latex','FontSize',20);
set(gca,'FontSize',20);
grid on
hold off

%% Update r
%calculate updated r
%[ r ] = generate_r(num_k_RRH, num_nodes, num_users, 0, 1, 1, u, U_k_max, R_k_max, cov_jik, delta_jki_RRH); 
r_temp=r;
r_old=r;
        if sum(r_temp,2)<=N_k_RRH'
            if (sum(r_temp)<=y)
                        r=r_temp;
            else
                [pos2 value2]=ind2sub(size(y(:)),find(ismember(y(:),0))); 
                  r_temp(:,pos2)=0;
                  r=r_temp;
            end
                            
        end
        
figure(401)
subplot(2,1,1);
No_r_old=[r_old(1,1) r_old(2,1);...
          r_old(1,2) r_old(2,2);...
          r_old(1,3) r_old(2,3);...
          r_old(1,4) r_old(2,4);...
          r_old(1,5) r_old(2,5);...
          r_old(1,6) r_old(2,6);...
         ];
    
bar(No_r_old,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('K Types','Interpreter','latex','FontSize',20);
legend('RRH k=1', 'RRH k=2');
title(['r before ']);
set(gca,'FontSize',20);
grid on

subplot(2,1,2);
%No_r_new=[r(1,1) r(1,2) r(1,3) r(1,4) r(1,5) r(1,6);...
%          r(2,1) r(2,2) r(2,3) r(2,4) r(2,5) r(2,6);...
%         ];
No_r_new=[r(1,1) r(2,1);...
          r(1,2) r(2,2);...
          r(1,3) r(2,3);...
          r(1,4) r(2,4);...
          r(1,5) r(2,5);...
          r(1,6) r(2,6);...
         ];
    
bar(No_r_new,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('K Types');
legend('RRH k=1', 'RRH k=2');
title(['r after ']);
set(gca,'FontSize',20);
grid on

figure(402)
bar(Tic_toc_vector(1:end));
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('Round time ($ms$)','Interpreter','latex','FontSize',20);
legend('Iterations');
set(gca,'FontSize',20);
grid on

%%off peak
Optimal_mintraffic=load ('Optimal_offpeak_t_min.txt');
Optimal_maxtraffic=load ('Optimal_offpeak_t_max.txt');

%peak
%Optimal_mintraffic=load ('Optimal_peak_t_min.mat','user_throughput');
%Optimal_mintraffic=Optimal_mintraffic.user_throughput;
%Optimal_maxtraffic=load ('Optimal_peak_t_max.mat','user_throughput');
%Optimal_maxtraffic=Optimal_maxtraffic.user_throughput;

%% Second Particle Generation-PSO for find t, b,
tic
num_swarm=10;                                                               % swarm particle number
maxIt=50;                                                                  % Maximum number of iterations
particle_vector=1:num_swarm;

%%% optimize t 
Particle_value_vector=zeros(num_swarm,num_nodes, num_users);                % normal matrix
Velocity_value_vector=zeros(num_swarm,num_nodes, num_users);                %velocity_vector
Pbest_value_vector=zeros(num_swarm,num_nodes, num_users);                   %Pbest_vector
Gbest_particle=zeros(num_swarm,num_nodes, num_users);                       %Gbest particle
temp=zeros(num_swarm, num_nodes, num_users);
%%% optimize t and y
%Particle_value_vector=zeros(num_swarm,num_nodes, 2*num_users);                % normal matrix
%Pbest_value_vector=zeros(num_swarm,num_nodes, 2*num_users);                   %Pbest_vector
%Velocity_value_vector=zeros(num_swarm,num_nodes, 2*num_users);                %velocity_vector
%Gbest_particle=zeros(num_swarm,num_nodes, 2*num_users);                       %Gbest particle
%temp=zeros(num_swarm, num_nodes, 2*num_users);


%% Second PSO-the rest
fval=zeros(1,num_swarm);                                                      % Save otimizartion for the t+1 loop
fval_old=zeros(1,num_swarm);                                                  % Save otimizartion for the t loop
inertia=1.0;
correction_factor1=2.0;
correction_factor2=2.0;
t=delta_k_MEC.*rand(num_nodes, num_users);
%y=randi([0,1],1,num_nodes-1);
%y=[1 y];
t_vector=zeros(maxIt+1,num_swarm);

%%traffic Peak and off peak.
for k=1:num_k_RRH
 for i=1:num_nodes
     for j=1:num_users
       t(i,j)=max(delta_jki_RRH(j,:,i));  %max traffic over i-th node
       %t(i,j)=min(delta_jki_RRH(j,:,i)); %min traffic over i-th node
     end        
 end
end
% t(i,j)=min(delta_jki_RRH())
% end
punish_threshold=0.01;

save dataset_results1.mat delta_k_MEC M_i_CHW M_ik_BD M_ik_BS M_ik_MD M_ik_MS C_i_CHW C_ik_BD C_ik_BS C_ik_MD C_ik_MS B_i_DHW O_kwz R_k_max delta_jki_RRH U_MAX cov_jik delta_k_BBU ...
                          r u y t  
load dataset_results1.mat delta_k_MEC M_i_CHW M_ik_BD M_ik_BS M_ik_MD M_ik_MS C_i_CHW C_ik_BD C_ik_BS C_ik_MD C_ik_MS B_i_DHW O_kwz R_k_max delta_jki_RRH U_MAX cov_jik delta_k_BBU ...
                          r u y t                      

Punishment_Value_vector=zeros(maxIt+1,num_swarm);
%% Second PSO-Define the objective funcion here (vectorized form)
%objfcn1 =  @(y)(sum(y));                                % minimization
%objfcn2 =  @(t)(sum(sum(t)));                           % maximization
objfcn2=@(t)(1);                                         % no min/max of t
worst_object=[zeros(num_nodes, num_users) ones(num_nodes,num_nodes)]; % worst case (f_w)
%% Second PSO-initialization of the swarms

B_i_DHW=[787.91 122.91 122.91 122.91 122.91 727.99];
 [ Particle particle_storage_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_DWH_i_RRH, delta_DWH_i_BBU, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_jik, delta_k_MEC, O_kwz, M, t, y, u, r);

if (t_accepty)~=1
error('Error.\n we can not find the proper state fot this swarm %s');
end

for ii=1:num_swarm
    %%%Swarm particle initialization
    if (sum(y)>N_max_used)
    error('Error.\n sum y is more than %s',N_max_used);
    end
    %[ Particle particle_storage_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_jik,delta_k_MEC, O_kwz, M, t , y);
   % [ Particle particle_storage_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle_without_u_r(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_jik,delta_k_MEC, O_kwz, M, t , y, u, r);
 [ Particle particle_storage_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_DWH_i_RRH, delta_DWH_i_BBU, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_jik, delta_k_MEC, O_kwz, M, t, y, u, r);
Particle_value_vector(ii,:,:)=Particle;
    %Check constraint satisfaction
%     [ Punishment_Value accp17 accp18 accp19 accp20 accp22 accp23 accp24 accp26 accp28 accp29 accp30 accp31 accp33 accp34 accp37 accp38 accp40 accp43] = generate_particle_punishment(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
%     num_k_MEC, delta_jki_RRH, delta_w_BBU, C_i_MEC, C_i_BBU, M_i_MEC, M_i_BBU, B_i_DHW, C_i_CHW, M_i_CHW, N_k_RRH, N_k_BBU, N_k_MEC, ...
%     U_k_max, R_k_max, cov_jik, delta_k_MEC, O_kwz, M, delta_ik_RRH, particle_storage_cell, t, y);
%     if (Punishment_Value>punish_threshold) % some of the ineqaulity is not-satisfied (out of boundry of solution)
%         fval(ii) =  sum(ones(1,num_nodes))+Punishment_Value;                    % overall Minimize (Pbest)
%     else
%        % fval(ii) =  objfcn1([y])-objfcn2([t]);                    % overall Minimize (Pbest)
       
      fval(ii) =  objfcn2([t]);                                  % overall Minimize (Pbest)
% 
%     end
%    Punishment_Value_vector(1,ii)=Punishment_Value;
    fval_old(ii)=fval(ii);
    %y_vector(1,ii)=objfcn1([y]);
    t_vector(1,ii)=objfcn2([t]);
    y_vector(1,ii)=sum(y);

    %%%velocity initialization
    
    %[ Velocity Velocity_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_jik,delta_k_MEC, O_kwz, M, t, y);
   % [ Velocity Velocity_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle_without_u_r(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_jik,delta_k_MEC, O_kwz, M, t, y, u, r);
   [ Velocity Velocity_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_DWH_i_RRH, delta_DWH_i_BBU, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_jik, delta_k_MEC, O_kwz, M, t, y, u, r);

    Velocity_value_vector(ii,:,:)=Velocity;
    
    %%%primary Pbest initialization
    Pbest_value_vector(ii,:,:)=Particle_value_vector(ii,:,:);
    
end
[val index]=max(fval); % find Gbest
Gbest_particle=Pbest_value_vector(index,:,:);
%% Second PSO-Main Loop of PSO 


iter_out=1;
for iter=1: maxIt
    iter
    % update the velocity of the particles
    for iter1=1:num_swarm
        for i=1:num_nodes
            for j=1:num_users %for j=1:2*num_users
                temp(iter1,i,j)= Gbest_particle(1,i,j)-Particle_value_vector(iter1,i,j);
            end
        end
    end
    Velocity_value_vector=inertia.*Velocity_value_vector+(correction_factor1*rand).*(Pbest_value_vector-Particle_value_vector)+...
        (correction_factor2*rand).*temp; %x velocity component
    
    Particle_value_vector=  Particle_value_vector+Velocity_value_vector; % next particle (t+1)
    
    
    
    for ii=1:num_swarm
        if N_max_used==1
        t=squeeze(Particle_value_vector(ii,:,1:num_users))';
        else
        t=squeeze(Particle_value_vector(ii,:,1:num_users));
        end
        %y=squeeze(Particle_value_vector(ii,:,num_users+1));
        %[t y]=generate_t_y_refinement(t, y,delta_k_MEC, num_nodes, num_users); %refine from out of boundry
        [t]=generate_t_y_refinement_without_y(t, delta_k_MEC, num_nodes, num_users); %refine from out of boundry
        %[t]=generate_t_y_refinement_without_y1(t, delta_k_MEC, num_nodes, num_users,Optimal_mintraffic,Optimal_maxtraffic); %refine from out of boundry
        %[t]=generate_t_y_refinement_without_y2(t, delta_k_MEC, num_nodes, num_users,Optimal_mintraffic,Optimal_maxtraffic); %refine from out of boundry
        %[Particle particle_storage_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_jik,delta_k_MEC, O_kwz, M, t , y);
        %[Particle particle_storage_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle_without_u_r(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_jik,delta_k_MEC, O_kwz, M, t , y, u,r);
        [ Particle particle_storage_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_DWH_i_RRH, delta_DWH_i_BBU, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_jik, delta_k_MEC, O_kwz, M, t, y, u, r);

%        [t]=generate_t_y_refinement_without_y1(t, delta_k_MEC, num_nodes, num_users,Optimal_mintraffic,Optimal_maxtraffic); %refine from out of boundry

        Particle_value_vector(ii,:,:)=Particle;
       % y_vector(iter+1,ii)=objfcn1([y]);
        y_vector(iter+1,ii)=sum(y);

        t_vector(iter+1,ii)=objfcn2([t]);
%        [Punishment_Value accp17 accp18 accp19 accp20 accp22 accp23 accp24 accp26 accp28 accp29 accp30 accp31 accp33 accp34 accp37 accp38 accp40 accp43] = generate_particle_punishment(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
%              num_k_MEC, delta_jki_RRH, delta_w_BBU, C_i_MEC, C_i_BBU, M_i_MEC, M_i_BBU, B_i_DHW, C_i_CHW, M_i_CHW, N_k_RRH, N_k_BBU, N_k_MEC, ...
%              U_k_max, R_k_max, cov_jik, delta_k_MEC, O_kwz, M, delta_ik_RRH, particle_storage_cell, t, y);
%     if (Punishment_Value>punish_threshold) % some of the ineqaulity is not-satisfied (out of boundry of solution)
%         fval(ii) =  sum(ones(1,num_nodes))+Punishment_Value;                    % overall Minimize (Pbest)
%     else
%         fval(ii) =  objfcn1([y])-objfcn2([t]);                    % overall Minimize (Pbest)
         fval(ii) =  objfcn2([t]);                                  % overall Minimize (Pbest)
%     end
%    Punishment_Value_vector(iter+1,ii)=Punishment_Value;
            
        if (fval(ii)>fval_old(ii))                                %if FF(t+1) is better than FF(t) in ii-th particle, clone the ii-particle as Pbest vector
            Pbest_value_vector(ii,:,:)=Particle_value_vector(ii,:,:);
        else
            fval(ii)=fval_old(ii);
        end
        
    end
    %check final convergance
    if (sum(fval_old)==sum(fval)) && (sum(fval_old==fval)==length(fval))
        iter_out=iter+1;
        break
    else
        iter_out=iter+1;
    end
    
    fval_old=fval;
    [val index]=max(fval); % find Gbest
    Gbest_particle=Pbest_value_vector(index,:,:);
    
    %[ Velocity Velocity_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_jik,delta_k_MEC, O_kwz, M);
    %      Velocity_value_vector(ii,:,:)=Velocity;
end
u=particle_storage_cell{1,1};
r=particle_storage_cell{2,1};
b=particle_storage_cell{3,1};
m=particle_storage_cell{4,1};
c=particle_storage_cell{5,1};
d=particle_storage_cell{6,1};
%e=particle_storage_cell{7,1};
%f=particle_storage_cell{8,1};


toc

save dataset_results2.mat particle_storage_cell delta_DWH_i_RRH delta_DWH_i_BBU  C_i_BBU C_i_MEC ...
                             M_i_BBU M_i_MEC iter_out t y u;

%% First-Second PSO-Particle definition

%particle_storage_cell={u;r;b;m};
%Particle=[t y_ij]; % for t_ij and y_ij
%particle_storage_cell{1,1}=u
%particle_storage_cell{2,1}=r
%particle_storage_cell{3,1}=b
%particle_storage_cell{4,1}=m


figure(1000)
plot(1:1:num_swarm, fval,'-*k',1:1:num_swarm, fval_old,'-+b');
xlabel('swarm no','Interpreter','latex','FontSize',20);
ylabel('objective','Interpreter','latex','FontSize',20);
legend('Current Objective','Previous Objective');
set(gca,'FontSize',20);
grid on

figure(1010)
subplot(2,2,1);
Mplots=[C_i_BBU', C_i_MEC'];
bar(Mplots,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
%plot(1:1:num_nodes, C_i_BBU,'-*k',1:1:num_nodes, C_i_BBU,'-*b');
xlabel('Nodes ID','Interpreter','latex','FontSize',20);
ylabel('CPU Utilization [units]','Interpreter','latex','FontSize',20);
legend('BBU','MEC');
set(gca,'FontSize',20);
%legend('BBU','MEC');
grid on

subplot(2,2,2);
Mplots=[M_i_BBU', M_i_MEC'];
bar(Mplots,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('Memory Utilization [units]','Interpreter','latex','FontSize',20);
legend('BBU','MEC','Interpreter','latex','FontSize',20);
set(gca,'FontSize',20);
grid on

subplot(2,2,3);
%b(1,:,:);
%m(1,:,:);
%b(2,:,:);
Mplots=[r(1,:)' r(2,:)'];
No_RFBs=[r(1,1) r(2,1) sum(b(1,:,1)) sum(b(2,:,1)) sum(m(1,:,1));...
         r(1,2) r(2,2) sum(b(1,:,2)) sum(b(2,:,2)) sum(m(1,:,2));...
         r(1,3) r(2,3) sum(b(1,:,3)) sum(b(2,:,3)) sum(m(1,:,3));...
         r(1,4) r(2,4) sum(b(1,:,4)) sum(b(2,:,4)) sum(m(1,:,4));...
         r(1,5) r(2,5) sum(b(1,:,5)) sum(b(2,:,5)) sum(m(1,:,5));...
         r(1,6) r(2,6) sum(b(1,:,6)) sum(b(2,:,6)) sum(m(1,:,6))];
bar(No_RFBs,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('Number of RFBs','Interpreter','latex','FontSize',20);
legend('RRH k=1', 'RRH k=2', 'BBU k=1', 'BBU k=2','MEC');
set(gca,'FontSize',20);
grid on

subplot(2,2,4);
cdfplot(sum(t));
xlabel('Throughput per user [Mbps]','Interpreter','latex','FontSize',20);
ylabel('CDF','Interpreter','latex','FontSize',20);
legend('traffic');
set(gca,'FontSize',20);
grid on

figure(1030)
nobest_users=[sum(Gbest_particle(1,1,1:num_users)) sum(Gbest_particle(1,2,1:num_users))...
    sum(Gbest_particle(1,3,1:num_users)) sum(Gbest_particle(1,4,1:num_users))...
    sum(Gbest_particle(1,5,1:num_users)) sum(Gbest_particle(1,6,1:num_users))];
bar(nobest_users,'FaceColor',[0 .5 .5],'EdgeColor',[0 .9 .9],'LineWidth',1.5);
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('Users Traffic per node [Mbps]','Interpreter','latex','FontSize',20);
set(gca,'FontSize',20);
grid on

figure(1101)


No_RFBs1=[delta_DWH_i_RRH(1) delta_DWH_i_BBU(1);...
         delta_DWH_i_RRH(2)  delta_DWH_i_BBU(2);...
         delta_DWH_i_RRH(3)  delta_DWH_i_BBU(3);...
         delta_DWH_i_RRH(4)  delta_DWH_i_BBU(4);...
         delta_DWH_i_RRH(5)  delta_DWH_i_BBU(5);...
         delta_DWH_i_RRH(6)  delta_DWH_i_BBU(6)];
bar(No_RFBs1,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('DHW Capacity [Mbps]','Interpreter','latex','FontSize',20);
legend('RRH', 'BBU');
set(gca,'FontSize',20);
grid on



% figure(1100)
% plot(1:1:num_swarm, y_vector(iter_out,:),'-*k',1:1:num_swarm, t_vector(iter_out,:),'-+b');
% xlabel('swarm no','Interpreter','latex','FontSize',20);
% ylabel('objective','Interpreter','latex','FontSize',20);
% legend('y Objective','t Objective');
% set(gca,'FontSize',20);
% grid on

% PSO_minnodes_offpeak1=max(t.*u);
% Optimal_minnodes_offpeak=load ('Optimal_offpeak_t_min.txt');
% Optimal_maxnodes_offpeak=load ('Optimal_offpeak_t_max.txt');
% figure(12000)
% h1 = cdfplot(Optimal_minnodes_offpeak);
% set(h1,'Color','b');
% hold on
% %cdfplot(Optimal_maxnodes_offpeak);
% h2 = cdfplot(Optimal_maxnodes_offpeak);
% set(h2,'Color','r');
% hold on
% h3 = cdfplot(PSO_minnodes_offpeak1);
% set(h3,'Color','k');
% hold on
% 
% %cdfplot(PSO_maxnodes_offpeak);
% %h4 = cdfplot(PSO_maxnodes_offpeak1);
% %set(h4,'Color','g');
% %hold on
% 
% xlabel('Throughput per user [Mbps]','Interpreter','latex','FontSize',20);
% ylabel('CDF','Interpreter','latex','FontSize',20);
% legend('Optimal- Min. Nodes','Optimal- Offpeak','PSO- Offpeak');
% set(gca,'FontSize',20);
% grid on


X
