function [ CMat ] = generate_sumcolequal1( m,n,llim, ulim, collim)
%ulim=1;    %max value
%llim=0;    %min value
%rowlim=1;  %max sum for each row
%m=5;    %rows
%n=4;    %columns
CMat=randi([llim, ulim],m, n);
Csum=sum(CMat);
Ccheck=(Csum>collim)| (Csum==0);
while any(Ccheck) %replace any row whose sum is > rowlim
    I=find(Ccheck);
    CMat(:,I)=randi([llim, ulim],m, length(I));
    Csum=sum(CMat);
    Ccheck=(Csum>collim)| (Csum==0);
end
%disp(CMat)


end

