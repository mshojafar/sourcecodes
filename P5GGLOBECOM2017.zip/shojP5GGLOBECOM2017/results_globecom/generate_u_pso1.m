function [ u , power_state, n_users, n_users_served, flag_user_served, ordered_delta] = generate_u_pso1(cov_jik, num_users, num_k, num_nodes, N_max_used,r, delta_jki_RRH, u_max, turned_ON_poslist)
%delta_jki_RRH=load('delta_jki_RRH','delta_jki_RRH');
%cov_ijk=load('delta_jki_RRH','cov_ijk');
%cov_ijk=cov_ijk.cov_ijk;
%cov_jik=cov_ijk;
cov_ij=zeros(num_nodes,num_users);
u=zeros(num_nodes,num_users);
for i=1:num_nodes
    for j=1:num_users
        cov_ij(i,j)=sum(squeeze(cov_jik(j,i,:)).*r(:,i));
    end
end
%delta_jki_RRH=delta_jki_RRH.delta_jki_RRH;
A=delta_jki_RRH;
%// Sort A and get the indices
[sorted_vals,sorted_idx] = sort(A(:),'descend');

%// Set storage for indices as a slot array and then store sorted indices into it
c = cell([1 numel(size(A))]);
[c{:}] = ind2sub(size(A),sorted_idx);

%// Convert c to the requested format and concatenate with slot arary version of
%// sorted values for the desired output
ordered_delta = [num2cell(sorted_vals) mat2cell([c{:}],ones(1,numel(A)),numel(size(A)))];

%u_max=[142 42 42 42 42 0];
n_users=zeros(1,num_nodes);
number_nodes_powered_on=0;
max_number_nodes_powered_on=N_max_used;
n_users_served=0;
flag_user_served=false(1,num_users);
power_state=zeros(1,num_nodes);
for c=1:length(ordered_delta(:,1))
    tic
    % ordered_delta{c,1}
    value=ordered_delta{c,1};
    slot=ordered_delta{c,2};% slot (j,k,i)=k-th type,i-th node, j-th user: slot(1,1)=j  slot(1,2)=k slot(1,3)=i
    if any(slot(1,3)==turned_ON_poslist)% if the served node is must be in the list of available nodes
        
        if (flag_user_served(slot(1,1))==false)
            if (n_users(slot(1,3))<u_max(slot(1,3))) && (cov_ij(slot(1,3),slot(1,1))==1)
                if (power_state(slot(1,3))== 0)
                    if (number_nodes_powered_on<max_number_nodes_powered_on)
                        power_state(slot(1,3))=1;
                        number_nodes_powered_on=number_nodes_powered_on+1;
                        n_users(slot(1,3))=n_users(slot(1,3))+1;
                        n_users_served=n_users_served+1;
                        flag_user_served(slot(1,1))=true;
                        u(slot(1,3),slot(1,1))=1;
                    end
                else
                    n_users(slot(1,3))=n_users(slot(1,3))+1;
                    n_users_served=n_users_served+1;
                    flag_user_served(slot(1,1))=true;
                    u(slot(1,3),slot(1,1))=1;
                end
            end
            
        end
    else
        
    end
end

end