function [ C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH ] = control_vars1(num_k, num_nodes, num_users, num_k_MEC, num_k_BBU, num_k_RRH, delta_jki_RRH, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, r, u, m, b, c, d, t, y)
%%default
delta_ik_RRH=zeros(num_nodes, num_k_RRH); 
C_i_MEC=zeros(1, num_nodes);
C_i_BBU=zeros(1, num_nodes);
M_i_MEC=zeros(1, num_nodes);
M_i_BBU=zeros(1, num_nodes);
for i=1:num_nodes
    for k=1:num_k_MEC
    m(k,:,i)=m(k,:,i)*y(i);
    end
    r(:,i)=r(:,i)*y(i);
    u(i,:)=u(i,:)*y(i);
    for k=1:num_k_BBU
    b(k,:,i)=b(k,:,i)*y(i);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (21)
temp0=zeros(num_k_RRH, num_nodes);
temp=0;
    for i=1:num_nodes
        for k=1:num_k_RRH
            for j=1:num_users
                temp=delta_jki_RRH(j,k,i)*u(i,j)+temp;
            end
            temp0(i,k)=temp;
            temp=0;
           delta_ik_RRH(i,k)=temp0(i,k)*r(k,i); 
        end
    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (32)
temp1=zeros(num_k_MEC, num_nodes);
sumtemp1=0;
for i=1:num_nodes
    for k=1:num_k_MEC
        temp11=sum(t,2);
            for p=1:num_nodes
              sumtemp1=temp11(p)*m(k,p,i)+sumtemp1;
            end
    temp1(k,i)=sumtemp1;
    sumtemp1=0;
    end
end
for i=1:num_nodes
           C_i_MEC(i)=sum(C_ik_MS(i,:)*c(i,:))+sum(C_ik_MD(i,:))*sum(temp1(:,i)); 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (36)
temp2=zeros(num_k_BBU, num_nodes);
sumtemp2=0;
for i=1:num_nodes
    for k=1:num_k_BBU
        temp21=sum(t,2);
            for p=1:num_nodes
              sumtemp2=temp21(p)*b(k,p,i)+sumtemp2;
            end
    temp2(k,i)=sumtemp2;
    sumtemp2=0;
    end
end
for i=1:num_nodes
        
           C_i_BBU(i)=sum(C_ik_BS(i,:)*d(i,:))+sum(C_ik_BD(i,:))*sum(temp2(:,i)); 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (41)
temp3=zeros(num_k_MEC, num_nodes);
sumtemp3=0;
for i=1:num_nodes
    for k=1:num_k_MEC
          temp31=sum(u,2);
            for p=1:num_nodes
              sumtemp3=temp31(p)*m(k,p,i)+sumtemp3;
            end
    temp3(k,i)=sumtemp3;
    sumtemp3=0;
    end
end
for i=1:num_nodes
           M_i_MEC(i)=sum(M_ik_MS(i,:)*c(i,:))+sum(M_ik_MD(i,:))*sum(temp3(:,i)); 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (42)
temp4=zeros(num_k_BBU, num_nodes);
sumtemp4=0;
for i=1:num_nodes
    for k=1:num_k_BBU
        temp41=sum(u,2);
            for p=1:num_nodes
              sumtemp4=temp41(p)*b(k,p,i)+sumtemp4;
            end
    temp4(k,i)=sumtemp4;
    sumtemp4=0;
    end
end
for i=1:num_nodes
        
           M_i_BBU(i)=sum(M_ik_BS(i,:)*d(i,:))+sum(M_ik_BD(i,:))*sum(temp4(:,i)); 
end
    