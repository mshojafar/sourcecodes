function [ CMat ] = generate_sumcolequal_N_max(rows,columns, N_max_used)
%rows = 10;
%columns = 15;
%N_max_used = 4;
% Initialize matrix.
CMat = zeros(rows, columns, 'int32');

for col = 1 : columns
	% Get random order of rows.
	randRows = randperm(rows);
	% Pick out "onesPerColumn" rows that will be set to 1.
	rowsWithOne = randRows(1:N_max_used);
	% Set those rows only to 1 for this column.
	CMat(rowsWithOne, col) = 1;
end
% Display CMat

end

