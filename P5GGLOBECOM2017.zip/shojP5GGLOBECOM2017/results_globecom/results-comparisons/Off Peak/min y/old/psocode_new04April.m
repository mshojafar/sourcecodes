clear all
close all
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Set Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% System Parameters (MIMO)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num_ofdm=7;                                                 % number of ODFM symbols
tau=3;                                                      % OFDM symbols used for pilots
T_c=500/10^6;                                               % coherence time
T_slot=500/10^6;                                            % slot duration
T_s=T_c/num_ofdm;                                           % symbol interval
T_u=66.7/10^6;                                              % useful symbol duration
T_g=T_s - T_u;                                              % guard interval
T_d=T_g;                                                    % Largest possible delay spread
B=20*10^6;                                                  % Total bandwidth
alfa=1;                                                     % frequency reuse factor

loss_exponent=3.8;                                          % path loss exponent
std_dev_db=8;                                            %std-dev variable for shadowing (recall that 10log10(z(i,j,k)) is a zero mean gaussian with a std-dev)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% RFB Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
users=[];
nodes=[];
types=1;                                                    % k type RFB
n_users=27;                                               % j users
%n_users=110;                                               % j users
%n_users=260;  %260                                              % j users
%n_users=50;  %260                                              % j users
max_u=(tau*T_u/T_d);                                        %maximum number of users
U_MAX=max_u;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% BBU RFB Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


S_rate=30.72*10^6;                                          % sampling rate for a carrier at 20 MHz
N_Res=15;                                                   % number of bits per sample
O_CW=16/15;                                                 % control words overhead
O_LC=10/8;                                                  % line coding overhead
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Other Installation Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


nodes_macro=[ 0 0 ];
outer_macro=[-1000 -1000; -1000 1000; 1000 1000; 1000 -1000];
nodes_micro=[120 0; 0 120; -120 0; 0 -120];

%%%for presenting the node plaements
seed1=123;
seed2=3000;
seed3=3455;
seed4=3134;
s1=RandStream.create('mt19937ar','Seed',seed1);
s2=RandStream.create('mt19937ar','Seed',seed2);
s3=RandStream.create('mt19937ar','Seed',seed3);
s4=RandStream.create('mt19937ar','Seed',seed4);
[users nodes] = generate_users_nodes_position(n_users, nodes_macro, nodes_micro, s1,s2);


figure(10)
plot(users(:,1), users(:,2),'.');
hold on
plot(nodes_macro(1), nodes_macro(2), 'rO','MarkerSize',8,'MarkerFaceColor','r');
hold on
plot(nodes_micro(:,1),nodes_micro(:,2),'ks','MarkerSize',8,'MarkerFaceColor','k');
legend('Users','Macro Cell','Small Cell');
xlabel ' [m]'
ylabel '[m]'
set(gca,'FontSize',20);
grid on
hold off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% log normal random variable generation and beta computation of the beta terms for the micro
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
distance=[];
for i=1:size(users,1)
    for j=1:size(nodes,1)
        distance(i,j)=compute_distance(i,j,users,nodes);
        for k=1:size(types,1)
            [z(i,j,k)  s3] =generate_log_normal_random_variable(std_dev_db,s3);
            %z(i,j,k)=10^(4/10);
            beta(i,j,k)=z(i,j,k)/distance(i,j)^loss_exponent;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% log normal random variable generation and beta computation of the beta terms for the outer macros
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
distance=[];
for i=1:size(users,1)
    for j=1:size(outer_macro,1)
        distance=compute_distance(i,j,users,outer_macro);
        for k=1:size(types,1)
            [z_outer_macro(i,j,k)  s4] =generate_log_normal_random_variable(std_dev_db,s4);
            %z(i,j,k)=10^(4/10);
            beta_outer_macro(i,j,k)=z_outer_macro(i,j,k)/distance^loss_exponent;
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% SIR computation for micro
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:size(users,1)
    for j=2:size(nodes,1)
        for k=1:size(types,1)
            den=0;
            for j2=2:size(nodes,1)
                for k2=1:size(types,1)
                    if (j == j2) && (k == k2)
                        %%% Not counting
                    else
                        den=den+beta(i,j2,k2)^2;
                    end
                end
            end
            if(den>0)
                SIR(i,j,k)=beta(i,j,k)^2/den;
            else
                SIR(i,j,k)=beta(i,j,k)^2/10^-32; %#ok<SAGROW>
            end
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% SIR computation for macro
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:size(users,1)
    for k=1:size(types,1)
        den=0;
        for j2=1:size(outer_macro,1)
            for k2=1:size(types,1)
                if (j == j2) && (k == k2)
                    %%% Not counting
                else
                    den=den+beta_outer_macro(i,j2,k2)^2;
                end
            end
        end
        if (den > 0)
            SIR(i,1,k)=beta(i,1,k)^2/den;
        else
            SIR(i,1,k)=beta(i,1,k)^2/10^-32;
        end
    end
end




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Capacity computation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:size(users,1)
    for j=1:size(nodes,1)
        for k=1:size(types,1)
            delta(i,j,k)=(B/alfa)*(num_ofdm-tau-1)/num_ofdm*T_u/T_s*log2(1+SIR(i,j,k));
        end
    end
end

%figure
%plot(10*log10(SIR),'.');



%%%% construction of the delta_ijk
num_k=2;  %%%%% from now on I consider two types of RFB RRH with different capacities
num_users_placed=size(users,1);
num_nodes=size(delta,2)+1; %%%% Added also the EPC node

delta_Mbps=delta/10^6; %%%%%%%%%%%%%%%% transformation of delta into Mpbs
for i=1:size(users,1)
    delta_Mbps(i,num_nodes)=0;  %%%%the last node is the EPC, its capacity is zero since it can not install any RRH
end


delta_ikj_RRH=zeros(num_users_placed,num_k,num_nodes);

for i=1:num_users_placed
    for j=1:num_nodes-1
        delta_ikj_RRH(i,1,j)=delta_Mbps(i,j);
        delta_ikj_RRH(i,2,j)=delta_Mbps(i,j);
    end
    delta_ikj_RRH(i,1,num_nodes)=0;   %%%%%% the EPC does not host any RRH
    delta_ikj_RRH(i,2,num_nodes)=0;   %%%%%% the EPC does not host any RRH
end

%%%%%%%%% construction of the cov_ijk

min_throghput_value=10^-15;
cov_ijk=[];
cov_ij=[];
for i=1:num_users_placed
    for j=1:num_nodes
        for k=1:num_k
            if delta_Mbps(i,j) <= min_throghput_value
                cov_ij(i,j)=0;
            else
                cov_ij(i,j)=1;
            end
            if delta_ikj_RRH(i,k,j)<=min_throghput_value
                cov_ijk(i,j,k)=0;
            else
                cov_ijk(i,j,k)=1;
            end
        end
    end
end


%%%%%% computation of user throughput

%plot(delta/(10^6),'.');
[user_throughput max_index]=max(delta_Mbps,[],2);

edges=1:1:size(nodes,1);
connected_users = hist(max_index,edges);

%%%%%% computation of node throughput with best eNB

node_throughput=[];
for i=1:(size(nodes_micro,1)+1)
    node_throughput(i)=0;
end

for i=1:length(user_throughput)
    node_throughput(max_index(i))=node_throughput(max_index(i))+user_throughput(i);
end

%%%%%%%%%% computation of nodes throughput with all the users connected to
%%%%%%%%%% each node

for i=1:size(delta,2)
    node_max_throughput(i)=sum(delta_Mbps(:,i));
end

%%%%%%%%%%%%%%%% from the nodes throughput the maximum capacity of the each
%%%%%%%%%%%%%%%% type is set

R_k_max=[node_max_throughput(1)/0.84 max(node_max_throughput(2:num_nodes-1))/0.84];    %%%%% the maximum throughput on each RRH type is taken from node_max_throughput + a safe margin


%%%%%%%%%% computation of compatibility chain parameter O_kwz

num_k_RRH=num_k;
num_k_BBU=2;
num_k_MEC=1;

O_kwz=zeros(num_k_RRH,num_k_BBU,num_k_MEC);

%%%%%%%%% the ratio is the following BBU and RRH of the same type are
%%%%%%%%% required, while MEC can be big or small
O_kwz(2,2,1)=1;
O_kwz(1,1,1)=1;


%%%%%%%% dimensioning the BBU capacity (around ten times the RRH capacity)

delta_k_BBU=R_k_max*10;


%%%%%%%%%%%% dimensioning the node capacity dedicated HW
over_provisioning_factor=0.5;
B_i_DHW=[];
B_i_DHW(1)=(R_k_max(1)+delta_k_BBU(1)+delta_k_BBU(2)*4)/over_provisioning_factor; %%% the macro can host one macro RRH, one macro BBU + the micro BBUs
for i=2:num_nodes-1
    B_i_DHW(i)=(R_k_max(2)+delta_k_BBU(2))/over_provisioning_factor;  %%%each micro is dimensioned to host one RRH + one BBU + a bit of overprovisioning
end
B_i_DHW(num_nodes)=(delta_k_BBU(1)+delta_k_BBU(2)*4)/over_provisioning_factor;   %%%% the EPC node can host the macro BBU + the micro BBUs


%%%%%%%%%%%% dimensioning the C-HW part

%%%%%%%%%%%%%% mec capacity (CPU)
%%% a the macro node can host at most the micro and the macro MEC RFBs together
%%%% the micro can host one MEC RFB
%%%% the EPC can host all the MEC RFBS
%%%%
%%%% the static capacity is set to 50% if this value
tot_MEC_cap=[R_k_max(1)+(num_nodes-2)*R_k_max(2)  R_k_max(2) R_k_max(2) R_k_max(2) R_k_max(2) R_k_max(1)+(num_nodes-2)*R_k_max(2)];

%%%%%%%%% static and dynamic MEC capacity (CPU)
C_ik_MS=[0.5 0.5 0.5 0.5 0.5 0.5];   %%%% I have inserted an high initial cost
C_ik_MD=(1.-C_ik_MS)./tot_MEC_cap;

%%%%%%%%%%%%%% static and dyanamic BBU capacity (CPU)
C_ik_BS=C_ik_MS;
C_ik_BD=C_ik_MD;


%%%%%%%%%%%%%% node capacity (CPU)
%%% the macro node can host 1 MEC from the macro itself and 4 MEC from the
%%% micro

C_i_CHW=C_ik_MS+C_ik_MD.*tot_MEC_cap+C_ik_BS+C_ik_BD.*tot_MEC_cap;





%%%%%%%%%%%%%% mec capacity (memory)
M_ik_MS=[0.5 0.5 0.5 0.5 0.5 0.5];   %%%% I have inserted an high initial cost
num_users_micro=max(connected_users(2:length(connected_users)));
num_users_mec=[num_users_placed num_users_micro num_users_micro num_users_micro num_users_micro num_users_placed];

M_ik_MD=(1-M_ik_MS)./num_users_mec;

M_ik_BS=M_ik_MS;
M_ik_BD=M_ik_MD;

M_i_CHW=M_ik_MS+M_ik_MD.*num_users_mec+M_ik_BS+M_ik_BD.*num_users_mec;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% MEC Capacity provided to users
delta_k_MEC=R_k_max(1);     %%%%%%%%%%% this is a loose constraint, as we have already taken into account the traffic of users in the computation of CPU and memory capacity for each node






%%%%%%%%%%%%%%%%%% link capacity - it is largely overprovisioned at this
%%%%%%%%%%%%%%%%%% time
cap_min=(delta_k_BBU(2))/0.5;
cap_max=(delta_k_BBU(2)*(num_nodes-2)+delta_k_BBU(1))/0.5;

C_L_ab=[0 cap_min cap_min cap_min cap_min cap_max; cap_min 0 0 0 0 0; cap_min 0 0 0 0 0; cap_min 0 0 0 0 0; cap_min 0 0 0 0 0; 0 0 0 0 cap_max 0];

alfa_param=1;

save toy_case_example.mat alfa_param C_L_ab delta_k_MEC M_i_CHW M_ik_BD M_ik_BS M_ik_MD M_ik_MS C_i_CHW C_ik_BD C_ik_BS C_ik_MD C_ik_MS B_i_DHW O_kwz R_k_max delta_ikj_RRH U_MAX cov_ijk delta_k_BBU



%M_i_

%plot(y,'.');
min_user_throughput=min(user_throughput);
max_user_throughput=max(user_throughput);
%[edges_throughput cdf_throughput]=ecdf(user_throughput, min_user_throughput, max_user_throughput);
[edges_throughput cdf_throughput]=my_ecdf(user_throughput, min_user_throughput, max_user_throughput);
%figure
%hh  = plot (edges_throughput, cdf_throughput,'b','LineWidth',2);
%grid on
%xlabel 'Maximum Throughput per User [Mbps]'
%ylabel 'Cumulative Distribution Function'


user_throughput_macro=delta(:,1,1)/10^6;
%plot(y,'.')
%[edges_throughput_macro cdf_throughput_macro]=ecdf(user_throughput_macro, min_user_throughput,max_user_throughput);
[edges_throughput_macro cdf_throughput_macro]=my_ecdf(user_throughput_macro, min_user_throughput,max_user_throughput);
%figure
%hold on
%plot (edges_throughput_macro, cdf_throughput_macro,'b','LineWidth',2);
%grid on
%xlabel 'Maximum Throughput per User [Mbps]'
%ylabel 'Cumulative Distribution Function'
user_throughput_micro=[];
edges_throughput_micro=[];
cdf_throughput_micro=[];
%for j=2:size(nodes,1)
%    user_throughput_micro(j,:)=delta(:,j,1)/10^6;
%    [edges_throughput_micro(j,:) cdf_throughput_micro(j,:)]=my_ecdf(user_throughput_micro(j,:), min_user_throughput, max_user_throughput);
%   plot (edges_throughput_micro(j,:), cdf_throughput_micro(j,:));
%   hold on
%end
%legend('Macro', 'SC1','SC2');
%hold off
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M=10^15;                                                % big coffient number

num_users= size(users,1);                               %users number -peak
%num_users= size(users,1);                               %users number -off peak
%num_k                                                  %type number
%num_nodes                                              %nodes number
delta_jki_RRH=delta_ikj_RRH;
N_k_RRH=[1,4];
num_k_RRH=length(N_k_RRH);
N_k_BBU=[1,4];
num_k_BBU=length(N_k_BBU);
N_k_MEC=[5];
num_k_MEC=length(N_k_MEC);
k_type=[1,2,2]; % RRH types, BBU types, MEC types
U_k_max=[126, 42];
%U_k_max_pso=[126 42 42 42 42 42];
U_k_max_pso=[126 42 42 42 42 0];
delta_w_BBU=[156 52];
C_i_CHW=[2 2 2 2 4 4];
M_i_CHW=[2 2 2 2 4 4];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% control variables
t=zeros(num_nodes, num_users);                          %traffic per i-th node and j-th user
u=zeros(num_nodes, num_users);                          %boolean indicator, j-th user is connected to the i-th node
r=zeros(num_k_RRH, num_nodes);                              %RRH RFB boolean indicator, if RRH RFB type k installed on node i
b=zeros(num_k_BBU, num_nodes, num_nodes);                   %BBU RFB boolean indicator, b_{kpi}: if BBU RFB type k that is in Node p installed on node i that has any RRH RFB
m=zeros(num_k_MEC, num_nodes, num_nodes);                   %MEC RFB boolean indicator, m_{kpi}: if MEC RFB type k that is in Node p installed on node i that has any RRH RFB and BBU RFB
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Axillary variables
e=zeros(num_nodes, num_k_MEC);                              %Axillary boolean indicator for MEC RFB type k hosted in node i
c=zeros(num_nodes, num_k_MEC);                              %Axillary boolean indicator for MEC RFB type k hosted in node i
d=zeros(num_nodes, num_k_BBU);                              %Axillary boolean indicator for BBU RFB type k hosted in node i
f=zeros(num_nodes, num_k_BBU);                              %Axillary boolean indicator for BBU RFB type k hosted in node i
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PSO parmetrs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% swarm_size = 64;                       % number of the swarm particles
% num_swarm = 50;                          % maximum number of iterations
% inertia = 1.0;
% correction_factor = 2.0;
% % set the position of the initial swarm
% a = 1:8;
%[X,Y] = meshgrid(a,a);
%C = cat(2,X',Y');
%D = reshape(C,[],2);
%swarm(1:swarm_size,1,1:2) = D;          % set the position of the particles in 2D
%swarm(:,2,:) = 0;                       % set initial velocity for particles
%swarm(:,4,1) = 1000;                    % set the best value so far
%plotObjFcn = 1;                         % set to zero if you do not need a final plot

% %%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%% PSO constraint inituialization
% t=delta_k_MEC.*rand(num_nodes, num_users);
% y=randi([0,1],1,num_nodes);
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %num_users=4;
% %num_nodes=3;
% %%%(eq 16) \sum(u_ij)=1 \forall j
% [ u ] = generate_sumcolequal(num_nodes, num_users,0, 1, 1);
% %%%(eq 19)  \sum(r_ki)\leq 1 \forall i
% %[ r ] = generate_sumcollequal(num_k, num_nodes,0, 1, 1);
% %%%eq. (16)+(18)(19)(20)(21)(22)
% [ r ] = generate_r(num_k_RRH, num_nodes, num_users, 0, 1, N_k_RRH, u, U_k_max, R_k_max, cov_ijk);
% %%%eq (25)(26)(29)
% [ b bcounter] = generate_b(num_k_BBU, num_nodes, num_nodes, 0, 1, N_k_BBU, r, O_kwz);
% %%%eq (27)(28)
% [ m mcounter] = generate_m(num_k_MEC, num_nodes, num_nodes, 0, 1, N_k_MEC, r);
% %%%eq (23)(24)(30)
% [ t_acceptt, t_acc23, t_acc24, t_acc30 t r u m] = feasibility_check_t(num_k, num_nodes, num_users, t, r, u, m, delta_jki_RRH, delta_k_MEC, N_k_RRH, N_k_MEC, M);
% %%%eq (33)(34)(35)
% [ t_accept2, t_acc33, t_acc34, t_acc35 e c m ] = axillary_var1(num_k_MEC, num_nodes, m, M);
% %%%eq (37)(38)(39)
% [ t_accep3, t_acc37, t_acc38, t_acc39 f d b ] = axillary_var2(num_k_BBU, num_nodes, b, M);
% %% control decsisions Eqs. (21) (32) (36) (41) (42)
% [ C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH ] = control_vars(num_k, num_nodes, num_users, num_k_MEC, num_k_BBU, num_k_RRH, delta_jki_RRH, C_ik_MS', C_ik_MD', C_ik_BS', C_ik_BD', M_ik_MS', M_ik_MD', M_ik_BS', M_ik_BD', r, u, m, b, c, d, e, f, t);
% %%% conrol variable decision (feasibility_check for y)
% %%%eq (31)(40)(43)
% [ t_accepty, t_acc31, t_acc40, t_acc43 y ] = feasibility_check_y(num_k, num_k_RRH, num_k_BBU, num_k_MEC, num_nodes, r, b, delta_ik_RRH, delta_w_BBU, B_i_DHW, C_i_MEC, C_i_BBU,C_i_CHW, M_i_MEC, M_i_BBU, M_i_CHW, y);
% y_ij=zeros(num_nodes, num_users);
% for j=1:num_users
% y_ij(:,j)=y(:);
% end
%% manual calculation of U and r
u=randi([0,1],num_nodes, num_users);
[ u ] = generate_sumcolequal1(num_nodes, num_users,0, 1, 1);
%%%(eq 19)  \sum(r_ki)\leq 1 \forall i
%[ r ] = generate_sumcollequal(num_k, num_nodes,0, 1, 1);
%%%eq. (16)+(18)(19)(20)(21)(22)
%[ r ] = generate_r1(num_k_RRH, num_nodes, num_users, 0, 1, N_k_RRH, u, U_k_max, R_k_max, cov_ijk);
%% First Particle Generation-PSO for find u, r and y
y=randi([0,1],1,num_nodes-1);
y=[1 y];
N_max_used=num_nodes;                                                              %number N_max nodes in the system 
num_swarm=10;                                                              % swarm particle number
maxIt=50;                                                                  % Maximum number of iterations
particle_vector=1:num_swarm;

r=[1 0 0 0 0 0;...
   0 1 1 1 1 0];

N_max_f_val=zeros(N_max_used,num_swarm);
N_max_f_val_old=zeros(N_max_used,num_swarm);
N_max_optimal_vector=zeros(N_max_used,maxIt+1);
N_max_optimal_vector_iter=zeros(1,N_max_used);
N_max_optimal_u=zeros(N_max_used,num_nodes, num_users);
coverag_flag_vector=zeros(N_max_used,num_swarm);
loop_back_counter_vector=zeros(N_max_used,num_swarm);
Tic_toc_vector=zeros(1,N_max_used);
y_ij_N_max_user=zeros(N_max_used,num_nodes, num_swarm);
y_opt=zeros(N_max_used,num_nodes);
for N_max_value=1:N_max_used
    tic
% coverag_flag_vector=zeros(1,num_swarm);
% loop_back_counter_vector=zeros(1,num_swarm);
%[ y_ij ] = generate_sumcolequal_N_max(num_nodes-1, num_swarm, N_max_used-1);
[ y_ij ] = generate_sumcolequal_N_max(num_nodes-1, num_swarm, N_max_value-1);
y_ij=[ones(1,num_swarm); y_ij];
y_ij_N_max_user(N_max_value,:,:)=y_ij(:,:);
%[ vel_ij ] = generate_sumcolequal_N_max(num_nodes-1, num_swarm, N_max_used-1);
[ vel_ij ] = generate_sumcolequal_N_max(num_nodes-1, num_swarm, N_max_value-1);
vel_ij=[ones(1,num_swarm); vel_ij];

%mat = randi([0,1],num_swarm,num_nodes);
%rowsum = sum(mat,2);
%mat = bsxfun(@rdivide, mat, rowsum);

U_k_max_pso_des=sort(U_k_max_pso,'descend');

if sum(U_k_max_pso_des(2:N_max_value))<(num_users-U_k_max_pso(1)) % check with the current number of nodes can we cover the users or not! (we assume that the first node is Macro Cell (MC))
    fprintf('The software is infeasible for N_max_used == %i.\n',N_max_value); 
    continue
end

%%% optimize u, r, y 
Particle_value_vector=zeros(num_swarm,num_nodes, num_users);                % normal matrix
Velocity_value_vector=zeros(num_swarm,num_nodes, num_users);                %velocity_vector
Pbest_value_vector=zeros(num_swarm,num_nodes, num_users);                   %Pbest_vector
Gbest_particle=zeros(num_swarm,num_nodes, num_users);                       %Gbest particle
temp=zeros(num_swarm, num_nodes, num_users);
punish_threshold=0.01;
Punishment_Value_vector=zeros(maxIt+1,num_swarm);
fval=zeros(1,num_swarm);                                                      % Save otimizartion for the t+1 loop
fval_old=zeros(1,num_swarm);                                                  % Save otimizartion for the t loop
inertia=1.0;
correction_factor1=2.0;
correction_factor2=2.0;
y_vector=zeros(maxIt+1,num_swarm);
u_vector=zeros(maxIt+1,num_swarm);
optimal_vector=zeros(1,maxIt+1);
worst_object=[zeros(num_nodes, num_users) ones(num_nodes,num_nodes)];         % worst case (f_w)

cov_jik=cov_ijk;

objfcn =  @(u)(sum(sum(squeeze(delta_jki_RRH(:,1,:)).*u')));           % minimization
%% First PSO-initialization of the swarms


for ii=1:num_swarm
    %%%Swarm particle initialization
    if (sum(y_ij(:,ii))>N_max_value)
    error('Error.\n sum y is more than %s',N_max_used);
    end
    
    u0=zeros(num_nodes, num_users);
    %[val index]=find(y_ij(:,ii)==1);
    [val1 pos1]=ind2sub(size(y_ij(:,ii)),find(ismember(y_ij(:,ii),1))); % to find the proper location of rows in u that should use in the next row formula for the user assignemnts
    U_k_max_pso1=[];
    r1=[];
    cov_jik1=[];
    for tt=1:length(pos1)
        colnum=val1(tt);
        U_k_max_pso1=[U_k_max_pso1 U_k_max_pso(colnum)];
        r1=[r1 r(:,colnum)];
        
        
    end
    for tt=1:length(pos1)
                colnum=val1(tt);
        for kk=1:2
                cov_jik1(:,tt,kk)=cov_jik(:,colnum,kk)*r1(kk,tt); %#ok<SAGROW>
        end
    end
    if (sum(U_k_max_pso1)>=num_users) % the current set of nodes is able to cover the users
    
    %[ u ] = generate_sumcolequal3(length(pos1), num_users, 1, y_ij(:,ii), U_k_max_pso1);
   % [ u , u_rowSums ] = generate_sumcolequal4(length(pos1), num_users, 1, y_ij(:,ii), U_k_max_pso1');
   U_k_max_pso1=U_k_max*r1;
   counter=0;
    %[ u , u_rowSums, coverag_flag, counter ] = generate_sumcolequal5(length(pos1), num_users, 1, y_ij(:,ii), U_k_max_pso1(:), r1, sum(cov_jik1,3)', counter);
    [ u , u_rowSums, coverag_flag, counter ] = generate_sumcolequal6(length(pos1), num_users, 1, y_ij(:,ii), U_k_max_pso1(:), r1, sum(cov_jik1,3)', counter);
    coverag_flag_vector(N_max_value,ii)=coverag_flag;
    loop_back_counter_vector(N_max_value,ii)=counter;
    u_tempo=zeros(num_nodes,num_users);
    for i=1:length(pos1)
        rownum=val1(i);
        u_tempo(rownum,:)=u(i,:);
    end
    u=u_tempo;
    else % if the set of nodes unable to cover the incoming users
        u=zeros(num_nodes,num_users);
    end
    Particle_value_vector(ii,:,:)=u;                                       % particle initialization value
  % [ r ] = generate_r(num_k_RRH, num_nodes, num_users, 0, 1, 1, u, U_k_max, R_k_max, cov_ijk); 
  temporary3=zeros(num_users,num_k,num_nodes);
  for tj=1:num_users
    for tk=1:num_k
        for ti=1:num_nodes
                temporary3(tj,tk,ti)=delta_jki_RRH(tj,tk,ti).*r(tk,ti).*u(ti,tj);
        end 
    end
  end
   
    
    fval(ii) =  sum(sum(sum(temporary3)));                % overall Minimize (Pbest)
    fval_old(ii)=fval(ii);
    u_vector(1,ii)= fval(ii);
    
    
    u0=zeros(num_nodes, num_users);
    [val1 pos1]=ind2sub(size(vel_ij(:,ii)),find(ismember(vel_ij(:,ii),1))); % to find the proper location of rows in velocity that should use in the next row formula for the user assignemnts 
    r1=[];
    U_k_max_pso1=[];
    cov_jik1=[];
    for tt=1:length(pos1)
        colnum=val1(tt);
        U_k_max_pso1=[U_k_max_pso1 U_k_max_pso(colnum)];
        r1=[r1 r(:,colnum)];
    end
    for tt=1:length(pos1)
          colnum=val1(tt);
        for kk=1:2
                cov_jik1(:,tt,kk)=cov_jik(:,colnum,kk)*r1(kk,tt); %#ok<SAGROW>
        end
    end
    if (sum(U_k_max_pso1)>=num_users) % the current set of nodes is able to cover the users
        
    %[ velocity ] = generate_sumcolequal3(length(pos1), num_users, 1, vel_ij(:,ii),U_k_max_pso1);
    %[ velocity , velocity_rowSums ] = generate_sumcolequal4(length(pos1), num_users, 1, vel_ij(:,ii), U_k_max_pso1');
       U_k_max_pso1=U_k_max*r1;
       counter=0;
    %[ velocity , velocity_rowSums, coverag_flag, counter ] = generate_sumcolequal5(length(pos1), num_users, 1, vel_ij(:,ii), U_k_max_pso1(:), r1, sum(cov_jik1,3)', counter);
    [ velocity , velocity_rowSums, coverag_flag, counter ] = generate_sumcolequal6(length(pos1), num_users, 1, vel_ij(:,ii), U_k_max_pso1(:), r1, sum(cov_jik1,3)', counter);
    velocity_tempo=zeros(num_nodes,num_users);
    for i=1:length(pos1)
        rownum=val1(i);
        velocity_tempo(rownum,:)=velocity(i,:);
    end
     velocity=velocity_tempo;
    else % if the set of nodes unable to cover the incoming users
        velocity=zeros(num_nodes,num_users);
    end
   
    Velocity_value_vector(ii,:,:)=velocity;                                  % velicity initialization value
   Velocity_value_vector_storage=Velocity_value_vector;
    

    %%%primary Pbest initialization
    Pbest_value_vector(ii,:,:)=Particle_value_vector(ii,:,:);
    Particle_value_vector_storage=Particle_value_vector;
end
[val index]=max(fval); % find Gbest
Gbest_particle=Pbest_value_vector(index,:,:);
 optimal_vector(1)=val;
% figure(1)
% plot(1:1:num_swarm, fval(:),'-*b');
% xlabel('swarm no');
% ylabel('objective');
% legend('\sum_i\delta_{ij} \times u_{ij}');
% grid on
%% First PSO-Main Loop of PSO 

iter_out=1;
for iter=1: maxIt
    iter
    % update the velocity of the particles
    for iter1=1:num_swarm
        for i=1:num_nodes
            for j=1:num_users %for j=1:2*num_users
                temp(iter1,i,j)= Gbest_particle(1,i,j)-Particle_value_vector(iter1,i,j);
            end
        end
    end
    Velocity_value_vector=inertia.*Velocity_value_vector+(correction_factor1*rand).*(Pbest_value_vector-Particle_value_vector)+...
        (correction_factor2*rand).*temp; %x velocity component
    
    Particle_value_vector=  Particle_value_vector+Velocity_value_vector; % next particle (t+1)
    
    
    for ii=1:num_swarm
        
        %control u matrix
        u=squeeze(Particle_value_vector(ii,:,1:num_users));
       [u]=generate_u_refinement(u, y_ij(:,ii), num_nodes, num_users); %refine from out of boundry
       
       u_failed=0;
        for j=1:num_users
            if sum(u(:,j))~=1
             u_failed=u_failed+1;
             end
        end
        if u_failed~=0
        Particle_value_vector(ii,:,:)=Particle_value_vector_storage(ii,:,:); % if new u is not satisfy  \sum_i u=1 keep the old one
        else
        Particle_value_vector_storage(ii,:,:)=u;
        Particle_value_vector(ii,:,:)=u;
        end
        
        %control velocity matrix
       velocity=squeeze(Velocity_value_vector(ii,:,1:num_users));
       [velocity]=generate_u_refinement(velocity, vel_ij(:,ii), num_nodes, num_users); %refine from out of boundry
       v_failed=0;
        for j=1:num_users
            if sum(velocity(:,j))~=1
             v_failed=v_failed+1;
             end
        end
        if v_failed~=0
        Velocity_value_vector(ii,:,:)=Velocity_value_vector_storage(ii,:,:); % if new u is not satisfy  \sum_i velocity=1 keep the old one
        else
        Velocity_value_vector_storage(ii,:,:)=velocity;
        end
        
        %pso controllers
        
    temporary3=zeros(num_users,num_k,num_nodes);
  for tj=1:num_users
    for tk=1:num_k
        for ti=1:num_nodes
                temporary3(tj,tk,ti)=delta_jki_RRH(tj,tk,ti).*r(tk,ti).*u(ti,tj);
        end 
    end
  end
    fval(ii) =  sum(sum(sum(temporary3)));                % overall Minimize (Pbest)
    
    u_vector(iter+1,ii)= fval(ii);
        

            
        if (fval(ii)<fval_old(ii))                                %if FF(t+1) is better than FF(t) in ii-th particle, clone the ii-particle as Pbest vector
            Pbest_value_vector(ii,:,:)=Particle_value_vector(ii,:,:);
        else
            fval(ii)=fval_old(ii);
        end
        
    end %swarm loop
    %check final convergance
    if (sum(fval_old)==sum(fval)) && (sum(fval_old==fval)==length(fval))
        iter_out=iter+1;
        [val index]=max(fval); % find Gbest
        Gbest_particle=Pbest_value_vector(index,:,:);
        optimal_vector(iter_out)=max(fval);
        y_opt(N_max_value,:)=squeeze(y_ij_N_max_user(N_max_value,:,index));
        break
    else
        iter_out=iter+1;
    end
    
    fval_old=fval;
    [val index]=max(fval); % find Gbest
    Gbest_particle=Pbest_value_vector(index,:,:);
    optimal_vector(iter_out)=val;
    y_opt(N_max_value,:)=squeeze(y_ij_N_max_user(N_max_value,:,index));
end % For maIt iteration
% figure(2+N_max_value)
% subplot(1,2,1);
% plot(1:1:num_swarm, fval(:),'-*r',1:1:num_swarm, fval_old(:),'-*b');
% xlabel('swarm no');
% ylabel('objective');
% legend('\sum_i\delta_{ij} \times u_{ij} (NEW)','\sum_i\delta_{ij} \times u_{ij} (OLD)','Interpreter','latex','FontSize',20);
% grid on
% subplot(2,2,2);
% plot(1:1:maxIt+1, optimal_vector(:),'-b');
% xlabel('PSO iteration loop');
% ylabel('objective');
% legend('\sum_i\delta_{ij} \times u_{ij}','Interpreter','latex','FontSize',20);
% grid on
N_max_f_val(N_max_value,:)=fval;
N_max_f_val_old(N_max_value,:)=fval_old;
N_max_optimal_vector(N_max_value,:)=optimal_vector;
N_max_optimal_vector_iter(N_max_value)=iter_out;
N_max_optimal_u(N_max_value,:,:)=squeeze(Gbest_particle(1,:,1:num_users));
test1=squeeze(Gbest_particle(1,:,1:num_users));
Tic_toc_vector(N_max_value)=toc
end % loop N_max
%time1=toc;
%time1
for t_N_max=1:N_max_used
Max_N_max_f_val(t_N_max)=max(N_max_f_val(t_N_max,:));
end
[value index]=max(Max_N_max_f_val);
u=squeeze(N_max_optimal_u(index,:,1:num_users));
y=y_opt(index,:);

figure(110)
plot(1:1:num_swarm,coverag_flag_vector(2,:),'-gd',1:1:num_swarm,coverag_flag_vector(3,:),'-b*',...
     1:1:num_swarm,coverag_flag_vector(4,:),'--ko',1:1:num_swarm,coverag_flag_vector(5,:),'--gd',1:1:num_swarm,coverag_flag_vector(6,:),'--b*',...
     'LineWidth', 3,'MarkerSize', 10);
xlabel('swarm no','Interpreter','latex','FontSize',20);
ylabel('coverage satisfaction','Interpreter','latex','FontSize',20);
legend('N_{max}=2 ', 'N_{max}=3 ',...
       'N_{max}=4 ','N_{max}=5 ', 'N_{max}=6');
title(['#Users= ' num2str(num_users) ',  #nodes= ' num2str(num_nodes) '']);
set(gca,'FontSize',20);
grid on

figure(120)
plot(1:1:num_swarm,loop_back_counter_vector(2,:),'-gd',1:1:num_swarm,loop_back_counter_vector(3,:),'-b*',...
     1:1:num_swarm,loop_back_counter_vector(4,:),'--ko',1:1:num_swarm,loop_back_counter_vector(5,:),'--gd',1:1:num_swarm,loop_back_counter_vector(6,:),'--b*',...
     'LineWidth', 3,'MarkerSize', 10);
xlabel('swarm no','Interpreter','latex','FontSize',20);
ylabel('recursive loop number per swarm','Interpreter','latex','FontSize',20);
legend('N_{max}=2 ', 'N_{max}=3 ',...
       'N_{max}=4 ','N_{max}=5 ', 'N_{max}=6');
title(['#Users= ' num2str(num_users) ',  #nodes= ' num2str(num_nodes) '']);
set(gca,'FontSize',20);
grid on


figure(300)
title(['#Users= ' num2str(num_users) ',  #nodes= ' num2str(num_nodes) '']);
subplot(2,2,1);
plot(1:1:num_swarm, N_max_f_val(2,:),'-ko',1:1:num_swarm, N_max_f_val(3,:),'-b*',1:1:num_swarm, N_max_f_val(4,:),'--kd',...
     1:1:num_swarm, N_max_f_val(5,:),'--gh',1:1:num_swarm, N_max_f_val(6,:),'--rs','LineWidth', 3,'MarkerSize', 10);
 set(gca,'FontSize',20);
xlabel('swarm no','Interpreter','latex','FontSize',20);
ylabel('objective','Interpreter','latex','FontSize',20);
legend('N_{max}=2 ', 'N_{max}=3 ',...
       'N_{max}=4 ','N_{max}=5 ', 'N_{max}=6');
grid on
subplot(2,2,2);
%plot(2:1:N_max_used, N_max_optimal_vector_iter(2:1:N_max_used),'-b');
bar(N_max_optimal_vector_iter(1:end));
set(gca,'FontSize',20);
xlabel('$N_{Max}$','Interpreter','latex','FontSize',20);
ylabel('PSO iteration','Interpreter','latex','FontSize',20);
legend('Iterations');
grid on

subplot(2,2,3);
%plot(2:1:N_max_used, N_max_optimal_vector_iter(2:1:N_max_used),'-b');
bar(N_max_optimal_vector(1:end,1));
set(gca,'FontSize',20);
xlabel('$N_{Max}$','Interpreter','latex','FontSize',20);
ylabel('$\sum_i\delta_{ij} u_{ij}$','Interpreter','latex','FontSize',20);
legend('Objective');
grid on
% UPN=[sum(N_max_optimal_u(1,1,:)), sum(N_max_optimal_u(2,1,:)), sum(N_max_optimal_u(3,1,:)),...
%      sum(N_max_optimal_u(4,1,:)), sum(N_max_optimal_u(5,1,:)), sum(N_max_optimal_u(6,1,:));...Node1=MC
%      sum(N_max_optimal_u(1,2,:)), sum(N_max_optimal_u(2,2,:)), sum(N_max_optimal_u(3,2,:)),...
%      sum(N_max_optimal_u(4,2,:)), sum(N_max_optimal_u(5,2,:)), sum(N_max_optimal_u(6,2,:));...Node2=mc1
%      sum(N_max_optimal_u(1,3,:)), sum(N_max_optimal_u(2,3,:)), sum(N_max_optimal_u(3,3,:)),...
%      sum(N_max_optimal_u(4,3,:)), sum(N_max_optimal_u(5,3,:)), sum(N_max_optimal_u(6,3,:));...Node2=mc2
%      sum(N_max_optimal_u(1,4,:)), sum(N_max_optimal_u(2,4,:)), sum(N_max_optimal_u(3,4,:)),...
%      sum(N_max_optimal_u(4,4,:)), sum(N_max_optimal_u(5,4,:)), sum(N_max_optimal_u(6,4,:));...Node2=mc3
%      sum(N_max_optimal_u(1,5,:)), sum(N_max_optimal_u(2,5,:)), sum(N_max_optimal_u(3,5,:)),...
%      sum(N_max_optimal_u(4,5,:)), sum(N_max_optimal_u(5,5,:)), sum(N_max_optimal_u(6,5,:));...Node2=mc4
%      sum(N_max_optimal_u(1,6,:)), sum(N_max_optimal_u(2,6,:)), sum(N_max_optimal_u(3,6,:)),...
%      sum(N_max_optimal_u(4,6,:)), sum(N_max_optimal_u(5,6,:)), sum(N_max_optimal_u(6,6,:));...Node2=EPC
%      ];
 

UPN=[sum(N_max_optimal_u(1,1,:)),sum(N_max_optimal_u(1,2,:)), sum(N_max_optimal_u(1,3,:)), ... 
    sum(N_max_optimal_u(1,4,:)), sum(N_max_optimal_u(1,5,:)), sum(N_max_optimal_u(1,6,:)); ...N_max=1
    sum(N_max_optimal_u(2,1,:)), sum(N_max_optimal_u(2,2,:)), sum(N_max_optimal_u(2,3,:)), ...
    sum(N_max_optimal_u(2,4,:)), sum(N_max_optimal_u(2,5,:)), sum(N_max_optimal_u(2,6,:)); ...N_max=2
    sum(N_max_optimal_u(3,1,:)), sum(N_max_optimal_u(3,2,:)), sum(N_max_optimal_u(3,3,:)), ...
    sum(N_max_optimal_u(3,4,:)), sum(N_max_optimal_u(3,5,:)), sum(N_max_optimal_u(3,6,:)); ...N_max=3
    sum(N_max_optimal_u(4,1,:)), sum(N_max_optimal_u(4,2,:)), sum(N_max_optimal_u(4,3,:)), ...
    sum(N_max_optimal_u(4,4,:)), sum(N_max_optimal_u(4,5,:)), sum(N_max_optimal_u(4,6,:)); ...N_max=4
    sum(N_max_optimal_u(5,1,:)), sum(N_max_optimal_u(5,2,:)), sum(N_max_optimal_u(5,3,:)), ...
    sum(N_max_optimal_u(5,4,:)), sum(N_max_optimal_u(5,5,:)), sum(N_max_optimal_u(5,6,:)); ...N_max=5
    sum(N_max_optimal_u(6,1,:)), sum(N_max_optimal_u(6,2,:)), sum(N_max_optimal_u(6,3,:)), ...
    sum(N_max_optimal_u(6,4,:)), sum(N_max_optimal_u(6,5,:)), sum(N_max_optimal_u(6,6,:)); ...N_max=6
    ];
%UPN=sum(u,2);
subplot(2,2,4);
%plot(2:1:N_max_used, N_max_optimal_vector_iter(2:1:N_max_used),'-b');
bar(UPN);
set(gca,'FontSize',20);
xlabel('$N_{max}$','Interpreter','latex','FontSize',20);
ylabel('Users per Node (UpN)','Interpreter','latex','FontSize',20);
legend('MC','mc1','mc2','mc3','mc4','EPC');

grid on

figure(400)
subplot(1,2,1);
plot(users(:,1), users(:,2),'.');
hold on
plot(nodes_macro(1), nodes_macro(2), 'rO','MarkerSize',8,'MarkerFaceColor','r');
hold on
plot(nodes_micro(:,1),nodes_micro(:,2),'ks','MarkerSize',8,'MarkerFaceColor','k');
legend('Users','Macro Cell','Small Cell');
xlabel ('[m]','Interpreter','latex','FontSize',20);
ylabel ('[m]','Interpreter','latex','FontSize',20);
set(gca,'FontSize',20);
grid on
hold off


subplot(1,2,2);
plot(users(:,1), users(:,2),'*','MarkerSize',13,'MarkerFaceColor','b');
hold on
plot(nodes_macro(1), nodes_macro(2), 'rO','MarkerSize',8,'MarkerFaceColor','r');
hold on
plot(nodes_micro(:,1),nodes_micro(:,2),'ks','MarkerSize',8,'MarkerFaceColor','k');
for j=1:num_users
[pos index]=find(u(:,j)==1);
if pos==1 % it should connect to macro-cell
plot([users(j,1), nodes_macro(1,1)],[users(j,2), nodes_macro(1,2)],'Color','r','LineWidth',3);
hold on
elseif pos==2 %Microcell1
plot([users(j,1), nodes_micro(1,1)],[users(j,2), nodes_micro(1,2)],'Color','g','LineWidth',2);
hold on
elseif pos==3 %Microcell2
plot([users(j,1), nodes_micro(2,1)],[users(j,2), nodes_micro(2,2)],'Color','b','LineWidth',2);
hold on
elseif pos==4 %microcell3
plot([users(j,1), nodes_micro(3,1)],[users(j,2), nodes_micro(3,2)],'Color','k','LineWidth',2);
hold on
elseif pos==5 %microcell4
plot([users(j,1), nodes_micro(4,1)],[users(j,2), nodes_micro(4,2)],'Color','m','LineWidth',2);
hold on
else
    continue
end

end
legend('Users','Macro Cell','Small Cell');
xlabel ('[m]','Interpreter','latex','FontSize',20);
ylabel ('[m]','Interpreter','latex','FontSize',20);
title(['#Users= ' num2str(num_users) ' #nodes= ' num2str(num_nodes) ' #N^{max}_c^*= ' num2str(sum(y)) ''],'Interpreter','latex','FontSize',20);
set(gca,'FontSize',20);
grid on
hold off

%% Update r
%calculate updated r
%[ r ] = generate_r(num_k_RRH, num_nodes, num_users, 0, 1, 1, u, U_k_max, R_k_max, cov_ijk, delta_jki_RRH); 
r_temp=r;
r_old=r;
        if sum(r_temp,2)<=N_k_RRH'
            if (sum(r_temp)<=y)
                        r=r_temp;
            else
                [pos2 value2]=ind2sub(size(y(:)),find(ismember(y(:),0))); 
                  r_temp(:,pos2)=0;
                  r=r_temp;
            end
                            
        end
        
figure(401)
subplot(2,1,1);
No_r_old=[r_old(1,1) r_old(2,1);...
          r_old(1,2) r_old(2,2);...
          r_old(1,3) r_old(2,3);...
          r_old(1,4) r_old(2,4);...
          r_old(1,5) r_old(2,5);...
          r_old(1,6) r_old(2,6);...
         ];
    
bar(No_r_old,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('K Types','Interpreter','latex','FontSize',20);
legend('RRH k=1', 'RRH k=2');
title(['r before ']);
set(gca,'FontSize',20);
grid on

subplot(2,1,2);
%No_r_new=[r(1,1) r(1,2) r(1,3) r(1,4) r(1,5) r(1,6);...
%          r(2,1) r(2,2) r(2,3) r(2,4) r(2,5) r(2,6);...
%         ];
No_r_new=[r(1,1) r(2,1);...
          r(1,2) r(2,2);...
          r(1,3) r(2,3);...
          r(1,4) r(2,4);...
          r(1,5) r(2,5);...
          r(1,6) r(2,6);...
         ];
    
bar(No_r_new,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('K Types');
legend('RRH k=1', 'RRH k=2');
title(['r after ']);
set(gca,'FontSize',20);
grid on

figure(402)
bar(Tic_toc_vector(1:end));
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('Round time ($ms$)','Interpreter','latex','FontSize',20);
legend('Iterations');
set(gca,'FontSize',20);
grid on




%% Second Particle Generation-PSO for find t, b,
tic
num_swarm=10;                                                               % swarm particle number
maxIt=50;                                                                  % Maximum number of iterations
particle_vector=1:num_swarm;

%%% optimize t 
Particle_value_vector=zeros(num_swarm,num_nodes, num_users);                % normal matrix
Velocity_value_vector=zeros(num_swarm,num_nodes, num_users);                %velocity_vector
Pbest_value_vector=zeros(num_swarm,num_nodes, num_users);                   %Pbest_vector
Gbest_particle=zeros(num_swarm,num_nodes, num_users);                       %Gbest particle
temp=zeros(num_swarm, num_nodes, num_users);
%%% optimize t and y
%Particle_value_vector=zeros(num_swarm,num_nodes, 2*num_users);                % normal matrix
%Pbest_value_vector=zeros(num_swarm,num_nodes, 2*num_users);                   %Pbest_vector
%Velocity_value_vector=zeros(num_swarm,num_nodes, 2*num_users);                %velocity_vector
%Gbest_particle=zeros(num_swarm,num_nodes, 2*num_users);                       %Gbest particle
%temp=zeros(num_swarm, num_nodes, 2*num_users);


%% Second PSO-the rest
fval=zeros(1,num_swarm);                                                      % Save otimizartion for the t+1 loop
fval_old=zeros(1,num_swarm);                                                  % Save otimizartion for the t loop
inertia=1.0;
correction_factor1=2.0;
correction_factor2=2.0;
t=delta_k_MEC.*rand(num_nodes, num_users);
%y=randi([0,1],1,num_nodes-1);
%y=[1 y];
t_vector=zeros(maxIt+1,num_swarm);

%%traffic Peak and off peak.
for k=1:num_k_RRH
 for i=1:num_nodes
     for j=1:num_users
       t(i,j)=max(delta_jki_RRH(j,:,i));  %max traffic over i-th node
       %t(i,j)=min(delta_jki_RRH(j,:,i)); %min traffic over i-th node
     end        
 end
end
% t(i,j)=min(delta_jki_RRH())
% end
punish_threshold=0.01;

save dataset_mediumpeak1.mat alfa_param C_L_ab delta_k_MEC M_i_CHW M_ik_BD M_ik_BS M_ik_MD M_ik_MS C_i_CHW C_ik_BD C_ik_BS C_ik_MD C_ik_MS B_i_DHW O_kwz R_k_max delta_ikj_RRH U_MAX cov_ijk delta_k_BBU ...
                          r u y t  
load dataset_mediumpeak1.mat alfa_param C_L_ab delta_k_MEC M_i_CHW M_ik_BD M_ik_BS M_ik_MD M_ik_MS C_i_CHW C_ik_BD C_ik_BS C_ik_MD C_ik_MS B_i_DHW O_kwz R_k_max delta_ikj_RRH U_MAX cov_ijk delta_k_BBU ...
                          r u y t                      

Punishment_Value_vector=zeros(maxIt+1,num_swarm);
%% Second PSO-Define the objective funcion here (vectorized form)
%objfcn1 =  @(y)(sum(y));                                % minimization
objfcn2 =  @(t)(sum(sum(t)));                           % maximization
objfcn2=@(t)(1);                                              % no min/max of t
worst_object=[zeros(num_nodes, num_users) ones(num_nodes,num_nodes)]; % worst case (f_w)
%% Second PSO-initialization of the swarms

B_i_DHW=[787.91 122.91 122.91 122.91 122.91 727.99];
 [ Particle particle_storage_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_DWH_i_RRH, delta_DWH_i_BBU, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_ijk, delta_k_MEC, O_kwz, M, t, y, u, r);

if (t_accepty)~=1
error('Error.\n we can not find the proper state fot this swarm %s');
end

for ii=1:num_swarm
    %%%Swarm particle initialization
    if (sum(y)>N_max_used)
    error('Error.\n sum y is more than %s',N_max_used);
    end
    %[ Particle particle_storage_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_ijk,delta_k_MEC, O_kwz, M, t , y);
   % [ Particle particle_storage_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle_without_u_r(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_ijk,delta_k_MEC, O_kwz, M, t , y, u, r);
 [ Particle particle_storage_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_DWH_i_RRH, delta_DWH_i_BBU, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_ijk, delta_k_MEC, O_kwz, M, t, y, u, r);
Particle_value_vector(ii,:,:)=Particle;
    %Check constraint satisfaction
%     [ Punishment_Value accp17 accp18 accp19 accp20 accp22 accp23 accp24 accp26 accp28 accp29 accp30 accp31 accp33 accp34 accp37 accp38 accp40 accp43] = generate_particle_punishment(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
%     num_k_MEC, delta_jki_RRH, delta_w_BBU, C_i_MEC, C_i_BBU, M_i_MEC, M_i_BBU, B_i_DHW, C_i_CHW, M_i_CHW, N_k_RRH, N_k_BBU, N_k_MEC, ...
%     U_k_max, R_k_max, cov_ijk, delta_k_MEC, O_kwz, M, delta_ik_RRH, particle_storage_cell, t, y);
%     if (Punishment_Value>punish_threshold) % some of the ineqaulity is not-satisfied (out of boundry of solution)
%         fval(ii) =  sum(ones(1,num_nodes))+Punishment_Value;                    % overall Minimize (Pbest)
%     else
%        % fval(ii) =  objfcn1([y])-objfcn2([t]);                    % overall Minimize (Pbest)
       
      fval(ii) =  objfcn2([t]);                                  % overall Minimize (Pbest)
% 
%     end
%    Punishment_Value_vector(1,ii)=Punishment_Value;
    fval_old(ii)=fval(ii);
    %y_vector(1,ii)=objfcn1([y]);
    t_vector(1,ii)=objfcn2([t]);
    y_vector(1,ii)=sum(y);

    %%%velocity initialization
    
    %[ Velocity Velocity_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_ijk,delta_k_MEC, O_kwz, M, t, y);
   % [ Velocity Velocity_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle_without_u_r(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_ijk,delta_k_MEC, O_kwz, M, t, y, u, r);
   [ Velocity Velocity_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_DWH_i_RRH, delta_DWH_i_BBU, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_ijk, delta_k_MEC, O_kwz, M, t, y, u, r);

    Velocity_value_vector(ii,:,:)=Velocity;
    
    %%%primary Pbest initialization
    Pbest_value_vector(ii,:,:)=Particle_value_vector(ii,:,:);
    
end
[val index]=max(fval); % find Gbest
Gbest_particle=Pbest_value_vector(index,:,:);
%% Second PSO-Main Loop of PSO 


iter_out=1;
for iter=1: maxIt
    iter
    % update the velocity of the particles
    for iter1=1:num_swarm
        for i=1:num_nodes
            for j=1:num_users %for j=1:2*num_users
                temp(iter1,i,j)= Gbest_particle(1,i,j)-Particle_value_vector(iter1,i,j);
            end
        end
    end
    Velocity_value_vector=inertia.*Velocity_value_vector+(correction_factor1*rand).*(Pbest_value_vector-Particle_value_vector)+...
        (correction_factor2*rand).*temp; %x velocity component
    
    Particle_value_vector=  Particle_value_vector+Velocity_value_vector; % next particle (t+1)
    
    
    
    for ii=1:num_swarm
        t=squeeze(Particle_value_vector(ii,:,1:num_users));
        %y=squeeze(Particle_value_vector(ii,:,num_users+1));
        %[t y]=generate_t_y_refinement(t, y,delta_k_MEC, num_nodes, num_users); %refine from out of boundry
        [t]=generate_t_y_refinement_without_y(t, delta_k_MEC, num_nodes, num_users); %refine from out of boundry
        %[Particle particle_storage_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_ijk,delta_k_MEC, O_kwz, M, t , y);
        %[Particle particle_storage_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle_without_u_r(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_ijk,delta_k_MEC, O_kwz, M, t , y, u,r);
        [ Particle particle_storage_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_DWH_i_RRH, delta_DWH_i_BBU, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_ijk, delta_k_MEC, O_kwz, M, t, y, u, r);


        Particle_value_vector(ii,:,:)=Particle;
       % y_vector(iter+1,ii)=objfcn1([y]);
        y_vector(iter+1,ii)=sum(y);

        t_vector(iter+1,ii)=objfcn2([t]);
%        [Punishment_Value accp17 accp18 accp19 accp20 accp22 accp23 accp24 accp26 accp28 accp29 accp30 accp31 accp33 accp34 accp37 accp38 accp40 accp43] = generate_particle_punishment(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
%              num_k_MEC, delta_jki_RRH, delta_w_BBU, C_i_MEC, C_i_BBU, M_i_MEC, M_i_BBU, B_i_DHW, C_i_CHW, M_i_CHW, N_k_RRH, N_k_BBU, N_k_MEC, ...
%              U_k_max, R_k_max, cov_ijk, delta_k_MEC, O_kwz, M, delta_ik_RRH, particle_storage_cell, t, y);
%     if (Punishment_Value>punish_threshold) % some of the ineqaulity is not-satisfied (out of boundry of solution)
%         fval(ii) =  sum(ones(1,num_nodes))+Punishment_Value;                    % overall Minimize (Pbest)
%     else
%         fval(ii) =  objfcn1([y])-objfcn2([t]);                    % overall Minimize (Pbest)
         fval(ii) =  objfcn2([t]);                                  % overall Minimize (Pbest)
%     end
%    Punishment_Value_vector(iter+1,ii)=Punishment_Value;
            
        if (fval(ii)>fval_old(ii))                                %if FF(t+1) is better than FF(t) in ii-th particle, clone the ii-particle as Pbest vector
            Pbest_value_vector(ii,:,:)=Particle_value_vector(ii,:,:);
        else
            fval(ii)=fval_old(ii);
        end
        
    end
    %check final convergance
    if (sum(fval_old)==sum(fval)) && (sum(fval_old==fval)==length(fval))
        iter_out=iter+1;
        break
    else
        iter_out=iter+1;
    end
    
    fval_old=fval;
    [val index]=max(fval); % find Gbest
    Gbest_particle=Pbest_value_vector(index,:,:);
    
    %[ Velocity Velocity_cell C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter t_acceptt t_accepty t y] = generate_particle(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, U_k_max, R_k_max, cov_ijk,delta_k_MEC, O_kwz, M);
    %      Velocity_value_vector(ii,:,:)=Velocity;
end
u=particle_storage_cell{1,1};
r=particle_storage_cell{2,1};
b=particle_storage_cell{3,1};
m=particle_storage_cell{4,1};
c=particle_storage_cell{5,1};
d=particle_storage_cell{6,1};
%e=particle_storage_cell{7,1};
%f=particle_storage_cell{8,1};


toc

save dataset_mediumpeak2.mat particle_storage_cell delta_DWH_i_RRH delta_DWH_i_BBU  C_i_BBU C_i_MEC ...
                             M_i_BBU M_i_MEC iter_out t y;

%% First-Second PSO-Particle definition

%particle_storage_cell={u;r;b;m};
%Particle=[t y_ij]; % for t_ij and y_ij
%particle_storage_cell{1,1}=u
%particle_storage_cell{2,1}=r
%particle_storage_cell{3,1}=b
%particle_storage_cell{4,1}=m


figure(1000)
plot(1:1:num_swarm, fval,'-*k',1:1:num_swarm, fval_old,'-+b');
xlabel('swarm no','Interpreter','latex','FontSize',20);
ylabel('objective','Interpreter','latex','FontSize',20);
legend('Current Objective','Previous Objective');
set(gca,'FontSize',20);
grid on

figure(1010)
subplot(2,2,1);
Mplots=[C_i_BBU', C_i_MEC'];
bar(Mplots,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
%plot(1:1:num_nodes, C_i_BBU,'-*k',1:1:num_nodes, C_i_BBU,'-*b');
xlabel('Nodes ID','Interpreter','latex','FontSize',20);
ylabel('CPU Utilization [units]','Interpreter','latex','FontSize',20);
legend('BBU','MEC');
set(gca,'FontSize',20);
%legend('BBU','MEC');
grid on

subplot(2,2,2);
Mplots=[M_i_BBU', M_i_MEC'];
bar(Mplots,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('Memory Utilization [units]','Interpreter','latex','FontSize',20);
legend('BBU','MEC','Interpreter','latex','FontSize',20);
set(gca,'FontSize',20);
grid on

subplot(2,2,3);
%b(1,:,:);
%m(1,:,:);
%b(2,:,:);
Mplots=[r(1,:)' r(2,:)'];
No_RFBs=[r(1,1) r(2,1) sum(b(1,:,1)) sum(b(2,:,1)) sum(m(1,:,1));...
         r(1,2) r(2,2) sum(b(1,:,2)) sum(b(2,:,2)) sum(m(1,:,2));...
         r(1,3) r(2,3) sum(b(1,:,3)) sum(b(2,:,3)) sum(m(1,:,3));...
         r(1,4) r(2,4) sum(b(1,:,4)) sum(b(2,:,4)) sum(m(1,:,4));...
         r(1,5) r(2,5) sum(b(1,:,5)) sum(b(2,:,5)) sum(m(1,:,5));...
         r(1,6) r(2,6) sum(b(1,:,6)) sum(b(2,:,6)) sum(m(1,:,6))];
bar(No_RFBs,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('Number of RFBs','Interpreter','latex','FontSize',20);
legend('RRH k=1', 'RRH k=2', 'BBU k=1', 'BBU k=2','MEC');
set(gca,'FontSize',20);
grid on

subplot(2,2,4);
cdfplot(sum(t));
xlabel('Throughput per user [Mbps]','Interpreter','latex','FontSize',20);
ylabel('CDF','Interpreter','latex','FontSize',20);
legend('traffic');
set(gca,'FontSize',20);
grid on

figure(1030)
nobest_users=[sum(Gbest_particle(1,1,1:num_users)) sum(Gbest_particle(1,2,1:num_users))...
    sum(Gbest_particle(1,3,1:num_users)) sum(Gbest_particle(1,4,1:num_users))...
    sum(Gbest_particle(1,5,1:num_users)) sum(Gbest_particle(1,6,1:num_users))];
bar(nobest_users,'FaceColor',[0 .5 .5],'EdgeColor',[0 .9 .9],'LineWidth',1.5);
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('Users Traffic per node [Mbps]','Interpreter','latex','FontSize',20);
set(gca,'FontSize',20);
grid on

figure(1101)


No_RFBs1=[delta_DWH_i_RRH(1) delta_DWH_i_BBU(1);...
         delta_DWH_i_RRH(2)  delta_DWH_i_BBU(2);...
         delta_DWH_i_RRH(3)  delta_DWH_i_BBU(3);...
         delta_DWH_i_RRH(4)  delta_DWH_i_BBU(4);...
         delta_DWH_i_RRH(5)  delta_DWH_i_BBU(5);...
         delta_DWH_i_RRH(6)  delta_DWH_i_BBU(6)];
bar(No_RFBs1,'stacked');
set(gca, 'XTickLabel', {'MC','SC1','SC2','SC3','SC4','EPC'},...
    'XTick',[1 2 3 4 5 6]);
ylabel('DHW Capacity [Mbps]','Interpreter','latex','FontSize',20);
legend('RRH', 'BBU');
set(gca,'FontSize',20);
grid on



figure(1100)
plot(1:1:num_swarm, y_vector(iter_out,:),'-*k',1:1:num_swarm, t_vector(iter_out,:),'-+b');
xlabel('swarm no','Interpreter','latex','FontSize',20);
ylabel('objective','Interpreter','latex','FontSize',20);
legend('y Objective','t Objective');
set(gca,'FontSize',20);
grid on

% figure(1110)
% plot(1:1:iter_out, Punishment_Value_vector(:,1)', '-*b');
% xlabel('Iterations');
% ylabel('Punishment Error Rate');
% legend('Error Rate');
% grid on

X






% %%%%%%%%%%%%%%%%%%%%test
% ulim=1;    %max value
% llim=0;    %min value
% rowlim=[1,4];  %max sum for each row
% m=2;    %rows
% n=4;    %columns
% o=3;   %height
% RMat=randi([0, 1],m, n, o);
% test=sum(RMat,3);
% Rsum=sum(test,2);
% Rcheck=(Rsum'>rowlim);
% while any(Rcheck) %replace any row whose sum is > rowlim
%     I=find(Rcheck);
%     update=zeros(n,o);
%     %for k1=1:m
%      for k2=1:length(I)
%      t=I(k2);
%      update=randi([0, 1],n, o);
%      RMat(t,:,:)=update;
%      %end
%      end
%     test=sum(RMat,3);
%     Rsum=sum(test,2);
%     Rcheck=(Rsum'>rowlim);
% end
% disp(RMat)