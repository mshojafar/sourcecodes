clc 
clear all
close all


Optimal_minnodes_peak=load ('Optimal_peak_t_min.mat','user_throughput');
Optimal_minnodes_peak=Optimal_minnodes_peak.user_throughput;

Optimal_maxnodes_peak=load ('Optimal_peak_t_max.mat','user_throughput');
Optimal_maxnodes_peak=Optimal_maxnodes_peak.user_throughput;

% PSO_minnodes_peak=load ('PSO_peak_t_min.mat','t');
% PSO_minnodes_peak=PSO_minnodes_peak.t;
% 
% PSO_minnodes_peaku=load ('PSO_peak_t_min1.mat','u');
% PSO_minnodes_peaku=PSO_minnodes_peaku.u;

% PSO_minnodes_peak=load ('PSO_peak_t_min2.mat','t');
% PSO_minnodes_peak=PSO_minnodes_peak.t;
% 
% PSO_minnodes_peaku=load ('PSO_peak_t_min2.mat','u');
% PSO_minnodes_peaku=PSO_minnodes_peaku.u;


%  PSO_minnodes_peak=load ('PSO_peak_t_min3.mat','t');
%  PSO_minnodes_peak=PSO_minnodes_peak.t;
% 
%  PSO_minnodes_peaku=load ('PSO_peak_t_min3.mat','u');
%  PSO_minnodes_peaku=PSO_minnodes_peaku.u;
 
 PSO_minnodes_peak=load ('PSO_peak_t_min4.mat','t');
 PSO_minnodes_peak=PSO_minnodes_peak.t;

 PSO_minnodes_peaku=load ('PSO_peak_t_min4.mat','u');
 PSO_minnodes_peaku=PSO_minnodes_peaku.u;


 PSO_minnodes_peak1=(max(PSO_minnodes_peak.*PSO_minnodes_peaku));


% PSO_maxnodes_peak=load ('PSO_peak_t_max2.mat','t');   
% PSO_maxnodes_peak=PSO_maxnodes_peak.t;
% 
% PSO_maxnodes_peaku=load ('PSO_peak_t_max2.mat','u');
% PSO_maxnodes_peaku=PSO_maxnodes_peaku.u;

% PSO_maxnodes_peak=load ('PSO_peak_t_max3.mat','t');
% PSO_maxnodes_peak=PSO_maxnodes_peak.t;
% 
% PSO_maxnodes_peaku=load ('PSO_peak_t_max3.mat','u');
% PSO_maxnodes_peaku=PSO_maxnodes_peaku.u;

PSO_maxnodes_peak=load ('PSO_peak_t_max4.mat','t');
PSO_maxnodes_peak=PSO_maxnodes_peak.t;

PSO_maxnodes_peaku=load ('PSO_peak_t_max4.mat','u');
PSO_maxnodes_peaku=PSO_maxnodes_peaku.u;

PSO_maxnodes_peak1=(max(PSO_maxnodes_peak.*PSO_maxnodes_peaku));

figure(10)
%cdfplot(Optimal_minnodes_peak);
h1 = cdfplot(Optimal_minnodes_peak);
set(h1,'Color','b');
hold on

%cdfplot(Optimal_maxnodes_peak);
h2 = cdfplot(Optimal_maxnodes_peak);
set(h2,'Color','r');
hold on

%cdfplot(PSO_minnodes_peak);
h3 = cdfplot(PSO_minnodes_peak1);
set(h3,'Color','k');
hold on

%cdfplot(PSO_maxnodes_peak);
h4 = cdfplot(PSO_maxnodes_peak1);
set(h4,'Color','g');
hold on

xlabel('Throughput per user [Mbps]','Interpreter','latex','FontSize',20);
ylabel('CDF','Interpreter','latex','FontSize',20);
legend('Optimal- Min. Nodes','Optimal- peak','PSO- Min. Nodes','PSO- peak');
set(gca,'FontSize',20);
grid on

X