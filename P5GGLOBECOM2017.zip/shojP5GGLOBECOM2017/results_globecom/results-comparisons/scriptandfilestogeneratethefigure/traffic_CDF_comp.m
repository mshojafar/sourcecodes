clear all 
close all
clc

load t_max.mat

t_max=user_throughput';

load t_min.mat

t_min=t_min/10^6;

min_user_throughput=0;
max_user_throughput=max([t_min t_max]);

[edges_throughput_t_max cdf_throughput_t_max]=ecdf(t_max, min_user_throughput, max_user_throughput);


[edges_throughput_t_min cdf_throughput_t_min]=ecdf(t_min, min_user_throughput, max_user_throughput);

load Traffic_258_users.txt

[edges_throughput_t_258_users cdf_throughput_t_258_users]=ecdf(Traffic_258_users', min_user_throughput, max_user_throughput);

load Traffic_26_users.txt

[edges_throughput_t_26_users cdf_throughput_t_26_users]=ecdf(Traffic_26_users', min_user_throughput, max_user_throughput);

load Traffic_26_users_1_node.txt

[edges_throughput_t_26_users_1_node cdf_throughput_t_26_users_1_node]=ecdf(Traffic_26_users_1_node', min_user_throughput, max_user_throughput);

figure
hh  = plot (edges_throughput_t_max, cdf_throughput_t_max,'b','LineWidth',2);
hold on
plot (edges_throughput_t_min, cdf_throughput_t_min,'r','LineWidth',2);

plot (edges_throughput_t_258_users, cdf_throughput_t_258_users,'k:','LineWidth',2);
plot (edges_throughput_t_26_users, cdf_throughput_t_26_users,'g-.','LineWidth',2);
plot (edges_throughput_t_26_users_1_node, cdf_throughput_t_26_users_1_node,'c--','LineWidth',2);

legend('Best Node Allocation','Worst Node Allocation', 'Max. Traffic - Peak', 'Max. Traffic - Off Peak', 'Min Nodes - Off Peak' , 'Location', 'southeast')



grid on
xlabel('Throughput per User [Mbps]','FontSize',12)
ylabel('Cumulative Distribution Function','FontSize',12)

set(gca,'fontsize',12)

hold off