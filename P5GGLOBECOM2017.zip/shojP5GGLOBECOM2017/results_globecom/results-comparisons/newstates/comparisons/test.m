clc 
clear all
close all
%% Optimal Max Throughput
Optimal_minnodes_peak1=load ('Optimal_peak_t_min.mat','user_throughput');
Optimal_minnodes_peak1=Optimal_minnodes_peak1.user_throughput;
Optimal_maxnodes_peak1=load ('Optimal_peak_t_max.mat','user_throughput');
Optimal_maxnodes_peak1=Optimal_maxnodes_peak1.user_throughput;
%% Optimal Min nodes
Optimal_minnodes_peak=load ('Optimal_peak_t_min.txt');
Optimal_maxnodes_peak=load ('Optimal_peak_t_max.txt');
%% Max Throuput Results
%26 users
 PSO_LP01_maxT=load ('PSO_LP_01_MaxThrouput.mat','t');
 PSO_LP01_maxT=PSO_LP01_maxT.t; 
 PSO_LP01_maxTu=load ('PSO_LP_01_MaxThrouput.mat','u');
 PSO_LP01_maxTu=PSO_LP01_maxTu.u;
 PSO_LP01_maxT_result=(max(PSO_LP01_maxT.*PSO_LP01_maxTu));

%65 users
 PSO_LP25_maxT=load ('PSO_LP_25_MaxThrouput.mat','t');
 PSO_LP25_maxT=PSO_LP25_maxT.t; 
 PSO_LP25_maxTu=load ('PSO_LP_25_MaxThrouput.mat','u');
 PSO_LP25_maxTu=PSO_LP25_maxTu.u;
 PSO_LP25_maxT_result=max(PSO_LP25_maxT.*PSO_LP25_maxTu);

 %104 users
 PSO_LP04_maxT=load ('PSO_LP_04_MaxThrouput.mat','t');
 PSO_LP04_maxT=PSO_LP04_maxT.t; 
 PSO_LP04_maxTu=load ('PSO_LP_04_MaxThrouput.mat','u');
 PSO_LP04_maxTu=PSO_LP04_maxTu.u;
 PSO_LP04_maxT_result=max(PSO_LP04_maxT.*PSO_LP04_maxTu);

%142 users
 PSO_LP55_maxT=load ('PSO_LP_55_MaxThrouput.mat','t');
 PSO_LP55_maxT=PSO_LP55_maxT.t; 
 PSO_LP55_maxTu=load ('PSO_LP_55_MaxThrouput.mat','u');
 PSO_LP55_maxTu=PSO_LP55_maxTu.u;
 PSO_LP55_maxT_result=max(PSO_LP55_maxT.*PSO_LP55_maxTu);
 
 %181 users
 PSO_LP07_maxT=load ('PSO_LP_07_MaxThrouput.mat','t');
 PSO_LP07_maxT=PSO_LP07_maxT.t; 
 PSO_LP07_maxTu=load ('PSO_LP_07_MaxThrouput.mat','u');
 PSO_LP07_maxTu=PSO_LP07_maxTu.u;
 PSO_LP07_maxT_result=max(PSO_LP07_maxT.*PSO_LP07_maxTu);
 
  %220 users
 PSO_LP85_maxT=load ('PSO_LP_85_MaxThrouput.mat','t');
 PSO_LP85_maxT=PSO_LP85_maxT.t; 
 PSO_LP85_maxTu=load ('PSO_LP_85_MaxThrouput.mat','u');
 PSO_LP85_maxTu=PSO_LP85_maxTu.u;
 PSO_LP85_maxT_result=max(PSO_LP85_maxT.*PSO_LP85_maxTu);
 
  %260 users
 PSO_LP1_maxT=load ('PSO_LP_1_MaxThrouput.mat','t');
 PSO_LP1_maxT=PSO_LP1_maxT.t; 
 PSO_LP1_maxTu=load ('PSO_LP_1_MaxThrouput.mat','u');
 PSO_LP1_maxTu=PSO_LP1_maxTu.u;
 PSO_LP1_maxT_result=max(PSO_LP1_maxT.*PSO_LP1_maxTu);

 %% Min Nodes Results
%26 users
 PSO_LP01_minN=load ('PSO_LP_01_MinNodes.mat','t');
 PSO_LP01_minN=PSO_LP01_minN.t; 
 PSO_LP01_minNu=load ('PSO_LP_01_MinNodes.mat','u');
 PSO_LP01_minNu=PSO_LP01_minNu.u;
 PSO_LP01_minN_result=(max(PSO_LP01_minN.*PSO_LP01_minNu));

%65 users
 PSO_LP25_minN=load ('PSO_LP_25_MinNodes.mat','t');
 PSO_LP25_minN=PSO_LP25_minN.t; 
 PSO_LP25_minNu=load ('PSO_LP_25_MinNodes.mat','u');
 PSO_LP25_minNu=PSO_LP25_minNu.u;
 PSO_LP25_minN_result=max(PSO_LP25_minN.*PSO_LP25_minNu);

 %104 users
 PSO_LP04_minN=load ('PSO_LP_04_MinNodes.mat','t');
 PSO_LP04_minN=PSO_LP04_minN.t; 
 PSO_LP04_minNu=load ('PSO_LP_04_MinNodes.mat','u');
 PSO_LP04_minNu=PSO_LP04_minNu.u;
 PSO_LP04_minN_result=max(PSO_LP04_minN.*PSO_LP04_minNu);

%142 users
 PSO_LP55_minN=load ('PSO_LP_55_MinNodes.mat','t');
 PSO_LP55_minN=PSO_LP55_minN.t; 
 PSO_LP55_minNu=load ('PSO_LP_55_MinNodes.mat','u');
 PSO_LP55_minNu=PSO_LP55_minNu.u;
 PSO_LP55_minN_result=max(PSO_LP55_minN.*PSO_LP55_minNu);
 
 %181 users
 PSO_LP07_minN=load ('PSO_LP_07_MinNodes.mat','t');
 PSO_LP07_minN=PSO_LP07_minN.t; 
 PSO_LP07_minNu=load ('PSO_LP_07_MinNodes.mat','u');
 PSO_LP07_minNu=PSO_LP07_minNu.u;
 PSO_LP07_minN_result=max(PSO_LP07_minN.*PSO_LP07_minNu);
 
  %220 users
 PSO_LP85_minN=load ('PSO_LP_85_MinNodes.mat','t');
 PSO_LP85_minN=PSO_LP85_minN.t; 
 PSO_LP85_minNu=load ('PSO_LP_85_MinNodes.mat','u');
 PSO_LP85_minNu=PSO_LP85_minNu.u;
 PSO_LP85_minN_result=max(PSO_LP85_minN.*PSO_LP85_minNu);
 
  %260 users
 PSO_LP1_minN=load ('PSO_LP_1_MinNodes.mat','t');
 PSO_LP1_minN=PSO_LP1_minN.t; 
 PSO_LP1_minNu=load ('PSO_LP_1_MinNodes.mat','u');
 PSO_LP1_minNu=PSO_LP1_minNu.u;
 PSO_LP1_minN_result=max(PSO_LP1_minN.*PSO_LP1_minNu);
%% plot

figure(10)
clr = jet(14);
hold on
h1 = cdfplot(PSO_LP01_maxT_result);
h11 = cdfplot(PSO_LP01_minN_result);
set(h1,'Color',clr(1,:));
set(h1,'MarkerSize',8,'LineWidth',3,'LineStyle','-');
set(h11,'Color',clr(2,:));
set(h11,'MarkerSize',8,'LineWidth',3,'LineStyle','--');
hold on

h2 = cdfplot(PSO_LP25_maxT_result);
h22 = cdfplot(PSO_LP25_minN_result);
set(h2,'Color',clr(3,:));
set(h2,'MarkerSize',8,'LineWidth',3,'LineStyle','-');
set(h22,'Color',clr(4,:));
set(h22,'MarkerSize',8,'LineWidth',3,'LineStyle','--');
hold on

h3 = cdfplot(PSO_LP04_maxT_result);
h33 = cdfplot(PSO_LP04_minN_result);
set(h3,'Color',clr(5,:));
set(h3,'MarkerSize',8,'LineWidth',3,'LineStyle','-');
set(h33,'Color',clr(6,:));
set(h33,'MarkerSize',8,'LineWidth',3,'LineStyle','--');
hold on

h4 = cdfplot(PSO_LP55_maxT_result);
h44 = cdfplot(PSO_LP55_minN_result);
set(h4,'Color',clr(7,:));
set(h4,'MarkerSize',8,'LineWidth',3,'LineStyle','-');
set(h44,'Color',clr(8,:));
set(h44,'MarkerSize',8,'LineWidth',3,'LineStyle','--');
hold on

h5 = cdfplot(PSO_LP07_maxT_result);
h55 = cdfplot(PSO_LP07_minN_result);
set(h5,'Color',clr(9,:));
set(h5,'MarkerSize',8,'LineWidth',3,'LineStyle','-');
set(h55,'Color',clr(10,:));
set(h55,'MarkerSize',8,'LineWidth',3,'LineStyle','--');
hold on

h6 = cdfplot(PSO_LP85_maxT_result);
h66 = cdfplot(PSO_LP85_minN_result);
set(h6,'Color',clr(11,:));
set(h6,'MarkerSize',8,'LineWidth',3,'LineStyle','-');
set(h66,'Color',clr(12,:));
set(h66,'MarkerSize',8,'LineWidth',3,'LineStyle','--');
hold on

h7 = cdfplot(PSO_LP1_maxT_result);
h77 = cdfplot(PSO_LP1_minN_result);
set(h7,'Color',clr(13,:));
set(h7,'MarkerSize',8,'LineWidth',4,'LineStyle','-');
set(h77,'Color',clr(14,:));
set(h77,'MarkerSize',8,'LineWidth',3,'LineStyle','--');
hold on

xlabel('Throughput per user [Mbps]','Interpreter','latex','FontSize',20);
ylabel('CDF','Interpreter','latex','FontSize',20);
%legend('PSO- 26 Users','PSO- 65 Users','PSO- 104 Users','PSO- 142 Users','PSO- 181 Users','PSO- 220 Users','PSO- 260 Users');
legend('Max Th.- 26 Users','Min Nodes- 26 Users','Max Th.- 65 Users','Min Nodes- 65 Users','Max Th.- 104 Users','Min Nodes- 104 Users','Max Th.- 142 Users',...
       'Min Nodes- 142 Users','Max Th.- 181 Users','Min Nodes- 181 Users','Max Th.- 220 Users','Min Nodes- 220 Users','Max Th.- 260 Users','Min Nodes- 260 Users');
set(gca,'FontSize',25);
title('Min Nodes/Max Throughput','Interpreter','latex');
%title('Max Throughput','Interpreter','latex');
grid on

X