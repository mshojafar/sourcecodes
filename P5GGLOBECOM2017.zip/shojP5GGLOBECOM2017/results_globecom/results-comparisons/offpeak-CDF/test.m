clc 
clear all
close all

Optimal_minnodes_offpeak=load ('Optimal_offpeak_t_min.txt');
Optimal_maxnodes_offpeak=load ('Optimal_offpeak_t_max.txt');

PSO_minnodes_offpeak=load ('PSO_offpeak_t_min.mat','t');
PSO_minnodes_offpeak=PSO_minnodes_offpeak.t;
PSO_minnodes_offpeaku1=load ('PSO_offpeak_t_min.mat','u');
PSO_minnodes_offpeaku1=PSO_minnodes_offpeaku1.u;

PSO_minnodes_offpeak1=max(PSO_minnodes_offpeak.*PSO_minnodes_offpeaku1);

PSO_maxnodes_offpeak=load ('PSO_offpeak_t_max.mat','t');
PSO_maxnodes_offpeak=PSO_maxnodes_offpeak.t;
PSO_minnodes_offpeaku2=load ('PSO_offpeak_t_max.mat','u');
PSO_minnodes_offpeaku2=PSO_minnodes_offpeaku2.u;

PSO_maxnodes_offpeak1=(max(PSO_maxnodes_offpeak.*PSO_minnodes_offpeaku2));

figure(10)
%cdfplot(Optimal_minnodes_offpeak);
h1 = cdfplot(Optimal_minnodes_offpeak);
set(h1,'Color','b');
hold on

%cdfplot(Optimal_maxnodes_offpeak);
h2 = cdfplot(Optimal_maxnodes_offpeak);
set(h2,'Color','r');
hold on

%cdfplot(PSO_minnodes_offpeak);
h3 = cdfplot(PSO_minnodes_offpeak1);
set(h3,'Color','k');
hold on

%cdfplot(PSO_maxnodes_offpeak);
h4 = cdfplot(PSO_maxnodes_offpeak1);
set(h4,'Color','g');
hold on

xlabel('Throughput per user [Mbps]','Interpreter','latex','FontSize',20);
ylabel('CDF','Interpreter','latex','FontSize',20);
legend('Optimal- Min. Nodes','Optimal- Offpeak','PSO- Min. Nodes','PSO- Offpeak');
set(gca,'FontSize',20);
grid on

X