function [ edges cdf ] = my_ecdf( y, min_value, max_value)
%ECDF COMPUTATION

%min_value=min(y);
%max_value=max(y);
edges=(0:0.1:100)/100*max_value+min_value;
H = hist(y,edges);
cdf = cumsum(H) ./ sum(H);

end

