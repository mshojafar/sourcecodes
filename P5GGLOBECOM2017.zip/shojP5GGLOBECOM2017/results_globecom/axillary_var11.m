function [ c_accept, c] = axillary_var11(num_k, num_nodes, m, M, y)
%%default
%t_acc1=zeros(num_nodes, num_k); % checker for Eq. (33) satisfaction
%t_acc2=zeros(num_nodes, num_k); % checker for Eq. (34) satisfaction
%t_acc3=zeros(num_nodes, num_k); % checker for Eq. (35) satisfaction
c_accept=zeros(num_nodes, num_k); % checker for Eqs. (33)(34)(35) satisfaction

c=zeros(num_nodes, num_k);
%e=zeros(num_nodes, num_k);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% (33)-(35)
    for i=1:num_nodes
        for k=1:num_k
           % c1=randi([0,1],1,1);
            if (y(i)==0) && (sum(m(k,:,i))>=1)
                c(i,k)=1;
               c_accept(i,k)=1;

            if (sum(m(k,:,i))>M)
                %c(i,k)=0;
               c_accept(i,k)=0;
            elseif  (1<sum(m(k,:,i))<=M)
                c(i,k)=1;
               c_accept(i,k)=1;
            end
            end
                     
        end
    end
end