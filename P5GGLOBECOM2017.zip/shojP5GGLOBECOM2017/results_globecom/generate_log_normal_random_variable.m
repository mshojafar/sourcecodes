function [ z stream ] = generate_log_normal_random_variable( std_dev_db,stream )
      std_dev_lin=10^(std_dev_db/10);
      z=exp(randn(stream, 1)*std_dev_lin);
end

