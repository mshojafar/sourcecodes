function [ b bcounter] = generate_b(num_k, num_nodes1, num_nodes2, llim, ulim, rowlimvector, r, O_kwz,y)
%%default
%ulim=1;    %max value
%llim=0;    %min value
%rowlim=1;  %max sum for each row
%m=5;    %rows
%n=4;    %columns
%o=3;   %pages
%rowlimvector=[1,4];  %max sum for each page
b=randi([llim, ulim],num_k, num_nodes1, num_nodes2);

%%%%%% Eq. (26)
for i=1:num_k
    if (rowlimvector(i)==1)
        b(i,:,:)=0;
        b(randi([1 numel(b(i,:,:))]))=1; 
    end
end
test=sum(b,3);
Rsum=sum(test,2);
Rcheck=(Rsum'>rowlimvector);
bcounter=1;

while any(Rcheck) && (bcounter<100) %replace any row whose sum is > rowlim
    I=find(Rcheck);
    update=zeros(num_nodes1, num_nodes2);
    %for k1=1:m
     for k2=1:length(I)
     t=I(k2); 
     
     update(randperm(numel(update), rowlimvector(t))) = 1;  % find a 2D matrix with the rowlimvector(spcefici row) number of 1
     
     %while (mean(update)~= rowlimvector(t)) 
     %update=randi([llim, ulim],n, o);
     %rng(0,'twister');
     %end
     b(t,:,:)=update;
     %end
     end
    test=sum(b,3);
    Rsum=sum(test,2);
    Rcheck=(Rsum'>rowlimvector);
    bcounter=bcounter+1;
end
%%%%% Eq. (25)
for i=1:num_nodes1 
    btemp=sum(b,3);
    if (sum(btemp(:,i)))~=sum(r(:,i))
        [ b bcounter] = generate_sum3Dlequal(num_k, num_nodes1, num_nodes2, llim, ulim, rowlimvector, r, O_kwz);
    else 
        return
    end
end
%%%%% Eq. (29)
set(0,'RecursionLimit',2000);
for k=1:num_k
    for w=1:num_k
        for i=1:num_nodes1
            if (r(k,i)*(sum(b(w,i,:))))>O_kwz(k,w)
             [ b bcounter] = generate_sum3Dlequal(num_k, num_nodes1, num_nodes2, llim, ulim, rowlimvector, r, O_kwz);
            end
        end
    end
end

for i=1:num_nodes1
    for k=1:num_k
    b(k,:,i)=b(k,:,i)*y(i);
    end
end

%disp(b)

end

