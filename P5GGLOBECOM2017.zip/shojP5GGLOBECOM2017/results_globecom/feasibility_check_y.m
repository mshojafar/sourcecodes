function [ t_accepty, t_acc1, t_acc2, t_acc3, delta_DWH_i_RRH, delta_DWH_i_BBU] = feasibility_check_y(num_k, num_k_RRH, num_k_BBU, Num_k_MEC, num_nodes, r, b, delta_ik_RRH, delta_w_BBU, B_i_DHW, C_i_MEC, C_i_BBU,C_i_CHW, M_i_MEC, M_i_BBU, M_i_CHW, y)
%%default
%ulim=1;    %max value
%llim=0;    %min value
%rowlim=1;  %max sum for each row
%m=5;    %rows
%n=4;    %columns
%o=3;   %pages
%rowlimvector=[1,4];  %max sum for each page
t_acc1=zeros(1, num_nodes); % checker for Eq. (31) satisfaction
t_acc2=zeros(1, num_nodes); % checker for Eq. (40) satisfaction
t_acc3=zeros(1, num_nodes); % checker for Eq. (43) satisfaction
t_accepty=zeros(1, num_nodes); % checker for Eqs. (31)(40)(43) satisfaction
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (31)
temp1=0;
temp11=zeros(1, num_nodes);
for i=1:num_nodes
    for k=1:num_k_RRH
        temp1=r(k,i)*delta_ik_RRH(i,k)+temp1;
    end
    temp11(i)=temp1;
    temp1=0;
end
temp2=0;
temp21=zeros(num_nodes, num_k_BBU);
temp22=zeros(1, num_nodes);
for i=1:num_nodes
    for w=1:num_k_BBU
        for p=1:num_nodes
            temp2=b(w,p,i)*delta_w_BBU(w)+temp2;
        end
        temp21(i,w)=temp2;
        temp2=0;
    end
end
temp22=sum(temp21,2);
for i=1:num_nodes
    if ((temp11(i)/1000)+temp22(i))<=B_i_DHW(i)*y(i)
        t_acc1(i)=1;
    else
        %y(i)=1;
        t_acc1(i)=1;
        
    end
end
delta_DWH_i_BBU=sum(temp21,2)'; %(Gbps)
delta_DWH_i_RRH=temp11/1000; %(Gbps)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (40)
for i=1:num_nodes
    if C_i_MEC(i)+C_i_BBU(i)<=C_i_CHW(i)*y(i)
        t_acc2(i)=1;
    else
        %y(i)=1;
        t_acc2(i)=1;
    end
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (43)
for i=1:num_nodes
    if M_i_MEC(i)+M_i_BBU(i)<=M_i_CHW(i)*y(i)
        t_acc3(i)=1;
    else
        %y(i)=1;
        t_acc3(i)=1;
    end
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% integration (31)+(40)+(43)
for i=1:num_nodes
    t_accepty(i)=t_acc1(i)*t_acc2(i)*t_acc3(i);
end
