function [ d_accept, d] = axillary_var22(num_k, num_nodes, b, M, y)
%%default
%t_acc1=zeros(num_nodes, num_k); % checker for Eq. (37) satisfaction
%t_acc2=zeros(num_nodes, num_k); % checker for Eq. (38) satisfaction
%t_acc3=zeros(num_nodes, num_k); % checker for Eq. (39) satisfaction
d_accept=zeros(num_nodes, num_k); % checker for Eqs. (37)(38)(39) satisfaction

d=zeros(num_nodes, num_k);
%f=zeros(num_nodes, num_k);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% (37)-(39)
     for i=1:num_nodes
        for k=1:num_k
            %c1=randi([0,1],1,1);
            if (y(i)==0) && (sum(b(k,:,i))>=1)
                d(i,k)=1;
               d_accept(i,k)=1;

            if (sum(b(k,:,i))>M)
                %c(i,k)=0;
                d_accept(i,k)=0;
            elseif  (1<sum(b(k,:,i))<=M)
                d(i,k)=1;
               d_accept(i,k)=1;
            end
            end
                     
        end
    end

end