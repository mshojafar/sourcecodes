function [ m mcounter] = generate_m(num_k, num_nodes1, num_nodes2, llim, ulim, rowlimvector, r, y)
%%default
%ulim=1;    %max value
%llim=0;    %min value
%rowlim=1;  %max sum for each row
%m=5;    %rows
%n=4;    %columns
%o=3;   %pages
%rowlimvector=[1,4];  %max sum for each page
m=randi([llim, ulim], num_k, num_nodes1, num_nodes2);
for i=1:num_nodes1
    for k=1:num_k
    m(k,:,i)=m(k,:,i)*y(i);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (28)
for i=1:num_k
    if (rowlimvector(i)==1)
        m(i,:,:)=0;
        m(randi([1 numel(m(i,:,:))]))=1; 
    end
end
test=sum(m,3);
Rsum=sum(test,2);
Rcheck=(Rsum'>rowlimvector);
mcounter=1;

while any(Rcheck) && (mcounter<100) %replace any row whose sum is > rowlim
    I=find(Rcheck);
    update=zeros(num_nodes1, num_nodes2);
    %for k1=1:m
     for k2=1:length(I)
     t=I(k2); 
     
     update(randperm(numel(update), rowlimvector(t))) = 1;  % find a 2D matrix with the rowlimvector(spcefici row) number of 1
     
     %while (mean(update)~= rowlimvector(t)) 
     %update=randi([llim, ulim],n, o);
     %rng(0,'twister');
     %end
     m(t,:,:)=update;
     %end
     end
    test=sum(m,3);
    Rsum=sum(test,2);
    Rcheck=(Rsum'>rowlimvector);
    mcounter=mcounter+1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Eq. (27)
set(0,'RecursionLimit',2000);
for i=1:num_nodes1 
    mtemp=sum(m,3);
    if (sum(mtemp(:,i)))~=sum(r(:,i))
        [ m mcounter] = generate_m(num_k, num_nodes1, num_nodes2, llim, ulim, rowlimvector, r, y);
        
    else 
        return
    end
end

%disp(b)

end
