function [ Particle particle_storage_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_DWH_i_RRH, delta_DWH_i_BBU, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_ijk, delta_k_MEC, O_kwz, M, t, y, u, r)

%y(end)=0; % keep EPC without u and r
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% constraints
%%%eq (25)(26)(29)(31)
[ b bcounter] = generate_b(num_k_BBU, num_nodes, num_nodes, 0, 1, N_k_BBU, r, O_kwz,y);
%%%eq (27)(28)
[ m mcounter] = generate_m(num_k_MEC, num_nodes, num_nodes, 0, 1, N_k_MEC, r, y);
%%%eq (23)(24)(30)
[ t_acceptt, t_acc23, t_acc24, t_acc30, t] = feasibility_check_t1(num_k, num_nodes, num_users, t, r, u, m, delta_jki_RRH, delta_k_MEC, N_k_RRH, N_k_MEC, num_k_RRH, num_k_BBU, num_k_MEC, M, y);

[ c_accept, c] = axillary_var11(num_k_MEC, num_nodes, m, M, y);

[ d_accept, d] = axillary_var22(num_k_BBU, num_nodes, b, M, y);

[ C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH] = control_vars1(num_k, num_nodes, num_users, num_k_MEC, num_k_BBU, num_k_RRH, delta_jki_RRH, C_ik_MS', C_ik_MD', C_ik_BS', C_ik_BD', M_ik_MS', M_ik_MD', M_ik_BS', M_ik_BD', r, u, m, b, c, d, t,y);
%%% conrol variable decision (feasibility_check for y)
%%%eq (31)(40)(43)
[ t_accepty, t_acc31, t_acc40, t_acc43, delta_DWH_i_RRH, delta_DWH_i_BBU] = feasibility_check_y(num_k, num_k_RRH, num_k_BBU, num_k_MEC, num_nodes, r, b, delta_ik_RRH, delta_w_BBU, B_i_DHW, C_i_MEC, C_i_BBU, C_i_CHW, M_i_MEC, M_i_BBU, M_i_CHW, y);

% 
% for i=1:num_nodes
%     for k=1:num_k_BBU
%     b(k,:,i)=b(k,:,i)*y(i);
%     end
%     r(:,i)=r(:,i)*y(i);
%     for k=1:num_k_MEC
%     m(k,:,i)=m(k,:,i)*y(i);
%     end
% end
particle_storage_cell={u;r;b;m;c;d};
%Particle=[t y_ij]; % for t_ij and y_ij
Particle=[t]; % for t_ij and y_ij
