function [ Particle particle_storage_cell C_i_BBU, C_i_MEC, ...
    M_i_BBU, M_i_MEC, delta_ik_RRH bcounter mcounter, ...
    t_acceptt t_accepty t y] = generate_particle_just_t(num_k, num_nodes, num_users, num_k_RRH, num_k_BBU, ...
    num_k_MEC, delta_jki_RRH, delta_w_BBU, B_i_DHW, C_i_CHW, M_i_CHW, ...
    C_ik_MS, C_ik_MD, C_ik_BS, C_ik_BD, M_ik_MS, M_ik_MD, M_ik_BS, M_ik_BD, N_k_RRH, N_k_BBU, N_k_MEC, ...
    U_k_max, R_k_max, cov_ijk, delta_k_MEC, O_kwz, M, t, y, u, r)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% constraints
%[ u ] = generate_sumcolequal(num_nodes, num_users,0, 1, 1);
%%%(eq 19)  \sum(r_ki)\leq 1 \forall i
%[ r ] = generate_sumcollequal(num_k, num_nodes,0, 1, 1);
%%%eq. (16)+(18)(19)(20)(21)(22)
%[ r ] = generate_r(num_k_RRH, num_nodes, num_users, 0, 1, N_k_RRH, u, U_k_max, R_k_max, cov_ijk);
%%%eq (25)(26)(29)
[ b bcounter] = generate_b(num_k_BBU, num_nodes, num_nodes, 0, 1, N_k_BBU, r, O_kwz,y);
%%%eq (27)(28)
[ m mcounter] = generate_m(num_k_MEC, num_nodes, num_nodes, 0, 1, N_k_MEC, r, y);
%%%eq (23)(24)(30)
[ t_acceptt, t_acc23, t_acc24, t_acc30 r u] = feasibility_check_t(num_k, num_nodes, num_users, t, r, u, m, delta_jki_RRH, delta_k_MEC, N_k_RRH, N_k_MEC, num_k_RRH, num_k_BBU, num_k_MEC, M, y);
%%%eq (33)(34)(35)
[ t_accept2, t_acc33, t_acc34, t_acc35 e c] = axillary_var1(num_k_MEC, num_nodes, m, M);
%%%eq (37)(38)(39)
[ t_accep3, t_acc37, t_acc38, t_acc39 f d] = axillary_var2(num_k_BBU, num_nodes, b, M);
%%% control decsisions Eqs. (21) (32) (36) (41) (42)
[ C_i_BBU, C_i_MEC, M_i_BBU, M_i_MEC, delta_ik_RRH] = control_vars(num_k, num_nodes, num_users, num_k_MEC, num_k_BBU, num_k_RRH, delta_jki_RRH, C_ik_MS', C_ik_MD', C_ik_BS', C_ik_BD', M_ik_MS', M_ik_MD', M_ik_BS', M_ik_BD', r, u, m, b, c, d, e, f, t,y);
%%% conrol variable decision (feasibility_check for y)
%%%eq (31)(40)(43)
[ t_accepty, t_acc31, t_acc40, t_acc43] = feasibility_check_y(num_k, num_k_RRH, num_k_BBU, num_k_MEC, num_nodes, r, b, delta_ik_RRH, delta_w_BBU, B_i_DHW, C_i_MEC, C_i_BBU, C_i_CHW, M_i_MEC, M_i_BBU, M_i_CHW, y);

y_ij=zeros(num_nodes, num_users);
for j=1:num_users
    y_ij(:,j)=y(:);
    
end

for i=1:num_nodes
    for k=1:num_k_BBU
    b(k,:,i)=b(k,:,i)*y(i);
    end
    r(:,i)=r(:,i)*y(i);
    for k=1:num_k_MEC
    m(k,:,i)=m(k,:,i)*y(i);
    end
end
particle_storage_cell={u;r;b;m;c;d;e;f};
%Particle=[t y_ij]; % for t_ij and y_ij
Particle=[t]; % for t_ij and y_ij
