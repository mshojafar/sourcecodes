function [ b counter] = generate_b(m,n,o,llim, ulim,rowlimvector, r_ki, O_kwz)
%%default
%ulim=1;    %max value
%llim=0;    %min value
%rowlim=1;  %max sum for each row
%m=5;    %rows
%n=4;    %columns
%o=3;   %pages
%rowlimvector=[1,4];  %max sum for each page
b=randi([llim, ulim],m, n, o);

%%%%%% Eq. (26)
for i=1:m
    if (rowlimvector(i)==1)
        b(i,:,:)=0;
        b(randi([1 numel(b(i,:,:))]))=1; 
    end
end
test=sum(b,3);
Rsum=sum(test,2);
Rcheck=(Rsum'>rowlimvector);
counter=1;

while any(Rcheck) && (counter<100) %replace any row whose sum is > rowlim
    I=find(Rcheck);
    update=zeros(n,o);
    %for k1=1:m
     for k2=1:length(I)
     t=I(k2); 
     
     update(randperm(numel(update), rowlimvector(t))) = 1;  % find a 2D matrix with the rowlimvector(spcefici row) number of 1
     
     %while (mean(update)~= rowlimvector(t)) 
     %update=randi([llim, ulim],n, o);
     %rng(0,'twister');
     %end
     b(t,:,:)=update;
     %end
     end
    test=sum(b,3);
    Rsum=sum(test,2);
    Rcheck=(Rsum'>rowlimvector);
    counter=counter+1;
end
%%%%% Eq. (25)
for i=1:n 
    btemp=sum(b,3);
    if (sum(btemp(:,i)))~=sum(r_ki(:,i))
        [ b counter] = generate_sum3Dlequal(m,n,o,llim, ulim,rowlimvector, r_ki, O_kwz);
    else 
        return
    end
end
%%%%% Eq. (29)
for k=1:m
    for w=1:m
        for i=1:n
            if (r_ki(k,i)*(sum(b(w,i,:))))>O_kwz(k,w)
             [ b counter] = generate_sum3Dlequal(m,n,o,llim, ulim,rowlimvector, r_ki, O_kwz);
            end
        end
    end
end


%disp(b)

end

