function [users nodes seed] = generate_users_nodes_position(n_users, nodes_macro, nodes_micro, s1, s2)
    %%%%%%%%% FIRST VERSION: ASSUMPTION: UNIFORM DISTRIBUTION FOR MICRO;
    %%%%%%%%% UNIFORM DISTRIBUTRION FOR MACRO, 20% of users attached
    %%%%%%%%%  to macro, 80% of users attached to the micro

    r_micro=50;
    r_macro=200;
    
    ratio_users_micro=0.3;
    n_nodes_micro=size(nodes_micro,1);
    index_user=1;
    
    num_users_macro=n_users-ratio_users_micro*n_users;
    num_users_micro=ratio_users_micro*n_users;
    num_users_single_micro=num_users_micro/n_nodes_micro;
    for i=1:n_nodes_micro
        for j=1:num_users_single_micro
            
            theta=rand(s1,1)*2*pi;
            
            a=2*pi*rand
            curr_r=sqrt(rand(s2,1));
            delta_x=r_micro*curr_r*(cos(theta))+nodes_micro(i,1);
            delta_y=r_micro*curr_r*(sin(theta))+nodes_micro(i,2);
           
            %delta_x=rand(s1,1)*r_micro*2-r_micro + nodes_micro(i,1);
            %delta_y=rand(s2,1)*r_micro*2-r_micro + nodes_micro(i,2);
            users(index_user,1)=delta_x;
            users(index_user,2)=delta_y;
            index_user=index_user+1;
        end
    end

    for j=1:num_users_macro
        delta_x=rand(s1,1)*r_macro*2-r_macro+nodes_macro(1,1);
        delta_y=rand(s2,1)*r_macro*2-r_macro+nodes_macro(1,2);
        users(index_user,1)=delta_x;
        users(index_user,2)=delta_y;
        index_user=index_user+1;
    end
  
    
    nodes=[nodes_macro; nodes_micro];
end

