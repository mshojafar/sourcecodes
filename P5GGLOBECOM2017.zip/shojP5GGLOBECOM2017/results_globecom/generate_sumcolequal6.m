function [ u , rowSums, coverag_flag, counter ] = generate_sumcolequal6(rows, columns, onesPerColumn, y, U_k_max_pso1, r1, sum_cov_ji, counter)
%[ u ] = generate_sumcolequal2(length(pos1), num_users, 1, y_ij(:,ii), U_k_max_pso1)
% Set up parameters.
%rows = 10;
%columns = 15;
%onesPerColumn = 4;
% Initialize matrix.
% Get some random B value, since we don't know what else to use.
%B = randi(rows, rows, 1)
%B=[126; 42; 42; 42; 42;42; 42; 42; 42; 42]
loopcounter = 1; % The failsafe.
maxAttempts = 5000; % A hundred thousand attempts.
%U_k_max_pso1=U_k_max_pso1*r1;
%U_k_max_pso1=U_k_max_pso1';
while loopcounter < maxAttempts
	u = zeros(rows, columns);
	% Get rows to put 1's into
	rowsWith1s = randi(rows, 1, columns);
	% Load those 1s into A.
	for col = 1 : columns
		u(rowsWith1s(col), col) = onesPerColumn;
	end
	% 	A % Print to command window
	% Get row sums:
	rowSums = sum(u, 2);
	% Bail out if all sums are less than B
	if all(rowSums <= U_k_max_pso1)
		%fprintf('Succeeded after %d attempts\n', loopcounter);
		break;
	end
	loopcounter = loopcounter + 1;
end
cc=0;
if loopcounter == maxAttempts
%     while all(rowSums > U_k_max_pso1)
%             [ u , rowSums ] = generate_sumcolequal4(rows, columns, onesPerColumn, y, U_k_max_pso1);
%             if cc==300
%                 break
%             else 
%                 cc=cc+1;
%             end
% 	break;
% 	end
set(0,'RecursionLimit',800);
 while sum(sum(u>sum_cov_ji))>0 && (counter<700)
    counter=counter+1;
    
    
    if all(rowSums <= U_k_max_pso1)==0
     status_users=rowSums - U_k_max_pso1;
    [pos1]=find(status_users>0);
    [pos2]=find(status_users<0);
    extra_users=status_users(pos1);
    need_users=status_users(pos2);
    
    for ii=1:length(extra_users)
    
    
    end %for
    
    end %if
    
    if counter==699
         MAX=10000;   
         %rowSums = sum(u, 2);
        [A B]=find (u>sum_cov_ji); 
        for ttt=1:length(A)
            rowSums = sum(u, 2);
            rowSums(A(ttt))=MAX;                               % put out the currnet node that has users (B) from the process
            if (u(A(ttt),B(ttt))==1)
               [A1 B1]=find(u(:,B(ttt))==0); % before turn off the user(B) in A, we need to find a turn OFF user in the node A to be turn ON that keep two row/column constraints
               
              for tk=1: length(A1)
%               [sortedrowSums, sortedInds] = sort(rowSums(:));  
%               top = sortedInds(tk);
%               [i, j] = ind2sub(size(rowSums), top3);
                  [xpos ypos]=min(rowSums);
                   %if rowSums(A1(tk))<=U_k_max_pso1(A1(tk))-1
                   if (xpos<=U_k_max_pso1(ypos)-1) && (sum_cov_ji(ypos,B(ttt))==1) % does this node (ypos) has capacity for new user changing and can cover this user
                   u(ypos,B(ttt))=1;
                      break;
                   elseif (xpos>U_k_max_pso1(ypos)-1)  % this node (ypos) does not have capacity so must drop out from the nodes in the processing
                       rowSums(ypos)=MAX; 
                   elseif (xpos<=U_k_max_pso1(ypos)-1) && (sum_cov_ji(ypos,B(ttt))==0) % this node (ypos) does not capacity for this user so i should refer to other node to cover this user
                       rowSums(ypos)=MAX;
                   end
              
              end
                
                u(A(ttt),B(ttt))=0;
            else
                [A1 B1]=find(u(:,B(ttt))==1);  % before turn ON the user(B) in A, we find current turn ON user in the node A to be turn OFF
                u(A1,B1)=0;
               u(A,B)=1;
            end
            
          
        end
        rowSums = sum(u, 2);
            if all(rowSums <= U_k_max_pso1)
                    %fprintf('Succeeded after %d attempts\n', loopcounter);
                break;
            end
    %break;
    end
    [ u , rowSums, coverag_flag, counter ] = generate_sumcolequal6(rows, columns, onesPerColumn, y, U_k_max_pso1, r1, sum_cov_ji, counter);
        %if (coverag_flag==0)
         %   break;
      %  end
 end
          rowSums = sum(u, 2);

else
	%fprintf('The final A:\n');
	%rowSums % Print to command window
	%u % Print to command window
    rowSums = sum(u, 2);
end

 if  u<=sum_cov_ji
     coverag_flag=1;
 else
     coverag_flag=0;
 end
%% Old Method
% u = zeros(rows, columns, 'int32');
% 
% for col = 1 : columns
% 	% Get random order of rows.
% 	randRows = randperm(rows);
% 	% Pick out "onesPerColumn" rows that will be set to 1.
% 	rowsWithOne = randRows(1:onesPerColumn);
% 	% Set those rows only to 1 for this column.
% 	u(rowsWithOne, col) = 1;
% end
% % Display u
% %if (y)
%  % u
% %end
% set(0,'RecursionLimit',2000);
% for row= 1: rows
%     if (sum(u(row,:)))>U_k_max_pso1(row)
%         [ u ] = generate_sumcolequal2(rows, columns, onesPerColumn, y, U_k_max_pso1);
%     end
% end

end