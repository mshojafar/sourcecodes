function [t]=generate_t_y_refinement_without_y1(t, delta_k_MEC, num_nodes, num_users, Optimal_mintraffic, Optimal_maxtraffic)
  %% t== i, j

  for i=1:num_nodes
      for j=1:num_users
          if (t(i,j)>delta_k_MEC) || (t(i,j)>(Optimal_maxtraffic(j)))
            t(i,j)=Optimal_maxtraffic(j);
          elseif (t(i,j)<0) 
            t(i,j)=0;
          end
          if ((t(i,j)<(Optimal_mintraffic(j))))
              t(i,j)=Optimal_mintraffic(j);
          end
          
      end
     
  end


end
