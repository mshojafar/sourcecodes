


VM=[1:1:10];%numero Macchine Virtuali
NumSimulazioni=length(VM);


% costo_speed_VM=zeros(1,NumSimulazioni);
% costo_switch_VM=zeros(1,NumSimulazioni);
% costo_channel_VM=zeros(1,NumSimulazioni);


costo_tot_VM=zeros(1,NumSimulazioni);
costo_tot_VM_f_succ=zeros(1,NumSimulazioni);
costo_tot_VM_f_prec=zeros(1,NumSimulazioni);
costo_tot_VM_TS=zeros(1,NumSimulazioni);
costo_VM_TS_switch=zeros(1,NumSimulazioni);
costo_tot_VM_TSpiuSwitch=zeros(1,NumSimulazioni);


f_VM_prima=zeros(1,NumSimulazioni);
f_VM_ultima=zeros(1,NumSimulazioni);


iter_VM=zeros(1,NumSimulazioni);

L_VM_prima=zeros(1,NumSimulazioni);
L_VM_ultima=zeros(1,NumSimulazioni);



%SET UTILIZZATO PER FIG.2
%chi_completo=[0.5:0.25:100]; %1000 - BLU
%chi_completo=0.5.*ones(1,100);%2000 - VERDE
%chi_completo=0.2*ones(1,100);%3000 - ROSSO
%chi_completo=[0.5:0.5:100];%4000 - NERO



chi_completo=[0.5:0.25:100];


rand('twister',0);
%Jobs=8.*ones(1,1000);  %carico deterministico
%Jobs=6 + (10-6).*rand(1,1000); %carico uniformemente distribuito   8+-2   %UTILIZZATO PER FIG.2, FIG.6 e FIG.7
%Jobs=2 + (14-2).*rand(1,1000); %carico uniformemente distribuito   8+-6
Jobs=(16).*rand(1,1000); %carico uniformemente distribuito   8+-8



        for k=1:NumSimulazioni
             tic
    k
    M=VM(k);
    
    
    %INIZIALIZZAZIONE PARAMETRI %%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    ni_opt=zeros(1,M);
    f_opt=zeros(1,M);
    L_opt=zeros(1,M);
    mu_opt=0;

   

    alpha_step=0.01; %<==  N.B. Parametro utilizzato all'interno della funzione di tracking - settare in modo congruo
    V_step=0;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% N.B. --> NEL CASO GENERALE DI: L_b>0, IL MAX VA FATTO RISPETTO A L_b/Delta, NON RISPETTO A 0.
% OCCORRE MODIFICARE CONSEGUENTEMENTE TUTTE LE OCCORRENZE DI :
% f_opt=max(0,min(f_star,f_max)) IN QUESTO FILE E NEGLI ALTRI.


%inizializzazione variabili

k_e=0.05; %0.005; %0.05; ke grande e piccolo
R_tot=100; %C_max=15; %(Mb/s)
T_tot=5; %(s)



f_max=100.*ones(1,M);  %(Mb/s)


%f_zero=0.1.*f_max;
f_zero=zeros(1,M);  % (Mb/s)
chi=chi_completo(1:M);
W=ones(1,M);
%N0=ones(1,M);
%g=ones(1,M);
%chi=N0.*W./g; <== definizione del parametro chi. Nelle simulazioni viene 
%fissato direttamente chi, N0 e g non servono direttamente ma compaiono
%nelle espressioni soltanto come rapporto, calcolato quindi come:
%(N0./g)=chi./W.

Th=2.*log(2).*(chi./W);

E_max=240.*ones(1,M);  % (mJ)
E_idle=5.*ones(1,M);  % (mJ)
P_N_idle=0.5.*ones(1,M);% (Watt)
omega=1.*ones(1,M);
Delta=1; %caso OMOGENEO: delta uguale per tutti i canali
L_b=zeros(1,M);  % NB. il codice funziona bene per L_b=0, altrimenti aggiungere modifica su f_opt.

Omega=0.5*(10^(-3)).*ones(1,M); %(mwatt)
RTT=70.*ones(1,M); %(micro secconds)


temp=2.*k_e+(2.*E_max.*omega./(f_max.^2));
alpha_zero=2.*k_e./temp;
alpha_mu=Delta./temp;

%FREQUENZE DISCRETE INIZIALIZZAZIONE %%%%%%%%%%%%%%%%%%%%%%%%%%%%
Q=6; %numero frequenze discrete;
f_discrete=zeros(M,Q);
for conta=1:M
    f_discrete(conta,:)=[0:f_max(conta)./(Q-1):f_max(conta)];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       

            for num_job=1:length(Jobs)
                L_tot=Jobs(num_job);



                    %CHECK FEASIBILITY - controllare funzionamento operatori %%%%%%%%%%%%%%%%%%

                    condizione_feas_carico=(sum(f_max.*Delta-L_b)>=L_tot);
                    condizione_feas_tempo=(L_tot<=R_tot.*(T_tot-Delta)./2);
                    condizione_feas_back=min(Delta.*f_max>=L_b); 


                    feasibility=condizione_feas_carico && condizione_feas_tempo && condizione_feas_back;

                    if ~feasibility
                        'VM=' 
                        M
                        error('Problem unfeasible')
%                     else
%                         'Problem Feasibile!'
                    end



                  [conv,iter,mu_opt,ni_opt,f_opt,L_opt,alpha_step,V_step]=tracking2(L_tot,L_b,alpha_zero,alpha_mu,chi,W,T_tot,Delta,f_zero,f_max,M,Th,mu_opt,ni_opt,f_opt,L_opt,alpha_step,V_step);


                    R_opt=2.*L_opt./(T_tot-Delta);
                    iter_VM(k)=iter_VM(k)+iter;



                     L_VM_prima(k)=L_VM_prima(k)+L_opt(1);
                     L_VM_ultima(k)=L_VM_ultima(k)+L_opt(M);
                     f_VM_prima(k)=f_VM_prima(k)+f_opt(1);
                     f_VM_ultima(k)=f_VM_ultima(k)+f_opt(M);
                     
                     
                     
                     %Calcolo f_precedente e f_successiva a partire da
                     %f_opt %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                            f_precedente=zeros(1,M);
                            f_successiva=zeros(1,M);
                            x=zeros(1,M);

                            for conta=1:M

                                delta_f_discrete=f_discrete(conta,:)-f_opt(conta);
                                [ff,ind_ff]=min(abs(delta_f_discrete));
                                if ff==0
                                    f_precedente(conta)=f_discrete(conta,ind_ff);
                                    f_successiva(conta)=f_discrete(conta,ind_ff);
                                    x(conta)=1; %qualsiasi valore � indifferente
                                elseif ind_ff==1
                                    f_precedente(conta)=f_discrete(conta,1);
                                    f_successiva(conta)=f_discrete(conta,2);
                                    x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
                                elseif ind_ff==Q
                                    f_precedente(conta)=f_discrete(conta,Q-1);
                                    f_successiva(conta)=f_discrete(conta,Q);
                                    x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
                                elseif delta_f_discrete(ind_ff)>0
                                    f_precedente(conta)=f_discrete(conta,ind_ff-1);
                                    f_successiva(conta)=f_discrete(conta,ind_ff);
                                    x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
                                else 
                                    f_precedente(conta)=f_discrete(conta,ind_ff);
                                    f_successiva(conta)=f_discrete(conta,ind_ff+1);
                                    x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
                                end

                            end
                            
                            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




                    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                    %%%%%%%%%%  costo  %%%%%%%%%%%%%%%%%%
                    if (~conv)
                        error('Errore: Carico non correttamente allocato')
                    end

                    %costo_speed=sum(((f_opt./f_max).^2).*omega.*E_max);
                    costo_speed=sum(((f_opt./f_max).^2).*omega.*(E_max-E_idle)+E_idle);

                    costo_switch=sum(k_e.*(f_opt-f_zero).^2);
                    %costo_channel=sum(2.*P_net.*L_opt./C_max);
                    %costo_channel=(T_tot-Delta).*sum(chi.*((2.^(R_opt./W))-1));
                    costo_channel=(T_tot-Delta).*sum((Omega.*[(RTT.*R_opt).^2])+P_N_idle);

                    costo_tot=costo_speed+costo_switch+costo_channel;
                    
                    
                    
                    %%%%%%%%%%%%%%%%%%   COSTI FREQUENZE DISCRETE  %%%%%%%%%


                        % Costo frequenza_successiva
                        %costo_speed_f_succ=sum(((f_successiva./f_max).^2).*omega.*E_max);
                        costo_speed_f_succ=sum(((f_successiva./f_max).^2).*omega.*(E_max-E_idle)+E_idle);

                        costo_switch_f_succ=sum(k_e.*(f_successiva-f_zero).^2);
                        %costo_channel_f_succ=(T_tot-Delta).*sum(chi.*((2.^(R_opt./W))-1));
                        costo_channel_f_succ=(T_tot-Delta).*sum((Omega.*[(RTT.*R_opt).^2])+P_N_idle);

                        costo_tot_f_succ=costo_speed_f_succ+costo_switch_f_succ+costo_channel_f_succ;

                        % Costo frequenza_precedente
                        %costo_speed_f_prec=sum(((f_precedente./f_max).^2).*omega.*E_max);
                        costo_speed_f_prec=sum(((f_precedente./f_max).^2).*omega.*(E_max-E_idle)+E_idle);
                        costo_switch_f_prec=sum(k_e.*(f_precedente-f_zero).^2);
                        %costo_channel_f_prec=(T_tot-Delta).*sum(chi.*((2.^(R_opt./W))-1));
                        costo_channel_f_prec=(T_tot-Delta).*sum((Omega.*[(RTT.*R_opt).^2])+P_N_idle);
                        costo_tot_f_prec=costo_speed_f_prec+costo_switch_f_prec+costo_channel_f_prec;

                        % Costo Time-sharing
                        costo_speed_TS=sum((((f_precedente./f_max).^2).*omega.*E_max).*(1-x)+(((f_successiva./f_max).^2).*omega.*E_max).*x);
                        costo_switch_TS=sum((k_e.*(f_precedente-f_zero).^2).*(1-x)+(k_e.*(f_successiva-f_zero).^2).*x);
                        %costo_channel_TS=(T_tot-Delta).*sum(chi.*((2.^(R_opt./W))-1));
                        costo_channel_TS=(T_tot-Delta).*sum((Omega.*[(RTT.*R_opt).^2])+P_N_idle);
                        costo_tot_TS=costo_speed_TS+costo_switch_TS+costo_channel_TS;


                        %Costo Time-sharing-switch
                        costo_TS_switch=sum(k_e.*(f_successiva-f_precedente).^2);
                        costo_tot_TSpiuSwitch=costo_tot_TS+costo_TS_switch;



                        %%%%%%%%%%%%%%%%%%   FINE  COSTI FREQUENZE DISCRETE  %%%%%%%%%




                    % risultati e deallocazione

%                     costo_speed_VM(k)=costo_speed_VM(k)+costo_speed;
%                     costo_switch_VM(k)=costo_switch_VM(k)+costo_switch;
%                     costo_channel_VM(k)=costo_channel_VM(k)+costo_channel;
%                     costo_tot_VM(k)=costo_tot_VM(k)+costo_tot;
                    
                    
                    costo_tot_VM(k)=costo_tot_VM(k)+costo_tot;
                    costo_tot_VM_f_succ(k)=costo_tot_VM_f_succ(k)+costo_tot_f_succ;
                    costo_tot_VM_f_prec(k)=costo_tot_VM_f_prec(k)+costo_tot_f_prec;
                    costo_tot_VM_TS(k)=costo_tot_VM_TS(k)+costo_tot_TS;
                    costo_VM_TS_switch(k)=costo_VM_TS_switch(k)+costo_TS_switch;
                    costo_tot_VM_TSpiuSwitch(k)=costo_tot_VM_TSpiuSwitch(k)+costo_tot_TSpiuSwitch;
                    
                    
                    f_zero=f_opt; 
                    
            end
            
        
                                 
            k

             costo_tot_VM(k)=costo_tot_VM(k)./length(Jobs);
             costo_tot_VM_f_succ(k)=costo_tot_VM_f_succ(k)./length(Jobs);
             costo_tot_VM_f_prec(k)=costo_tot_VM_f_prec(k)./length(Jobs);
             costo_tot_VM_TS(k)=costo_tot_VM_TS(k)./length(Jobs);
             costo_VM_TS_switch(k)=costo_VM_TS_switch(k)./length(Jobs);
             costo_tot_VM_TSpiuSwitch(k)=costo_tot_VM_TSpiuSwitch(k)./length(Jobs);
            
            
             
        iter_VM(k)=iter_VM(k)./length(Jobs);
       
        
        L_VM_prima(k)=L_VM_prima(k)./length(Jobs);
        L_VM_ultima(k)=L_VM_ultima(k)./length(Jobs);
        f_VM_prima(k)=f_VM_prima(k)./length(Jobs);
        f_VM_ultima(k)=f_VM_ultima(k)./length(Jobs);
        
        
                    
       clear f_max f_zero Th E_max omega Delta L_b temp alpha_zero alpha_mu chi W ni_opt f_opt L_opt mu_opt alpha_step V_step f_precedente f_successiva delta_f_discrete x;
                
        

        toc
        end

        
        
        
%figure(20)
figure(3000+NumSimulazioni+1)
plot(VM,costo_tot_VM,'--o',VM,costo_tot_VM_f_succ,'--o',VM,costo_tot_VM_f_prec,'--o',VM,costo_tot_VM_TS,'--o',VM,costo_tot_VM_TSpiuSwitch,'--o'),xlabel('VM'),ylabel('Overall Cost'),legend('Q=\infty (no DVFS)','f_succ','f_prec','TS','TS+Switch');

figure(3000+NumSimulazioni+2)
plot(VM,costo_VM_TS_switch,'--o'),xlabel('VM'),ylabel('Time Sharing contiguous switch cost');

figure(3000+NumSimulazioni+3)
plot(VM,f_VM_prima,'--o',VM,f_VM_ultima,'--o'),xlabel('VM'),ylabel('rate VM(1)'),legend('first VM','last VM');

%figure(21)
figure(3000+NumSimulazioni+4)
plot(VM,L_VM_prima,'--o',VM,L_VM_ultima,'--o'),xlabel('VM'),ylabel('workload VM(1)'),legend('first VM','last VM');


                
    





