%%%%%%%%%%Esto se puede cambiar para que sea sensado cada 10 rounds o si no
%%%%%%%%%%que sea sensado siempre como se lo ha hecho en este caso si no
%%%%%%%%%%fuese asi se cambiaria  en la parte donde se elige los nodos CH y
%%%%%%%%%%se pondria q solo en tal rango sean sensados

clear all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Field Dimensions - x and y maximum (in meters)
xm=100;
ym=100;

%x and y Coordinates of the Sink
sink.x=0.5*xm;
sink.y=0.5*ym;
 for loop = 1:3
   if loop==1
       Eo=0.5;
      
   end
    if loop==2
      Eo=1;
    
    end
    if loop==3
       Eo=1.5;
   
   end
%Number of Nodes in the field
n=100;
u=0;
%Optimal Election Probability of a node
%to become cluster head
p=0.1;

%Energy Model (all values in Joules)
%Initial Energy 
m=0.1;
%Eelec=Etx=Erx
ETX=50*0.000000001;
ERX=50*0.000000001;
%Transmit Amplifier types
Efs=10*0.000000000001;
Emp=0.0013*0.000000000001;
%Data Aggregation Energy
EDA=5*0.000000001;

%Values for Hetereogeneity
%Percentage of nodes than are advanced
%m=0.1;
%\alpha
a=1;

%maximum number of rounds
rmax=5000;

%%%%%%%%%%%%%%%%%%%%%%%%% END OF PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%

%Computation of do
do=sqrt(Efs/Emp); 

%Creation of the random Sensor Network
%este figure(1);
for i=1:1:n
    S(i).xd=rand(1,1)*xm;
    XR(i)=S(i).xd;
    S(i).yd=rand(1,1)*ym;
    YR(i)=S(i).yd;
    S(i).G=0;
    %initially there are no cluster heads only nodes
    S(i).type='N';
   
    temp_rnd0=i;
    %Random Election of Normal Nodes
    if (temp_rnd0>=m*n+1) 
        S(i).E=Eo;
        S(i).ENERGY=0;
        %%%%plot(S(i).xd,S(i).yd,'o');
        hold on;
    end
    %Random Election of Advanced Nodes
    if (temp_rnd0<m*n+1)  
        S(i).E=Eo*(1+a);
        S(i).ENERGY=1;
        E1=Eo*(1+a);
        %%%%plot(S(i).xd,S(i).yd,'+');
         hold on;
    end
end

S(n+1).xd=sink.x;
S(n+1).yd=sink.y;
%%%%plot(S(n+1).xd,S(n+1).yd,'x');
    
        
%First Iteration
%estefigure(1);

%counter for CHs
countCHs=0;
%counter for CHs per round
rcountCHs=0;
cluster=1;

countCHs;
rcountCHs=rcountCHs+countCHs;
flag_first_dead=0;
for r=0:1:rmax
   % r
  sum=0;
  % use this code to take a average of the energy of alive nodes in each
  % round
  A=0;
for j=1:1:n
if(S(j).E>0)
    A(j)=S(j).E;
end
end
a=1;
% avg=sum/n;
  %Election Probability for Normal Nodes
   pnrm=max(( p/ (1+a*m)),( (p/ (1+a*m))*(min(A)/mean(A))));
  %Election Probability for Advanced Nodes
  padv= ( p*(1+a)/(1+a*m)*(mean(A)/E1) );
    
  %Operation for heterogeneous epoch
  if(mod(r, round(1/pnrm) )==0)
    for i=1:1:n
        S(i).G=0;
        S(i).cl=0;
    end
  end

 %Operations for sub-epochs
 if(mod(r, round(1/padv) )==0)
    for i=1:1:n
        if(S(i).ENERGY==1)
            S(i).G=0;
            S(i).cl=0;
        end
    end
  end

 
hold off;

%Number of dead nodes
dead=0;
%Number of dead Advanced Nodes
dead_a=0;
%Number of dead Normal Nodes
dead_n=0;

%counter for bit transmitted to Bases Station and to Cluster Heads
packets_TO_BS=0;
packets_TO_CH=0;
%counter for bit transmitted to Bases Station and to Cluster Heads 
%per round
PACKETS_TO_CH(r+1)=0;
PACKETS_TO_BS(r+1)=0;

%estefigure(1);

for i=1:1:n
    %checking if there is a dead node
    if (S(i).E<=0)
 %este       plot(S(i).xd,S(i).yd,'red .');
        dead=dead+1;
        if(S(i).ENERGY==1)
            dead_a=dead_a+1;
        end
        if(S(i).ENERGY==0)
            dead_n=dead_n+1;
        end
        hold on;    
    end
    if S(i).E>0
        S(i).type='N';
        if (S(i).ENERGY==0)  
 %este       plot(S(i).xd,S(i).yd,'o');
        end
        if (S(i).ENERGY==1)  
  %este      plot(S(i).xd,S(i).yd,'+');
        end
        hold on;
    end
end
%este plot(S(n+1).xd,S(n+1).yd,'x');


STATISTICS(r+1).DEAD=dead;
DEAD(r+1)=dead;
DEAD_N(r+1)=dead_n;
DEAD_A(r+1)=dead_a;

%When the first node dies
if (dead==1)
    if(flag_first_dead==0)
        first_dead=r;
        flag_first_dead=1;
    end
end

countCHs=0;
cluster=1;
for i=1:1:n
   if(S(i).E>0)
   temp_rand=rand;     
   if ( (S(i).G)<=0)

 %Election of Cluster Heads for normal nodes
 if( ( S(i).ENERGY==0 && ( temp_rand <= ( pnrm / ( 1 - pnrm * mod(r,round(1/pnrm)) )) ) )  )
     
     countCHs=countCHs+1;
     packets_TO_BS=packets_TO_BS+1;
     PACKETS_TO_BS(r+1)=packets_TO_BS;
     
     S(i).type='C';
     S(i).G=100;
     C(cluster).xd=S(i).xd;
     C(cluster).yd=S(i).yd;
 %este    plot(S(i).xd,S(i).yd,'k*');
     
     distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
     C(cluster).distance=distance;
     C(cluster).id=i;
     X(cluster)=S(i).xd;
     Y(cluster)=S(i).yd;
     cluster=cluster+1;
     
     %Calculation of Energy dissipated
     distance;
     if (distance>do)
         S(i).E=S(i).E- ( (ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance ));
     end
     if (distance<=do)
         S(i).E=S(i).E- ( (ETX+EDA)*(4000)  + Efs*4000*( distance * distance ));
     end
 end
 


 %Election of Cluster Heads for Advanced nodes
 if( ( S(i).ENERGY==1 && ( temp_rand <= ( padv / ( 1 - padv * mod(r,round(1/padv)) )) ) )  )
        
            countCHs=countCHs+1;
            packets_TO_BS=packets_TO_BS+1;
            PACKETS_TO_BS(r+1)=packets_TO_BS;
            
            S(i).type='C';
            S(i).G=100;
            C(cluster).xd=S(i).xd;
            C(cluster).yd=S(i).yd;
 %este           plot(S(i).xd,S(i).yd,'k*');
            
            distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
            C(cluster).distance=distance;
            C(cluster).id=i;
            X(cluster)=S(i).xd;
            Y(cluster)=S(i).yd;
            cluster=cluster+1;
            
            %Calculation of Energy dissipated
            distance;
            if (distance>do)
                S(i).E=S(i).E- ( (ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance )); 
            end
            if (distance<=do)
                S(i).E=S(i).E- ( (ETX+EDA)*(4000)  + Efs*4000*( distance * distance )); 
            end
        end     
    
    end
  end 
end



STATISTICS(r+1).CLUSTERHEADS=cluster-1;
CLUSTERHS(r+1)=cluster-1;

%Election of Associated Cluster Head for Normal Nodes
for i=1:1:n
    if ( S(i).type=='N' && S(i).E>0 )
        if(cluster-1>=1)
            min_dis=sqrt( (S(i).xd-S(n+1).xd)^2 + (S(i).yd-S(n+1).yd)^2 );
            min_dis_cluster=1;
            for c=1:1:cluster-1
                temp=min(min_dis,sqrt( (S(i).xd-C(c).xd)^2 + (S(i).yd-C(c).yd)^2 ) );
                if ( temp<min_dis )
                    min_dis=temp;
                    min_dis_cluster=c;
                end
            end
            
            %Energy dissipated by associated Cluster Head
            min_dis;
            if (min_dis>do)
                S(i).E=S(i).E- ( ETX*(4000) + Emp*4000*( min_dis * min_dis * min_dis * min_dis));
            end
            if (min_dis<=do)
                S(i).E=S(i).E- ( ETX*(4000) + Efs*4000*( min_dis * min_dis));
            end
            %Energy dissipated
            if(min_dis>0)
                S(C(min_dis_cluster).id).E = S(C(min_dis_cluster).id).E- ( (ERX + EDA)*4000 );
                PACKETS_TO_CH(r+1)=n-dead-cluster+1;
            end
            
            S(i).min_dis=min_dis;
            S(i).min_dis_cluster=min_dis_cluster;
            
        end
    end
end
hold on;
    
    countCHs;
  
    rcountCHs=rcountCHs+countCHs;
    sum=0;
for i=1:1:n
if(S(i).E>0)
    sum=sum+S(i).E;
end
end
avg=sum/n;
STATISTICS(r+1).AVG=avg;
uu(r+1).AVG=(STATISTICS(r+1).AVG)*100;
sum;
    grid on;
%     if Eo==0.25
%         x(r+1)=uu(r+1).AVG;
%     end
  if Eo==0.5
    alive=u;
    x1(r+1)=uu(r+1).AVG;
end
if Eo==1
    alivee=u;
    x11(r+1)=uu(r+1).AVG;
end
if Eo==1.5
    aliveee=u;
    x111(r+1)=uu(r+1).AVG;
end
        

%     if Eo==1
%         x2(r+1)=uu(r+1).AVG;
%     end
%     [vx,vy]=voronoi(X,Y);
% plot(X,Y,'r*',vx,vy,'b-');
% hold on;
% voronoi(X,Y);
% axis([0 xm 0 ym]);
end % round


if Eo==0.5
    pack111=PACKETS_TO_BS;
    for i=1:1:rmax
    alive(i)=n-DEAD(i);      
    end
chs=CLUSTERHS;
end
if Eo==1
    pack1111=PACKETS_TO_BS;
    for i=1:1:rmax
    alivee(i)=n-DEAD(i);      
    end
chss=CLUSTERHS;
end
if Eo==1.5
    pack11111=PACKETS_TO_BS;
    for i=1:1:rmax
    aliveee(i)=n-DEAD(i);      
    end
chsss=CLUSTERHS;
end

save  chs.mat;
save  chss.mat;
save  chsss.mat;
save  pack111.mat;
save  pack1111.mat;
save  pack11111.mat;
save  alive.mat;
save  alivee.mat;
save  aliveee.mat;
save  x1.mat;
save  x11.mat;
save  x111.mat;
save  pa.mat;
save  pn.mat;
 end
% end
% figure(3)
% r=1:1:rmax;
% plot(x(r),r,'--',x1(r),r,'g',x2(r),r,':');
% legend(['m=0.1','  ','\alpha=3','  ','Eo=0.25'],['m=0.1','  ','\alpha=3','  ','Eo=0.50'],['m=0.1','  ','\alpha=3','  ','Eo=1']);
%     xlabel('Average Energy of Each Node');
%     ylabel('Round Number');   
%      hold on;

% figure(4)
% for 
% end
% figure(3)
% r=0:1:rmax;
%     plot(x,r,'--rs',x1,r,'g',x2,r,':');
%     legend(['m=0.1','  ','\alpha=1','  ','Eo=0.25'],['m=0.1','  ','\alpha=1','  ','Eo=0.50'],['m=0.1','  ','\alpha=1','  ','Eo=1']);
%     xlabel('Average Energy of Each Node');
%     ylabel('Round Number');
    

% figure(3)
% r=0:1:rmax;
% plot(x,r,'--rs',x1,r,'g',x2,r,':');
% xlabel('Average Energy of Each Node');
% ylabel('Round Number');
% legend(['m=0.1','  ','\alpha=1','  ','Eo=0.25'],['m=0.1','  ','\alpha=1','  ','Eo=0.50'],['m=0.1','  ','\alpha=1','  ','Eo=1']);
%      hold on;

% figure(3)
% r=0:1:rmax;
%        plot(x,r,'--rs',x1,r,'g',x2,r,':');
%     xlabel('Average Energy of Each Node');
%     ylabel('Round Number');
% %   legend(['Eo=' num2str(Eo),'','Eo=' num2str(Eo),'','Eo=' num2str(Eo)]);
%      hold on;
 
 
% 
% figure(4)
% r=1:1:rmax;
% plot(r,alive,'--');
% legend(['m=0.1','  ','\alpha=1']);
% ylabel('Number of AliveNodes')
% xlabel('Round Number')
% figure(4)
% r=1:1:rmax;
% plot(r,x,'--',r,x1,'g',r,x2,':');
% legend(['m=0.1','  ','\alpha=3'],['m=0.1','  ','\alpha=3'],['m=0.1','  ','\alpha=3']);
% ylabel('Number of AliveNodes')
% xlabel('Round Number')

% legend('SEP','Location','northeast');
% end
% end
 %  figure(4)
%  for r=0:1:rmax;
%     plot([r r+1],[STATISTICS(r+1).AVG STATISTICS(r+2).AVG],'red');
%     plot(r,alive,'color','blue');
%     hold on;
%  end


%%
%%SEP ORIGINAL

clear all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Field Dimensions - x and y maximum (in meters)
xm=100;
ym=100;

%x and y Coordinates of the Sink
sink.x=0.5*xm;
sink.y=0.5*ym;
 for loop = 1:3
   if loop==1
       Eo=0.5;
      
   end
    if loop==2
       Eo=1;
    
    end
    if loop==3
       Eo=1.5;
   
   end
%Number of Nodes in the field
n=100;
u=0;
%Optimal Election Probability of a node
%to become cluster head
p=0.1;

%Energy Model (all values in Joules)
%Initial Energy 
m=0.1;
%Eelec=Etx=Erx
ETX=50*0.000000001;
ERX=50*0.000000001;
%Transmit Amplifier types
Efs=10*0.000000000001;
Emp=0.0013*0.000000000001;
%Data Aggregation Energy
EDA=5*0.000000001;

%Values for Hetereogeneity
%Percentage of nodes than are advanced
%m=0.1;
%\alpha
a=1;

%maximum number of rounds
rmax=5000;

%%%%%%%%%%%%%%%%%%%%%%%%% END OF PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%

%Computation of do
do=sqrt(Efs/Emp); 

%Creation of the random Sensor Network
%este figure(1);
for i=1:1:n
    S(i).xd=rand(1,1)*xm;
    XR(i)=S(i).xd;
    S(i).yd=rand(1,1)*ym;
    YR(i)=S(i).yd;
    S(i).G=0;
    %initially there are no cluster heads only nodes
    S(i).type='N';
   
    temp_rnd0=i;
    %Random Election of Normal Nodes
    if (temp_rnd0>=m*n+1) 
        S(i).E=Eo;
        S(i).ENERGY=0;
        %%%%plot(S(i).xd,S(i).yd,'o');
        hold on;
    end
    %Random Election of Advanced Nodes
    if (temp_rnd0<m*n+1)  
        S(i).E=Eo*(1+a);
        S(i).ENERGY=1;
        %%%%plot(S(i).xd,S(i).yd,'+');
         hold on;
    end
end

S(n+1).xd=sink.x;
S(n+1).yd=sink.y;
%%%%plot(S(n+1).xd,S(n+1).yd,'x');
    
        
%First Iteration
%estefigure(1);

%counter for CHs
countCHs=0;
%counter for CHs per round
rcountCHs=0;
cluster=1;

countCHs;
rcountCHs=rcountCHs+countCHs;
flag_first_dead=0;

for r=0:1:rmax
   % r

  %Election Probability for Normal Nodes
  pnrm=( p/ (1+a*m) );
  %Election Probability for Advanced Nodes
  padv= ( p*(1+a)/(1+a*m) );
    
  %Operation for heterogeneous epoch
  if(mod(r, round(1/pnrm) )==0)
    for i=1:1:n
        S(i).G=0;
        S(i).cl=0;
    end
  end

 %Operations for sub-epochs
 if(mod(r, round(1/padv) )==0)
    for i=1:1:n
        if(S(i).ENERGY==1)
            S(i).G=0;
            S(i).cl=0;
        end
    end
  end

 
hold off;

%Number of dead nodes
dead=0;
%Number of dead Advanced Nodes
dead_a=0;
%Number of dead Normal Nodes
dead_n=0;

%counter for bit transmitted to Bases Station and to Cluster Heads
packets_TO_BS=0;
packets_TO_CH=0;
%counter for bit transmitted to Bases Station and to Cluster Heads 
%per round
PACKETS_TO_CH(r+1)=0;
PACKETS_TO_BS(r+1)=0;

%estefigure(1);

for i=1:1:n
    %checking if there is a dead node
    if (S(i).E<=0)
 %este       plot(S(i).xd,S(i).yd,'red .');
        dead=dead+1;
        if(S(i).ENERGY==1)
            dead_a=dead_a+1;
        end
        if(S(i).ENERGY==0)
            dead_n=dead_n+1;
        end
        hold on;    
    end
    if S(i).E>0
        S(i).type='N';
        if (S(i).ENERGY==0)  
 %este       plot(S(i).xd,S(i).yd,'o');
        end
        if (S(i).ENERGY==1)  
  %este      plot(S(i).xd,S(i).yd,'+');
        end
        hold on;
    end
end
%este plot(S(n+1).xd,S(n+1).yd,'x');


STATISTICS(r+1).DEAD=dead;
DEAD(r+1)=dead;
DEAD_N(r+1)=dead_n;
DEAD_A(r+1)=dead_a;

%When the first node dies
if (dead==1)
    if(flag_first_dead==0)
        first_dead=r;
        flag_first_dead=1;
    end
end

countCHs=0;
cluster=1;
for i=1:1:n
   if(S(i).E>0)
   temp_rand=rand;     
   if ( (S(i).G)<=0)

 %Election of Cluster Heads for normal nodes
 if( ( S(i).ENERGY==0 && ( temp_rand <= ( pnrm / ( 1 - pnrm * mod(r,round(1/pnrm)) )) ) )  )
     
     countCHs=countCHs+1;
     packets_TO_BS=packets_TO_BS+1;
     PACKETS_TO_BS(r+1)=packets_TO_BS;
     
     S(i).type='C';
     S(i).G=100;
     C(cluster).xd=S(i).xd;
     C(cluster).yd=S(i).yd;
 %este    plot(S(i).xd,S(i).yd,'k*');
     
     distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
     C(cluster).distance=distance;
     C(cluster).id=i;
     X(cluster)=S(i).xd;
     Y(cluster)=S(i).yd;
     cluster=cluster+1;
     
     %Calculation of Energy dissipated
     distance;
     if (distance>do)
         S(i).E=S(i).E- ( (ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance ));
     end
     if (distance<=do)
         S(i).E=S(i).E- ( (ETX+EDA)*(4000)  + Efs*4000*( distance * distance ));
     end
 end
 


 %Election of Cluster Heads for Advanced nodes
 if( ( S(i).ENERGY==1 && ( temp_rand <= ( padv / ( 1 - padv * mod(r,round(1/padv)) )) ) )  )
        
            countCHs=countCHs+1;
            packets_TO_BS=packets_TO_BS+1;
            PACKETS_TO_BS(r+1)=packets_TO_BS;
            
            S(i).type='C';
            S(i).G=100;
            C(cluster).xd=S(i).xd;
            C(cluster).yd=S(i).yd;
 %este           plot(S(i).xd,S(i).yd,'k*');
            
            distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
            C(cluster).distance=distance;
            C(cluster).id=i;
            X(cluster)=S(i).xd;
            Y(cluster)=S(i).yd;
            cluster=cluster+1;
            
            %Calculation of Energy dissipated
            distance;
            if (distance>do)
                S(i).E=S(i).E- ( (ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance )); 
            end
            if (distance<=do)
                S(i).E=S(i).E- ( (ETX+EDA)*(4000)  + Efs*4000*( distance * distance )); 
            end
        end     
    
    end
  end 
end



STATISTICS(r+1).CLUSTERHEADS=cluster-1;
CLUSTERHS(r+1)=cluster-1;

%Election of Associated Cluster Head for Normal Nodes
for i=1:1:n
    if ( S(i).type=='N' && S(i).E>0 )
        if(cluster-1>=1)
            min_dis=sqrt( (S(i).xd-S(n+1).xd)^2 + (S(i).yd-S(n+1).yd)^2 );
            min_dis_cluster=1;
            for c=1:1:cluster-1
                temp=min(min_dis,sqrt( (S(i).xd-C(c).xd)^2 + (S(i).yd-C(c).yd)^2 ) );
                if ( temp<min_dis )
                    min_dis=temp;
                    min_dis_cluster=c;
                end
            end
            
            %Energy dissipated by associated Cluster Head
            min_dis;
            if (min_dis>do)
                S(i).E=S(i).E- ( ETX*(4000) + Emp*4000*( min_dis * min_dis * min_dis * min_dis));
            end
            if (min_dis<=do)
                S(i).E=S(i).E- ( ETX*(4000) + Efs*4000*( min_dis * min_dis));
            end
            %Energy dissipated
            if(min_dis>0)
                S(C(min_dis_cluster).id).E = S(C(min_dis_cluster).id).E- ( (ERX + EDA)*4000 );
                PACKETS_TO_CH(r+1)=n-dead-cluster+1;
            end
            
            S(i).min_dis=min_dis;
            S(i).min_dis_cluster=min_dis_cluster;
            
        end
    end
end
hold on;
%     if DEAD(r+1)==n
%         rmax=r+1;
%         break;
%     end
countCHs;
rcountCHs=rcountCHs+countCHs;
  sum=0;
for i=1:1:n
if(S(i).E>0)
    sum=sum+S(i).E;
end
end
avg=sum/n;
STATISTICS(r+1).AVG=avg;
uu(r+1).AVG=(STATISTICS(r+1).AVG)*100;
sum;





%Code for Voronoi Cells
%Unfortynately if there is a small
%number of cells, Matlab's voronoi
%procedure has some problems

%[vx,vy]=voronoi(X,Y);
%plot(X,Y,'r*',vx,vy,'b-');
% hold on;
% voronoi(X,Y);
% axis([0 xm 0 ym]);
  if Eo==0.5
    alive1=u;
    x2(r+1)=uu(r+1).AVG;
end
if Eo==1
    alive11=u;
    x22(r+1)=uu(r+1).AVG;
end
if Eo==1.5
    alive111=u;
    x222(r+1)=uu(r+1).AVG;
end 

end

if Eo==0.5
    pack222=PACKETS_TO_BS;
    for i=1:1:rmax
    alive1(i)=n-DEAD(i);   
    end
chs1=CLUSTERHS;
end
if Eo==1
    pack2222=PACKETS_TO_BS;
       for i=1:1:rmax
    alive11(i)=n-DEAD(i);   
       end
chs11=CLUSTERHS;
end
if Eo==1.5
    pack22222=PACKETS_TO_BS;
       for i=1:1:rmax
    alive111(i)=n-DEAD(i);   
       end
chs111=CLUSTERHS;
end






save  chs1.mat;
save  chs11.mat;
save  chs111.mat;
save alive1.mat;
save alive11.mat;
save alive111.mat;
save  x2.mat;
save  x22.mat;
save  x222.mat;
save  pack222.mat;
save  pack2222.mat;
save  pack22222.mat;
end
% figure(3)
% r=1:1:rmax;
% plot(r,alive,'--');
% legend(['m=0.1','  ','\alpha=1']);
% ylabel('Number of AliveNodes')
% xlabel('Round Number')
% hold on;
%%
% %%LEACH
clear all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Field Dimensions - x and y maximum (in meters)
xm=100;
ym=100;

%x and y Coordinates of the Sink
sink.x=0.5*xm;
sink.y=0.5*ym;
 for loop = 1:3
   if loop==1
       Eo=0.5;
      
   end
    if loop==2
       Eo=1;
    
    end
    if loop==3
       Eo=1.5;
   
   end
%Number of Nodes in the field
n=100;

%Optimal Election Probability of a node
%to become cluster head
p=0.1;

%Energy Model (all values in Joules)
%Initial Energy 
m=0.1;
%Eelec=Etx=Erx
ETX=50*0.000000001;
ERX=50*0.000000001;
%Transmit Amplifier types
Efs=10*0.000000000001;
Emp=0.0013*0.000000000001;
%Data Aggregation Energy
EDA=5*0.000000001;

%Values for Hetereogeneity
%Percentage of nodes than are advanced
%m=0.1;
%\alpha
a=1;
u=0;
r_s=0;
%maximum number of rounds
rmax=5000;

%%%%%%%%%%%%%%%%%%%%%%%%% END OF PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%

%Computation of do
do=sqrt(Efs/Emp);

%Creation of the random Sensor Network
% figure(1);
for i=1:1:n
    S(i).xd=rand(1,1)*xm;
    XR(i)=S(i).xd;
    S(i).yd=rand(1,1)*ym;
    YR(i)=S(i).yd;
    S(i).G=0;
    %initially there are no cluster heads only nodes
    S(i).type='N';
   
    temp_rnd0=i;
    %Random Election of Normal Nodes
    if (temp_rnd0>=m*n+1) 
        S(i).E=Eo;
        S(i).ENERGY=0;
%         plot(S(i).xd,S(i).yd,'o');
        hold on;
    end
    %Random Election of Advanced Nodes
    if (temp_rnd0<m*n+1)  
        S(i).E=Eo*(1+a)
        S(i).ENERGY=1;
%         plot(S(i).xd,S(i).yd,'+');
        hold on;
    end
end

S(n+1).xd=sink.x;
S(n+1).yd=sink.y;
plot(S(n+1).xd,S(n+1).yd,'x');
    
        
%First Iteration
% figure(1);

%counter for CHs
countCHs=0;
%counter for CHs per round
rcountCHs=0;
cluster=1;

countCHs;
rcountCHs=rcountCHs+countCHs;
flag_first_dead=0;

for r=0:1:rmax
    r

  %Operation for epoch
  if(mod(r, round(1/p) )==0)
    for i=1:1:n
        S(i).G=0;
        S(i).cl=0;
    end
  end

hold off;

%Number of dead nodes
dead=0;
%Number of dead Advanced Nodes
dead_a=0;
%Number of dead Normal Nodes
dead_n=0;

%counter for bit transmitted to Bases Station and to Cluster Heads
packets_TO_BS=0;
packets_TO_CH=0;
%counter for bit transmitted to Bases Station and to Cluster Heads 
%per round
PACKETS_TO_CH(r+1)=0;
PACKETS_TO_BS(r+1)=0;

% figure(1);

for i=1:1:n
    %checking if there is a dead node
    if (S(i).E<=0)
%         plot(S(i).xd,S(i).yd,'red .');
        dead=dead+1;
        if(S(i).ENERGY==1)
            dead_a=dead_a+1;
        end
        if(S(i).ENERGY==0)
            dead_n=dead_n+1;
        end
        hold on;    
    end
    if S(i).E>0
        S(i).type='N';
        if (S(i).ENERGY==0)  
%         plot(S(i).xd,S(i).yd,'o');
        end
        if (S(i).ENERGY==1)  
%         plot(S(i).xd,S(i).yd,'+');
        end
        hold on;
    end
end
% plot(S(n+1).xd,S(n+1).yd,'x');


STATISTICS(r+1).DEAD=dead;
DEAD(r+1)=dead;
DEAD_N(r+1)=dead_n;
DEAD_A(r+1)=dead_a;

%When the first node dies
if (dead==1)
    if(flag_first_dead==0)
        first_dead=r
        flag_first_dead=1;
    end
end

countCHs=0;
cluster=1;
for i=1:1:n
   if(S(i).E>0)
   temp_rand=rand;     
   if ( (S(i).G)<=0)

 %Election of Cluster-Heads
 if(temp_rand<= (p/(1-p*mod(r,round(1/p)))))
            countCHs=countCHs+1;
            packets_TO_BS=packets_TO_BS+1;
            PACKETS_TO_BS(r+1)=packets_TO_BS;
            
            S(i).type='C';
            S(i).G=round(1/p)-1;
            C(cluster).xd=S(i).xd;
            C(cluster).yd=S(i).yd;
%             plot(S(i).xd,S(i).yd,'k*');
            
            distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
            C(cluster).distance=distance;
            C(cluster).id=i;
            X(cluster)=S(i).xd;
            Y(cluster)=S(i).yd;
            cluster=cluster+1;
            
            %Calculation of Energy dissipated
            distance;
            if (distance>do)
                S(i).E=S(i).E- ( (ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance )); 
            end
            if (distance<=do)
                S(i).E=S(i).E- ( (ETX+EDA)*(4000)  + Efs*4000*( distance * distance )); 
            end
        end     
    
    end
  end 
end

STATISTICS(r+1).CLUSTERHEADS=cluster-1;
CLUSTERHS(r+1)=cluster-1;

%Election of Associated Cluster Head for Normal Nodes
for i=1:1:n
   if ( S(i).type=='N' && S(i).E>0 )
     if(cluster-1>=1)
       min_dis=sqrt( (S(i).xd-S(n+1).xd)^2 + (S(i).yd-S(n+1).yd)^2 );
       min_dis_cluster=1;
       for c=1:1:cluster-1
           temp=min(min_dis,sqrt( (S(i).xd-C(c).xd)^2 + (S(i).yd-C(c).yd)^2 ) );
           if ( temp<min_dis )
               min_dis=temp;
               min_dis_cluster=c;
           end
       end
       
       %Energy dissipated by associated Cluster Head
            min_dis;
            if (min_dis>do)
                S(i).E=S(i).E- ( ETX*(4000) + Emp*4000*( min_dis * min_dis * min_dis * min_dis)); 
            end
            if (min_dis<=do)
                S(i).E=S(i).E- ( ETX*(4000) + Efs*4000*( min_dis * min_dis)); 
            end
        %Energy dissipated
        if(min_dis>0)
          S(C(min_dis_cluster).id).E = S(C(min_dis_cluster).id).E- ( (ERX + EDA)*4000 ); 
         PACKETS_TO_CH(r+1)=n-dead-cluster+1; 
        end

       S(i).min_dis=min_dis;
       S(i).min_dis_cluster=min_dis_cluster;
           
   end
 end
end
hold on;
% if DEAD(r+1)==n
%     rmax=r+1;
%     break;
% end
countCHs;
rcountCHs=rcountCHs+countCHs;
  sum=0;
for i=1:1:n
if(S(i).E>0)
    sum=sum+S(i).E;
end
end

avg=sum/n;
STATISTICS(r+1).AVG=avg;
uu(r+1).AVG=(STATISTICS(r+1).AVG)*100;
sum;



%Code for Voronoi Cells
%Unfortynately if there is a small
%number of cells, Matlab's voronoi
%procedure has some problems

%[vx,vy]=voronoi(X,Y);
%plot(X,Y,'r*',vx,vy,'b-');
% hold on;
% voronoi(X,Y);
% axis([0 xm 0 ym]);
if Eo==0.5
    alive2=u;
    x3(r+1)=uu(r+1).AVG;
end
if Eo==1    
    alive22=u;
    x33(r+1)=uu(r+1).AVG;
end
if Eo==1.5    
    alive222=u;
    x333(r+1)=uu(r+1).AVG;
end
end

if Eo==0.5
       pack333=PACKETS_TO_BS;
       for i=1:1:rmax
    alive2(i)=n-DEAD(i);
       end
chs2=CLUSTERHS;
    end
if Eo==1
   pack3333=PACKETS_TO_BS;
   for i=1:1:rmax
    alive22(i)=n-DEAD(i);
   end
chs22=CLUSTERHS;
end
if Eo==1.5
   pack33333=PACKETS_TO_BS;
   for i=1:1:rmax
    alive222(i)=n-DEAD(i);
   end
chs222=CLUSTERHS;
end 
save  pack333.mat;
save  pack3333.mat;
save  pack33333.mat;
save  chs2.mat;
save  chs22.mat;
save  chs222.mat;
save alive2.mat;
save alive22.mat;
save alive222.mat;
save  x3.mat;
save  x33.mat;
save  x333.mat;
end



% figure(5)
% r= 1:1:rmax;
% plot(r,alive,'r');  



%%

% %%A-LEACH
% 
% clear all;
% clc;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% %Field Dimensions - x and y maximum (in meters)
% xm=100;
% ym=100;
% 
% %x and y Coordinates of the Sink
% sink.x=0.5*xm;
% sink.y=0.5*ym;
% 
% %Number of Nodes in the field
% n=100;
% 
% %Optimal Election Probability of a node
% %to become cluster head
% p=0.1;
% 
% %Energy Model (all values in Joules)
% %Initial Energy 
% Eo=0.5;
% %Eelec=Etx=Erx
% ETX=50*0.000000001;
% ERX=50*0.000000001;
% %Transmit Amplifier types
% Efs=10*0.000000000001;
% Emp=0.0013*0.000000000001;
% %Data Aggregation Energy
% EDA=5*0.000000001;
% 
% %Values for Hetereogeneity
% %Percentage of nodes than are advanced
% m=0.1;
% %\alpha
% a=1;
% u=0;
% x4=0;
% %maximum number of rounds
% rmax=5000;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%% END OF PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%
% 
% %Computation of do
% do=sqrt(Efs/Emp);
% 
% %Creation of the random Sensor Network
% %figure(1);
% for i=1:1:n
%     S(i).xd=rand(1,1)*xm;
%     XR(i)=S(i).xd;
%     S(i).yd=rand(1,1)*ym;
%     YR(i)=S(i).yd;
%     S(i).G=0;
%     %initially there are no cluster heads only nodes
%     S(i).type='N';
%    
%     temp_rnd0=i;
%     %Random Election of Normal Nodes
%     if (temp_rnd0>=m*n+1) 
%         S(i).E=Eo;
%         S(i).ENERGY=0;
%   %      plot(S(i).xd,S(i).yd,'o');
%         hold on;
%     end
%     %Random Election of Advanced Nodes
%     if (temp_rnd0<m*n+1)  
%         S(i).E=Eo*(1+a);
%         S(i).ENERGY=1;
%    %     plot(S(i).xd,S(i).yd,'+');
%         hold on;
%     end
% end
% 
% S(n+1).xd=sink.x;
% S(n+1).yd=sink.y;
% %plot(S(n+1).xd,S(n+1).yd,'x');
%     
%         
% %First Iteration
% %figure(1);
% 
% %counter for CHs
% countCHs=0;
% %counter for CHs per round
% rcountCHs=0;
% cluster=1;
% 
% countCHs;
% rcountCHs=rcountCHs+countCHs;
% flag_first_dead=0;
% 
% for r=0:1:rmax
%     r
% 
%   %Operation for epoch
%   if(mod(r, round(1/p) )==0)
%     for i=1:1:n
%         S(i).G=0;
%         S(i).cl=0;
%     end
%   end
% 
% hold off;
% 
% %Number of dead nodes
% dead=0;
% %Number of dead Advanced Nodes
% dead_a=0;
% %Number of dead Normal Nodes
% dead_n=0;
% 
% %counter for bit transmitted to Bases Station and to Cluster Heads
% packets_TO_BS=0;
% packets_TO_CH=0;
% %counter for bit transmitted to Bases Station and to Cluster Heads 
% %per round
% PACKETS_TO_CH(r+1)=0;
% PACKETS_TO_BS(r+1)=0;
% 
% %figure(1);
% 
% for i=1:1:n
%     %checking if there is a dead node
%     if (S(i).E<=0)
%  %      plot(S(i).xd,S(i).yd,'red .');
%         dead=dead+1;
%         if(S(i).ENERGY==1)
%             dead_a=dead_a+1;
%         end
%         if(S(i).ENERGY==0)
%             dead_n=dead_n+1;
%         end
%         hold on;    
%     end
%     if S(i).E>0
%         S(i).type='N';
%         if (S(i).ENERGY==0)  
%   %     plot(S(i).xd,S(i).yd,'o');
%         end
%         if (S(i).ENERGY==1)  
%    %     plot(S(i).xd,S(i).yd,'+');
%         end
%         hold on;
%     end
% end
% %plot(S(n+1).xd,S(n+1).yd,'x');
% 
% 
% STATISTICS(r+1).DEAD=dead;
% DEAD(r+1)=dead;
% DEAD_N(r+1)=dead_n;
% DEAD_A(r+1)=dead_a;
% 
% %When the first node dies
% if (dead==1)
%     if(flag_first_dead==0)
%         first_dead=r;
%         flag_first_dead=1;
%     end
% end
% 
% countCHs=0;
% cluster=1;
%  %*r_s=0;
%  cl1=0;
% for i=1:1:n 
%    %*  r_s=r_s+1;
%    if(S(i).E>0)
%    temp_rand=rand;     
%    if ( (S(i).G)<=0)
% 
%  %Election of Cluster-Heads
%  if(temp_rand<= (p/(n-p*mod(r,round(n/p))))+((S(i).E/Eo)*(p/n)))    
%    %*((S(i).E/Eo)+(r_s/(1/p))*(1-(S(i).E/Eo)))
%    cl1=cl1+1;
%      countCHs=countCHs+1;
%      packets_TO_BS=packets_TO_BS+1;
%      PACKETS_TO_BS(r+1)=packets_TO_BS;
%      
%      S(i).type='C';
%      S(i).G=round(1/p)-1;
%      C(cluster).xd=S(i).xd;
%      C(cluster).yd=S(i).yd;
%   %   plot(S(i).xd,S(i).yd,'k*');
%      
%      distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
%      C(cluster).distance=distance;
%      C(cluster).id=i;
%      X(cluster)=S(i).xd;
%      Y(cluster)=S(i).yd;
%      cluster=cluster+1;
%      
%      %Calculation of Energy dissipated
%      distance;
%      if (distance>do)
%          S(i).E=S(i).E- ( (ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance ));
%      end
%      if (distance<=do)
%          S(i).E=S(i).E- ( (ETX+EDA)*(4000)  + Efs*4000*( distance * distance ));
%      end
%  end
%     
%     end
%    end 
%  % r_s=0;
% 
% end
% 
% STATISTICS(r+1).CLUSTERHEADS=cluster-1;
% CLUSTERHS(r+1)=cluster-1;
% 
% %Election of Associated Cluster Head for Normal Nodes
% for i=1:1:n
%    if ( S(i).type=='N' && S(i).E>0 )
%      if(cluster-1>=1)
%        min_dis=sqrt( (S(i).xd-S(n+1).xd)^2 + (S(i).yd-S(n+1).yd)^2 );
%        min_dis_cluster=1;
%        for c=1:1:cluster-1
%            temp=min(min_dis,sqrt( (S(i).xd-C(c).xd)^2 + (S(i).yd-C(c).yd)^2 ) );
%            if ( temp<min_dis )
%                min_dis=temp;
%                min_dis_cluster=c;
%            end
%        end
%        
%        %Energy dissipated by associated Cluster Head
%             min_dis;
%             if (min_dis>do)
%                 S(i).E=S(i).E- ( ETX*(4000) + Emp*4000*( min_dis * min_dis * min_dis * min_dis)); 
%             end
%             if (min_dis<=do)
%                 S(i).E=S(i).E- ( ETX*(4000) + Efs*4000*( min_dis * min_dis)); 
%             end
%         %Energy dissipated
%         if(min_dis>0)
%           S(C(min_dis_cluster).id).E = S(C(min_dis_cluster).id).E- ( (ERX + EDA)*4000 ); 
%          PACKETS_TO_CH(r+1)=n-dead-cluster+1; 
%         end
% 
%        S(i).min_dis=min_dis;
%        S(i).min_dis_cluster=min_dis_cluster;
%            
%    end
%  end
% end
% hold on;
% % if DEAD(r+1)==n
% %     rmax=r+1;
% %     break;
% % end
% countCHs;
% rcountCHs=rcountCHs+countCHs;
%   sum=0;
% for i=1:1:n
% if(S(i).E>0)
%     sum=sum+S(i).E;
% end
% end
% 
% 
% 
% 
% %Code for Voronoi Cells
% %Unfortynately if there is a small
% %number of cells, Matlab's voronoi
% %procedure has some problems
% 
% %[vx,vy]=voronoi(X,Y);
% %plot(X,Y,'r*',vx,vy,'b-');
% % hold on;
% % voronoi(X,Y);
% % axis([0 xm 0 ym]);
% 
% end
% pack3=PACKETS_TO_BS;
% alive3=u;
% 
% 
% j=0;
% CL=0;
% for i=1:rmax
%     if CLUSTERHS(i)~=0
%         j=j+1;
%         CL(j)=CLUSTERHS(i);  
%         DEAD1(j)=DEAD(i);
%         avg=sum/n;
% STATISTICS(i+1).AVG=avg;
% uu(i+1).AVG=(STATISTICS(i+1).AVG)*100;
% sum;
% x4(i+1)=uu(i+1).AVG;
%     end
%     
% end
% 
% for i=1:1:j
%     alive3(i)=n-DEAD1(i);
% end
% 
% for i=(j+1):1:rmax
%     alive3(i)=0;
%     x4(i)=0;
%     pack3(i)=0;
% end
% 
% save  pack3.mat;
% save alive3.mat;
% save  x4.mat;
% % figure(5)
% % r= 1:1:rmax;
% % plot(r,alive,'r');  
%%
%%M-SEP ORIGINAL

clear all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Field Dimensions - x and y maximum (in meters)
xm=100;
ym=100;

%x and y Coordinates of the Sink
sink.x=0.5*xm;
sink.y=0.5*ym;
 for loop = 1:3
   if loop==1
       Eo=0.5;
      
   end
    if loop==2
       Eo=1;
    
    end
    if loop==3
       Eo=1.5;
   
   end
%Number of Nodes in the field
n=100;
u=0;
%Optimal Election Probability of a node
%to become cluster head
p=0.1;

%Energy Model (all values in Joules)
%Initial Energy 
m=0.1;
%Eelec=Etx=Erx
ETX=50*0.000000001;
ERX=50*0.000000001;
%Transmit Amplifier types
Efs=10*0.000000000001;
Emp=0.0013*0.000000000001;
%Data Aggregation Energy
EDA=5*0.000000001;

%Values for Hetereogeneity
%Percentage of nodes than are advanced
%m=0.1;
%\alpha
a=1;

%maximum number of rounds
rmax=5000;

%%%%%%%%%%%%%%%%%%%%%%%%% END OF PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%

%Computation of do
do=sqrt(Efs/Emp); 

%Creation of the random Sensor Network
%este figure(1);
for i=1:1:n
    S(i).xd=rand(1,1)*xm;
    XR(i)=S(i).xd;
    S(i).yd=rand(1,1)*ym;
    YR(i)=S(i).yd;
    S(i).G=0;
    %initially there are no cluster heads only nodes
    S(i).type='N';
   
    temp_rnd0=i;
    %Random Election of Normal Nodes
    if (temp_rnd0>=m*n+1) 
        S(i).E=Eo;
        S(i).ENERGY=0;
        %%%%plot(S(i).xd,S(i).yd,'o');
        hold on;
    end
    %Random Election of Advanced Nodes
    if (temp_rnd0<m*n+1)  
        S(i).E=Eo*(1+a);
        E1=S(i).E;
        S(i).ENERGY=1;
        %%%%plot(S(i).xd,S(i).yd,'+');
         hold on;
    end
end

S(n+1).xd=sink.x;
S(n+1).yd=sink.y;
%%%%plot(S(n+1).xd,S(n+1).yd,'x');
    
        
%First Iteration
%estefigure(1);

%counter for CHs
countCHs=0;
%counter for CHs per round
rcountCHs=0;
cluster=1;

countCHs;
rcountCHs=rcountCHs+countCHs;
flag_first_dead=0;

for r=0:1:rmax
   % r

 %Election Probability for Normal Nodes
  pnrm=(p/(1+a*m*S(i).E));
  %Election Probability for Advanced Nodes
  padv= (p*(1+a)/(1+a*m*S(i).E));
    
  %Operation for heterogeneous epoch
  if(mod(r, round(1/pnrm) )==0)
    for i=1:1:n
        S(i).G=0;
        S(i).cl=0;
    end
  end

 %Operations for sub-epochs
 if(mod(r, round(1/padv) )==0)
    for i=1:1:n
        if(S(i).ENERGY==1)
            S(i).G=0;
            S(i).cl=0;
        end
    end
  end

 
hold off;

%Number of dead nodes
dead=0;
%Number of dead Advanced Nodes
dead_a=0;
%Number of dead Normal Nodes
dead_n=0;

%counter for bit transmitted to Bases Station and to Cluster Heads
packets_TO_BS=0;
packets_TO_CH=0;
%counter for bit transmitted to Bases Station and to Cluster Heads 
%per round
PACKETS_TO_CH(r+1)=0;
PACKETS_TO_BS(r+1)=0;

%estefigure(1);

for i=1:1:n
    %checking if there is a dead node
    if (S(i).E<=0)
 %este       plot(S(i).xd,S(i).yd,'red .');
        dead=dead+1;
        if(S(i).ENERGY==1)
            dead_a=dead_a+1;
        end
        if(S(i).ENERGY==0)
            dead_n=dead_n+1;
        end
        hold on;    
    end
    if S(i).E>0
        S(i).type='N';
        if (S(i).ENERGY==0)  
 %este       plot(S(i).xd,S(i).yd,'o');
        end
        if (S(i).ENERGY==1)  
  %este      plot(S(i).xd,S(i).yd,'+');
        end
        hold on;
    end
end
%este plot(S(n+1).xd,S(n+1).yd,'x');


STATISTICS(r+1).DEAD=dead;
DEAD(r+1)=dead;
DEAD_N(r+1)=dead_n;
DEAD_A(r+1)=dead_a;

%When the first node dies
if (dead==1)
    if(flag_first_dead==0)
        first_dead=r;
        flag_first_dead=1;
    end
end

countCHs=0;
cluster=1;
sum=0;
for i=1:1:n
if(S(i).E>0)
    sum=sum+S(i).E;
end
end
Eavg=sum/n;
for i=1:1:n
   if(S(i).E>0)
   temp_rand=rand;     
   if ( (S(i).G)<=0)

 %Election of Cluster Heads for normal nodes
 if( ( S(i).ENERGY==0 && ( temp_rand <= (( 3*pnrm / ( 1 - pnrm * mod(r,round(1/(3*pnrm))) ))*(Eavg/Eo)) ) )  )
     
     countCHs=countCHs+1;
     packets_TO_BS=packets_TO_BS+1;
     PACKETS_TO_BS(r+1)=packets_TO_BS;
     
     S(i).type='C';
     S(i).G=100;
     C(cluster).xd=S(i).xd;
     C(cluster).yd=S(i).yd;
 %este    plot(S(i).xd,S(i).yd,'k*');
     
     distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
     C(cluster).distance=distance;
     C(cluster).id=i;
     X(cluster)=S(i).xd;
     Y(cluster)=S(i).yd;
     cluster=cluster+1;
     
     %Calculation of Energy dissipated
     distance;
     if (distance>do)
         S(i).E=S(i).E- ( (ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance ));
     end
     if (distance<=do)
         S(i).E=S(i).E- ( (ETX+EDA)*(4000)  + Efs*4000*( distance * distance ));
     end
 end
 


 %Election of Cluster Heads for Advanced nodes
 if( ( S(i).ENERGY==1 && ( temp_rand <= (( 3*padv / ( 1 - padv * mod(r,round(1/(3*padv))) ))*(Eavg/E1)) ) )  )
        
            countCHs=countCHs+1;
            packets_TO_BS=packets_TO_BS+1;
            PACKETS_TO_BS(r+1)=packets_TO_BS;
            
            S(i).type='C';
            S(i).G=100;
            C(cluster).xd=S(i).xd;
            C(cluster).yd=S(i).yd;
 %este           plot(S(i).xd,S(i).yd,'k*');
            
            distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
            C(cluster).distance=distance;
            C(cluster).id=i;
            X(cluster)=S(i).xd;
            Y(cluster)=S(i).yd;
            cluster=cluster+1;
            
            %Calculation of Energy dissipated
            distance;
            if (distance>do)
                S(i).E=S(i).E- ( (ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance )); 
            end
            if (distance<=do)
                S(i).E=S(i).E- ( (ETX+EDA)*(4000)  + Efs*4000*( distance * distance )); 
            end
        end     
    
    end
  end 
end



STATISTICS(r+1).CLUSTERHEADS=cluster-1;
CLUSTERHS(r+1)=cluster-1;

%Election of Associated Cluster Head for Normal Nodes
for i=1:1:n
    if ( S(i).type=='N' && S(i).E>0 )
        if(cluster-1>=1)
            min_dis=sqrt( (S(i).xd-S(n+1).xd)^2 + (S(i).yd-S(n+1).yd)^2 );
            min_dis_cluster=1;
            for c=1:1:cluster-1
                temp=min(min_dis,sqrt( (S(i).xd-C(c).xd)^2 + (S(i).yd-C(c).yd)^2 ) );
                if ( temp<min_dis )
                    min_dis=temp;
                    min_dis_cluster=c;
                end
            end
            
            %Energy dissipated by associated Cluster Head
            min_dis;
            if (min_dis>do)
                S(i).E=S(i).E- ( ETX*(4000) + Emp*4000*( min_dis * min_dis * min_dis * min_dis));
            end
            if (min_dis<=do)
                S(i).E=S(i).E- ( ETX*(4000) + Efs*4000*( min_dis * min_dis));
            end
            %Energy dissipated
            if(min_dis>0)
                S(C(min_dis_cluster).id).E = S(C(min_dis_cluster).id).E- ( (ERX + EDA)*4000 );
                PACKETS_TO_CH(r+1)=n-dead-cluster+1;
            end
            
            S(i).min_dis=min_dis;
            S(i).min_dis_cluster=min_dis_cluster;
            
        end
    end
end
hold on;
%     if DEAD(r+1)==n
%         rmax=r+1;
%         break;
%     end
countCHs;
rcountCHs=rcountCHs+countCHs;
  sum=0;
for i=1:1:n
if(S(i).E>0)
    sum=sum+S(i).E;
end
end
avg=sum/n;
STATISTICS(r+1).AVG=avg;
uu(r+1).AVG=(STATISTICS(r+1).AVG)*100;
sum;


% if m==0.1
%     x=u;
% end
% if m==0.2
%     x1=u;
% end
% if m==0.3
%     x2=u;
% end

%Code for Voronoi Cells
%Unfortynately if there is a small
%number of cells, Matlab's voronoi
%procedure has some problems

%[vx,vy]=voronoi(X,Y);
%plot(X,Y,'r*',vx,vy,'b-');
% hold on;
% voronoi(X,Y);
% axis([0 xm 0 ym]);
 if Eo==0.5
    x5(r+1)=uu(r+1).AVG;
    alive4=u;
end
if Eo==1    
    alive44=u;
    x55(r+1)=uu(r+1).AVG;
end
if Eo==1.5
    x555(r+1)=uu(r+1).AVG;
    alive444=u;
end  

end


if Eo==0.5
       pack444=PACKETS_TO_BS;
       for i=1:1:rmax
    alive4(i)=n-DEAD(i);     
       end
chs3=CLUSTERHS;
    end
if Eo==1
   pack4444=PACKETS_TO_BS;
   for i=1:1:rmax
    alive44(i)=n-DEAD(i);   
   end
chs33=CLUSTERHS;
end
if Eo==1.5
   pack44444=PACKETS_TO_BS;
   for i=1:1:rmax
    alive444(i)=n-DEAD(i);   
   end
chs333=CLUSTERHS;
end 
save  pack444.mat;
save  pack4444.mat;
save  pack44444.mat;
save alive4.mat;
save alive44.mat;
save alive444.mat;
save  x5.mat;
save  x55.mat;
save  x555.mat;
save  chs3.mat;
save  chs33.mat;
save  chs333.mat;
 end


% figure(3)
% r=1:1:rmax;
% plot(r,alive,'--');
% legend(['m=0.1','  ','\alpha=1']);
% ylabel('Number of AliveNodes')
% xlabel('Round Number')
% hold on;


%%

% %% EM-SEP ORIGINAL
% 
% clear all;
% clc;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% %Field Dimensions - x and y maximum (in meters)
% xm=100;
% ym=100;
% 
% %x and y Coordinates of the Sink
% sink.x=0.5*xm;
% sink.y=0.5*ym;
%  for loop = 1:3
%    if loop==1
%        m=0.1;
%       
%    end
%     if loop==2
%        m=0.1;
%     
%     end
%     if loop==3
%        m=0.1;
%    
%    end
% %Number of Nodes in the field
% n=100;
% u=0;
% %Optimal Election Probability of a node
% %to become cluster head
% p=0.1;
% 
% %Energy Model (all values in Joules)
% %Initial Energy 
% Eo=0.5;
% %Eelec=Etx=Erx
% ETX=50*0.000000001;
% ERX=50*0.000000001;
% %Transmit Amplifier types
% Efs=10*0.000000000001;
% Emp=0.0013*0.000000000001;
% %Data Aggregation Energy
% EDA=5*0.000000001;
% 
% %Values for Hetereogeneity
% %Percentage of nodes than are advanced
% %m=0.1;
% %\alpha
% a=1;
% mo=0.9;
% %maximum number of rounds
% rmax=5000;
% 
% %%%%%%%%%%%%%%%%%%%%%%%%% END OF PARAMETERS %%%%%%%%%%%%%%%%%%%%%%%%
% 
% %Computation of do
% do=sqrt(Efs/Emp); 
% E1=Eo*(1+a);
% %Creation of the random Sensor Network
% %este figure(1);
% for i=1:1:n
%     S(i).xd=rand(1,1)*xm;
%     XR(i)=S(i).xd;
%     S(i).yd=rand(1,1)*ym;
%     YR(i)=S(i).yd;
%     S(i).G=0;
%     %initially there are no cluster heads only nodes
%     S(i).type='N';
%    
%     temp_rnd0=i;
%     %Random Election of Normal Nodes
%     if (temp_rnd0>=m*n+1) 
%         S(i).E=Eo;
%         S(i).ENERGY=0;
%         %%%%plot(S(i).xd,S(i).yd,'o');
%         hold on;
%     end
%     %Random Election of Advanced Nodes
%     if (temp_rnd0<m*n+1)  
%         S(i).E=Eo*(1+a);
%         S(i).ENERGY=1;
%         %%%%plot(S(i).xd,S(i).yd,'+');
%          hold on;
%     end
% end
% 
% S(n+1).xd=sink.x;
% S(n+1).yd=sink.y;
% %%%%plot(S(n+1).xd,S(n+1).yd,'x');
%     
%         
% %First Iteration
% %estefigure(1);
% 
% %counter for CHs
% countCHs=0;
% %counter for CHs per round
% rcountCHs=0;
% cluster=1;
% 
% countCHs;
% rcountCHs=rcountCHs+countCHs;
% flag_first_dead=0;
% 
% for r=0:1:rmax
%    % r
%  distance=0.765*(xm/2);
% K_opt=sqrt(n/(2*pi))*(0.765);
%  p=K_opt/n;  
%   %Election Probability for Normal Nodes
%   pnrm=( p/ (1+a*m) );
%   %Election Probability for Advanced Nodes
%   padv= ( (p*(1+a))/ (1+a*m)) ;
%     
%   %Operation for heterogeneous epoch
%   if(mod(r, round(1/pnrm))==0)
%     for i=1:1:n
%         S(i).G=0;
%         S(i).cl=0;
%     end
%   end
% 
%  %Operations for sub-epochs
%  if(mod(r, round(1/padv) )==0)
%     for i=1:1:n
%         if(S(i).ENERGY==1)
%             S(i).G=0;
%             S(i).cl=0;
%         end
%     end
%   end
% 
%  
% hold off;
% 
% %Number of dead nodes
% dead=0;
% %Number of dead Advanced Nodes
% dead_a=0;
% %Number of dead Normal Nodes
% dead_n=0;
% 
% %counter for bit transmitted to Bases Station and to Cluster Heads
% packets_TO_BS=0;
% packets_TO_CH=0;
% %counter for bit transmitted to Bases Station and to Cluster Heads 
% %per round
% PACKETS_TO_CH(r+1)=0;
% PACKETS_TO_BS(r+1)=0;
% 
% %estefigure(1);
% 
% for i=1:1:n
%     %checking if there is a dead node
%     if (S(i).E<=0)
%  %este       plot(S(i).xd,S(i).yd,'red .');
%         dead=dead+1;
%         if(S(i).ENERGY==1)
%             dead_a=dead_a+1;
%         end
%         if(S(i).ENERGY==0)
%             dead_n=dead_n+1;
%         end
%         hold on;    
%     end
%     if S(i).E>0
%         S(i).type='N';
%         if (S(i).ENERGY==0)  
%  %este       plot(S(i).xd,S(i).yd,'o');
%         end
%         if (S(i).ENERGY==1)  
%   %este      plot(S(i).xd,S(i).yd,'+');
%         end
%         hold on;
%     end
% end
% %este plot(S(n+1).xd,S(n+1).yd,'x');
% 
% 
% STATISTICS(r+1).DEAD=dead;
% DEAD(r+1)=dead;
% DEAD_N(r+1)=dead_n;
% DEAD_A(r+1)=dead_a;
% 
% %When the first node dies
% if (dead==1)
%     if(flag_first_dead==0)
%         first_dead=r;
%         flag_first_dead=1;
%     end
% end
% 
% countCHs=0;
% cluster=1;
% for i=1:1:n
%    if(S(i).E>0)
%    temp_rand=rand;     
%    if ( (S(i).G)<=0)
% 
%  %Election of Cluster Heads for normal nodes
%  if( ( S(i).ENERGY==0 && ( temp_rand <= ( pnrm / ( 1 - pnrm * mod(r,round(1/pnrm)) )) ) )  )
%      
%      countCHs=countCHs+1;
%      packets_TO_BS=packets_TO_BS+1;
%      PACKETS_TO_BS(r+1)=packets_TO_BS;
%      
%      S(i).type='C';
%      S(i).G=100;
%      C(cluster).xd=S(i).xd;
%      C(cluster).yd=S(i).yd;
%  %este    plot(S(i).xd,S(i).yd,'k*');
%      
%      distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
%      C(cluster).distance=distance;
%      C(cluster).id=i;
%      X(cluster)=S(i).xd;
%      Y(cluster)=S(i).yd;
%      cluster=cluster+1;
%      
%      %Calculation of Energy dissipated
%      distance;
%      if (distance>do)
%          S(i).E=S(i).E- (((ETX+EDA)*(4000)*((n/cluster)-1)) +((ETX+EDA)*(4000)*((n/cluster)))+ Emp*4000*( distance*distance*distance*distance ));
%      end
%      if (distance<=do)
%          S(i).E=S(i).E- (((ETX+EDA)*(4000)*((n/cluster)-1)) +((ETX+EDA)*(4000)*((n/cluster)))+ Efs*4000*( distance * distance ));
%      end
%  end
%  
% 
% 
%  %Election of Cluster Heads for Advanced nodes
%  if( ( S(i).ENERGY==1 && ( temp_rand <= ( padv / ( 1 - padv * mod(r,round(1/padv)) )) ) )  )
%         
%             countCHs=countCHs+1;
%             packets_TO_BS=packets_TO_BS+1;
%             PACKETS_TO_BS(r+1)=packets_TO_BS;
%             
%             S(i).type='C';
%             S(i).G=100;
%             C(cluster).xd=S(i).xd;
%             C(cluster).yd=S(i).yd;
%  %este           plot(S(i).xd,S(i).yd,'k*');
%             
%             distance=sqrt( (S(i).xd-(S(n+1).xd) )^2 + (S(i).yd-(S(n+1).yd) )^2 );
%             C(cluster).distance=distance;
%             C(cluster).id=i;
%             X(cluster)=S(i).xd;
%             Y(cluster)=S(i).yd;
%             cluster=cluster+1;
%             
%             %Calculation of Energy dissipated
%             distance;
%             if (distance>do)
%                 S(i).E=S(i).E- ( (ETX+EDA)*(4000) + Emp*4000*( distance*distance*distance*distance )); 
%             end
%             if (distance<=do)
%                 S(i).E=S(i).E- ( (ETX+EDA)*(4000)  + Efs*4000*( distance * distance )); 
%             end
%         end     
%     
%     end
%   end 
% end
% 
% 
% 
% STATISTICS(r+1).CLUSTERHEADS=cluster-1;
% CLUSTERHS(r+1)=cluster-1;
% 
% %Election of Associated Cluster Head for Normal Nodes
% for i=1:1:n
%     if ( S(i).type=='N' && S(i).E>0 )
%         if(cluster-1>=1)
%             min_dis=sqrt( (S(i).xd-S(n+1).xd)^2 + (S(i).yd-S(n+1).yd)^2 );
%             min_dis_cluster=1;
%             for c=1:1:cluster-1
%                 temp=min(min_dis,sqrt( (S(i).xd-C(c).xd)^2 + (S(i).yd-C(c).yd)^2 ) );
%                 if ( temp<min_dis )
%                     min_dis=temp;
%                     min_dis_cluster=c;
%                 end
%             end
%             
%             %Energy dissipated by associated Cluster Head
%             min_dis;
%             if (min_dis>do)
%                 S(i).E=S(i).E- ( ETX*(4000) + Emp*4000*( min_dis * min_dis * min_dis * min_dis));
%             end
%             if (min_dis<=do)
%                 S(i).E=S(i).E- ( ETX*(4000) + Efs*4000*( min_dis * min_dis));
%             end
%             %Energy dissipated
%             if(min_dis>0)
%                 S(C(min_dis_cluster).id).E = S(C(min_dis_cluster).id).E- ( (ERX + EDA)*4000 );
%                 PACKETS_TO_CH(r+1)=n-dead-cluster+1;
%             end
%             
%             S(i).min_dis=min_dis;
%             S(i).min_dis_cluster=min_dis_cluster;
%             
%         end
%     end
% end
% hold on;
% 
% countCHs;
% rcountCHs=rcountCHs+countCHs;
% 
%   sum=0;
% for i=1:1:n
% if(S(i).E>0)
%     sum=sum+S(i).E;
% end
% end
% avg=sum/n;
% STATISTICS(r+1).AVG=avg;
% uu(r+1).AVG=(STATISTICS(r+1).AVG)*100;
% sum;
% alive5=u;
% x6(r+1)=uu(r+1).AVG;
% 
% % if m==0.1
% %     x=u;
% % end
% % if m==0.2
% %     x1=u;
% % end
% % if m==0.3
% %     x2=u;
% % end
% 
% %Code for Voronoi Cells
% %Unfortynately if there is a small
% %number of cells, Matlab's voronoi
% %procedure has some problems
% 
% %[vx,vy]=voronoi(X,Y);
% %plot(X,Y,'r*',vx,vy,'b-');
% % hold on;
% % voronoi(X,Y);
% % axis([0 xm 0 ym]);
%    
% 
% end
% for i=1:1:rmax
%     alive5(i)=n-DEAD(i);
%     
%     
% %     if m==0.1
% %         x(i)= alive(i);
% %     end
% % if m==0.2
% %     x1(i)= alive(i);
% % end
% % if m==0.3
% %     x2(i)= alive(i);
% % end 
%    
% end
% if m==0.1
%        pack555=PACKETS_TO_BS;
%     end
% if m==0.2
%    pack5555=PACKETS_TO_BS;
% end
% if m==0.3
%    pack55555=PACKETS_TO_BS;
% end 
% save  pack555.mat;
% save  pack5555.mat;
% save  pack55555.mat;
% end
% pack5=PACKETS_TO_BS;
% chs4=CLUSTERHS;
% save  chs4.mat;
% save  pack5.mat;
% save alive5.mat;
% save  x6.mat;
% % figure(3)
% % r=1:1:rmax;
% % plot(r,alive,'--');
% % legend(['m=0.1','  ','\alpha=1']);
% % ylabel('Number of AliveNodes')
% % xlabel('Round Number')
% % hold on;

%%
% clear all;
% clc;
load  chs.mat;
load  chss.mat;
load  chsss.mat;
load  pack111.mat;
load  pack1111.mat;
load  pack11111.mat;
load  alive.mat;
load  alivee.mat;
load  aliveee.mat;
load  x1.mat;
load  x11.mat;
load  x111.mat;

load  chs1.mat;
load  chs11.mat;
load  chs111.mat;
load alive1.mat;
load alive11.mat;
load alive111.mat;
load  x2.mat;
load  x22.mat;
load  x222.mat;
load  pack222.mat;
load  pack2222.mat;
load  pack22222.mat;

load  pack333.mat;
load  pack3333.mat;
load  pack33333.mat;
load  chs2.mat;
load  chs22.mat;
load  chs222.mat;
load alive2.mat;
load alive22.mat;
load alive222.mat;
load  x3.mat;
load  x33.mat;
load  x333.mat;

load  pack444.mat;
load  pack4444.mat;
load  pack44444.mat;
load alive4.mat;
load alive44.mat;
load alive444.mat;
load  x5.mat;
load  x55.mat;
load  x555.mat;
load  chs3.mat;
load  chs33.mat;
load  chs333.mat;
% load ('pack.mat');
% load ('pack2.mat');
% load ('pack1.mat');
% %load ('pack3.mat');
% load ('pack4.mat');
% load ('pack5.mat');

figure(1)
r=1:1:rmax;
plot(r,alive,'--o',r,alive1,'--s',r,alive2,'--p',r,alive4,'--+');
legend('N-SEP','SEP','LEACH','M-SEP');
%,'A-LEACH' %,r,alive3,'--o'
ylabel('Number of AliveNodes');
xlabel('Round Number');
hold on;

figure(2)
r=1:1:rmax;
plot(r,alivee,'--o',r,alive11,'--s',r,alive22,'--p',r,alive44,'--+');
legend('N-SEP','SEP','LEACH','M-SEP');
%,'A-LEACH' %,r,alive3,'--o'
ylabel('Number of AliveNodes');
xlabel('Round Number');
hold on;


figure(3)
r=1:1:rmax;
plot(r,aliveee,'--o',r,alive111,'--s',r,alive222,'--p',r,alive444,'--+');
legend('N-SEP','SEP','LEACH','M-SEP');
%,'A-LEACH' %,r,alive3,'--o'
ylabel('Number of AliveNodes');
xlabel('Round Number');
hold on;


figure(4)
r=1:1:rmax;
plot(r,x1(r),'--o',r,x2(r),'--s',r,x3(r),'--p',r,x5(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');
% ,'A-LEACH'   %,x4(r),r,'--o'
ylabel('Average Energy of Each Node');
xlabel('Round Number');   
hold on;


figure(5)
r=1:1:rmax;
plot(r,x11(r),'--o',r,x22(r),'--s',r,x33(r),'--p',r,x55(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');
% ,'A-LEACH'   %,x4(r),r,'--o'
ylabel('Average Energy of Each Node');
xlabel('Round Number');   
hold on;

figure(6)
r=1:1:rmax;
plot(r,x111(r),'--o',r,x222(r),'--s',r,x333(r),'--p',r,x555(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');
% ,'A-LEACH'   %,x4(r),r,'--o'
ylabel('Average Energy of Each Node');
xlabel('Round Number');   
hold on;
% 
figure(7)
r=1:1:rmax;
plot(r,pack111(r),'--o',r,pack222(r),'--s',r,pack333(r),'--p',r,pack444(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('Packets to Sink');
xlabel('Round Number');
hold on;
% 
figure(8)
r=1:1:rmax;
plot(r,pack1111(r),'--o',r,pack2222(r),'--s',r,pack3333(r),'--p',r,pack4444(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('Packets to Sink');
xlabel('Round Number');
hold on;


figure(9)
r=1:1:rmax;
plot(r,pack11111(r),'--o',r,pack22222(r),'--s',r,pack33333(r),'--p',r,pack44444(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('Packets to Sink');
xlabel('Round Number');
hold on;
% 
figure(10)
r=1:1:rmax;
plot(r,chs(r),'--o',r,chs1(r),'--s',r,chs2(r),'--p',r,chs3(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('Packets to Sink');
xlabel('ClusterHeads');
hold on;

figure(11)
r=1:1:rmax;
plot(r,chss(r),'--o',r,chs11(r),'--s',r,chs22(r),'--p',r,chs33(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('ClusterHeads');
xlabel('Round Number');
hold on;
% 
figure(12)
r=1:1:rmax;
plot(r,chsss(r),'--o',r,chs111(r),'--s',r,chs222(r),'--p',r,chs333(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('ClusterHeads');
xlabel('Round Number');
hold on;


figure(13)
r=1:200:rmax;
plot(r,pack111(r),'--o',r,pack222(r),'--s',r,pack333(r),'--p',r,pack444(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('Packets to Sink');
xlabel('Round Number');
hold on;
% 
figure(14)
r=1:200:rmax;
plot(r,pack1111(r),'--o',r,pack2222(r),'--s',r,pack3333(r),'--p',r,pack4444(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('Packets to Sink');
xlabel('Round Number');
hold on;


figure(15)
r=1:200:rmax;
plot(r,pack11111(r),'--o',r,pack22222(r),'--s',r,pack33333(r),'--p',r,pack44444(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('Packets to Sink');
xlabel('Round Number');
hold on;
% 
figure(16)
r=1:200:rmax;
plot(r,chs(r),'--o',r,chs1(r),'--s',r,chs2(r),'--p',r,chs3(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('ClusterHeads');
xlabel('Round Number');
hold on;

figure(17)
r=1:200:rmax;
plot(r,chss(r),'--o',r,chs11(r),'--s',r,chs22(r),'--p',r,chs33(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('ClusterHeads');
xlabel('Round Number');
hold on;
% 
figure(18)
r=1:200:rmax;
plot(r,chsss(r),'--o',r,chs111(r),'--s',r,chs222(r),'--p',r,chs333(r),'--+');
legend('N-SEP','SEP','LEACH','M-SEP');  
% ,'A-LEACH'  %,r,pack3(r),'--o'
ylabel('ClusterHeads');
xlabel('Round Number');
hold on;