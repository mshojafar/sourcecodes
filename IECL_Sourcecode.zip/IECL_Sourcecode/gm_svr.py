
# -*- coding: utf-8 -*-
"""
Created on Wed Nov 29 22:15:03 2019

@author: chern.lei
"""
import pandas as pd
import numpy as np
from sklearn.svm import LinearSVR
from sklearn.svm import SVR
from sklearn.model_selection import GridSearchCV
import joblib
import matplotlib.pyplot as plt
inputFile = 'data/cpu.xlsx'           # 灰色预测后保存的路径
data = pd.read_excel(inputFile, index_col=0)      # 读取数据
feature = ['x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x8', 'x9', 'x10', 'x11', 'x12', 'x13', 'x14', 'x15',
           'x16', 'x17', 'x18', 'x19', 'x20', 'x21', 'x22', 'x23', 'x24', 'x25', 'x26','x27', 'x28','x29']
#feature = ['x4']
data_train = data.loc[range(1, 300)].copy()   # 取2014年前的数据建模

data_mean = data_train.mean()
data_std = data_train.std()
data_train = (data_train - data_mean)/data_std   # 数据标准化
x_train = data_train[feature].values    # 特征数据
y_train = data_train['y'].values         # 标签数据

svr = SVR()                                # 调用LinearSVR()函数
# svr.fit(x_train, y_train)                        # 模型训练
# parameters=[{'C': range(1, 1000),
#              'kernel':['rbf','poly'],
#             'epsilon': range(1, 1000),
#              'gamma': range(1, 1000)}]
parameters=[{'C': [0.01,0.05,0.1,0.5,1,5,10,100,1000],
             'kernel':['rbf','poly'],
            'epsilon': [0.0001, 0.0005, 0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 5, 10],
             'gamma': [0.001,0.005,0.01,0.05,0.1,0.5,1,10,100]}]
#modelsvr=SVR()
grid_search=GridSearchCV(estimator=svr,
                         param_grid=parameters,
                         cv=5,
                         scoring='neg_mean_squared_error',
                         n_jobs=-1)
grid_search=grid_search.fit(x_train,y_train)
print(grid_search.best_params_)
print(grid_search.best_score_)
print(grid_search.best_estimator_)
# SVR模型保存
joblib.dump(grid_search, 'svr.pkl')

# SVR模型加载
svr = joblib.load('svr.pkl')

#SVR模型测试
y_hat = svr.predict(x_train)
#svr=grid_search.best_estimator_
#svr=SVR(C= pa['C'],kernel= pa['kernel'],epsilon=['epsilon'],gamma= pa['gamma'])
#svr.fit(x_train,y_train)
x = ((data[feature] - data_mean[feature])/data_std[feature]).values  # 预测，并还原结果。
data[u'y_pred'] = svr.predict(x) * data_std['y'] + data_mean['y']

outputFile = 'data/cpu2_predict.xlsx'     # SVR预测后保存的结果
data.to_excel(outputFile)
from pylab import mpl

mpl.rcParams['font.sans-serif'] = ['SimHei']  # 修改为中文字体
plt.plot(data[['y', 'y_pred']])
plt.xlabel('时间', fontsize=12)
plt.ylabel('功率', fontsize=12)
plt.title('CPU密集型数据下预测性能')
plt.savefig("CPU.png")
plt.show()
# print('真实值与预测值分别为：', data[['y', 'y_pred']])
# print('预测图为：', data[['y', 'y_pred']].plot(style=['b-o', 'r-*']))
# plt.show()
from sklearn.metrics import mean_absolute_error
from sklearn.metrics import mean_squared_error
import math
def mape(y_true, y_pred):
    return np.mean(np.abs((y_pred - y_true) / y_true)) * 100
print('测试集上的MAE/MSE/MAPE')
print(mean_absolute_error(data['y'],data['y_pred']))
print(mean_squared_error(data['y'],data['y_pred']))
print(mape(data['y'],data['y_pred']))
