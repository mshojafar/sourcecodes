﻿1.  Runtime environment：Pycharm+python3.7+win10;
2.  Need install package：pandas，numpy，sklearn，joblib，matplotlib;
3.  Take cpu-intensive task as an example,running"gm_svr.py", it can create the experimental results.