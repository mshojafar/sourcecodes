clc
clear all
close all

VM=[1:1:10];%numero Macchine Virtuali
NumSimulazioni=length(VM);

%Jobs=6 + (10-6).*rand(1,1000); %carico uniformemente distribuito
%Jobs=10.*ones(1,10);  %carico deterministico
%Jobs=ciel(abs(10.*Nrand(0,1)));
%Jobs=random('Poisson',1:NumSimulazioni,1,NumSimulazioni);
%Jobs=ceil(abs(random('Normal',0,4,1,10)));

Jobs=8000.*rand(1,10000); %carico uniformemente distribuito PMR=2

costo_speed_VM1=zeros(1,NumSimulazioni);
costo_switch_VM1=zeros(1,NumSimulazioni);
costo_channel_VM1=zeros(1,NumSimulazioni);
costo_tot_VM1=zeros(1,NumSimulazioni);
costo_tot_VM=zeros(NumSimulazioni,length(Jobs));
costo_tot_VM_f_succ=zeros(NumSimulazioni,length(Jobs));
costo_tot_VM_f_prec=zeros(NumSimulazioni,length(Jobs));
costo_tot_VM_TS=zeros(NumSimulazioni,length(Jobs));
costo_tot_VM_TS_switch=zeros(NumSimulazioni,length(Jobs));
costo_tot_VM_TSpiuSwitch=zeros(NumSimulazioni,length(Jobs));

costo_speed_IDEAL=zeros(NumSimulazioni,length(Jobs));
costo_switch_IDEAL=zeros(NumSimulazioni,length(Jobs));
costo_tot_IDEAL=zeros(NumSimulazioni,length(Jobs));


f_VM_ultima=zeros(1,NumSimulazioni);


%inizio le simulazioni
P_net_completo=[1:0.25:10000];
%P_net_completo=zeros(1,100);

for k=1:NumSimulazioni
    tic
    k
    M=VM(k);
    costo_speed=0;
    costo_switch=0;
    costo_channel=0;
    costo_tot=0;
    rate_ultima_macchina=0;
    
    
    k_e=0.05*10^(-18);
    C_max=15; %(Mb/s)
    T_tot=5; %(s)
    
    f_max=2.6*10^9.*ones(1,M);  %(Mb/s)
    f_zero=zeros(1,M);  % (Mb/s)
    %f_zero=0.2.*f_max;
    %f_zero=f_max;
    P_net=P_net_completo(1:M); %(mW)
    %P_net=1.*ones(1,M);   %NB.! ORDINARE LE MACCHINE VIRTUALI IN MODO DA AVERE LE POTENZE IN ORDINE CRESCENTE
    %(unicamente perch� semplifica la scritura del
    %software - controindicazione: il codicie funziona bene indipendentemente)
    Th=2.*P_net./C_max;   %Soglia di ibernazione macchina; (tutte le VM per cui mu_opt<=Th vengono ibernate con coefficiente di
    % ibernazione alpha_zero)
    
    E_max=240.*ones(1,M);  % (mJ)
    omega=1.*ones(1,M);
    Delta=1.*ones(1,M); % (s)
    Delta_max=max(Delta);
    L_b=zeros(1,M);  % NB. il codice funziona bene per L_b=0, altrimenti aggiungere modifica su f_opt.
    
    temp=2.*k_e+(2.*E_max.*omega./(f_max.^2));
    alpha_zero=2.*k_e./temp;
    alpha_mu=Delta./temp;
    
    
    
    
    for num_job=1:length(Jobs)
        L_tot=Jobs(num_job);
        
        num_job
        
        k
        
        %CHECK FEASIBILITY - controllare funzionamento operatori %%%%%%%%%%%%%%%%%%
        
        condizione_feas_carico=(sum(f_max.*Delta-L_b)>=L_tot);
        %condizione_feas_tempo=(L_tot<=C_max.*(T_tot-Delta_max)./2);
        condizione_feas_tempo=1;
        condizione_feas_back=min(Delta.*f_max>=L_b);
        
        
        feasibility=condizione_feas_carico && condizione_feas_tempo && condizione_feas_back;
        
        if ~feasibility
            'VM='
            M
            error('Problem unfeasible')
        else
            'Problem Feasibile!'
        end
        
        
        
        
        
        %SOLUZIONE EQUAZIONE:   sum(L_opt)=L_tot;
        
        %NB. IL PUNTO DI ATTRAVERSAMENTO DELLO ZERO POTREBBE NON ESISTERE. IN QUEL
        %CASO mu_opt E' IL PUNTO DI GRADINO FRA LA ZONA POSITIVA E QUELLA NEGATIVA
        %E delta_mu (CHE E' IL VALORE DELL'EQUAZIONE IN mu) E' DIVERSO DA ZERO.
        
       
        [mu,delta_mu]= Mu_opt_bisezione(alpha_zero,alpha_mu,P_net,C_max,f_zero,f_max,Delta,L_b,L_tot);
        tol_mu=10^(-2);%tolleranza per decisione macchine in stato limite
        tol_carico_allocato=10^(-2);
        if ((abs(delta_mu)./L_tot)<tol_carico_allocato)%tutto il carico � allocato con un errore relativo inferiore a tol_allocazione
            caso_limite=0;
            %'Caso standard: nessuna VM in stato limite'
        else
            caso_limite=1;
            %'Una o pi� VM � in stato limite'
            VM_limite=find(abs(Th-mu)<tol_mu);
            if length(VM_limite)==0
                'VM='
                M
                error('nessuna VM in stato limite e carico complessivo L_tot non allocato correttamente')
            end
            
        end
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%   scheduler ottimo  %%%%%%%%%%%%%%%%%
        
        
        
        
        f_mu=max(mu-2.*P_net./C_max,0);
        f_star=alpha_zero.*f_zero+alpha_mu.*f_mu;
        f_opt=max(0,min(f_star,f_max)); %N.B. --> NEL CASO GENERALE DI L_b>0 IL MAX VA FATTO RISPETTO A L_b/Delta, NON RISPETTO A 0.
        
        rate_ultima_macchina=rate_ultima_macchina+f_opt(M);
        
        
        
        canali_attivi=f_mu>0;
        L_opt=canali_attivi.*(f_opt.*Delta-L_b);
        
        %riallocazione delle eventuali VM sulla soglia (stato limite)
        
        if caso_limite
            L_opt(VM_limite)=0;
            L_allocato=sum(L_opt);
            L_residuo=L_tot-L_allocato;
            for k2=1:length(VM_limite);
                L_opt(VM_limite(k2))=min(L_residuo,f_opt(VM_limite(k2)).*Delta(VM_limite(k2))-L_b(VM_limite(k2)));
                L_residuo=L_residuo-L_opt(VM_limite(k2));
            end
            canali_attivi=(L_opt>0);
        end
        
        
        %Calcolo f_precedente e f_successiva a partire da f_opt
        
        f_precedente=zeros(1,M);
        f_successiva=zeros(1,M);
        x=zeros(1,M);
        
        Q=7; %numero frequenze discrete;
        f_discrete=zeros(M,Q);
        for conta=1:M
            %f_discrete(conta,:)=[0:f_max(conta)./(Q-1):f_max(conta)];
            f_discrete(conta,:)=[0, 1.6.*10^9, 1.8.*10^9, 2.*10^9, 2.2.*10^9, 2.4.*10^9, 2.6.*10^9];
        end
        
        
        
        for conta=1:M
            
            delta_f_discrete=f_discrete(conta,:)-f_opt(conta);
            [ff,ind_ff]=min(abs(delta_f_discrete));
            if ff==0
                f_precedente(conta)=f_discrete(conta,ind_ff);
                f_successiva(conta)=f_discrete(conta,ind_ff);
                x(conta)=1; %qualsiasi valore � indifferente
            elseif ind_ff==1
                f_precedente(conta)=f_discrete(conta,1);
                f_successiva(conta)=f_discrete(conta,2);
                x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
            elseif ind_ff==Q
                f_precedente(conta)=f_discrete(conta,Q-1);
                f_successiva(conta)=f_discrete(conta,Q);
                x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
            elseif delta_f_discrete(ind_ff)>0
                f_precedente(conta)=f_discrete(conta,ind_ff-1);
                f_successiva(conta)=f_discrete(conta,ind_ff);
                x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
            else
                f_precedente(conta)=f_discrete(conta,ind_ff);
                f_successiva(conta)=f_discrete(conta,ind_ff+1);
                x(conta)=(f_opt(conta)-f_precedente(conta))./(f_successiva(conta)-f_precedente(conta));
            end
            
        end
        
        
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%  costo  %%%%%%%%%%%%%%%%%%
        
        Delta_carico=sum(L_opt)-L_tot;
        if ((abs(Delta_carico)./L_tot)>=tol_carico_allocato)
            'Errore: Carico non correttamente allocato'
        end
        
        
        % Costo frequenza_successiva
%         costo_speed_f_succ=sum(((f_successiva./f_max).^2).*omega.*E_max);
%         costo_switch_f_succ=sum(k_e.*(f_successiva-f_zero).^2);
%         costo_channel_f_succ=sum(2.*P_net.*L_opt./C_max);
%         costo_tot_f_succ=costo_speed_f_succ+costo_switch_f_succ+costo_channel_f_succ;
%         
%         % Costo frequenza_precedente
%         costo_speed_f_prec=sum(((f_precedente./f_max).^2).*omega.*E_max);
%         costo_switch_f_prec=sum(k_e.*(f_precedente-f_zero).^2);
%         costo_channel_f_prec=sum(2.*P_net.*L_opt./C_max);
%         costo_tot_f_prec=costo_speed_f_prec+costo_switch_f_prec+costo_channel_f_prec;
        
        % Costo Time-sharing  (NICOLA)
        
        costo_speed_TS=sum((((f_precedente./f_max).^2).*omega.*E_max).*(1-x)+(((f_successiva./f_max).^2).*omega.*E_max).*x);
        costo_switch_TS=sum((k_e.*(f_precedente-f_zero).^2).*(1-x)+(k_e.*(f_successiva-f_zero).^2).*x);
        %costo_channel_TS=sum(2.*P_net.*L_opt./C_max);
        %costo_tot_TS=costo_speed_TS+costo_switch_TS+costo_channel_TS;
        %costo_tot_TS=costo_speed_TS+costo_switch_TS+costo_channel_TS;
        
        
        %Costo Time-sharing-switch
        costo_TS_switch=sum(k_e.*(f_successiva-f_precedente).^2);
        %costo_tot_TSpiuSwitch=costo_switch_TS+costo_TS_switch;
        
        
        
        %%%%%%%%%%%%%%%%%%   FINE  COSTI FREQUENZE DISCRETE  %%%%%%%%%
        
        
        % risultati e deallocazione
        
%         costo_tot_VM(k,num_job)=costo_tot;
%         costo_tot_VM_f_succ(k,num_job)=costo_tot_f_succ;
%         costo_tot_VM_f_prec(k,num_job)=costo_tot_f_prec;
        costo_tot_VM_TS(k,num_job)=costo_speed_TS;                             % NICOLA results cpu cost
        costo_tot_VM_TS_switch(k,num_job)=costo_switch_TS+costo_TS_switch;    % NICOLA results switch cost
        costo_tot_VM_TSpiuSwitch(k,num_job)=costo_speed_TS+costo_TS_switch;    % NICOLA results total
        
        costo_speed_IDEAL(k,num_job)=sum(((f_opt./f_max).^2).*omega.*E_max);   %IDEAL results
        costo_switch_IDEAL(k,num_job)=sum(k_e.*(f_opt-f_zero).^2);             %IDEAL results
        costo_tot_IDEAL(k,num_job)=costo_speed_IDEAL(k,num_job)+costo_switch_IDEAL(k,num_job); %IDEAL results
        % IDEAL case
        %costo_speed=costo_speed+sum(((f_opt./f_max).^2).*omega.*E_max);
        %costo_switch=costo_switch+sum(k_e.*(f_opt-f_zero).^2);
        %costo_channel=costo_channel+sum(2.*P_net.*L_opt./C_max);
        
        f_zero=f_opt;
        
    end
    
    
    % risultati e deallocazione
    
    
    k
    %IDEAL
%     costo_speed_VM1(k)=costo_speed./length(Jobs);
%     costo_switch_VM1(k)=costo_switch./length(Jobs);
%     costo_channel_VM1(k)=costo_channel./length(Jobs);
%     costo_tot_VM1(k)=costo_speed_VM1(k)+costo_switch_VM1(k)+costo_channel_VM1(k);
%     f_VM_ultima(k)=rate_ultima_macchina./length(Jobs);
    
    
    clear f_max f_zero P_net Th  E_max omega Delta L_b temp alpha_zero alpha_mu
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%   istogrammi  %%%%%%%%%%%%%%%%%%%%%%%%%
    
    %  figure(k);
    %  bar(f_opt),xlabel('VM');
    %  ylabel('Speed f');
    %  grid on;
    
    toc
end



TOT=zeros(1,length(VM));
for k=1:length(VM)
TOT(k)=mean(costo_tot_IDEAL(k,:));
end

CPU=zeros(1,length(VM));
for k=1:length(VM)
CPU(k)=mean(costo_speed_IDEAL(k,:));
end

SWITCH=zeros(1,length(VM));
for k=1:length(VM)
SWITCH(k)=mean(costo_switch_IDEAL(k,:));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
TOTNICOLA=zeros(1,length(VM));
for k=1:length(VM)
TOTNICOLA(k)=mean(costo_tot_VM_TSpiuSwitch(k,:));
end

CPUNICOLA=zeros(1,length(VM));
for k=1:length(VM)
CPUNICOLA(k)=mean(costo_tot_VM_TS(k,:));
end

SWITCHNICOLA=zeros(1,length(VM));
for k=1:length(VM)
SWITCHNICOLA(k)=mean(costo_tot_VM_TS_switch(k,:));
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


figure(1)
plot(VM,SWITCH,'--o',VM,SWITCHNICOLA,'--+'),xlabel('VM'),ylabel('Switch Cost');
grid on
figure(2)
plot(VM,CPU,'--o',VM,CPUNICOLA,'--+'),xlabel('VM'),ylabel('CPU Cost');
grid on

figure(3)
plot(VM,TOT,'--o',VM,TOTNICOLA,'--+'),xlabel('VM'),ylabel('TOT Cost');
grid on





% figure(1)
% plot(VM,costo_speed_VM,'--o'),xlabel('VM'),ylabel('Speed Cost');
% 


% figure(2)
% plot(VM,costo_switch_VM,'--o'),xlabel('VM'),ylabel('Switch Cost');
% 
% figure(3)
% plot(VM,costo_channel_VM,'--o'),xlabel('VM'),ylabel('Net Cost');
% 
% 
% %figure(20)
% figure(4)
% plot(VM,costo_tot_VM,'--o'),xlabel('VM'),ylabel('Overall Cost');
% 
% figure(5)
% plot(VM,f_VM_ultima,'--o'),xlabel('VM'),ylabel('rate last VM');
% 


