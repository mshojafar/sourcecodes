
package ica_schedule;
import java.util.ArrayList;
import java.util.Random;

public class ICA {

    public static int num_Task = 200;
    public static int num_Resource =30;
    public  int iter_ICA=100;
    public static int random_select=95;

 //*************************************************************
    static  int numOfCountries = 205;               		// Number of initial countries
    static  int numOfInitialImperialists =20;      		// Number of initial imperialists
    static  int numOfAllColonies = numOfCountries - numOfInitialImperialists;
    double zeta = 0.04;
    double pRevolve=0.5;
    static int[][] countriesArray = new int[numOfCountries][num_Task];
    public static ArrayList<Integer[]> ImpiresList = new ArrayList<Integer[]>();
    public static ArrayList cost_list_imp = new ArrayList();
    public static ArrayList<Integer[]> colonyArray = new ArrayList<Integer[]>();
    //public static ArrayList<Integer[]> num_colonyOfImpir = new ArrayList<Integer[]>();
    public static ArrayList power_imp = new ArrayList();
    public static ArrayList NTC = new ArrayList();
    public static ArrayList num_colonyOfImpir = new ArrayList();
    public static int[] randomStore = new int[random_select];
    public static ArrayList sumCostColonyOfImpir = new ArrayList();
    public static ArrayList TC = new ArrayList();
    public static double max_total_cost;
    public static int index_max_total_cost;
    public static ArrayList R = new ArrayList();
    public static ArrayList D = new ArrayList();
    public static ArrayList P = new ArrayList();

 //************************************************************
    public static Resource[] ResourceList = new Resource[num_Resource];
    public static Task[] TaskList = new Task[num_Task];
    public double ETC[][] = new double[num_Task][num_Resource];
    public static double fitness_list[] = new double[numOfCountries];
    public static double ready[] = new double[num_Resource];
    public static String StatusList[][] = new String[numOfCountries][num_Task];


    public void delete_Impire(int j){
        System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&  delete_Impire  &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");

        int temp[]=new int[num_Task];
        
        for (int i = 0; i < num_Task; i++) {
            temp[i]=(Integer)ImpiresList.get(j)[i];
        }
       numOfInitialImperialists=numOfInitialImperialists-1;
       ImpiresList.remove(j);
       cost_list_imp.remove(j);
       imperialisticCompetition1(temp);
    }
     public void imperialisticCompetition1(int temp[]){
      double sum=0.0;
      double max_D=0.0;
      int index_D=0;
      numOfAllColonies+=1;
      //int[][] colonyArray = new int[numOfAllColonies][num_Task+1];
      for (int i = 0; i < numOfInitialImperialists; i++) {
          
          NTC.add(i,(1.3* max_total_cost-(Double)TC.get(i)));
          sum+=(Double)NTC.get(i);
              }
     for (int i = 0; i < numOfInitialImperialists; i++) {
        P.add(i,(Double)NTC.get(i)/sum);
     }
      for (int i = 0; i < numOfInitialImperialists; i++) {
        R.add(i,Math.random());
     }
      for (int i = 0; i < numOfInitialImperialists; i++) {
         System.out.println("P: "+P.get(i)+"  R: "+R.get(i));
        D.add(i,(Double)P.get(i)-(Double)R.get(i));
        if(max_D<(Double)D.get(i)){
            max_D=(Double)D.get(i);
            index_D=i;
        }
     }
     System.out.println("index_power_impire: "+index_D+"  max: "+max_D);
      Integer[] intArr = new Integer[num_Task+1];
     for (int k = 0; k < num_Task; k++) {
         intArr[k]=temp[k];
     }
      intArr[num_Task]=index_D;
     colonyArray.add(intArr);
     num_colonyOfImpir.set(index_D,(Integer)num_colonyOfImpir.get(index_D)+1);

    }
     public void imperialisticCompetition(){
      double sum=0.0;
      double max_D=0.0;
      int index_D=0;
      
      System.out.println("index_poor_impire: "+index_max_total_cost+"  min: "+max_total_cost);
      int temp=(Integer)num_colonyOfImpir.get(index_max_total_cost);
      int g=(int)(temp*Math.random());
      for (int i = 0; i < numOfInitialImperialists; i++) {
          NTC.add(i,(1.3* max_total_cost-(Double)TC.get(i)));
          sum+=(Double)NTC.get(i);
              }
     for (int i = 0; i < numOfInitialImperialists; i++) {
        P.add(i,(Double)NTC.get(i)/sum);
     }
      for (int i = 0; i < numOfInitialImperialists; i++) {
         R.add(i,Math.random());
     }
      for (int i = 0; i < numOfInitialImperialists; i++) {
        System.out.println("P: "+P.get(i)+"  R: "+R.get(i));
        D.add(i,(Double)P.get(i)-(Double)R.get(i));
        
        if(max_D<(Double)D.get(i)){
            max_D=(Double)D.get(i);
            index_D=i;
        }
     }
     System.out.println("index_power_impire: "+index_D+"  max: "+max_D);
     colonyArray.get(g)[num_Task]=index_D;
     num_colonyOfImpir.set(index_D,(Integer)num_colonyOfImpir.get(index_D)+1);
     num_colonyOfImpir.set(index_max_total_cost,(Integer)num_colonyOfImpir.get(index_max_total_cost)-1);
     System.out.println("new colony: ");
      for (int i = 0; i <= num_Task; i++) {
          System.out.print(colonyArray.get(g)[i]);
      }
     System.out.println();
    }
    public void calculateTotalCost(){
        int solution_candid[]=new int[num_Task];
        double cost_colony1=0.0;
        double sum=0.0;
        double max=0.0;
        int index=0;

        for(int i=0;i<numOfAllColonies;i++){
            for(int j=0;j<num_Task;j++){
                solution_candid[j]=colonyArray.get(i)[j];
            }
            cost_colony1=computefitness1(solution_candid);
             for(int k=0;k<numOfInitialImperialists;k++){
                if(colonyArray.get(i)[num_Task]==k){
                    double temp=(Double)sumCostColonyOfImpir.get(k);
                    cost_colony1+=temp;
                }
                sumCostColonyOfImpir.set(k, cost_colony1);
            } 
         }
         for(int k=0;k<numOfInitialImperialists;k++){
             int numColony=(Integer)num_colonyOfImpir.get(k);
             double sumCostColonyOfImpi=(Double)sumCostColonyOfImpir.get(k);
             double taghsim=zeta*sumCostColonyOfImpi/numColony;
             double cost_list_imp1=(Double)cost_list_imp.get(k);
             double ccc=taghsim+cost_list_imp1;
             TC.add(k, ccc);
             if(max<(Double)TC.get(k)){
                   max= (Double)TC.get(k);
                   index=k;
                               }
         }
         max_total_cost=max;
         index_max_total_cost=index;
         for(int k=0;k<numOfInitialImperialists;k++){
             System.out.println("Total Cost: "+TC.get(k));
         }
           }
    public void exchangeColonies(){
        double cost_colony=0.0;
        double cost_impir=0.0;
        int temp=0;
        int solution_candid[]=new int[num_Task];

        for(int i=0;i<numOfAllColonies;i++){
            for(int j=0;j<num_Task;j++){
                solution_candid[j]=colonyArray.get(i)[j];
            }
            System.out.print("solution_candid[j]=");
             for(int j=0;j<num_Task;j++){
                System.out.print(solution_candid[j]);
            }
            System.out.println();
            cost_colony=computefitness1(solution_candid);
            System.out.println("cost_colony: "+cost_colony);
            for(int k=0;k<numOfInitialImperialists;k++){
                if(colonyArray.get(i)[num_Task]==k){
                    cost_impir=(Double)cost_list_imp.get(k);
                
                System.out.println("cost_impir: "+cost_impir);
                if(cost_colony<cost_impir){
                    cost_list_imp.set(k,cost_colony);
                     for(int z=0;z<num_Task;z++){
                         temp=colonyArray.get(i)[z];
                         colonyArray.get(i)[z]=ImpiresList.get(k)[z];
                         ImpiresList.get(k)[z]=temp;
                     }
                }
            }
            }
        }
    }
    public double  computefitness1(int[]solution_candid){

        double x=0.0;
        double max=0.0;
        for(int i=0;i<num_Task;i++){
         int temp=solution_candid[i];
         x=computeTime(i,temp);
         if(x>max){
             max=x;
         }
        }

      for(int i=0;i<num_Resource;i++){
        ready[i]=0.0;}
       //fitness_list[in]=max;

        return max;
    }
    public void revolveColonies(int index){
        double p=Math.random();
       if(p>=pRevolve) return;
        int []result=new int[num_Task];;
        int []n1=new int[num_Task];

        int first=(int)(num_Task*Math.random());
        int second;
        do{
            second=(int)(num_Task*Math.random());
        }while(first==second);
         for (int i = 0; i < num_Task; i++) {
             result[i]=colonyArray.get(index)[i];
         }
        double  temp1=computefitness1(result);
        result[first]=(int)(num_Resource*Math.random());
        result[second]=(int)(num_Resource*Math.random());
        double  temp2=computefitness1(result);
        if(temp1>temp2){
                         colonyArray.get(index)[first]=result[first];
                         colonyArray.get(index)[second]=result[second];
                        }
        

    }
    public void revolveColonies1(int index){
        double p=Math.random();
       if(p>=pRevolve) return;
        int result=0;
        int first=(int)(num_Task*Math.random());
        int second;
        do{
            second=(int)(num_Task*Math.random());
        }while(first==second);
        result=colonyArray.get(index)[first];
        colonyArray.get(index)[first]=colonyArray.get(index)[second];
        colonyArray.get(index)[second]=result;
        
    }
     public void assimilateColonies (){
      int[] countrArray = new int[num_Task+1];
          for (int i = 0; i < numOfInitialImperialists; i++) {
              fillVector();
                for (int j = 0; j < numOfAllColonies; j++) {
                    
                    if(colonyArray.get(j)[num_Task]==i){
                         for (int d = 0; d < num_Task+1; d++) {
                          countrArray[d]=colonyArray.get(j)[d];   
                         }
                       double  temp1=computefitness1(countrArray);
                        for(int k=0;k<random_select;k++){
                            countrArray[randomStore[k]]=ImpiresList.get(i)[randomStore[k]];
                        }
                    double  temp2=computefitness1(countrArray);
                    
                        if(temp1>temp2){
                             for(int k=0;k<random_select;k++){
                            colonyArray.get(j)[randomStore[k]]=ImpiresList.get(i)[randomStore[k]];
                        }
                        }
                    }
                }
          }
    }
    public void assimilateColonies1 (){
      
          for (int i = 0; i < numOfInitialImperialists; i++) {
              fillVector();
                for (int j = 0; j < numOfAllColonies; j++) {
                    
                    if(colonyArray.get(j)[num_Task]==i){
                       
                        for(int k=0;k<random_select;k++){
                            colonyArray.get(j)[randomStore[k]]=ImpiresList.get(i)[randomStore[k]];
                        }
                        
                    }
                }
          }
    }
    public void fillVector(){
      //  System.out.println("Distinctive Random Sequence of One-Digit Numbers:");
        for (int round = 0; round < random_select; round++) {
            randomStore[round]=0;
        }

      Random random = new Random();
      int trial = 0;

     for (int round = 0; round < random_select; round++) {
        trial = random.nextInt(num_Task);
        for (int index = 0; index < round; index++) {
           while (trial == randomStore[index]) {
               trial = random.nextInt(num_Task);
               index = 0;
           }
        }
        randomStore[round] = trial;
     }
System.out.print("random: ");
      for (int i = 0; i < randomStore.length; i++)
           System.out.print(randomStore[i]);
        System.out.println();
    }
    public static void calculateColonyofImpir(){
      double sum=0.0;
      int sum_colon=0;
      int count=0;
      int index=numOfInitialImperialists;
     
      for (int i = 0; i < numOfInitialImperialists; i++) {
          double x1=(Double)cost_list_imp.get(i);
          double x2=1.3*(Double)cost_list_imp.get(numOfInitialImperialists-1);
         
          power_imp.add(x1-x2);
          sum+=(Double)power_imp.get(i);
              }
     for (int i = 0; i < numOfInitialImperialists; i++) {
         double h1=(Double)power_imp.get(i);
         int h=(int)Math.round(h1/sum*numOfAllColonies);
         num_colonyOfImpir.add(h);
         sum_colon+= h;
        
     }
       
      if(sum_colon>numOfAllColonies){
        int g=(Integer)num_colonyOfImpir.get(numOfInitialImperialists-1);
        g-=1;
         num_colonyOfImpir.set(numOfInitialImperialists-1, g);
       
      }
              if(sum_colon<numOfAllColonies){
                 int g=(Integer)  num_colonyOfImpir.get(0);
                 g+=1;
                 num_colonyOfImpir.set(0, g);
      }

      for(int k=0;k<numOfInitialImperialists;k++){
          int c=(Integer)num_colonyOfImpir.get(k);
          for(int z=0;z<c;z++){
              set_colony(k,count,index);
               count++;
               index++;
          }
      }
      /* System.out.println("**********list colonyArray************");
       for(int i=0;i<numOfAllColonies;i++){
       for(int j=0;j<num_Task+1;j++){
                System.out.print(colonyArray[i][j]);

            }
            System.out.print("; ");
       }
        System.out.println();*/
  }
     public static void  set_colony(int k,int count,int index){

           colonyArray.get(count)[num_Task] = k;
         
     }
    public static void initializeImperials(){
      System.out.println("+++++++++++++ EMPIR ++++++++++++");
      for (int i = 0; i < numOfInitialImperialists; i++) {
         
          Integer[] intArr = new Integer[num_Task];
       for (int j = 0; j < num_Task; j++) {
           intArr[j] = countriesArray[i][j];
      }
        ImpiresList.add(i, intArr);  
        
      }
      
          // Double[] intArr1 = new Double[numOfInitialImperialists];
            for (int j = 0; j < numOfInitialImperialists; j++) {
                cost_list_imp.add(fitness_list[j]);
            }
         
      
      
       for (int i = 0; i < numOfInitialImperialists; i++) {
            System.out.print( cost_list_imp.get(i)+ "   ");

        }
        System.out.println();
        System.out.println("+++++++++++++ end of fitness ++++++++++++");

         System.out.println("**********empiresList-sort************");
        for (int i = 0; i < numOfInitialImperialists; i++) {
            for (int j = 0; j < num_Task; j++) {
                System.out.print(ImpiresList.get(i)[j]);

            }
            System.out.print("; ");
        }
        System.out.println();


   }
    public static void selectSort(double[]fitness_list){
    int posMin;
    double temp;
    int[]countriesArray1=new int[num_Task];
     for (int j = 0; j < num_Task; j++) {
         countriesArray1[j]=0;
     }
    for(int fill=0;fill<fitness_list.length-1;fill++){
        posMin=findPosMin(fitness_list,fill);
        if(posMin!=fill){
            temp=fitness_list[fill];
            fitness_list[fill]=fitness_list[posMin];
            fitness_list[posMin]=temp;
           for (int j = 0; j < num_Task; j++) {
               countriesArray1[j]=countriesArray[fill][j];
               countriesArray[fill][j]=countriesArray[posMin][j];
               countriesArray[posMin][j]=countriesArray1[j];

           }
        }
    }
}
  public static void fillColony(){
      int temp=0;
      for (int i = numOfInitialImperialists; i < numOfCountries; i++) {
          Integer[] intArr2 = new Integer[num_Task+1];
        for (int j = 0; j < num_Task; j++) {
            intArr2[j] = countriesArray[i][j];
    }
          intArr2[num_Task]=0;
          colonyArray.add(temp, intArr2);
          temp++;
          }

  }

public static int findPosMin(double[]x,int fill){
    int posMinSoFar=fill;
    for(int i=fill+1;i<x.length;i++)
        if(x[i]<x[posMinSoFar])
            posMinSoFar=i;
            return posMinSoFar;
        }

    public void creatCountries() {
        for (int i = 0; i < numOfInitialImperialists; i++) {
            sumCostColonyOfImpir.add(0.0);
        }

        for (int i = 0; i < numOfCountries; i++) {
            for (int j = 0; j < num_Task; j++) {
                countriesArray[i][j] = (int) ((num_Resource) * Math.random());
                //countriesArray1[i][j]=countriesArray[i][j];
            }
        }
        System.out.println("**********list Countries************");
        for (int i = 0; i < numOfCountries; i++) {
            for (int j = 0; j < num_Task; j++) {
                System.out.print(countriesArray[i][j]);

            }
            System.out.print("; ");
        }
        System.out.println();
        System.out.println("*************************************");

        double xx = 0.0;
        int min = 100;
        int max = 110;
        Random r = new Random();

        for (int i = 0; i < num_Task; i++) {
            xx = r.nextInt(max - min + 1) + min;
            ETC[i][0]=(xx/8);
            ETC[i][1]=xx/4;
            ETC[i][2]=xx/7;
            ETC[i][3]=xx/6;
            ETC[i][4]=xx/10;
            ETC[i][5]=xx/3;
            ETC[i][6]=xx/9;
            ETC[i][7]=xx/5;
            ETC[i][8]=xx/7;
            ETC[i][9]=xx/11;
          ETC[i][10]=(xx/8);
            ETC[i][11]=xx/4;
            ETC[i][12]=xx/7;
            ETC[i][13]=xx/6;
            ETC[i][14]=xx/10;
            ETC[i][15]=xx/3;
            ETC[i][16]=xx/9;
            ETC[i][17]=xx/5;
            ETC[i][18]=xx/7;
            ETC[i][19]=xx/11;
          ETC[i][20]=xx/4;
            ETC[i][21]=xx/7;
            ETC[i][22]=xx/6;
            ETC[i][23]=xx/10;
            ETC[i][24]=xx/3;
            ETC[i][25]=xx/9;
            ETC[i][26]=xx/5;
            ETC[i][27]=xx/7;
            ETC[i][28]=xx/11;
            ETC[i][29]=xx/13;
        }
        System.out.println("**********list ETC************");
        for (int i = 0; i < num_Task; i++) {
            for (int j = 0; j < num_Resource; j++) {
                System.out.print(ETC[i][j] + "   ");

            }
            System.out.print("; ");
        }

        System.out.println();
        System.out.println("*************************************");
        System.out.println("+++++++++++++++++fitness of first countries+++++++++++++++++");

        for (int i = 0; i < numOfCountries; i++) {
            System.out.print(computefitness(i) + "   ");
            fitness_list[i] =computefitness(i);
        }
        System.out.println();
        System.out.println("+++++++++++++ end of fitness ++++++++++++");


    }
     public double computefitness(int in) {

        double x = 0.0;
        double max = 0.0;
        for (int i = 0; i < num_Task; i++) {
            int temp = countriesArray[in][i];
            x = computeTime(i, temp);
            if (x > max) {
                max = x;
            }
        }
        for (int i = 0; i < num_Task; i++) {
            if (max > TaskList[i].getDeadline()) {
                StatusList[in][i] = "failed";
            } else {
                StatusList[in][i] = "Success";
                ;
            }
        }
        for (int i = 0; i < num_Resource; i++) {
            ready[i] = 0.0;
        }
        fitness_list[in] = max;
        return max;
    }

    public double computeTime(int T, int R) {
        double time_completion = 0.0;
        try {
            time_completion = ETC[T][R] + ready[R];
            ready[R] += ETC[T][R];
        } catch (Exception ex) {
            ex.printStackTrace();
            System.exit(0);
        }
        return time_completion;
    }
    public void creatTask() {
        for (int j = 0; j < num_Task; j++) {
            TaskList[j] = new Task();
            TaskList[j].setDeadline(j + num_Task*2);
            TaskList[j].setID(j);
            TaskList[j].setLength(j + 100);
        }
    }
    public void creatResource() {

        for (int i = 0; i < num_Resource; i++) {
            ResourceList[i] = new Resource();
            ResourceList[i].setresource_Id(i);
            ResourceList[i].setresource_Name("resource" + i);
        }
    }
    public void printResorce() {
        System.out.print("resource_ID: ");
        for (int j = 0; j < num_Resource; j++) {
            System.out.print(ResourceList[j].getresource_Id() + " ");

        }
        System.out.println();
        System.out.print("resource_Name: ");
        for (int j = 0; j < num_Resource; j++) {
            System.out.print(ResourceList[j].getresource_Name() + " ");
        }
        System.out.println();
    }

    public void printTask() {
        System.out.print("Task_ID: ");
        for (int j = 0; j < num_Task; j++) {
            System.out.print(TaskList[j].getID() + " ");

        }
        System.out.println();
        System.out.print("Deadline: ");
        for (int j = 0; j < num_Task; j++) {
            System.out.print(TaskList[j].getDeadline() + " ");
        }
        System.out.println();
        System.out.print("Len: ");
        for (int j = 0; j < num_Task; j++) {
            System.out.print(TaskList[j].getLength() + " ");
        }
        System.out.println();
    }
     public void runICA() throws Exception {
        for(int decade=0; decade<=iter_ICA; decade++){
            System.out.println("*************generation" + decade + "*************");
            for(int i=0;i<num_Resource;i++){
                ready[i]=0.0;}
		assimilateColonies();
                for(int i=0; i<colonyArray.size(); i++){
                revolveColonies(i);
                }
                exchangeColonies();
                calculateTotalCost();
                imperialisticCompetition();
                if (ImpiresList.size() == 1 )
			{
				return;
			}

                for (int j = 0; j < numOfInitialImperialists; j++) {
                  if((Integer)num_colonyOfImpir.get(j)<1){
                      delete_Impire(j);
                  }
                }
          


       System.out.println("************end of generation" + decade + "**********");
        }
    }

    public static void main(String[] args)throws Exception {
        ICA m=new ICA();
        m.creatResource();
        m.creatTask();
        m.printResorce();
        m.printTask();
        m.creatCountries();
        m.selectSort(fitness_list);

        System.out.println("**********list Countries-sort************");
        for (int i = 0; i < numOfCountries; i++) {
            for (int j = 0; j < num_Task; j++) {
                System.out.print(countriesArray[i][j]);

            }
            System.out.print("; ");
        }
        System.out.println();

        System.out.println("+++++++++++++++++fitness-sort+++++++++++++++++");

        for (int i = 0; i < numOfCountries; i++) {
            System.out.print( fitness_list[i] + "   ");

        }
        System.out.println();
        System.out.println("+++++++++++++ end of fitness ++++++++++++");


        m.initializeImperials();
        m.fillColony();
        m.calculateColonyofImpir();
        System.out.println("***************list colony at first**********************");
        for (int i = 0; i < numOfAllColonies; i++) {
        for (int j = 0; j < num_Task; j++) {
          System.out.print(colonyArray.get(i)[j]);
          }
         System.out.print("; ");
      }

      System.out.println();
      System.out.println("***************num_colony of impire**********************");
      //  System.out.println();
        for (int i = 0; i < numOfInitialImperialists; i++) {
            System.out.print( num_colonyOfImpir.get(i) + "   ");

        }
         System.out.println();
      System.out.println("***************list colony after set for Impire**********************");
        //System.out.println();
        for (int i = 0; i < numOfAllColonies; i++) {
        for (int j = 0; j < num_Task+1; j++) {
          System.out.print(colonyArray.get(i)[j]);
          }
         System.out.print("; ");
      }

      System.out.println();
      m.runICA();
      System.out.println("***************list colony after assimilateColonies**********************");
        for (int i = 0; i < numOfAllColonies; i++) {
        for (int j = 0; j < num_Task+1; j++) {
          System.out.print(colonyArray.get(i)[j]);
          }
         System.out.print("; ");
      }

      System.out.println();
      System.out.println("***************list colony after revolveColonies**********************");
        for (int i = 0; i < numOfAllColonies; i++) {
        for (int j = 0; j < num_Task+1; j++) {
          System.out.print(colonyArray.get(i)[j]);
          }
         System.out.print("; ");
      }

      System.out.println();
      System.out.println("**********list ImpiresList after revolveColonies************");
        for (int i = 0; i < numOfInitialImperialists; i++) {
            for (int j = 0; j < num_Task; j++) {
                System.out.print(ImpiresList.get(i)[j]);

            }
            System.out.print("; ");
        }
        System.out.println();
        System.out.println(cost_list_imp);

        

    }

}
