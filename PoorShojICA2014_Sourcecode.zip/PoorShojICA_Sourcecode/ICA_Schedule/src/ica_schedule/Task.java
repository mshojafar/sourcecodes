/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ica_schedule;

public class Task {
private int id;
private double length;
private double deadline;
private static String  statusString;

public void setID(int id1){
    id=id1;
}

public void setDeadline(double  deadline1){
    deadline=deadline1;
}

public void setLength(double  len){
    length=len;
}

 public static String getStatusString(int status)
{
     switch (status)
        {
            case 0:
                statusString = "failed";
                break;

            case 1:
                statusString = "Success";
                break;
            default:
                break;
        }

        return statusString;

}

public int getID(){
    return id;
}

public double  getLength(){
    return length;
}

public double  getDeadline(){
    return deadline;
}

}

