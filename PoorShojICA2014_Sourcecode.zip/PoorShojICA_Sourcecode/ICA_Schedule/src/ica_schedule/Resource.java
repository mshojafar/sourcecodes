/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ica_schedule;

public class Resource {
private int resource_Id;
private String resource_Name;
//private boolean  status;

public void setresource_Id(int resource_Id1){
   resource_Id=resource_Id1;
}

public void setresource_Name(String resource_Name1){
    resource_Name=resource_Name1;
}

public String getresource_Name(){
    return resource_Name;
}

public int getresource_Id(){
    return resource_Id;
}
}