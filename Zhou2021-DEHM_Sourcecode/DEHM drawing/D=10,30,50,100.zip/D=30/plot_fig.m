clc;clear;
pool=[3,10,14,29];
for ii=2:4
    i=pool(ii);
%     filepath1=strcat('./IADE/data_Mean_',num2str(i));    
%     datapath1=strcat(filepath1,'.mat');
%     load(datapath1);
%     plot(bestfit,'LineWidth',1.5);
% %    xticks(1e-15:1e5:1e14);
%     xlabel('Evolution algebra(g)');
%     ylabel('Function value');
% %     legend('IADE');
%     hold on;
    
    filepath2=strcat('./DE_rand_1/data_Mean_',num2str(i));    
    datapath2=strcat(filepath2,'.mat');
    load(datapath2);
    plot(bestfitness,'LineWidth',1.5);
    xlabel('Evolution algebra(g)');
    ylabel('Function value');
    hold on;
    
    filepath3=strcat('./LSHADE-SPACMA/data_Mean_',num2str(i));  
    datapath3=strcat(filepath3,'.mat');
    load(datapath3);
    plot(bestfit,'LineWidth',1.5);
%     legend('DE/best/1');
    hold on;
    
    filepath4=strcat('./DE_rand-to-best_2/data_Mean_',num2str(i));   
    datapath4=strcat(filepath4,'.mat');
    load(datapath4);
    plot(bestfitness,'LineWidth',1.5);
%     legend('DE/rand-to-best/2');
    hold on;
    
    filepath5=strcat('./DEHM/data_Mean_',num2str(i));   
    datapath5=strcat(filepath5,'.mat');
    load(datapath5);
    plot(bestfit,'LineWidth',1.5);
    hold on;
    legend('DE/rand/1','LSHADE-SPACMA','DE/rand-to-best/2','DEHM');

end