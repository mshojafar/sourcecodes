function Analysis(readFrom)
    if size(readFrom,1)==0
        readFrom='C:\Users\Mahdi\Desktop\SFC\Conference\';
    else
        readFrom=[readFrom,'\'];
    end
    files=dir(readFrom);
    for i=1:size(files,1)
        if strcmp(files(i).name,'.')==0 && strcmp(files(i).name,'..')==0 && files(i).isdir==0 && strcmp(files(i).name,'Notation.txt')==0
            [A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0] ...
                =LoadResult([readFrom,files(i).name]);
            [EC]=MapVMEnergyConsumptionBetween150And300(EC);
            [linkUtilization]=LinkUtilization(n,p,A,C,B);
            [nodeUtilization]=NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC);
            [powerConsumption]=PowerConsumption(n,WN,EC);
            [netSideEffect]=NetworkSideEffect(n,p,A,A0);
            [averagePathLength]=AveragePathLength(p,A,s,d);
            [avgDelay,numberOfDelayedFlow]=Delay(p,A,s,D,T);
            [avgHops]=AvgHops(p,A,s);
            
%             for i=1:n
%                 WN(i)=(sum(sum(U(i,:,:)))>0);
%             end
            
            display(files(i).name);
            display(['lnk:',num2str(AverageOverNaN(linkUtilization)),',',num2str(MaxOverNaN(linkUtilization)),...
                '    nod:',num2str(mean(nodeUtilization)),',',num2str(MaxOverNaN(nodeUtilization)),...
                '    power:',num2str(powerConsumption),'      pth lngth:',num2str(averagePathLength),'      sdeEfct: ',num2str(netSideEffect),...
                '    dly:', num2str(avgDelay),',',num2str(numberOfDelayedFlow),':',num2str(avgHops)]);
            input('\n press enter to see the next');
        end
    end
end
function [linkUtilization]=LinkUtilization(n,p,A,C,B)
    linkLoad=LinkLoad(n,p,A,C);
    linkUtilization=linkLoad./B;
end
function [nodeUtilization]=NodeUtilization(n,p,numbrOfFunctions,U,C,FP,NC)
    %NC: nodes processing capacity,
    nodeLoad=NodeLoad(n,p,numbrOfFunctions,U,C,FP);
    nodeUtilization=nodeLoad./NC;
end
function [linkLoad]=LinkLoad(n,p,A,C)
    linkLoad=zeros(n,n);
    for i=1:n
        for j=1:n
            for f=1:p
                linkLoad(i,j)=linkLoad(i,j)+(A(i,j,f)>0)*C(f);
            end
        end
    end
end
function [nodeLoad]=NodeLoad(n,p,numberOfFunction,U,C,FP)
    %FP: required processing power of funtionss, 
    nodeLoad=zeros(1,n);
    for i=1:n
        for f=1:p
            for m=1:numberOfFunction
                nodeLoad(i)=nodeLoad(i)+U(i,m,f)*C(f)*FP(m);
            end
        end
    end
end
function [powerConsumption]=PowerConsumption(n,WN,EC)
    %EC: nodes' energy consumption
    %WN: state of switches(On/Off),    
    powerConsumption=0;
    for i=1:n
        powerConsumption=powerConsumption+WN(i)*EC(i);
    end
end
function [netSideEffect]=NetworkSideEffect(n,p,A,A0)
    netSideEffect=0;
    for i=1:n
        for j=1:n
            for f=1:p
                netSideEffect=netSideEffect+abs(A(i,j,f)-A0(i,j,f));
            end
        end
    end
end
function [averagePathLength]=AveragePathLength(p,A,s,d)
    averagePathLength=0;
    for i=1:p
        averagePathLength=averagePathLength+PathLength(i,A,s(i),d(i));
    end
    averagePathLength=averagePathLength/p;
end
function [pathLength]=PathLength(flowIndex,A,s,d)
    pathLength=0;
    maxAllowedLength=100;
    while sum(A(s,:,flowIndex)) && maxAllowedLength    
        pathLength=pathLength+1;
        s1=find(A(s,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(s,:,flowIndex)==min(A(s,s1,flowIndex)));
        A(s,s1,flowIndex)=0;
        s=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #1***************');
    end
end
function [res]=AverageOverNaN(input)
    res=0;
    num=0;
    for i=1:size(input,1)
        for j=1:size(input,2)
            if ~isnan(input(i,j))
                res=res+input(i,j);
                num=num+1;
            end
        end
    end
    res= res/num;
end
function [res]=MaxOverNaN(input)
    res=0;
    for i=1:size(input,1)
        for j=1:size(input,2)
            if ~isnan(input(i,j)) && res<input(i,j)
                res=input(i,j);
            end
        end
    end
end
function [avgDelay,numberOfDelayedFlow]=Delay(p,A,src,D,T)
    avgDelay=0;numberOfDelayedFlow=0;
    for f=1:p
        tmpDly=FlowDelay(A,src(f),D,f);
        avgDelay=avgDelay+tmpDly;
        if tmpDly>T(f)
            numberOfDelayedFlow=numberOfDelayedFlow+1;
        end
    end
    avgDelay=avgDelay/p;
end
function [delay]=FlowDelay(A,src,D,flowIndex)
    delay=0;
    maxAllowedLength=100;
    while sum(A(src,:,flowIndex)) && maxAllowedLength    
        s1=find(A(src,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
        A(src,s1,flowIndex)=0;
        delay=delay+D(src,s1);
        src=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #2***************');
    end


end
function [avgHops]=AvgHops(p,A,src)
    avgHops=0;
    for f=1:p
        tmpDly=FlowHops(A,src(f),f);
        avgHops=avgHops+tmpDly;
    end
    avgHops=avgHops/p;
end
function [hops]=FlowHops(A,src,flowIndex)
    hops=0;
    maxAllowedLength=100;
    while sum(A(src,:,flowIndex)) && maxAllowedLength    
        s1=find(A(src,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
        A(src,s1,flowIndex)=0;
        hops=hops+1;
        src=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #3***************');
    end


end
function [EC]=MapVMEnergyConsumptionBetween150And300(EC)
    EC=EC-min(EC);
    EC=EC/max(EC);
    EC=150+EC*150;
end









