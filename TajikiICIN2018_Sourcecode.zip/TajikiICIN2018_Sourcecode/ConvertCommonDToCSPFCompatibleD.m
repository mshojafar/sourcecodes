function [D] = ConvertCommonDToCSPFCompatibleD(D)%D: Links' propagation delay 
    MD=max(max(D));
    if MD~=100
        disp('************error in ConvertCommonDToCSPFCompatibleD: the delay of unconnected nodes must be 100. full mesh topology is not permited******');
    end
    for i=1:size(D,1)
        for j=1:size(D,2)
            if D(i,j)==MD
                D(i,j)=1./0;
            end
        end
    end    
end