function BarEnergyConsumptionAndPathLength(FolderAddres)
    if size(FolderAddres,1)==0
        FolderAddres='C:\Users\Mahdi\Desktop\SFC\Conference\';
    else
        FolderAddres=[FolderAddres,'\'];
    end
    folders=dir(FolderAddres);
    %for each folder with starting name '__'
    indexTmp=0;
    NameOfFile='';
    for iFolder=1:size(folders,1)
        if strcmp(folders(iFolder).name,'.')==0 && strcmp(folders(iFolder).name,'..')==0 && folders(iFolder).isdir==1 && strcmp(folders(iFolder).name(1:2),'__')
            readFrom=[FolderAddres,folders(iFolder).name,'\']; indNR=1;indHNR=1;
            files=dir(readFrom);
            indexTmp=indexTmp+1;
            NameOfFile=[NameOfFile,'p=',folders(iFolder).name(11:12),' alpha=',folders(iFolder).name(strfind(folders(iFolder).name,'alpha=')+6:strfind(folders(iFolder).name,'alpha=')+8)];
            %for each file in the folder
            for i=1:size(files,1)
                if strcmp(files(i).name,'.')==0 && strcmp(files(i).name,'..')==0 && files(i).isdir==0 && strcmp(files(i).name,'Notation.txt')==0
                    
                    [A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                        avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                        bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                        energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0] ...
                        =LoadResult([readFrom,files(i).name]);
                    
                    EC=MapEnergyConsumptionBetween200_400(EC);
                    
                    
                    
                    if strcmp(files(i).name(1:8),'NR_itr=5')
                        [RR_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC);
                        [RR_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,0);
                        [RR_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    elseif strcmp(files(i).name(1:12),'HNR_RR_itr=5')
                        %in HNR A0 is the Select Path for each flow in string mode
                        [NEW_RR_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC);
                        [NEW_RR_averagePathLength(indexTmp)]=AveragePathLength(p,A0,s,d,1);
                        [NEW_RR_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                    end
                end
            end
        end
    end

    NameOfFile=replace(NameOfFile,' ','');
    addrsToSaveFigures='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Conference\Figures\';
    %plot figures            
    NewBar4InputMatrix(3,RR_powerConsumption,NEW_RR_powerConsumption,...
        'Power Consumption [J]','Scenario Label',addrsToSaveFigures,['BarpwrCns',NameOfFile]);
    NewBar4InputMatrix(5,RR_averagePathLength,NEW_RR_averagePathLength,...
        'Average Path Length','Scenario Label',addrsToSaveFigures,['BarpthLen',NameOfFile]);
    NewBar4InputMatrix(5,RR_netSideEffect,NEW_RR_netSideEffect,...
        'Forwarding Table Elements','Scenario Label',addrsToSaveFigures,['BarnetSid',NameOfFile]);
end
function [powerConsumption]=PowerConsumption(n,WN,EC)
    %EC: nodes' energy consumption
    %WN: state of switches(On/Off),    
    powerConsumption=0;
    for i=1:n
%         powerConsumption=powerConsumption+WN(i)*EC(i);
        if WN(i)
            powerConsumption=powerConsumption+WN(i)*EC(i);
        else
            powerConsumption=powerConsumption+0*EC(i);
        end
    end
end
function [averagePathLength]=AveragePathLength(p,A,s,d,Heuristic)
    averagePathLength=0;
%     for i=1:p
%         averagePathLength=averagePathLength+PathLength(i,A,s(i),d(i));
%     end        
    if Heuristic
        for i=1:p
            averagePathLength=averagePathLength+sum(strfind(A(i),'->')>0);
        end
    else
        averagePathLength=sum(sum(sum(A)));
    end

    averagePathLength=averagePathLength/p;
end
function [pathLength]=PathLength(flowIndex,A,s,d)
    pathLength=0;
    maxAllowedLength=100;
    while sum(A(s,:,flowIndex)) && maxAllowedLength    
        pathLength=pathLength+1;
        s1=find(A(s,:,flowIndex));
        %in NSFF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(s,:,flowIndex)==min(A(s,s1,flowIndex)));
        A(s,s1,flowIndex)=0;
        s=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #1***************');
    end
end
function [netSideEffect]=NumberOfForwardingTableElements(A)
    netSideEffect=sum(sum(sum(A>0)));
end
function [netSideEffect]=NetworkSideEffect(n,p,A,A0)
    netSideEffect=0;
    for i=1:n
        for j=1:n
            for f=1:p
                netSideEffect=netSideEffect+abs(A(i,j,f)-A0(i,j,f));
            end
        end
    end
end
function NewBar4InputMatrix(figNumber, A, B, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    for i=1:size(A,2)
        BarMatrix(i,1)=A(i);
        BarMatrix(i,2)=B(i);
    end
    bar1=bar(BarMatrix);
    

    %Create Legend
%     set(bar1(1),'DisplayName','RR');
%     set(bar1(4),'DisplayName','NSFF');
%     set(bar1(2),'DisplayName','RRR');
%     set(bar1(3),'DisplayName','ECSPF');
    
    set(bar1(1),'DisplayName','ONR','FaceColor','r');
    set(bar1(2),'DisplayName','HNR','FaceColor','b');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',16.5,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
    Leg1=legend('ONR','HNR');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    %Save to file
%     savefig([AddrToSaveFig,FigName,'.fig']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.eps']);
%     saveas(gcf,[AddrToSaveFig,FigName,'.png']);
    
    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
    saveas(gcf,[AddrToSaveFig,FigName,'.epsc']);
end
function [EC]=MapEnergyConsumptionBetween200_400(EC)
    EC=(EC-min(EC))/(max(EC)-min(EC));
    EC=EC*200+200;
end