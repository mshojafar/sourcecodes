#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<conio.h>
#include<math.h>
#define max 1000
#define nrun 30
#define numItr 100
//#define numFog 60
//#define numTask 300
struct task {
	int id,s,m,d,in,out; 
	float p,q;
	/* s:size [MI], m:memory [MB] d:deadline [ms], p:penalty, q:QoS
	in:input file size [KB], out:output file size [KB] */
	int resp; /* resp:response time [ms] */
};
struct node {
	int id,c,m,b,a,d,dis,resp,rcl,ms; /* a:available time [ms] d:delay [ms] dis:distance [hop]
	resp:response time [ms], rcl: restricted candidate list */
	float pe,ce,pc,pmin,pmax,eng,procCost,fit, engCons; 
	/* pc:processing cost [G$ps] pe: power efficiency, ce: cost efficiency,
	ms: makespan, fit: fitness value */
};
struct task task[max];
struct node fog[max], cloud[max];
int i,j,k,x,y,index,etime,ntask,nfog,ncloud,r; /* etime:execution time, ntask:number of tasks, 
nfog:number of fog nodes, ncloud:number of cloud servers */
int index_f_max_pe, index_f_max_ce, index_c_max_pe, index_c_max_ce, totalPenalty;
float temp, tempq, violationCost, PDST, numSat;
float ftcDealy = rand()%271+30; // fog-to-cloud delay in ms
int max_pe, max_ce; // max_pe: max. power eff., max_ce: max. cost eff.
float alpha=0.4; //alpha=0:greedy alpha=1:random
void tasks(int);
void nodes(int, int);
void FCFS(struct task [],struct node [],struct node [],int,int,int);
void EDF(struct task [],struct node [],struct node [],int,int,int);
void GfE(struct task [],struct node [],struct node [],int,int,int);
void Detour(struct task [],struct node [],struct node [],int,int,int);
void semiGreedy(struct task [],struct node [],struct node [],int,int,int);
void semiGreedyMultistart(struct task [],struct node [],struct node [],int,int,int);
void sortTasks(struct task [],int);
void sortNodesEng(struct task [],int);
void sortNodesEngGfE(struct task [],int);
main()
{
	int code;
	while(1) {
	printf("\n--------------------------------------------");
	printf("\nEnter # of Tasks:\n");
	scanf("%d", &ntask);
//	ntask=numTask;
	printf("\nEnter # of fog nodes:");
	scanf("%d", &nfog);
//	nfog=numFog;
	ncloud=5;
	printf("\n_________________________\n");
	FCFS(task,fog,cloud,ntask,nfog,ncloud);
	EDF(task,fog,cloud,ntask,nfog,ncloud);
	GfE(task,fog,cloud,ntask,nfog,ncloud);
	Detour(task,fog,cloud,ntask,nfog,ncloud);
	semiGreedy(task,fog,cloud,ntask,nfog,ncloud);
	semiGreedyMultistart(task,fog,cloud,ntask,nfog,ncloud);
	}
}

///////////////////////////////////////////////////////////////////////////////
void tasks(int ntask) 
{
	srand(time(NULL));
//	printf("\n************** TASK INFO. *********************\n");
//	printf("ID\t  Size RAM  Deadline Penalty  QoS  Input Output\n");
	for (i=0; i<ntask; i++) {
		x = rand()%2;
		if (x==0) {
			task[i].s = rand()%273 + 100; // [100,372] MI 
			task[i].d = rand()%2001 + 500; // [100,500] ms
		}
		else {
			task[i].s = rand()%3253 + 1028; // [1028,4280] MI
			task[i].d = rand()%2001 + 500; // [500,2500] ms
		}
			
			
//		task[i].s = rand()%9901 + 100; // [100,10000] MI
		task[i].m = rand()%151 + 50; // [50,200] MB
//		task[i].d = rand()%9901 + 100; // [100,10000] ms
		task[i].p =(rand()%50+1)/100.0;
		task[i].q =(rand()%1000+9000)/100.0;
		task[i].in = rand()%9901 + 100; // [100KB,10MB]
		task[i].out = rand()%991 + 1; // [1KB,1MB]
		task[i].id = i;
//		printf("task[%d] = %-4d %-4d %-8d %-8.2f %-5.2f %-5d %-5d\n", task[i].id, task[i].s, task[i].m,
//		task[i].d, task[i].p, task[i].q, task[i].in, task[i].out);
	}
}
void nodes(int nfog, int ncloud)
{
//	printf("\n************** Nodes INFO. *********************\n");
//	printf("ID\t CPU  RAM  BW   PC   Delay  P_Max P_Min\n");
	for (i=0; i<nfog; i++) {
		fog[i].c = rand()%4001 + 2000; // [2000,6000] MIPS
		fog[i].m = rand()%101 + 150; // [512,8192] MB
		fog[i].b = 1000; // Mbps
		fog[i].dis = rand()%5+1; // [1,5] hops
		fog[i].pc = (rand()%31 + 10)/100.0; // [0.1,0.4] G$ps
		fog[i].d = fog[i].dis * (rand()%3 + 1); // [1,3] ms propagation delay from broker 
		fog[i].pmax = rand()%121 + 80; // [80,200] W
		fog[i].pmin = (rand()%11 + 60)/100.0*fog[i].pmax;
		fog[i].id = i;
//		printf("fog[%d] = %-4d %-4d %-4d %-5.2f %-6d %-5g %-5g\n", fog[i].id, fog[i].c, fog[i].m, fog[i].b,
//		fog[i].pc, fog[i].d, fog[i].pmax, fog[i].pmin);
	}
//	printf("\nID\t   CPU   RAM   BW   PC    Delay  P_Max P_Min\n");
	x = rand()%301 + 200; // [200,500] ms
	for (i=0; i<ncloud; i++) {
		cloud[i].c = rand()%2001 + 3000; // [3000,5000] MIPS
		cloud[i].m = rand()%57345 + 8192; // [8192,65536] MB
		cloud[i].b = rand()%9901 + 100; // [100,10000] Mbps
		cloud[i].pc = (rand()%31 + 70)/100.0; // [0.7,1] G$ps
		cloud[i].d = x;
		cloud[i].pmax = rand()%201 + 200; // [200,400] W
		cloud[i].pmin = (rand()%1 + 60)/100.0*cloud[i].pmax;
		cloud[i].id = i;
//		printf("cloud[%d] = %-5d %-5d %-4d %-5.2f %-6d %-5g %-5g\n", cloud[i].id, cloud[i].c, cloud[i].m, cloud[i].b,
//		cloud[i].pc, cloud[i].d, cloud[i].pmax, cloud[i].pmin);
	}
//	printf("\n");
}

/////////////////////////  SortTasks  ////////////////////////////////
void sortTasks(struct task T[], int)  // based on their deadline in increasing order
{
	struct task temp;
	int i,j;
	for (i=0; i<ntask-1; i++)
		for (j=i+1; j<ntask; j++)
			if (T[j].d < T[i].d){
				temp = T[j];
				T[j] = T[i];
				T[i] = temp;	
			}
}

/////////////////////////  sortNodesEng  ////////////////////////////////
void sortNodesEng(struct node F[],int nfog)
{
	struct node temp;
	int i,j;
	for (i=0; i<nfog-1; i++)
		for (j=i+1; j<nfog; j++) {
			if (F[j].rcl > F[i].rcl){
				temp = F[j];
				F[j] = F[i];
				F[i] = temp;	
			}
			if (F[j].rcl==1 && F[i].rcl && F[j].engCons < F[i].engCons){
				temp = F[j];
				F[j] = F[i];
				F[i] = temp;	
			}
		}
}

/////////////////////////  sortNodesEngGfE  ////////////////////////////////
void sortNodesEngGfE(struct node F[],int nfog)
{
	struct node temp;
	int i,j;
	for (i=0; i<nfog-1; i++)
		for (j=i+1; j<nfog; j++) {
			if (F[j].engCons < F[i].engCons){
				temp = F[j];
				F[j] = F[i];
				F[i] = temp;	
			}
		}
}
	
/////////////////////////  FCFS  ////////////////////////////////
void FCFS(struct task task[],struct node fog[],struct node cloud[],int ntask,int nfog,int ncloud)
{
	float sumM=0, sumengCons=0, sumPDST=0;
	int sumPen=0, sumNumSat=0;
	for (r=1; r<=nrun; r++) {
//	printf("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
//	printf("Run=%d\n",r);
//	getch();
	struct task T[max];
	struct node F[max], Fcopy[max];
	tasks(ntask);
	nodes(nfog, ncloud);
	int M; // M:Makespan
	float engCons=0;
	for (i=0; i<ntask; i++) {
		T[i] = task[i];
		T[i].resp = 0;
	}
	for (i=0; i<nfog; i++) {
		F[i] = fog[i];
		F[i].a = 0;
		F[i].ms = 0;
		F[i].eng = 0;
	} 	
//	printf("\n----------Scheduling----------\n");
	for (i=0; i<ntask; i++) {
//		printf("\nT[%d] is ready to be scheduled!\n",T[i].id);
			x = rand()%nfog;
			etime = (float)T[i].s / F[x].c * 1000;
			T[i].resp = F[x].a + etime + F[x].d + F[x].dis*((T[i].in+T[i].out)/F[x].b);
			F[x].a += etime;
//			printf("T[%d] is assigned to F[%d]\n",T[i].id,F[x].id);
//			getch();
	}
	totalPenalty = 0;
	numSat = 0;
	PDST=0;
	for(i=0; i<ntask; i++)	
		if (T[i].resp > T[i].d) {
//			printf("T[%d].resp=%d  , T[%d].d=%d\n", T[i].id,T[i].resp,T[i].id,T[i].d);
			totalPenalty = totalPenalty + T[i].resp - T[i].d;	
//			printf("totalPenalty=%d\n",totalPenalty);
//			getch();
		}	
		else
			numSat++;
	// calculating makespan and degree of imbalance (DI)
	M=0;
	for(i=0; i<nfog; i++) 
		if(F[i].a > M)
			M = F[i].a;
//	printf("Makespan=%.2f\n",M/1000.0);
	for(i=0; i<nfog; i++) {
//		printf("F[%d].a=%d\n",F[i].id, F[i].a);
		F[i].eng = F[i].a/1000.0*F[i].pmax + (M/1000.0-F[i].a/1000.0)*F[i].pmin; //ws or j
//		printf("F[%d].eng=%g\n",F[i].id,F[i].eng);
//		getch();
		engCons += 	F[i].eng;	
	}
	sumM += M;
	sumNumSat += numSat;
	PDST = 1.0*numSat/ntask;
	sumPDST += PDST;
	sumengCons += engCons;
	sumPen += totalPenalty;	
	}
	printf("\n*************Final Reults (FCFS) *************");
	printf("\nMakespan: %.2f S",sumM/1000.0/nrun);
	printf("\nnumSat: %d",sumNumSat/nrun);
	printf("\nPDST: %.2f",sumPDST/nrun);
	printf("\nengCons: %.0f J",sumengCons/nrun);
	printf("\ntotPenalty: %.2f S",sumPen/1000.0/nrun);
}
			
/////////////////////////  EDF  ////////////////////////////////
void EDF(struct task task[],struct node fog[],struct node cloud[],int ntask,int nfog,int ncloud)
{
	float sumM=0, sumengCons=0, sumPDST=0;
	int sumPen=0, sumNumSat=0;
	for (r=1; r<=nrun; r++) {
//	printf("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
//	printf("Run=%d\n",r);
//	getch();
	struct task T[max];
	struct node F[max], Fcopy[max];
	tasks(ntask);
	nodes(nfog, ncloud);
	int M; // M:Makespan
	float engCons=0;
	for (i=0; i<ntask; i++) {
		T[i] = task[i];
		T[i].resp = 0;
	}
	for (i=0; i<nfog; i++) {
		F[i] = fog[i];
		F[i].a = 0;
		F[i].ms = 0;
		F[i].eng = 0;
	} 	
	sortTasks(T,ntask);
//	printf("\n----------Scheduling----------\n");
	for (i=0; i<ntask; i++) {
//		printf("\nT[%d] is ready to be scheduled!\n",T[i].id);
			x = rand()%nfog;
			etime = (float)T[i].s / F[x].c * 1000;
			T[i].resp = F[x].a + etime + F[x].d + F[x].dis*((T[i].in+T[i].out)/F[x].b);
			F[x].a += etime;
//			printf("T[%d] is assigned to F[%d]\n",T[i].id,F[x].id);
//			getch();
	}
	totalPenalty = 0;
	numSat = 0;
	PDST=0;
	for(i=0; i<ntask; i++)	
		if (T[i].resp > T[i].d) {
//			printf("T[%d].resp=%d  , T[%d].d=%d\n", T[i].id,T[i].resp,T[i].id,T[i].d);
			totalPenalty = totalPenalty + T[i].resp - T[i].d;	
//			printf("totalPenalty=%d\n",totalPenalty);
//			getch();
		}	
		else
			numSat++;
	// calculating makespan and degree of imbalance (DI)
	M=0;
	for(i=0; i<nfog; i++) 
		if(F[i].a > M)
			M = F[i].a;
//	printf("Makespan=%.2f\n",M/1000.0);
	for(i=0; i<nfog; i++) {
//		printf("F[%d].a=%d\n",F[i].id, F[i].a);
		F[i].eng = F[i].a/1000.0*F[i].pmax + (M/1000.0-F[i].a/1000.0)*F[i].pmin; //ws or j
//		printf("F[%d].eng=%g\n",F[i].id,F[i].eng);
//		getch();
		engCons += 	F[i].eng;	
	}
	sumM += M;
	sumNumSat += numSat;
	PDST = 1.0*numSat/ntask;
	sumPDST += PDST;
	sumengCons += engCons;
	sumPen += totalPenalty;	
	}
	printf("\n*************Final Reults (EDF) *************");
	printf("\nMakespan: %.2f S",sumM/1000.0/nrun);
	printf("\nnumSat: %d",sumNumSat/nrun);
	printf("\nPDST: %.2f",sumPDST/nrun);
	printf("\nengCons: %.0f J",sumengCons/nrun);
	printf("\ntotPenalty: %.2f S",sumPen/1000.0/nrun);
}

/////////////////////////  Greedy for Enegy (GfE)  ////////////////////////////////
void GfE(struct task task[],struct node fog[],struct node cloud[],int ntask,int nfog,int ncloud)
{
	float sumM=0, sumengCons=0, sumPDST=0;
	int sumPen=0, sumNumSat=0;
	for (r=1; r<=nrun; r++) {
//	printf("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
//	printf("Run=%d\n",r);
//	getch();
	struct task T[max];
	struct node F[max], Fcopy[max];
	tasks(ntask);
	nodes(nfog, ncloud);
	int M; // M:Makespan
	float engCons=0;
	for (i=0; i<ntask; i++) {
		T[i] = task[i];
		T[i].resp = 0;
	}
	for (i=0; i<nfog; i++) {
		F[i] = fog[i];
		F[i].a = 0;
		F[i].ms = 0;
		F[i].eng = 0;
	} 	
//	printf("\n----------Scheduling----------\n");
	for (i=0; i<ntask; i++) {
		engCons = 0;
//		printf("\nT[%d] is ready to be scheduled!\n",T[i].id);
		for (j=0; j<nfog; j++) {
			etime = (float)T[i].s / F[j].c * 1000;
			F[j].resp = F[j].a + etime + F[j].d + F[j].dis*((T[i].in+T[i].out)/F[j].b); 
//			printf("F[%d].resp=%d\n",F[j].id, F[j].resp);
			F[j].ms = F[j].a + etime;	// for calculating makespan
//			printf("F[%d].ms=%d\n",F[j].id, F[j].ms);
			M = 0;
			engCons = 0;
			for(k=0; k<nfog; k++) {
				if(F[k].ms > M)
					M = F[k].ms;
			}
//			printf("M=%d\n",M);
//		calculating energy consumption	
		for(k=0; k<nfog; k++) {
//			printf("F[%d].a=%d\n",F[i].id, F[i].a);
			F[k].eng = F[k].ms/1000.0*F[k].pmax + (M/1000.0-F[k].ms/1000.0)*F[k].pmin; //ws or j
//			printf("F[%d].eng=%g\n",F[k].id,F[k].eng);
			engCons += 	F[k].eng;	
		}
		F[j].engCons = engCons;
		F[j].ms = F[j].a;
//		printf("If T[%d] is assigned to F[%d], engCons=%g J \n",T[i].id,F[j].id,engCons);
//		printf("----------------\n");
//		getch(); 
		}

		for (k=0; k<nfog; k++) 
			Fcopy[k] = F[k];
		sortNodesEngGfE(Fcopy,nfog);
//		for (k=0; k<nfog; k++) 
//			printf("F[%d].eng=%g \n",F[Fcopy[k].id].id, Fcopy[k].engCons);
		index = Fcopy[0].id;
		F[index].a += (float)T[i].s/F[index].c*1000;
		F[index].ms = F[index].a;
		T[i].resp = F[index].resp;
//		printf("T[%d] is assigned to F[%d]\n",T[i].id,F[index].id);	
//		for (k=0; k<nfog; k++) 
//			printf("F[%d].a=%d \n",F[k].id, F[k].a);
//		printf("--------------------------\n");
//		getch();
		}

	totalPenalty = 0;
	numSat = 0;
	PDST=0;
	for(i=0; i<ntask; i++)	
		if (T[i].resp > T[i].d) {
//			printf("T[%d].resp=%d  , T[%d].d=%d\n", T[i].id,T[i].resp,T[i].id,T[i].d);
			totalPenalty = totalPenalty + T[i].resp - T[i].d;	
//			printf("totalPenalty=%d\n",totalPenalty);
//			getch();
		}	
		else
			numSat++;
	// calculating makespan and degree of imbalance (DI)
	M=0;
	for(i=0; i<nfog; i++) 
		if(F[i].a > M)
			M = F[i].a;
//	printf("Makespan=%.2f\n",M/1000.0);
	engCons=0;
	for(i=0; i<nfog; i++) {
//		printf("F[%d].a=%d\n",F[i].id, F[i].a);
		F[i].eng = F[i].a/1000.0*F[i].pmax + (M/1000.0-F[i].a/1000.0)*F[i].pmin; //ws or j
//		printf("F[%d].eng=%g\n",F[i].id,F[i].eng);
//		getch();
		engCons += 	F[i].eng;	
	}
	sumM += M;
	sumNumSat += numSat;
	PDST = 1.0*numSat/ntask;
	sumPDST += PDST;
	sumengCons += engCons;
	sumPen += totalPenalty;	
	}
	printf("\n*************Final Reults (GfE) *************");
	printf("\nMakespan: %.2f S",sumM/1000.0/nrun);
	printf("\nnumSat: %d",sumNumSat/nrun);
	printf("\nPDST: %.2f",sumPDST/nrun);
	printf("\nengCons: %.0f J",sumengCons/nrun);
	printf("\ntotPenalty: %.2f S",sumPen/1000.0/nrun);
}

/////////////////////////  Detour  ////////////////////////////////
void Detour(struct task task[],struct node fog[],struct node cloud[],int ntask,int nfog,int ncloud)
{
	float sumM=0, sumengCons=0, sumPDST=0;
	int sumPen=0, sumNumSat=0, minResp;
	for (r=1; r<=nrun; r++) {
//	printf("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
//	printf("Run=%d\n",r);
//	getch();
	struct task T[max];
	struct node F[max], Fcopy[max];
	tasks(ntask);
	nodes(nfog, ncloud);
	int M; // M:Makespan
	float engCons=0;
	for (i=0; i<ntask; i++) {
		T[i] = task[i];
		T[i].resp = 0;
	}
	for (i=0; i<nfog; i++) {
		F[i] = fog[i];
		F[i].a = 0;
		F[i].ms = 0;
		F[i].eng = 0;
	} 	
//	printf("\n----------Scheduling----------\n");
	for (i=0; i<ntask; i++) {
//		printf("\nT[%d] is ready to be scheduled!\n",T[i].id);
		minResp=1000000000;
		for (j=0; j<nfog; j++) {
			etime = (float)T[i].s / F[j].c * 1000;
			F[j].resp = F[j].a + etime + F[j].d + F[j].dis*((T[i].in+T[i].out)/F[j].b); 
//			printf("F[%d].resp=%d\n",F[j].id, F[j].resp);
			if(F[j].resp < minResp) {
				minResp = F[j].resp;
				index = j;
			}
		}
		F[index].a += (float)T[i].s/F[index].c*1000;
		T[i].resp = F[index].resp;
//		printf("T[%d] is assigned to F[%d]\n",T[i].id,F[index].id);	
//		for (k=0; k<nfog; k++) 
//			printf("F[%d].a=%d \n",F[k].id, F[k].a);
//		printf("--------------------------\n");
//		getch();
		}

	totalPenalty = 0;
	numSat = 0;
	PDST=0;
	for(i=0; i<ntask; i++)	
		if (T[i].resp > T[i].d) {
//			printf("T[%d].resp=%d  , T[%d].d=%d\n", T[i].id,T[i].resp,T[i].id,T[i].d);
			totalPenalty = totalPenalty + T[i].resp - T[i].d;	
//			printf("totalPenalty=%d\n",totalPenalty);
//			getch();
		}	
		else
			numSat++;
	// calculating makespan and degree of imbalance (DI)
	M=0;
	for(i=0; i<nfog; i++) 
		if(F[i].a > M)
			M = F[i].a;
//	printf("Makespan=%.2f\n",M/1000.0);
	engCons=0;
	for(i=0; i<nfog; i++) {
//		printf("F[%d].a=%d\n",F[i].id, F[i].a);
		F[i].eng = F[i].a/1000.0*F[i].pmax + (M/1000.0-F[i].a/1000.0)*F[i].pmin; //ws or j
//		printf("F[%d].eng=%g\n",F[i].id,F[i].eng);
//		getch();
		engCons += 	F[i].eng;	
	}
	sumM += M;
	sumNumSat += numSat;
	PDST = 1.0*numSat/ntask;
	sumPDST += PDST;
	sumengCons += engCons;
	sumPen += totalPenalty;	
	}
	printf("\n*************Final Reults (Detour) *************");
	printf("\nMakespan: %.2f S",sumM/1000.0/nrun);
	printf("\nnumSat: %d",sumNumSat/nrun);
	printf("\nPDST: %.2f",sumPDST/nrun);
	printf("\nengCons: %.0f J",sumengCons/nrun);
	printf("\ntotPenalty: %.2f S",sumPen/1000.0/nrun);
}

/////////////////////////  semiGreedy  ////////////////////////////////
void semiGreedy(struct task task[],struct node fog[],struct node cloud[],int ntask,int nfog,int ncloud)
{
	float sumM=0, sumengCons=0, sumPDST=0;
	int sumPen=0, sumNumSat=0, itr;
//	printf("Enter alpha (alpha=0:greedy , alpha=1:random):");
//	scanf("%f",&alpha);
	for (r=1; r<=nrun; r++) {
//	printf("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
//	printf("Run=%d\n",r);
//	getch();
	struct task T[max];
	struct node F[max], Fcopy[max];
	tasks(ntask);
	nodes(nfog, ncloud);
	int bestM=0, bestNumSat=0,  bestPen=0; 	
	float bestPDST=0, bestEngCons=0;
	for (itr=0; itr<1; itr++) {
//	printf("\n@@@@@@@@@@@@@@@@\n");
//	printf("itr=%d\n",itr);
//	getch();
	int M; // M:Makespan
	float engCons=0;
	for (i=0; i<ntask; i++) {
		T[i] = task[i];
		T[i].resp = 0;
	}
	for (i=0; i<nfog; i++) {
		F[i] = fog[i];
		F[i].a = 0;
		F[i].ms = 0;
		F[i].eng = 0;
	} 	
	sortTasks(T,ntask);
//	printf("\nSorted Tasks\n");
//	for (i=0; i<ntask; i++) 
//		printf("%d\t",T[i].id);
//	printf("\n----------Scheduling----------\n");
	for (i=0; i<ntask; i++) {
		engCons = 0;
//		creating RCL
//		printf("\nT[%d] is ready to be scheduled!\n",T[i].id);
		for (j=0; j<nfog; j++) {
			etime = (float)T[i].s / F[j].c * 1000;
			F[j].resp = F[j].a + etime + F[j].d + F[j].dis*((T[i].in+T[i].out)/F[j].b); 
			if (F[j].resp <= T[i].d)
				F[j].rcl=1;
			else
				F[j].rcl=0;
//			printf("F[%d].resp=%d\n",F[j].id, F[j].resp);
//			printf("F[%d].rcl=%d\n",F[j].id, F[j].rcl);
			F[j].ms = F[j].a + etime;	// for calculating makespan
//			printf("F[%d].ms=%d\n",F[j].id, F[j].ms);
			M = 0;
			engCons = 0;
			for(k=0; k<nfog; k++) {
				if(F[k].ms > M)
					M = F[k].ms;
			}
//			printf("M=%d\n",M);
//		calculating energy consumption	
		for(k=0; k<nfog; k++) {
	//		printf("F[%d].a=%d\n",F[i].id, F[i].a);
			F[k].eng = F[k].ms/1000.0*F[k].pmax + (M/1000.0-F[k].ms/1000.0)*F[k].pmin; //ws or j
//			printf("F[%d].eng=%g\n",F[k].id,F[k].eng);
			engCons += 	F[k].eng;	
		}
		F[j].engCons = engCons;
		F[j].ms = F[j].a;
//		printf("If T[%d] is assigned to F[%d], engCons=%g J \n",T[i].id,F[j].id,engCons);
//		printf("----------------\n");
//		getch(); 
		}
		int rclSize = 0; // size of rcl
		for (j=0; j<nfog; j++)
			if (F[j].rcl==1)
				rclSize++;
//		printf("rclSize=%d\n",rclSize);
		if (rclSize==0) {
//			printf("rclSize=0\n");
			int minResp = 1000000;
			for (j=0; j<nfog; j++)
				if (F[j].resp < minResp) {
					minResp = F[j].resp;
					index = j;
				}	
//			printf("F[%d] has the minimum respTime which is:%d\n",F[index].id,minResp);
//			printf("T[%d] is assigned to F[%d]\n",T[i].id,F[index].id);	
			F[index].a += (float)T[i].s/F[index].c*1000;
			F[index].ms = F[index].a;
			T[i].resp = F[index].resp;
		}
		else {
//			printf("rclSize is greater than 0!\n");
			for (k=0; k<nfog; k++) 
				Fcopy[k] = F[k];
			x = (int)(alpha*rclSize);  
			if (x<1)
				x=1;
//			printf("x=%d\n",x);
			sortNodesEng(Fcopy,nfog);
//			for (k=0; k<nfog; k++) 
//				printf("F[%d].eng=%g \n",F[Fcopy[k].id].id, Fcopy[k].engCons);
			y = rand()%x;
//			printf("y=%d\n",y);
			index = Fcopy[y].id;
//			printf("index=%d\n",index);
			F[index].a += (float)T[i].s/F[index].c*1000;
			F[index].ms = F[index].a;
			T[i].resp = F[index].resp;
//			printf("T[%d] is assigned to F[%d]\n",T[i].id,F[index].id);	
//			for (k=0; k<nfog; k++) 
//				printf("F[%d].a=%d \n",F[k].id, F[k].a);
		}
//		printf("--------------------------\n");
//		getch();
	}
//	getch();
//	printf("\n----------Results----------\n");
	violationCost = 0;
	totalPenalty = 0;
	numSat = 0;
	PDST=0;
	for(i=0; i<ntask; i++)	
		if (T[i].resp > T[i].d) {
//			printf("T[%d].resp=%d  , T[%d].d=%d\n", T[i].id,T[i].resp,T[i].id,T[i].d);
			totalPenalty =  totalPenalty + T[i].resp - T[i].d;	
//			printf("totalPenalty=%d\n",totalPenalty);
//			getch();
		}	
		else
			numSat++;
	// calculating makespan and degree of imbalance (DI)
	M=0;
	for(i=0; i<nfog; i++) 
		if(F[i].a > M)
			M = F[i].a;
//	printf("\nMakespan=%.2f\n",M/1000.0);
	engCons=0;
	for(i=0; i<nfog; i++) {
//		printf("F[%d].a=%d\n",F[i].id, F[i].a);
		F[i].eng = F[i].a/1000.0*F[i].pmax + (M/1000.0-F[i].a/1000.0)*F[i].pmin; //ws or j
//		printf("F[%d].eng=%g\n",F[i].id, F[i].eng);
//		getch();
		engCons += 	F[i].eng;	
	}
	PDST = 1.0*numSat/ntask;
	if (PDST > bestPDST) {
//		printf("PDST is updated!\n");
		bestM = M;
		bestNumSat = numSat;
		bestPDST = PDST;
		bestEngCons = engCons;
		bestPen = totalPenalty;
	}
//	printf("\nMakespan: %.2f",bestM/1000.0);
//	printf("\nnumSat: %d",bestNumSat);
//	printf("\nPDST: %.2f",bestPDST);
//	printf("\nengCons: %.0f",bestEngCons);
//	printf("\ntotPenalty: %d",bestPen);
//	printf("\n---------------------------------");
//	getch();
	}
	sumM += bestM;
	sumNumSat += bestNumSat;
	PDST = 1.0*bestNumSat/ntask;
	sumPDST += bestPDST;
	sumengCons += bestEngCons;
	sumPen += bestPen;
	}
	printf("\n*************Final Reults (PSG) *************");
	printf("\nMakespan: %.2f S",sumM/1000.0/nrun);
	printf("\nnumSat: %d",sumNumSat/nrun);
	printf("\nPDST: %.4f",sumPDST/nrun);
	printf("\nengCons: %.0f J",sumengCons/nrun);
	printf("\ntotPenalty: %.2f S",sumPen/1000.0/nrun);
}

/////////////////////////  PSG-M  ////////////////////////////////
void semiGreedyMultistart(struct task task[],struct node fog[],struct node cloud[],int ntask,int nfog,int ncloud)
{
	printf("\n______________________________________");
	float sumM=0, sumengCons=0, sumPDST=0;
	int sumPen=0, sumNumSat=0, itr;
//	printf("Enter alpha (alpha=0:greedy , alpha=1:random):");
//	scanf("%f",&alpha);
	for (r=1; r<=nrun; r++) {
//	printf("\n&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&\n");
//	printf("Run=%d\n",r);
//	getch();
	struct task T[max];
	struct node F[max], Fcopy[max];
	tasks(ntask);
	nodes(nfog, ncloud);
	int bestM=0, bestNumSat=0,  bestPen=0; 	
	float bestPDST=0, bestEngCons=0;
	for (itr=0; itr<numItr; itr++) {
//	printf("\n@@@@@@@@@@@@@@@@\n");
//	printf("itr=%d\n",itr);
//	getch();
	int M; // M:Makespan
	float engCons=0;
	for (i=0; i<ntask; i++) {
		T[i] = task[i];
		T[i].resp = 0;
	}
	for (i=0; i<nfog; i++) {
		F[i] = fog[i];
		F[i].a = 0;
		F[i].ms = 0;
		F[i].eng = 0;
	} 	
	sortTasks(T,ntask);
//	printf("\nSorted Tasks\n");
//	for (i=0; i<ntask; i++) 
//		printf("%d\t",T[i].id);
//	printf("\n----------Scheduling----------\n");
	for (i=0; i<ntask; i++) {
		engCons = 0;
//		creating RCL
//		printf("\nT[%d] is ready to be scheduled!\n",T[i].id);
		for (j=0; j<nfog; j++) {
			etime = (float)T[i].s / F[j].c * 1000;
			F[j].resp = F[j].a + etime + F[j].d + F[j].dis*((T[i].in+T[i].out)/F[j].b); 
			if (F[j].resp <= T[i].d)
				F[j].rcl=1;
			else
				F[j].rcl=0;
//			printf("F[%d].resp=%d\n",F[j].id, F[j].resp);
//			printf("F[%d].rcl=%d\n",F[j].id, F[j].rcl);
			F[j].ms = F[j].a + etime;	// for calculating makespan
//			printf("F[%d].ms=%d\n",F[j].id, F[j].ms);
			M = 0;
			engCons = 0;
			for(k=0; k<nfog; k++) {
				if(F[k].ms > M)
					M = F[k].ms;
			}
//			printf("M=%d\n",M);
//		calculating energy consumption	
		for(k=0; k<nfog; k++) {
	//		printf("F[%d].a=%d\n",F[i].id, F[i].a);
			F[k].eng = F[k].ms/1000.0*F[k].pmax + (M/1000.0-F[k].ms/1000.0)*F[k].pmin; //ws or j
//			printf("F[%d].eng=%g\n",F[k].id,F[k].eng);
			engCons += 	F[k].eng;	
		}
		F[j].engCons = engCons;
		F[j].ms = F[j].a;
//		printf("If T[%d] is assigned to F[%d], engCons=%g J \n",T[i].id,F[j].id,engCons);
//		printf("----------------\n");
//		getch(); 
		}
		int rclSize = 0; // size of rcl
		for (j=0; j<nfog; j++)
			if (F[j].rcl==1)
				rclSize++;
//		printf("rclSize=%d\n",rclSize);
		if (rclSize==0) {
//			printf("rclSize=0\n");
			int minResp = 1000000;
			for (j=0; j<nfog; j++)
				if (F[j].resp < minResp) {
					minResp = F[j].resp;
					index = j;
				}	
//			printf("F[%d] has the minimum respTime which is:%d\n",F[index].id,minResp);
//			printf("T[%d] is assigned to F[%d]\n",T[i].id,F[index].id);	
			F[index].a += (float)T[i].s/F[index].c*1000;
			F[index].ms = F[index].a;
			T[i].resp = F[index].resp;
		}
		else {
//			printf("rclSize is greater than 0!\n");
			for (k=0; k<nfog; k++) 
				Fcopy[k] = F[k];
			x = (int)(alpha*rclSize);  
			if (x<1)
				x=1;
//			printf("x=%d\n",x);
			sortNodesEng(Fcopy,nfog);
//			for (k=0; k<nfog; k++) 
//				printf("F[%d].eng=%g \n",F[Fcopy[k].id].id, Fcopy[k].engCons);
			y = rand()%x;
//			printf("y=%d\n",y);
			index = Fcopy[y].id;
//			printf("index=%d\n",index);
			F[index].a += (float)T[i].s/F[index].c*1000;
			F[index].ms = F[index].a;
			T[i].resp = F[index].resp;
//			printf("T[%d] is assigned to F[%d]\n",T[i].id,F[index].id);	
//			for (k=0; k<nfog; k++) 
//				printf("F[%d].a=%d \n",F[k].id, F[k].a);
		}
//		printf("--------------------------\n");
//		getch();
	}
//	getch();
//	printf("\n----------Results----------\n");
	violationCost = 0;
	totalPenalty = 0;
	numSat = 0;
	PDST=0;
	for(i=0; i<ntask; i++)	
		if (T[i].resp > T[i].d) {
//			printf("T[%d].resp=%d  , T[%d].d=%d\n", T[i].id,T[i].resp,T[i].id,T[i].d);
			totalPenalty =  totalPenalty + T[i].resp - T[i].d;	
//			printf("totalPenalty=%d\n",totalPenalty);
//			getch();
		}	
		else
			numSat++;
	// calculating makespan and degree of imbalance (DI)
	M=0;
	for(i=0; i<nfog; i++) 
		if(F[i].a > M)
			M = F[i].a;
//	printf("\nMakespan=%.2f\n",M/1000.0);
	engCons=0;
	for(i=0; i<nfog; i++) {
//		printf("F[%d].a=%d\n",F[i].id, F[i].a);
		F[i].eng = F[i].a/1000.0*F[i].pmax + (M/1000.0-F[i].a/1000.0)*F[i].pmin; //ws or j
//		printf("F[%d].eng=%g\n",F[i].id, F[i].eng);
//		getch();
		engCons += 	F[i].eng;	
	}
	PDST = 1.0*numSat/ntask;
	if (PDST > bestPDST) {
//		printf("\nPDST is updated!");
		bestM = M;
		bestNumSat = numSat;
		bestPDST = PDST;
//		printf("\nPDST: %.4f",bestPDST);
//		getch();
		bestEngCons = engCons;
		bestPen = totalPenalty;
	}
//	printf("\nMakespan: %.2f",bestM/1000.0);
//	printf("\nnumSat: %d",bestNumSat);
//	printf("\nPDST: %.2f",bestPDST);
//	printf("\nengCons: %.0f",bestEngCons);
//	printf("\ntotPenalty: %d",bestPen);
//	printf("\n---------------------------------");
//	getch();
	}
	sumM += bestM;
	sumNumSat += bestNumSat;
	PDST = 1.0*bestNumSat/ntask;
	sumPDST += bestPDST;
	sumengCons += bestEngCons;
	sumPen += bestPen;
	}
	printf("\n*************Final Reults (PSG-M) *************");
	printf("\nMakespan: %.2f S",sumM/1000.0/nrun);
	printf("\nnumSat: %d",sumNumSat/nrun);
	printf("\nPDST: %.4f",sumPDST/nrun);
	printf("\nengCons: %.0f J",sumengCons/nrun);
	printf("\ntotPenalty: %.2f S",sumPen/1000.0/nrun);
}
