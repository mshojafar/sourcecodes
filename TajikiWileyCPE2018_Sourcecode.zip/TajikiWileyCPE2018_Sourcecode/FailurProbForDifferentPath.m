function [LinksfaultProb,MT,switchFailProb]=FailurProbForDifferentPath(n)
    MT=0.1;
    switchFailProb=0.001*ones(1,n);
    LinksfaultProb=ones(1,2^n);
    for i=1:n
        for j=2^(i-1):2^i:2^n
            for z=0:2^(i-1)-1
                LinksfaultProb(j+z)=LinksfaultProb(j+z)*(1-switchFailProb(i));
            end
        end
    end
    LinksfaultProb=1-LinksfaultProb;
end