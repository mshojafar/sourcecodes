%LoopMode could be one of {'NoLoop', 'NoRepetetiveLink', 'LoopAllowed'}
function HFES(readFrom,SortFlows,FunctionType)
%   A0 is the string format of selected paths: e.g., A0(1)= 1->3 3->5 5->4     where s=1 and d=4
    for itmp=1:1
        %B: matrix of links' bandwidth, 
        %D: Links' propagation delay
        %C: flow bandwidth requirement, 
        %T: maximum tolerable propagation delay,
        %s: source switches, 
        %d: destination switches, 
        %R: functions requirements of flows, 
        %K: sequence of required functions
        %p:number of flows
        %FP: required processing power of funtionss, 
        %NC: nodes processing capacity, 
        %F: functions associated withe nodes,
        %EC: nodes' energy consumption
        %WN: current state of switches
        %U: Service a is delivered in node b to flow c
        if size(readFrom,1)==0
            readFrom='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Failure-Recovery SFC No-Energy-aware Fog-Support\Simulation\results\';
        else
            readFrom=[readFrom,'\'];
        end
    end
    files=dir(readFrom);
    for j=1:size(files,1)
        if strcmp(files(j).name,'.')==0 && strcmp(files(j).name,'..')==0 && files(j).isdir==0 && strcmp(files(j).name(1:6),'OFES_i')
            [A,U,NA,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
            avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
            bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
            energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0]= LoadResult([readFrom,files(j).name]);
        
%             [A0,U0,WN0]=FindPerivousState(readFrom,files(j).name,n,numbrOfFunctions,p);
            [D]=ConvertCommonDToCSPFCompatibleD(D);
            tB=B;tNC=NC;
            A=zeros(n,n,p);
            U=zeros(n,numbrOfFunctions,p);
            tic

            if SortFlows, ind=SortFlowsBasedOnTheirSize(C); else, ind=1:p;end
            
            WN=zeros(1,n);
            TxtPath(1,p)=string;
            %invoke the HNR_RR_Solver function. If the problem is not solvable with current miu and miu2, then these values are increased to one
            
            tB=tB*miu;tNC=tNC*miu2;
            
            for f=1:p
                [tA,tU,FailureProb,TxtPath(f)]=FindSolution(n,numbrOfFunctions,tB,D,C(ind(f)),s(ind(f)),d(ind(f)),K(ind(f),:),FP,tNC,...
                    F,1,WN,EC,miu,miu2,maxNmbrFuncPerFlw,R(:,ind(f))',B,FunctionType);
                if FailureProb<0
                    disp('************HFES cannot solve the problem***************');
                    return;
                else
                    A(:,:,ind(f))=tA;
                    U(:,:,ind(f))=tU;
                    tB=DecreaseBandwidth(tB,tA,n,C(f),1);
                    tNC=DecreaseProcessing(tNC,tU,n,C(f),1,numbrOfFunctions,FP);
                end
            end
            toc
            display(['for p= ',num2str(p)]);
            tmpName=files(j).name;
            SaveResult(['HFES_itr=',tmpName(8)],A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode,prcntOfDestPerFlow,...
                avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,TxtPath,U0,tmpName(9:size(tmpName,2)));
        end
    end
end

function [A,U,SurvivalProb,TxtPath]=FindSolution(n,numbrOfFunctions,B,D,flowRate,s,d,K,FP,NC,F,BRatioToD,WN,EC,miu,miu2,maxNmbrFuncPerFlw,...
    R,OriginalB,FunctionType)

    [nodesFaultProb,MT,switchFailProb]=FailurProbForDifferentPath(n);
%     for i=-1:10
         if size(FunctionType,1)==0 || strcmp(FunctionType,'RecursiveFunction')==1
%             [TxtPath,A,ProbOfFailure,U]=HFES_Solver_Recursive(s,d,K,B,NC,FP,nodesFaultProb,ProbOfFailure,'',MT,n,flowRate,zeros(n,n),F,...
%                  zeros(n,numbrOfFunctions),min(miu+miu*i*0.2,1));
            B(:,s)=0;%do not return to source
            [TxtPath,A,SurvivalProb,U]=HFES_Solver_Recursive(s,d,K,B,NC,FP,nodesFaultProb,1-nodesFaultProb(s),num2str(s),MT,n,flowRate,zeros(n,n),F,...
                 zeros(n,numbrOfFunctions),miu);
         end
        if SurvivalProb>=0 %negative value for SurvivalProb means that the algorithm could not find a solution
%             disp('one flow is routed');
            return;
        end
%     end
    disp('**********************FindSolution Method could not find any solution**********************');
end

%CP: Chosen Path, PR: Survival Probability of Path, CN: Current Node, NC:
%Node processing Capacity, p: failure probability, FN: Function -> Node
function [CP,A,SurvivalProb,U]=HFES_Solver_Recursive(CN,d,K,B,NC,FP,nodesFaultProb,SurvivalProb,CP,MT,n,flowRate,A,FN,U,miu)
    if 1-SurvivalProb>MT || SurvivalProb<0
        SurvivalProb=-1; return;
    elseif sum(K)==0 && CN==d
        return;
    elseif sum(K)==0
        if B(CN,d)>=flowRate
            CP=[CP,'->',d]; A(CN,d)=1;
            SurvivalProb=SurvivalProb*(1-nodesFaultProb(d));
            return;
        end
        PCN=zeros(1,n);%previously chosen nodes
        NH=1;%Random Initial value (to make do-while)
        while(NH~=-1)
            NH=-1;
            MFP=1;%minimume failure probability
            for i=1:n
                if ~PCN(i)
%                     if B(CN,i)*miu>=flowRate && MFP>=nodesFaultProb(i)
                    if B(CN,i)>=flowRate && MFP>=nodesFaultProb(i)
                        NH=i;
                        MFP=nodesFaultProb(i);
                    end
                end
            end
            if NH==-1, SurvivalProb=-1; return; end
            PCN(NH)=1;B2=B;
            for i=1:n, B2(i,NH)=0;end%remove incoming links to NH
            SP2=SurvivalProb*(1-nodesFaultProb(NH));
            CP2=[CP,'->',num2str(NH)];
%             A(CN,NH)=1;
            [CP2,A,SP2,U]=HFES_Solver_Recursive(NH,d,0,B2,NC,FP,nodesFaultProb,SP2,CP2,MT,n,flowRate,A,FN,U,miu);
            if SP2~=-1, CP=CP2; SurvivalProb=SP2; A(CN,NH)=1; return; end
        end
    else
        %Give service to flow with those functions that are supported by current node (CN)
        while (sum(K)~=0 && FN(CN,K(find(K,1))) && FP(K(find(K,1)))<=NC(CN))
            NC(CN)=NC(CN)-FP(K(find(K,1)));
            U(CN,K(find(K,1)))=1;
            K(find(K,1))=0;
        end
        if sum(K)==0
            [CP,A,SurvivalProb,U]=HFES_Solver_Recursive(CN,d,0,B,NC,FP,nodesFaultProb,SurvivalProb,CP,MT,n,flowRate,A,FN,U,miu);
            return;
        end
        PCN=zeros(1,n);%previously chosen nodes
        HS=K(find(K,1));%HS:requested service with highest priority
%         K2=K;
        NC2=NC;U2=U;
        NH=1;%Random Initial value (to make do-while)
        while(NH~=-1 && sum(K)~=0)
            NH=-1;NH2=-1;
            MFP=1;MFP2=1;
            for i=1:n%select next node
                if PCN(i)==0
                    if FN(i,HS) && B(CN,i)>=flowRate && MFP>=nodesFaultProb(i) && FP(HS)<=NC(i)
                        NH=i; 
                        MFP=nodesFaultProb(i);
                    elseif B(CN,i)>=flowRate && MFP2>=nodesFaultProb(i)
                        NH2=i; 
                        MFP2=nodesFaultProb(i);
                    end
                end
            end
            K2=K;
            if NH~=-1 %if a directly connected node that can provide a service is found
                NC2(NH)=NC(NH)-flowRate*FP(HS);
                U2(NH,HS)=1;
                K2(find(K2,1))=0;
            %if direct node with minimum failure probability that cannot
            %support a service is found
            elseif NH==-1 && NH2==-1, SurvivalProb=-1; return;
            %if no node is found
            elseif NH==-1, NH=NH2;
            end
            PCN(NH)=1;
            B2=B;
            for i=1:n, B2(i,NH)=0;end %prevent returning to NH
            SP2=SurvivalProb*(1-nodesFaultProb(NH));
            CP2=[CP,'->',num2str(NH)];
            A(CN,NH)=1;
            [CP2,A,SP2,U2]=HFES_Solver_Recursive(NH,d,K2,B2,NC2,FP,nodesFaultProb,SP2,CP2,MT,n,flowRate,A,FN,U2,miu);
            if SP2~=-1, SurvivalProb=SP2; CP=CP2; U=U2; return;
            else, NC2(NH)=NC(NH); U2=U; A(CN,NH)=0; end
        end
    end
    SurvivalProb=-1;
end

function [ind]=SortFlowsBasedOnTheirSize(C)
    ind=zeros(1,size(C,2));
    for i=1:size(C,2)
        tmp=find(C==max(C));
        ind(i)=tmp(1);
        C(ind(i))=-1;
    end
end

function B=DecreaseBandwidth(B,A,n,flowRate,numberOfFlows)
    for f=1:numberOfFlows, for i=1:n, for j=1:n, if A(i,j,f)==1, B(i,j)=B(i,j)-flowRate(f); end, end, end,end
end

function NC=DecreaseProcessing(NC,U,n,flowRate,numberOfFlows,numberOfFunctions,FunctionProcessingFactor)
    for f=1:numberOfFlows, for i=1:n, for x=1:numberOfFunctions, if U(i,x,f)==1, NC(i)=NC(i)-flowRate(f)*FunctionProcessingFactor(x); end, end, end, end
end










