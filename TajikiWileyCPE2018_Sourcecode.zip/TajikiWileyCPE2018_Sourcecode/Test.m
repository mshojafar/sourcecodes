function [failurProb]=Test(n)
    switchFailProb=0.001*ones(1,n);
    failurProb=ones(1,2^n);
    for i=1:n
        for j=2^(i-1):2^i:2^n
            for z=0:2^(i-1)-1
                failurProb(j+z)=failurProb(j+z)*(1-switchFailProb(i));
            end
        end
    end
    failurProb=1-failurProb;
end
% SFC_RR(1,1,'C:\Users\Mahdi\Desktop\SFC\Conference\RR_itr=1_n=11 p=250 b=0.0001 k=0.2 e=1.5 df=1 mf=2 d=70,150 np=1 fp=0.1 ep=0.1 hf=1 -Time=18-Jul-2017 15 52.txt',0,0,0)
% SFC_RR(1,1,'C:\Users\Mahdi\Desktop\SFC\Conference\RR_itr=1_n=11 p=500 b=0.0001 k=0.2 e=1.5 df=1 mf=2 d=70,150 np=1 fp=0.1 ep=0.1 hf=1 -Time=18-Jul-2017 15 38.txt',0,0,0)
% SFC_RR(1,1,'C:\Users\Mahdi\Desktop\SFC\Conference\RR_itr=1_n=11 p=750 b=0.0001 k=0.2 e=1.5 df=1 mf=2 d=70,150 np=1 fp=0.1 ep=0.1 hf=1 -Time=18-Jul-2017 19 18.txt',0,0,0)
% SFC_RR(1,1,'C:\Users\Mahdi\Desktop\SFC\Conference\RR_itr=1_n=11 p=1000 b=0.0001 k=0.2 e=1.5 df=1 mf=2 d=70,150 np=1 fp=0.1 ep=0.1 hf=1 -Time=18-Jul-2017 16 46.txt',0,0,0)
% SFC_RR(1,1,'C:\Users\Mahdi\Desktop\SFC\Conference\RR_itr=1_n=11 p=1500 b=0.0001 k=0.2 e=1.5 df=1 mf=2 d=70,150 np=1 fp=0.1 ep=0.1 hf=1 -Time=18-Jul-2017 18 7.txt',0,0,0)
% SFC_RR(1,1,'C:\Users\Mahdi\Desktop\SFC\Conference\RR_itr=1_n=11 p=2000 b=0.0001 k=0.2 e=1.5 df=1 mf=2 d=70,150 np=1 fp=0.1 ep=0.1 hf=1 -Time=18-Jul-2017 21 6.txt',0,0,0)