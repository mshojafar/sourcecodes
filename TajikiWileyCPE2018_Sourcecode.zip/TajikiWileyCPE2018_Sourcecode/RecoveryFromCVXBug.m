function [A,U,WN] = RecoveryFromCVXBug(A,U,WN)
    sizeA=size(A);
    sizeU=size(U);
    if size(sizeA,2)==2
        for i=1:sizeA(1)
            for j=1:sizeA(2)
                if A(i,j)<0.8
                    A(i,j)=0;
                else
                    A(i,j)=1;
                end
            end
        end
    else
        for i=1:sizeA(1)
            for j=1:sizeA(2)
                for f=1:sizeA(3)
                    if A(i,j,f)<0.8
                        A(i,j,f)=0;
                    else
                        A(i,j,f)=1;
                    end
                end
            end
        end
    end
    
    if size(sizeU,2)==2
        for i=1:sizeU(1)
            for j=1:sizeU(2)
                if U(i,j)<0.8
                    U(i,j)=0;
                else
                    U(i,j)=1;
                end
            end
        end
    else
        for i=1:sizeU(1)
            for j=1:sizeU(2)
                for f=1:sizeU(3)
                    if U(i,j,f)<0.8
                        U(i,j,f)=0;
                    else
                        U(i,j,f)=1;
                    end
                end
            end
        end
    end
    
    for i=1:size(WN,1)
        if WN(i)<0.8
            WN(i)=0;
        else
            WN(i)=1;
        end
    end
end