function BarEnergyConsumptionAndPathLength(FolderAddres)
    if size(FolderAddres,1)==0
        FolderAddres='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Failure-Recovery SFC No-Energy-aware Fog-Support\Simulation\results\';
    else
        FolderAddres=[FolderAddres,'\'];
    end
    folders=dir(FolderAddres);
    %for each folder with starting name '__'
    indexTmp=0;
    NameOfFile='Haji';
    for iFolder=1:size(folders,1)
        if strcmp(folders(iFolder).name,'.')==0 && strcmp(folders(iFolder).name,'..')==0 && folders(iFolder).isdir==1 && strcmp(folders(iFolder).name(1:2),'__')
            readFrom=[FolderAddres,folders(iFolder).name,'\']; indNR=1;indHNR=1;
            files=dir(readFrom);
%             indexTmp=indexTmp+1;
%             NameOfFile=[NameOfFile,'p=',folders(iFolder).name(11:12),' alpha=',folders(iFolder).name(strfind(folders(iFolder).name,'alpha=')+6:strfind(folders(iFolder).name,'alpha=')+8)];
            %for each file in the folder
            for i=1:size(files,1)
                if strcmp(files(i).name,'.')==0 && strcmp(files(i).name,'..')==0 && files(i).isdir==0 && strcmp(files(i).name,'Notation.txt')==0
                    
                    [A,U,WN,p,B,D,C,T,s,d,R,K,FP,NC,F,EC,WN0,n,miu,miu2,prcntOfEdgeNode,prcntOfSrcNode, prcntOfDestPerFlow,...
                        avgPrcntNmbrFlwFrmASrc,maxNmbrFlwFrmASrc, avgPrcntOfNmbrOfFuncPerFlw,minNmbrFuncPerFlw,maxNmbrFuncPerFlw,numbrOfFunctions,prcntOfAvgBandDmnd,...
                        bandwidth,minTolrblDly,maxTolrbDly, nodeProcessingPowerToBandwidhRatio,prcntNodThtCanHstFunc,prcntFncThatHostedByANode,...
                        energyToProcessingPowerRatio, funcProcessingPowerToBandwidthRatio,flowDemandIncreamentFactor,A0,U0] ...
                        =LoadResult([readFrom,files(i).name]);
                    
%                     EC=MapEnergyConsumptionBetween200_400(EC);
                    [nodesFaultProb,MT,switchFailProb]=FailurProbForDifferentPath(n);
                    
                    indexTmp=indexTmp+1;
                    if strcmp(files(i).name(1:9),'OFES_itr=')
                        [FNR_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC);
                        [FNR_averagePathLength(indexTmp)]=AveragePathLength(p,A,s,d,0);
                        [RR_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                        [FNR_averageFaultProb(indexTmp),FNR_numberOfViolatedConstraint(indexTmp)]=FaultProb(A,s,switchFailProb,MT,p);
                    elseif strcmp(files(i).name(1:11),'HFES_itr=r=')
                        %in HNR A0 is the Select Path for each flow in string mode
                        [NEW_HFNR_powerConsumption(indexTmp)]=PowerConsumption(n,WN,EC);
                        [NEW_HFNR_averagePathLength(indexTmp)]=AveragePathLength(p,A0,s,d,1);
                        [NEW_HFNR_netSideEffect(indexTmp)]=NumberOfForwardingTableElements(A);
                        [NEW_HFNR_averageFaultProb(indexTmp),NEW_HFNR_numberOfViolatedConstraint(indexTmp)]=FaultProb(A,s,switchFailProb,MT,p);
                    end
                end
            end
        end
    end

    NameOfFile=replace(NameOfFile,' ','');
    addrsToSaveFigures='C:\Users\Mahdi\OneDrive\Tor Vergata-Mahdi Tajiki\Failure-Recovery SFC No-Energy-aware Fog-Support\Simulation\figure\';
    %plot figures            
    SpiderPlotPrepration(FNR_powerConsumption,NEW_HFNR_powerConsumption,addrsToSaveFigures,['SpdPwrCns',NameOfFile]);
    SpiderPlotPrepration(RR_netSideEffect,NEW_HFNR_netSideEffect,addrsToSaveFigures,['SpdNetSid',NameOfFile]);
    SpiderPlotPrepration(FNR_averagePathLength,NEW_HFNR_averagePathLength,addrsToSaveFigures,['SprPthLen',NameOfFile]);
    SpiderPlotPrepration(FNR_averageFaultProb,NEW_HFNR_averageFaultProb,addrsToSaveFigures,['SpdFaultProb',NameOfFile]);
    NewBar4InputMatrix(3,FNR_powerConsumption,NEW_HFNR_powerConsumption,'Power Consumption [J]','Scenario Label',addrsToSaveFigures,['BarpwrCns',NameOfFile]);
    NewBar4InputMatrix(5,FNR_averagePathLength,NEW_HFNR_averagePathLength,'Average Path Length','Scenario Label',addrsToSaveFigures,['BarpthLen',NameOfFile]);
    NewBar4InputMatrix(5,RR_netSideEffect,NEW_HFNR_netSideEffect,'Forwarding Table Elements','Scenario Label',addrsToSaveFigures,['BarnetSid',NameOfFile]);
    NewBar4InputMatrix(5,FNR_averageFaultProb,NEW_HFNR_averageFaultProb,'Fault Prob.','Scenario Label',addrsToSaveFigures,['BarfaltProb',NameOfFile]);
end
function [powerConsumption]=PowerConsumption(n,WN,EC)
    %EC: nodes' energy consumption
    %WN: state of switches(On/Off),    
    powerConsumption=0;
    for i=1:n
%         powerConsumption=powerConsumption+WN(i)*EC(i);
        if WN(i)
            powerConsumption=powerConsumption+WN(i)*EC(i);
        else
            powerConsumption=powerConsumption+0.65*EC(i);
        end
    end
end
function [averagePathLength]=AveragePathLength(p,A,s,d,Heuristic)
    averagePathLength=0;
%     for i=1:p
%         averagePathLength=averagePathLength+PathLength(i,A,s(i),d(i));
%     end        
    if Heuristic
        for i=1:p
            averagePathLength=averagePathLength+sum(strfind(A(i),'->')>0);
        end
    else
        averagePathLength=sum(sum(sum(A)));
    end

    averagePathLength=averagePathLength/p;
end
function [pathLength]=PathLength(flowIndex,A,s,d)
    pathLength=0;
    maxAllowedLength=100;
    while sum(A(s,:,flowIndex)) && maxAllowedLength    
        pathLength=pathLength+1;
        s1=find(A(s,:,flowIndex));
        %in NSFF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(s,:,flowIndex)==min(A(s,s1,flowIndex)));
        A(s,s1,flowIndex)=0;
        s=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #1***************');
    end
end
function [netSideEffect]=NumberOfForwardingTableElements(A)
    netSideEffect=sum(sum(sum(A>0)));
end
function [netSideEffect]=NetworkSideEffect(n,p,A,A0)
    netSideEffect=0;
    for i=1:n
        for j=1:n
            for f=1:p
                netSideEffect=netSideEffect+abs(A(i,j,f)-A0(i,j,f));
            end
        end
    end
end
function [EC]=MapEnergyConsumptionBetween200_400(EC)
    EC=(EC-min(EC))/(max(EC)-min(EC));
    EC=EC*200+200;
end
function [faultProb]=PathFaultProb(A,src,flowIndex,switchFailProb,p)
    faultProb=1-switchFailProb(src);
    maxAllowedLength=100;
    while (sum(A(src,:,flowIndex))>0) && (maxAllowedLength>0)
        s1=find(A(src,:,flowIndex));
        %in CSPF loops are not forbiden but instead if a flow return to a
        %switch then when it exit the number is increased
        %e.g., A(1,2,3)=1, A(1,3,3)=2
        s1=find(A(src,:,flowIndex)==min(A(src,s1,flowIndex)));
        A(src,s1,flowIndex)=0;
        faultProb=faultProb*(1-switchFailProb(s1));
        src=s1;
        maxAllowedLength=maxAllowedLength-1;
    end
    if maxAllowedLength==0
        disp('************error in analysis #2***************');
    end
    faultProb=1-faultProb;
end
function [averageFaultProb,numberOfViolatedConstraint]=FaultProb(A,src,switchFailProb,MT,p)
    numberOfViolatedConstraint=0;
    for f=1:p
        FaultProb(f)=PathFaultProb(A,src(f),f,switchFailProb);
        if FaultProb(f)>MT
            numberOfViolatedConstraint=numberOfViolatedConstraint+1;
        end
    end
    averageFaultProb=sum(FaultProb)/p;
end
function varargout = radarPlot( P,minValueOfEachAxes,MaxValueOfEachAxes, varargin)
% RADARPLOT spiderweb or radar plot
% radarPlot(P) Make a spiderweb or radar plot using the columns of P as datapoints.
%  P is the dataset. The plot will contain M dimensions(or spiderweb stems)
%  and N datapoints (which is also the number of columns in P). Returns the
%  axes handle
%
% radarPlot(P, ..., lineProperties) specifies additional line properties to be
% applied to the datapoint lines in the radar plot
%
% h = radarPlot(...) returns the handles to the line objects.


%%% Get the number of dimensions and points
[M, N] = size(P);

%%% Plot the axes
% Radial offset per axis
th = (2*pi/M)*(ones(2,1)*(M:-1:1));
% Axis start and end
r = [0;1]*ones(1,M);
% Conversion to cartesian coordinates to plot using regular plot.
[x,y] = pol2cart(th, r);
hLine = line(x, y,...
    'LineWidth', 1.5,...
    'Color', [1, 1, 1]*0.5  );

for i = 1:numel(hLine)
    set(get(get(hLine(i),'Annotation'),'LegendInformation'),...
        'IconDisplayStyle','off'); % Exclude line from legend
end

toggle = ~ishold;

if toggle
    hold on
end

%%% Plot axes isocurves
% Radial offset per axis
th = (2*pi/M)*(ones(9,1)*(M:-1:1));
% Axis start and end
r = (linspace(0.1, 0.9, 9)')*ones(1,M);
% Conversion to cartesian coordinates to plot using regular plot.
[x,y] = pol2cart(th, r);
hLine = line([x, x(:,1)]', [y, y(:,1)]',...
    'LineWidth', 1,...
    'Color', [1, 1, 1]*0.5  );
for i = 1:numel(hLine)
    set(get(get(hLine(i),'Annotation'),'LegendInformation'),...
        'IconDisplayStyle','off'); % Exclude line from legend
end


%%% Insert axis labels

% Compute minimum and maximum per axis
% minV = min(P,[],2)*0;
% maxV = max(P,[],2)*1.2;
minV = minValueOfEachAxes;
maxV = MaxValueOfEachAxes;
for j = 1:M
    % Generate the axis label
    msg = sprintf('S{%d} = %5.2f ... %5.2f',...
        j, minV(j), maxV(j));
%     msg = sprintf('S_{%d}', j);
    [mx, my] = pol2cart( th(1, j), 1.1);
    text(mx, my, msg);
end
axis([-1,1,-1,1]*1.5)

% Hold on to plot data points
hold on

% Radius
R = 0.8*((P - (minV*ones(1,N)))./((maxV-minV)*ones(1,N))) + 0.1;
R = [R; R(1,:)];
Th = (2*pi/M) * ((M:-1:0)'*ones(1,N));

% polar(Th, R)
[X, Y] = pol2cart(Th, R);

h = plot(X, Y, varargin{:});
axis([-1,1,-1,1])
axis square
axis off

if toggle
    hold off
end

if nargout > 0 
    varargout{1} = h;
end
end
function NewBar4InputMatrix(figNumber, A, B, YlabelText, XlabelText, AddrToSaveFig, FigName)
    close all
%     clc
    
    % Create figure
    fig1=figure(figNumber);
    set(fig1, 'Visible', 'off');
    
    % Create axes
%     axes1 = axes('Position',[0.13 0.117549668874172 0.775 0.807450331125824]);
    axes1 = axes();
    hold(axes1,'on');
    
    % Create multiple lines using matrix input to plot
    for i=1:size(A,2)
        BarMatrix(i,1)=A(i);
        BarMatrix(i,2)=B(i);
    end
    bar1=bar(BarMatrix);
    

    %Create Legend
%     set(bar1(1),'DisplayName','RR');
%     set(bar1(4),'DisplayName','NSFF');
%     set(bar1(2),'DisplayName','RRR');
%     set(bar1(3),'DisplayName','ECSPF');
    
    set(bar1(1),'DisplayName','FNR','FaceColor','r');
    set(bar1(2),'DisplayName','HFNR','FaceColor','b');
    
    % Create labels
    ylabel(YlabelText);
    xlabel(XlabelText);
    
    box(axes1,'on');
    grid(axes1,'on');
    % Set the remaining axes properties
    set(axes1,'FontSize',16.5,'XTick',1:size(A,2));
%     set(axes1,'XTick',1:size(A,2));
    
    Leg1=legend('FNR','HFNR');
%     Leg1.Orientation = 'horizontal';
    set(Leg1,...
    'location','northoutside',...
    'Orientation','horizontal');
    
    %remove white space from the pdf file
    %     fig = gcf;
    fig1.PaperPositionMode = 'auto';
    fig_pos = fig1.PaperPosition;
    fig1.PaperSize = [fig_pos(3) fig_pos(4)];

    %Save to file
    savefig([AddrToSaveFig,FigName,'.fig']);
    
%     NewFigName='fig';
%     tmpIndN=strfind(FigName,'p=');
%     NewFigName=[NewFigName,FigName(tmpIndN+2:tmpIndN+3)];
%     NewFigName=[NewFigName,FigName(1:2)];
%     saveas(gcf,[AddrToSaveFig,NewFigName,'.pdf']);
    saveas(gcf,[AddrToSaveFig,FigName,'.pdf']);
end
function SpiderPlotPrepration(A,B,addrsToSaveFigures,NameToSave)
    close all
%     nPoints = 4;
%     nDimensions = 6;
%     Values = rand(nDimensions, nPoints);
%     pointNames = arrayfun( @(i)sprintf('p_{%d}', i),1:nPoints, 'UniformOutput', false);
%     radarPlot(Values, 'o:','LineWidth', 1.5, 'MarkerFaceColor', [0,0,0])
%     legend(pointNames{:}, 'Location', 'Best');
%     title('Radar Plot Demo');

    minValueOfEachAxes=min([A',B'],[],2)*0.9;
    MaxValueOfEachAxes=max([A',B'],[],2)*1.1;
    radarPlot([A',B'],minValueOfEachAxes,MaxValueOfEachAxes, 'o:','LineWidth', 3.5, 'MarkerFaceColor', [0,0,0]) 
    Leg1=legend('ONR','HNR');
    set(Leg1,'location','northoutside','Orientation','horizontal');
%     title(FigName);    
%     set(get(gca,'title'),'Position',[5.5 0.4 1.00011])

    %remove white space from the pdf file
    fig = gcf;
    fig.PaperPositionMode = 'auto';
    fig_pos = fig.PaperPosition;
    fig.PaperSize = [fig_pos(3) fig_pos(4)];

    savefig([addrsToSaveFigures,NameToSave,'.fig']);
    saveas(gcf,[addrsToSaveFigures,NameToSave,'.pdf']);
    
end








