//base
import java.text.DecimalFormat;
import java.util.*;

import org.cloudbus.cloudsim.*;

import org.cloudbus.cloudsim.power.*;
import org.cloudbus.cloudsim.power.models.PowerModelLinear;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerVm;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;


public class MyTest {
	
	private static List<Cloudlet> cloudletList;
	
	public static int hostNumber=4;        
	public static VmAllocationPolicy myvmallocation;
        //........................
        /** The vmlist. */
	private static List<Vm> vmlist;

	private static List<Vm> createVM(int userId, int vms) {

		//Creates a container to store VMs. This list is passed to the broker later
                //Total number of VMs=50
                        //VM mips 500-2000
                        //VM memory(RAM)=256-2048
                        //Vm Bandwidth= 500-1000
                        //cloudlet Scheduler= Space_shared and Time_shared
                        //Number of PEs requirement= 1-4
		LinkedList<Vm> list = new LinkedList<Vm>();

		//VM Parameters
		long size = 10000; //image size (MB)
		int ram = 256; //vm memory (MB)
		int mips = 500;
		long bw = 500;
		int pesNumber = 6; //number of cpus
		String vmm = "Xen"; //VMM name

		//create VMs
		Vm[] vm = new Vm[vms];

		vm[0] = new Vm(0, userId, mips=1000, pesNumber, ram+128, bw, size, vmm, new CloudletSchedulerTimeShared());
                vm[1] = new Vm(1, userId, mips+1500, pesNumber, 2048, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[2] = new Vm(2, userId, mips+1200, pesNumber, ram+1024, bw+50, size, vmm, new CloudletSchedulerTimeShared());
                vm[3] = new Vm(3, userId, mips+1400, pesNumber, 2048, bw+450, size, vmm, new CloudletSchedulerTimeShared());
                vm[4] = new Vm(4, userId, mips+1500, pesNumber, ram+256, bw+300, size, vmm, new CloudletSchedulerTimeShared());
                vm[5] = new Vm(5, userId, mips+1400, pesNumber, ram+128, bw+250, size, vmm, new CloudletSchedulerTimeShared());
                vm[6] = new Vm(6, userId, mips+800, pesNumber, ram+1152, bw+200, size, vmm, new CloudletSchedulerTimeShared());
                vm[7] = new Vm(7, userId, mips+100, pesNumber, ram+1536, bw, size, vmm, new CloudletSchedulerTimeShared());
                vm[8] = new Vm(8, userId, mips+900, pesNumber, ram+1664, bw, size, vmm, new CloudletSchedulerTimeShared());
                vm[9] = new Vm(9, userId, mips+1000, pesNumber, ram+1024, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[10] = new Vm(10, userId, mips+1500, pesNumber, ram+512, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[11] = new Vm(11, userId, mips+1100, pesNumber, ram+1792, bw+400, size, vmm, new CloudletSchedulerTimeShared());
                vm[12] = new Vm(12, userId, mips+1200, pesNumber, ram+1280, bw+400, size, vmm, new CloudletSchedulerTimeShared());
                vm[13] = new Vm(13, userId, mips+400, pesNumber, ram+1024, bw+300, size, vmm, new CloudletSchedulerTimeShared());
                vm[14] = new Vm(14, userId, mips+1300, pesNumber, ram+1664, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[15] = new Vm(15, userId, mips+1200, pesNumber, ram+512, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[16] = new Vm(16, userId, mips+1000, pesNumber, ram+512, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[17] = new Vm(17, userId, mips+1450, pesNumber, ram+256, bw+400, size, vmm, new CloudletSchedulerTimeShared());
                vm[18] = new Vm(18, userId, mips+1500, pesNumber, ram+128, bw+300, size, vmm, new CloudletSchedulerTimeShared());
                vm[19] = new Vm(19, userId, mips+1450, pesNumber, ram, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[20] = new Vm(20, userId, mips+1050, pesNumber, ram+1024, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[21] = new Vm(21, userId, mips+100, pesNumber, ram+256, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[22] = new Vm(22, userId, mips+500, pesNumber, ram+512, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[23] = new Vm(23, userId, mips+700, pesNumber, ram+1024, bw+300, size, vmm, new CloudletSchedulerTimeShared());
                vm[24] = new Vm(24, userId, mips+1500, pesNumber, ram+1536, bw+100, size, vmm, new CloudletSchedulerTimeShared());
                vm[25] = new Vm(25, userId, mips, pesNumber, ram+128, bw, size, vmm, new CloudletSchedulerTimeShared());
                vm[26] = new Vm(26, userId, mips+1500, pesNumber, ram+1792, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[27] = new Vm(27, userId, mips+1100, pesNumber, ram+1280, bw+400, size, vmm, new CloudletSchedulerTimeShared());
                vm[28] = new Vm(28, userId, mips+1200, pesNumber, ram+1408, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[29] = new Vm(29, userId, mips+800, pesNumber, ram+1024, bw+200, size, vmm, new CloudletSchedulerTimeShared());
                vm[30] = new Vm(30, userId, mips+700, pesNumber, ram+512, bw+300, size, vmm, new CloudletSchedulerTimeShared());
                vm[31] = new Vm(31, userId, mips+600, pesNumber, ram+256, bw+300, size, vmm, new CloudletSchedulerTimeShared());
                vm[32] = new Vm(32, userId, mips+800, pesNumber, ram+512, bw+200, size, vmm, new CloudletSchedulerTimeShared());
                vm[33] = new Vm(33, userId, mips+1400, pesNumber, ram+1536, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[34] = new Vm(34, userId, mips+1320, pesNumber, ram+1280, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[35] = new Vm(35, userId, mips+1020, pesNumber, ram+768, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[36] = new Vm(36, userId, mips+1090, pesNumber, ram+1024, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[37] = new Vm(37, userId, mips+800, pesNumber, ram+768, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[38] = new Vm(38, userId, mips+600, pesNumber, ram+1152, bw+400, size, vmm, new CloudletSchedulerTimeShared());
                vm[39] = new Vm(39, userId, mips+1300, pesNumber, ram+512, bw+300, size, vmm, new CloudletSchedulerTimeShared());
                vm[40] = new Vm(40, userId, mips+1380, pesNumber, ram+1792, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[41] = new Vm(41, userId, mips+1500, pesNumber, ram+1664, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[42] = new Vm(42, userId, mips+1400, pesNumber, ram+1536, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[43] = new Vm(43, userId, mips+1500, pesNumber, ram+1408, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[44] = new Vm(44, userId, mips+1500, pesNumber, ram+1280, bw+400, size, vmm, new CloudletSchedulerTimeShared());
                vm[45] = new Vm(45, userId, mips+1500, pesNumber, ram+1664, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[46] = new Vm(46, userId, mips+1500, pesNumber, ram+1792, bw+300, size, vmm, new CloudletSchedulerTimeShared());
                vm[47] = new Vm(47, userId, mips+1400, pesNumber, ram+1408, bw+500, size, vmm, new CloudletSchedulerTimeShared());
                vm[48] = new Vm(48, userId, mips+1400, pesNumber, ram+768, bw+200, size, vmm, new CloudletSchedulerTimeShared());
                vm[49] = new Vm(49, userId, mips+1500, pesNumber, ram+128, bw, size, vmm, new CloudletSchedulerTimeShared());
               
                for(int i=0;i<vms;i++){
		list.add(vm[i]);}
		return list;
	}
        //...........
        private static List<Cloudlet> createCloudlet(int userId, int cloudlets){
		//Length of task 1000-20000
                //Total number of task 100-1000
                // Creates a container to store Cloudlets
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();

		//cloudlet parameters
		long length = 1000;
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		UtilizationModel utilizationModel = new UtilizationModelFull();

		Cloudlet[] cloudlet = new Cloudlet[cloudlets];

		for(int i=0;i<cloudlets;i++){
			cloudlet[i] = new Cloudlet(i, length+10, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			// setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
                }
                cloudlet[0].setVmId(2);
                cloudlet[1].setVmId(50);
                cloudlet[2].setVmId(49);
                cloudlet[3].setVmId(41);
                cloudlet[4].setVmId(42);
                cloudlet[5].setVmId(43);
                cloudlet[6].setVmId(23);
                cloudlet[7].setVmId(32);
                cloudlet[8].setVmId(40);
                cloudlet[9].setVmId(47);
                cloudlet[10].setVmId(11);
                cloudlet[11].setVmId(20);
                cloudlet[12].setVmId(29);
                cloudlet[13].setVmId(36);
                cloudlet[14].setVmId(46);
                cloudlet[15].setVmId(10);
                cloudlet[16].setVmId(18);
                cloudlet[17].setVmId(28);
                cloudlet[18].setVmId(35);
                cloudlet[19].setVmId(45);
                cloudlet[20].setVmId(9);
                cloudlet[21].setVmId(34);
                cloudlet[22].setVmId(28);
                cloudlet[23].setVmId(27);
                cloudlet[24].setVmId(18);
                cloudlet[25].setVmId(8);
                cloudlet[26].setVmId(17);
                cloudlet[27].setVmId(6);
                cloudlet[28].setVmId(5);
                cloudlet[29].setVmId(16);
                cloudlet[30].setVmId(1);
                cloudlet[31].setVmId(5);
                cloudlet[32].setVmId(6);
                cloudlet[33].setVmId(8);
                cloudlet[34].setVmId(45);
                cloudlet[35].setVmId(24);
                cloudlet[36].setVmId(33);
                cloudlet[37].setVmId(44);
                cloudlet[38].setVmId(48);
                cloudlet[39].setVmId(40);
                cloudlet[40].setVmId(45);
                cloudlet[41].setVmId(24);
                cloudlet[42].setVmId(33);
                cloudlet[43].setVmId(44);
                cloudlet[44].setVmId(48);
                cloudlet[45].setVmId(12);
                cloudlet[46].setVmId(23);
                cloudlet[47].setVmId(32);
                cloudlet[48].setVmId(40);
                cloudlet[49].setVmId(47);
                cloudlet[50].setVmId(18);
                cloudlet[51].setVmId(32);
                cloudlet[52].setVmId(44);
                cloudlet[53].setVmId(1);
                cloudlet[54].setVmId(14);
                cloudlet[55].setVmId(12);
                cloudlet[56].setVmId(23);
                cloudlet[57].setVmId(32);
                cloudlet[58].setVmId(40);
                cloudlet[59].setVmId(36);
                cloudlet[60].setVmId(35);
                cloudlet[61].setVmId(10);
                cloudlet[62].setVmId(27);
                cloudlet[63].setVmId(34);
                cloudlet[64].setVmId(45);
                cloudlet[65].setVmId(26);
                cloudlet[66].setVmId(40);
                cloudlet[67].setVmId(20);
                cloudlet[68].setVmId(18);
                cloudlet[69].setVmId(47);
                cloudlet[70].setVmId(11);
                cloudlet[71].setVmId(29);
                cloudlet[72].setVmId(33);
                cloudlet[73].setVmId(45);
                cloudlet[74].setVmId(48);
                cloudlet[75].setVmId(12);
                cloudlet[76].setVmId(23);
                cloudlet[77].setVmId(32);
                cloudlet[78].setVmId(40);
                cloudlet[79].setVmId(47);
                cloudlet[80].setVmId(1);
                cloudlet[81].setVmId(15);
                cloudlet[82].setVmId(26);
                cloudlet[83].setVmId(34);
                cloudlet[84].setVmId(45);
                cloudlet[85].setVmId(3);
                cloudlet[86].setVmId(16);
                cloudlet[87].setVmId(27);
                cloudlet[88].setVmId(35);
                cloudlet[89].setVmId(46);
                cloudlet[90].setVmId(8);
                cloudlet[91].setVmId(18);
                cloudlet[92].setVmId(28);
                cloudlet[93].setVmId(32);
                cloudlet[94].setVmId(20);
                cloudlet[95].setVmId(26);
                cloudlet[96].setVmId(14);
                cloudlet[97].setVmId(28);
                cloudlet[98].setVmId(32);
                cloudlet[99].setVmId(26);
                
                cloudlet[100].setVmId(2);
                cloudlet[101].setVmId(45);
                cloudlet[102].setVmId(49);
                cloudlet[103].setVmId(17);
                cloudlet[104].setVmId(42);
                cloudlet[105].setVmId(48);
                cloudlet[106].setVmId(23);
                cloudlet[107].setVmId(27);
                cloudlet[108].setVmId(40);
                cloudlet[109].setVmId(3);
                cloudlet[110].setVmId(11);
                cloudlet[111].setVmId(5);
                cloudlet[112].setVmId(39);
                cloudlet[113].setVmId(7);
                cloudlet[114].setVmId(12);
                cloudlet[115].setVmId(50);
                cloudlet[116].setVmId(48);
                cloudlet[117].setVmId(46);
                cloudlet[118].setVmId(44);
                cloudlet[119].setVmId(40);
                cloudlet[120].setVmId(14);
                cloudlet[121].setVmId(10);
                cloudlet[122].setVmId(19);
                cloudlet[123].setVmId(14);
                cloudlet[124].setVmId(50);
                cloudlet[125].setVmId(49);
                cloudlet[126].setVmId(48);
                cloudlet[127].setVmId(46);
                cloudlet[128].setVmId(44);
                cloudlet[129].setVmId(39);
                cloudlet[130].setVmId(26);
                cloudlet[131].setVmId(12);
                cloudlet[132].setVmId(11);
                cloudlet[133].setVmId(8);
                cloudlet[134].setVmId(15);
                cloudlet[135].setVmId(17);
                cloudlet[136].setVmId(33);
                cloudlet[137].setVmId(50);
                cloudlet[138].setVmId(1);
                cloudlet[139].setVmId(40);
                cloudlet[140].setVmId(7);
                cloudlet[141].setVmId(9);
                cloudlet[142].setVmId(33);
                cloudlet[143].setVmId(6);
                cloudlet[144].setVmId(48);
                cloudlet[145].setVmId(24);
                cloudlet[146].setVmId(32);
                cloudlet[147].setVmId(23);
                cloudlet[148].setVmId(4);
                cloudlet[149].setVmId(40);
                cloudlet[150].setVmId(20);
                cloudlet[151].setVmId(23);
                cloudlet[152].setVmId(11);
                cloudlet[153].setVmId(2);
                cloudlet[154].setVmId(41);
                cloudlet[155].setVmId(21);
                cloudlet[156].setVmId(32);
                cloudlet[157].setVmId(45);
                cloudlet[158].setVmId(40);
                cloudlet[159].setVmId(30);
                cloudlet[160].setVmId(30);
                cloudlet[161].setVmId(7);
                cloudlet[162].setVmId(48);
                cloudlet[163].setVmId(43);
                cloudlet[164].setVmId(44);
                cloudlet[165].setVmId(21);
                cloudlet[166].setVmId(50);
                cloudlet[167].setVmId(17);
                cloudlet[168].setVmId(12);
                cloudlet[169].setVmId(19);
                cloudlet[170].setVmId(20);
                cloudlet[171].setVmId(28);
                cloudlet[172].setVmId(27);
                cloudlet[173].setVmId(26);
                cloudlet[174].setVmId(46);
                cloudlet[175].setVmId(50);
                cloudlet[176].setVmId(12);
                cloudlet[177].setVmId(17);
                cloudlet[178].setVmId(18);
                cloudlet[179].setVmId(48);
                cloudlet[180].setVmId(1);
                cloudlet[181].setVmId(19);
                cloudlet[182].setVmId(26);
                cloudlet[183].setVmId(43);
                cloudlet[184].setVmId(45);
                cloudlet[185].setVmId(30);
                cloudlet[186].setVmId(14);
                cloudlet[187].setVmId(14);
                cloudlet[188].setVmId(13);
                cloudlet[189].setVmId(46);
                cloudlet[190].setVmId(28);
                cloudlet[191].setVmId(18);
                cloudlet[192].setVmId(48);
                cloudlet[193].setVmId(32);
                cloudlet[194].setVmId(20);
                cloudlet[195].setVmId(36);
                cloudlet[196].setVmId(24);
                cloudlet[197].setVmId(48);
                cloudlet[198].setVmId(52);
                cloudlet[199].setVmId(16);
                
                cloudlet[200].setVmId(50);
                cloudlet[201].setVmId(5);
                cloudlet[202].setVmId(4);
                cloudlet[203].setVmId(1);
                cloudlet[204].setVmId(42);
                cloudlet[205].setVmId(14);
                cloudlet[206].setVmId(17);
                cloudlet[207].setVmId(19);
                cloudlet[208].setVmId(40);
                cloudlet[209].setVmId(42);
                cloudlet[210].setVmId(11);
                cloudlet[211].setVmId(40);
                cloudlet[212].setVmId(14);
                cloudlet[213].setVmId(30);
                cloudlet[214].setVmId(17);
                cloudlet[215].setVmId(16);
                cloudlet[216].setVmId(19);
                cloudlet[217].setVmId(20);
                cloudlet[218].setVmId(21);
                cloudlet[219].setVmId(29);
                cloudlet[220].setVmId(19);
                cloudlet[221].setVmId(14);
                cloudlet[222].setVmId(17);
                cloudlet[223].setVmId(19);
                cloudlet[224].setVmId(20);
                cloudlet[225].setVmId(29);
                cloudlet[226].setVmId(7);
                cloudlet[227].setVmId(16);
                cloudlet[228].setVmId(15);
                cloudlet[229].setVmId(46);
                cloudlet[230].setVmId(11);
                cloudlet[231].setVmId(1);
                cloudlet[232].setVmId(2);
                cloudlet[233].setVmId(18);
                cloudlet[234].setVmId(25);
                cloudlet[235].setVmId(14);
                cloudlet[236].setVmId(13);
                cloudlet[237].setVmId(34);
                cloudlet[238].setVmId(28);
                cloudlet[239].setVmId(10);
                cloudlet[240].setVmId(40);
                cloudlet[241].setVmId(12);
                cloudlet[242].setVmId(45);
                cloudlet[243].setVmId(34);
                cloudlet[244].setVmId(26);
                cloudlet[245].setVmId(11);
                cloudlet[246].setVmId(15);
                cloudlet[247].setVmId(3);
                cloudlet[248].setVmId(16);
                cloudlet[249].setVmId(27);
                cloudlet[250].setVmId(35);
                cloudlet[251].setVmId(5);
                cloudlet[252].setVmId(17);
                cloudlet[253].setVmId(1);
                cloudlet[254].setVmId(29);
                cloudlet[255].setVmId(20);
                cloudlet[256].setVmId(14);
                cloudlet[257].setVmId(24);
                cloudlet[258].setVmId(33);
                cloudlet[259].setVmId(44);
                cloudlet[260].setVmId(29);
                cloudlet[261].setVmId(10);
                cloudlet[262].setVmId(18);
                cloudlet[263].setVmId(32);
                cloudlet[264].setVmId(28);
                cloudlet[265].setVmId(7);
                cloudlet[266].setVmId(40);
                cloudlet[267].setVmId(30);
                cloudlet[268].setVmId(18);
                cloudlet[269].setVmId(27);
                cloudlet[270].setVmId(41);
                cloudlet[271].setVmId(50);
                cloudlet[272].setVmId(30);
                cloudlet[273].setVmId(40);
                cloudlet[274].setVmId(44);
                cloudlet[275].setVmId(35);
                cloudlet[276].setVmId(23);
                cloudlet[277].setVmId(29);
                cloudlet[278].setVmId(17);
                cloudlet[279].setVmId(18);
                cloudlet[280].setVmId(8);
                cloudlet[281].setVmId(15);
                cloudlet[282].setVmId(24);
                cloudlet[283].setVmId(32);
                cloudlet[284].setVmId(47);
                cloudlet[285].setVmId(30);
                cloudlet[286].setVmId(17);
                cloudlet[287].setVmId(29);
                cloudlet[288].setVmId(30);
                cloudlet[289].setVmId(49);
                cloudlet[290].setVmId(6);
                cloudlet[291].setVmId(4);
                cloudlet[292].setVmId(2);
                cloudlet[293].setVmId(1);
                cloudlet[294].setVmId(50);
                cloudlet[295].setVmId(46);
                cloudlet[296].setVmId(10);
                cloudlet[297].setVmId(12);
                cloudlet[298].setVmId(12);
                cloudlet[299].setVmId(25);
                
                cloudlet[300].setVmId(42);
                cloudlet[301].setVmId(54);
                cloudlet[302].setVmId(29);
                cloudlet[303].setVmId(45);
                cloudlet[304].setVmId(12);
                cloudlet[305].setVmId(47);
                cloudlet[306].setVmId(43);
                cloudlet[307].setVmId(30);
                cloudlet[308].setVmId(10);
                cloudlet[309].setVmId(41);
                cloudlet[310].setVmId(31);
                cloudlet[311].setVmId(29);
                cloudlet[312].setVmId(49);
                cloudlet[313].setVmId(37);
                cloudlet[314].setVmId(36);
                cloudlet[315].setVmId(16);
                cloudlet[316].setVmId(28);
                cloudlet[317].setVmId(21);
                cloudlet[318].setVmId(5);
                cloudlet[319].setVmId(49);
                cloudlet[320].setVmId(19);
                cloudlet[321].setVmId(30);
                cloudlet[322].setVmId(8);
                cloudlet[323].setVmId(17);
                cloudlet[324].setVmId(12);
                cloudlet[325].setVmId(18);
                cloudlet[326].setVmId(11);
                cloudlet[327].setVmId(16);
                cloudlet[328].setVmId(25);
                cloudlet[329].setVmId(36);
                cloudlet[330].setVmId(10);
                cloudlet[331].setVmId(50);
                cloudlet[332].setVmId(16);
                cloudlet[333].setVmId(48);
                cloudlet[334].setVmId(40);
                cloudlet[335].setVmId(14);
                cloudlet[336].setVmId(3);
                cloudlet[337].setVmId(4);
                cloudlet[338].setVmId(28);
                cloudlet[339].setVmId(20);
                cloudlet[340].setVmId(45);
                cloudlet[341].setVmId(34);
                cloudlet[342].setVmId(13);
                cloudlet[343].setVmId(44);
                cloudlet[344].setVmId(28);
                cloudlet[345].setVmId(2);
                cloudlet[346].setVmId(3);
                cloudlet[347].setVmId(42);
                cloudlet[348].setVmId(30);
                cloudlet[349].setVmId(45);
                cloudlet[350].setVmId(38);
                cloudlet[351].setVmId(39);
                cloudlet[352].setVmId(4);
                cloudlet[353].setVmId(1);
                cloudlet[354].setVmId(4);
                cloudlet[355].setVmId(42);
                cloudlet[356].setVmId(33);
                cloudlet[357].setVmId(2);
                cloudlet[358].setVmId(30);
                cloudlet[359].setVmId(46);
                cloudlet[360].setVmId(15);
                cloudlet[361].setVmId(10);
                cloudlet[362].setVmId(7);
                cloudlet[363].setVmId(4);
                cloudlet[364].setVmId(25);
                cloudlet[365].setVmId(22);
                cloudlet[366].setVmId(9);
                cloudlet[367].setVmId(26);
                cloudlet[368].setVmId(8);
                cloudlet[369].setVmId(7);
                cloudlet[370].setVmId(41);
                cloudlet[371].setVmId(9);
                cloudlet[372].setVmId(3);
                cloudlet[373].setVmId(25);
                cloudlet[374].setVmId(18);
                cloudlet[375].setVmId(32);
                cloudlet[376].setVmId(3);
                cloudlet[377].setVmId(42);
                cloudlet[378].setVmId(46);
                cloudlet[379].setVmId(37);
                cloudlet[380].setVmId(15);
                cloudlet[381].setVmId(45);
                cloudlet[382].setVmId(20);
                cloudlet[383].setVmId(24);
                cloudlet[384].setVmId(40);
                cloudlet[385].setVmId(30);
                cloudlet[386].setVmId(15);
                cloudlet[387].setVmId(7);
                cloudlet[388].setVmId(45);
                cloudlet[389].setVmId(42);
                cloudlet[390].setVmId(18);
                cloudlet[391].setVmId(8);
                cloudlet[392].setVmId(2);
                cloudlet[393].setVmId(12);
                cloudlet[394].setVmId(22);
                cloudlet[395].setVmId(6);
                cloudlet[396].setVmId(44);
                cloudlet[397].setVmId(27);
                cloudlet[398].setVmId(2);
                cloudlet[399].setVmId(46);
                
                cloudlet[400].setVmId(21);
                cloudlet[401].setVmId(5);
                cloudlet[402].setVmId(29);
                cloudlet[403].setVmId(47);
                cloudlet[404].setVmId(12);
                cloudlet[405].setVmId(49);
                cloudlet[406].setVmId(13);
                cloudlet[407].setVmId(30);
                cloudlet[408].setVmId(10);
                cloudlet[409].setVmId(49);
                cloudlet[410].setVmId(41);
                cloudlet[411].setVmId(28);
                cloudlet[412].setVmId(49);
                cloudlet[413].setVmId(34);
                cloudlet[414].setVmId(6);
                cloudlet[415].setVmId(19);
                cloudlet[416].setVmId(38);
                cloudlet[417].setVmId(26);
                cloudlet[418].setVmId(15);
                cloudlet[419].setVmId(40);
                cloudlet[420].setVmId(19);
                cloudlet[421].setVmId(30);
                cloudlet[422].setVmId(22);
                cloudlet[423].setVmId(17);
                cloudlet[424].setVmId(11);
                cloudlet[425].setVmId(48);
                cloudlet[426].setVmId(12);
                cloudlet[427].setVmId(16);
                cloudlet[428].setVmId(25);
                cloudlet[429].setVmId(36);
                cloudlet[430].setVmId(41);
                cloudlet[431].setVmId(50);
                cloudlet[432].setVmId(42);
                cloudlet[433].setVmId(10);
                cloudlet[434].setVmId(5);
                cloudlet[435].setVmId(4);
                cloudlet[436].setVmId(3);
                cloudlet[437].setVmId(24);
                cloudlet[438].setVmId(18);
                cloudlet[439].setVmId(30);
                cloudlet[440].setVmId(5);
                cloudlet[441].setVmId(34);
                cloudlet[442].setVmId(23);
                cloudlet[443].setVmId(4);
                cloudlet[444].setVmId(8);
                cloudlet[445].setVmId(2);
                cloudlet[446].setVmId(42);
                cloudlet[447].setVmId(30);
                cloudlet[448].setVmId(20);
                cloudlet[449].setVmId(27);
                cloudlet[450].setVmId(8);
                cloudlet[451].setVmId(2);
                cloudlet[452].setVmId(4);
                cloudlet[453].setVmId(1);
                cloudlet[454].setVmId(44);
                cloudlet[455].setVmId(2);
                cloudlet[456].setVmId(50);
                cloudlet[457].setVmId(32);
                cloudlet[458].setVmId(30);
                cloudlet[459].setVmId(26);
                cloudlet[460].setVmId(35);
                cloudlet[461].setVmId(14);
                cloudlet[462].setVmId(7);
                cloudlet[463].setVmId(24);
                cloudlet[464].setVmId(45);
                cloudlet[465].setVmId(6);
                cloudlet[466].setVmId(20);
                cloudlet[467].setVmId(28);
                cloudlet[468].setVmId(8);
                cloudlet[469].setVmId(7);
                cloudlet[470].setVmId(1);
                cloudlet[471].setVmId(29);
                cloudlet[472].setVmId(38);
                cloudlet[473].setVmId(43);
                cloudlet[474].setVmId(40);
                cloudlet[475].setVmId(19);
                cloudlet[476].setVmId(28);
                cloudlet[477].setVmId(37);
                cloudlet[478].setVmId(49);
                cloudlet[479].setVmId(27);
                cloudlet[480].setVmId(18);
                cloudlet[481].setVmId(25);
                cloudlet[482].setVmId(23);
                cloudlet[483].setVmId(4);
                cloudlet[484].setVmId(50);
                cloudlet[485].setVmId(32);
                cloudlet[486].setVmId(46);
                cloudlet[487].setVmId(27);
                cloudlet[488].setVmId(15);
                cloudlet[489].setVmId(40);
                cloudlet[490].setVmId(48);
                cloudlet[491].setVmId(12);
                cloudlet[492].setVmId(23);
                cloudlet[493].setVmId(31);
                cloudlet[494].setVmId(40);
                cloudlet[495].setVmId(16);
                cloudlet[496].setVmId(4);
                cloudlet[497].setVmId(8);
                cloudlet[498].setVmId(22);
                cloudlet[499].setVmId(26);
                
                cloudlet[500].setVmId(20);
                cloudlet[501].setVmId(40);
                cloudlet[502].setVmId(42);
                cloudlet[503].setVmId(21);
                cloudlet[504].setVmId(48);
                cloudlet[505].setVmId(33);
                cloudlet[506].setVmId(20);
                cloudlet[507].setVmId(32);
                cloudlet[508].setVmId(40);
                cloudlet[509].setVmId(17);
                cloudlet[510].setVmId(16);
                cloudlet[511].setVmId(30);
                cloudlet[512].setVmId(21);
                cloudlet[513].setVmId(6);
                cloudlet[514].setVmId(43);
                cloudlet[515].setVmId(30);
                cloudlet[516].setVmId(12);
                cloudlet[517].setVmId(48);
                cloudlet[518].setVmId(30);
                cloudlet[519].setVmId(15);
                cloudlet[520].setVmId(29);
                cloudlet[521].setVmId(32);
                cloudlet[522].setVmId(24);
                cloudlet[523].setVmId(27);
                cloudlet[524].setVmId(11);
                cloudlet[525].setVmId(28);
                cloudlet[526].setVmId(12);
                cloudlet[527].setVmId(6);
                cloudlet[528].setVmId(25);
                cloudlet[529].setVmId(6);
                cloudlet[530].setVmId(21);
                cloudlet[531].setVmId(4);
                cloudlet[532].setVmId(26);
                cloudlet[533].setVmId(18);
                cloudlet[534].setVmId(25);
                cloudlet[535].setVmId(4);
                cloudlet[536].setVmId(3);
                cloudlet[537].setVmId(24);
                cloudlet[538].setVmId(41);
                cloudlet[539].setVmId(43);
                cloudlet[540].setVmId(47);
                cloudlet[541].setVmId(24);
                cloudlet[542].setVmId(30);
                cloudlet[543].setVmId(4);
                cloudlet[544].setVmId(8);
                cloudlet[545].setVmId(2);
                cloudlet[546].setVmId(3);
                cloudlet[547].setVmId(32);
                cloudlet[548].setVmId(20);
                cloudlet[549].setVmId(36);
                cloudlet[550].setVmId(1);
                cloudlet[551].setVmId(2);
                cloudlet[552].setVmId(24);
                cloudlet[553].setVmId(12);
                cloudlet[554].setVmId(19);
                cloudlet[555].setVmId(42);
                cloudlet[556].setVmId(29);
                cloudlet[557].setVmId(22);
                cloudlet[558].setVmId(46);
                cloudlet[559].setVmId(26);
                cloudlet[560].setVmId(34);
                cloudlet[561].setVmId(14);
                cloudlet[562].setVmId(27);
                cloudlet[563].setVmId(36);
                cloudlet[564].setVmId(15);
                cloudlet[565].setVmId(22);
                cloudlet[566].setVmId(20);
                cloudlet[567].setVmId(27);
                cloudlet[568].setVmId(28);
                cloudlet[569].setVmId(43);
                cloudlet[570].setVmId(21);
                cloudlet[571].setVmId(29);
                cloudlet[572].setVmId(33);
                cloudlet[573].setVmId(25);
                cloudlet[574].setVmId(48);
                cloudlet[575].setVmId(17);
                cloudlet[576].setVmId(23);
                cloudlet[577].setVmId(2);
                cloudlet[578].setVmId(20);
                cloudlet[579].setVmId(7);
                cloudlet[580].setVmId(12);
                cloudlet[581].setVmId(5);
                cloudlet[582].setVmId(6);
                cloudlet[583].setVmId(45);
                cloudlet[584].setVmId(42);
                cloudlet[585].setVmId(30);
                cloudlet[586].setVmId(17);
                cloudlet[587].setVmId(27);
                cloudlet[588].setVmId(35);
                cloudlet[589].setVmId(40);
                cloudlet[590].setVmId(28);
                cloudlet[591].setVmId(38);
                cloudlet[592].setVmId(48);
                cloudlet[593].setVmId(32);
                cloudlet[594].setVmId(50);
                cloudlet[595].setVmId(16);
                cloudlet[596].setVmId(4);
                cloudlet[597].setVmId(38);
                cloudlet[598].setVmId(22);
                cloudlet[599].setVmId(16);
                
                cloudlet[600].setVmId(2);
                cloudlet[601].setVmId(50);
                cloudlet[602].setVmId(49);
                cloudlet[603].setVmId(41);
                cloudlet[604].setVmId(42);
                cloudlet[605].setVmId(43);
                cloudlet[606].setVmId(23);
                cloudlet[607].setVmId(32);
                cloudlet[608].setVmId(40);
                cloudlet[609].setVmId(47);
                cloudlet[610].setVmId(11);
                cloudlet[611].setVmId(20);
                cloudlet[612].setVmId(29);
                cloudlet[613].setVmId(36);
                cloudlet[614].setVmId(46);
                cloudlet[615].setVmId(10);
                cloudlet[616].setVmId(18);
                cloudlet[617].setVmId(28);
                cloudlet[618].setVmId(35);
                cloudlet[619].setVmId(45);
                cloudlet[620].setVmId(9);
                cloudlet[621].setVmId(34);
                cloudlet[622].setVmId(28);
                cloudlet[623].setVmId(27);
                cloudlet[624].setVmId(18);
                cloudlet[625].setVmId(8);
                cloudlet[626].setVmId(17);
                cloudlet[627].setVmId(6);
                cloudlet[628].setVmId(5);
                cloudlet[629].setVmId(16);
                cloudlet[630].setVmId(1);
                cloudlet[631].setVmId(5);
                cloudlet[632].setVmId(6);
                cloudlet[633].setVmId(8);
                cloudlet[634].setVmId(45);
                cloudlet[635].setVmId(24);
                cloudlet[636].setVmId(33);
                cloudlet[637].setVmId(44);
                cloudlet[638].setVmId(48);
                cloudlet[639].setVmId(40);
                cloudlet[640].setVmId(45);
                cloudlet[641].setVmId(24);
                cloudlet[642].setVmId(33);
                cloudlet[643].setVmId(44);
                cloudlet[644].setVmId(48);
                cloudlet[645].setVmId(12);
                cloudlet[646].setVmId(23);
                cloudlet[647].setVmId(32);
                cloudlet[648].setVmId(40);
                cloudlet[649].setVmId(47);
                cloudlet[650].setVmId(18);
                cloudlet[651].setVmId(32);
                cloudlet[652].setVmId(44);
                cloudlet[653].setVmId(1);
                cloudlet[654].setVmId(14);
                cloudlet[655].setVmId(12);
                cloudlet[656].setVmId(23);
                cloudlet[657].setVmId(43);
                cloudlet[658].setVmId(40);
                cloudlet[659].setVmId(36);
                cloudlet[660].setVmId(35);
                cloudlet[661].setVmId(41);
                cloudlet[662].setVmId(27);
                cloudlet[663].setVmId(46);
                cloudlet[664].setVmId(45);
                cloudlet[665].setVmId(26);
                cloudlet[666].setVmId(40);
                cloudlet[667].setVmId(20);
                cloudlet[668].setVmId(18);
                cloudlet[669].setVmId(47);
                cloudlet[670].setVmId(11);
                cloudlet[671].setVmId(42);
                cloudlet[672].setVmId(33);
                cloudlet[673].setVmId(45);
                cloudlet[674].setVmId(48);
                cloudlet[675].setVmId(12);
                cloudlet[676].setVmId(23);
                cloudlet[677].setVmId(40);
                cloudlet[678].setVmId(40);
                cloudlet[679].setVmId(47);
                cloudlet[680].setVmId(1);
                cloudlet[681].setVmId(48);
                cloudlet[682].setVmId(26);
                cloudlet[683].setVmId(34);
                cloudlet[684].setVmId(49);
                cloudlet[685].setVmId(3);
                cloudlet[686].setVmId(16);
                cloudlet[687].setVmId(27);
                cloudlet[688].setVmId(35);
                cloudlet[689].setVmId(46);
                cloudlet[690].setVmId(8);
                cloudlet[691].setVmId(42);
                cloudlet[692].setVmId(45);
                cloudlet[693].setVmId(46);
                cloudlet[694].setVmId(41);
                cloudlet[695].setVmId(47);
                cloudlet[696].setVmId(40);
                cloudlet[697].setVmId(48);
                cloudlet[698].setVmId(39);
                cloudlet[699].setVmId(49);
                
                for(int i=0;i<cloudlets;i++){                       
			list.add(cloudlet[i]);}

		return list;
	}
        //.....................
	public static void main(String[] args) {
		Log.printLine("Starting ...");
                
		try {
			int num_user = 1; // number of cloud users
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false; // mean trace events
			CloudSim.init(num_user, calendar, trace_flag);
			@SuppressWarnings("unused")
			Datacenter datacenter0 = createDatacenter("Datacenter_0");
                        Datacenter datacenter1 = createDatacenter("Datacenter_1");
                        Datacenter datacenter2 = createDatacenter("Datacenter_2");
                        Datacenter datacenter3 = createDatacenter("Datacenter_3");
                        Datacenter datacenter4 = createDatacenter("Datacenter_4");
                        Datacenter datacenter5 = createDatacenter("Datacenter_5");
                        Datacenter datacenter6 = createDatacenter("Datacenter_6");
                        Datacenter datacenter7 = createDatacenter("Datacenter_7");
                        Datacenter datacenter8 = createDatacenter("Datacenter_8");
                        Datacenter datacenter9 = createDatacenter("Datacenter_9");
			
                        //Third step: Create Broker
			DatacenterBroker broker = createBroker();
			int brokerId = broker.getId();

			//Fourth step: Create VMs and Cloudlets and send them to broker
			vmlist = createVM(brokerId,50); //creating 50 vms
			cloudletList = createCloudlet(brokerId,700); // creating 100-1000 cloudlets
                        
                                      
			broker.submitVmList(vmlist);
			broker.submitCloudletList(cloudletList);
                         
			CloudSim.startSimulation();
                        CloudSim.stopSimulation();
                        List<Cloudlet> newList = broker.getCloudletReceivedList();
			printCloudletList(newList);                       
                        //datacenter0.printDebts();
                 //       List<Vm> newList2 = broker.getVmList();
                //        printvmList(newList2);
			Log.printLine("Example_FT finished!");
                                                
                        
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("EXAMPLE_FT: Unwanted errors happen");
		}
	}
	
	private static Datacenter createDatacenter(String name)
	{
		List<Host> hostList = new ArrayList<Host>();
		int mips = 12000;
		int ram = 10048; // host memory (MB)
		long storage = 1000000; // host storage
		int bw = 100000;
		for (int i = 0; i < hostNumber; i++)
		{
			List<Pe> pes = new ArrayList<Pe>();
			pes.add(new Pe(0, new PeProvisionerSimple(mips))); 
                        
			hostList.add(
					new Host(
						i,
						new RamProvisionerSimple(ram),
						new BwProvisionerSimple(bw),
						storage,
						pes,
						new VmSchedulerTimeShared(pes)
					)
				);
			
		}
                
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this
										// resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are not adding SAN
													// devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
				arch, os, vmm, hostList, time_zone, cost, costPerMem,
				costPerStorage, costPerBw);

		Datacenter datacenter = null;
		try {
			datacenter = new Datacenter(name,
					characteristics, 
					new VmAllocationPolicySimple(hostList), 
					storageList,
					5.0);
                        
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	
        //..............
        private static DatacenterBroker createBroker(){

		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker("Broker");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}
        //................
	private static void printCloudletList(List<Cloudlet> list) {
		int size = list.size();
		Cloudlet cloudlet;
                double jam=0;
		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent
				+ "Data center ID" + indent + "VM ID" + indent + "Time" + indent
				+ "Start Time" + indent + "Finish Time");

		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
				Log.print("SUCCESS");

				Log.printLine(indent + indent + cloudlet.getResourceId()
						+ indent + indent + indent + cloudlet.getVmId()
						+ indent + indent
						+ dft.format(cloudlet.getActualCPUTime()) + indent
						+ indent + dft.format(cloudlet.getSubmissionTime())
						+ indent + indent
						+ dft.format(cloudlet.getFinishTime()));
                                jam+=cloudlet.getActualCPUTime();                                
                                //Here getSubmissionTime equls with getExecStartTime. Because we have no waiting time
			}
                        
		}
                Log.printLine("jam: "+jam);
	}
        //.................................
        private static void printvmList(List<Vm> list) {
		int size = list.size();
		Vm vm;

		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Vm mips");

		
		for (int i = 0; i < size; i++) {
			vm = list.get(i);
                        	Log.printLine(indent + vm.getMips());}
		
	}
}
