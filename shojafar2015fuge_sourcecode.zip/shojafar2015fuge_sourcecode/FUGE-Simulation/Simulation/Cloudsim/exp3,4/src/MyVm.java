//myvm
import org.cloudbus.cloudsim.CloudletScheduler;
import org.cloudbus.cloudsim.Vm;


public class MyVm extends Vm 
{
   public double consumption;
    public MyVm(
			int id,
                        double voltage,
                        double frequency,                        
			int userId,
			double mips,
			int numberOfPes,
			int ram,
			long bw,
			long size,
			String vmm,
                        CloudletScheduler cloudletScheduler) {
                super(id, userId,
				mips, numberOfPes, ram,
				bw,size,vmm,cloudletScheduler );

		
                this.consumption=voltage*frequency;
	}
    public double getconsumption() {
		return consumption;
	}
}
