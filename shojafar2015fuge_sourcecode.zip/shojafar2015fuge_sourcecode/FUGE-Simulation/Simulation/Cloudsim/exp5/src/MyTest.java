//base
import java.text.DecimalFormat;
import java.util.*;

import org.cloudbus.cloudsim.Cloudlet;

import org.cloudbus.cloudsim.power.*;
import org.cloudbus.cloudsim.power.models.PowerModelLinear;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.UtilizationModelStochastic;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicy;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerVm;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;


public class MyTest {
	public static ArrayList<Vm> vmlist;
	public static ArrayList<MyCloudlet> cloudletList;
	public static MyDatacenterBroker broker;
	public static int hostNumber=1;        
	public static VmAllocationPolicy myvmallocation;
	public static void main(String[] args) {
		Log.printLine("Starting CloudSimExample1...");
                
		try {
			int num_user = 1; // number of cloud users
			Calendar calendar = Calendar.getInstance();
			boolean trace_flag = false; // mean trace events
			CloudSim.init(num_user, calendar, trace_flag);
			@SuppressWarnings("unused")
			Datacenter datacenter0 = createDatacenter("Datacenter_0");
                        Datacenter datacenter1 = createDatacenter("Datacenter_1");
                        
                        
                        
			broker = createBroker();
			int brokerId = broker.getId();                        

			vmlist = new ArrayList<Vm>();
			int mips = 1000;
			long size = 10000; // image size (MB)
			int ram = 512; // vm memory (MB)
			long bw = 1000;
			int pesNumber = 1; // number of cpus
			String vmmachine = "Xen"; // VMM name
                        Vm vm = new Vm(0, brokerId, mips+400, pesNumber, ram+896, bw+100, size, vmmachine, new CloudletSchedulerTimeShared());
			Vm vm2 = new Vm(1, brokerId, mips+200, pesNumber, ram+128, bw+300, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm3 = new Vm(2, brokerId, mips+300, pesNumber, ram, bw+800, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm4 = new Vm(3, brokerId, mips+400, pesNumber, ram+256, bw+2000, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm5 = new Vm(4, brokerId, mips+200, pesNumber, ram+768, bw+400, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm6 = new Vm(5, brokerId, mips+400, pesNumber, ram+768, bw+600, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm7 = new Vm(6, brokerId, mips+300, pesNumber, ram+128, bw+550, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm8 = new Vm(7, brokerId, mips+200, pesNumber, ram+512, bw+1000, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm9 = new Vm(8, brokerId, mips+300, pesNumber, ram+128, bw+550, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm10 = new Vm(9, brokerId, mips+100, pesNumber, ram+512, bw+1000, size, vmmachine, new CloudletSchedulerTimeShared());
                        
                        Vm vm11 = new Vm(10, brokerId, mips+400, pesNumber, ram+896, bw+100, size, vmmachine, new CloudletSchedulerTimeShared());
			Vm vm12 = new Vm(11, brokerId, mips+300, pesNumber, ram+128, bw+300, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm13 = new Vm(12, brokerId, mips+200, pesNumber, ram, bw+800, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm14 = new Vm(13, brokerId, mips+100, pesNumber, ram+256, bw+200, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm15 = new Vm(14, brokerId, mips+400, pesNumber, ram+768, bw+400, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm16 = new Vm(15, brokerId, mips+300, pesNumber, ram+768, bw+600, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm17 = new Vm(16, brokerId, mips+300, pesNumber, ram+128, bw+550, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm18 = new Vm(17, brokerId, mips+100, pesNumber, ram+512, bw+1000, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm19 = new Vm(18, brokerId, mips+300, pesNumber, ram+128, bw+550, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm20 = new Vm(19, brokerId, mips+100, pesNumber, ram+512, bw+1000, size, vmmachine, new CloudletSchedulerTimeShared());
                        
                        Vm vm21 = new Vm(20, brokerId, mips+400, pesNumber, ram+896, bw+400, size, vmmachine, new CloudletSchedulerTimeShared());
			Vm vm22 = new Vm(21, brokerId, mips+400, pesNumber, ram+128, bw+300, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm23 = new Vm(22, brokerId, mips+300, pesNumber, ram, bw+800, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm24 = new Vm(23, brokerId, mips+400, pesNumber, ram+256, bw+2000, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm25 = new Vm(24, brokerId, mips+400, pesNumber, ram+768, bw+400, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm26 = new Vm(25, brokerId, mips+400, pesNumber, ram+768, bw+600, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm27 = new Vm(26, brokerId, mips+300, pesNumber, ram+128, bw+550, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm28 = new Vm(27, brokerId, mips+200, pesNumber, ram+512, bw+1000, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm29 = new Vm(28, brokerId, mips+300, pesNumber, ram+128, bw+550, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm30 = new Vm(29, brokerId, mips+400, pesNumber, ram+512, bw+1000, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm31 = new Vm(30, brokerId, mips+400, pesNumber, ram+768, bw+600, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm32 = new Vm(31, brokerId, mips+300, pesNumber, ram+128, bw+550, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm33 = new Vm(32, brokerId, mips+200, pesNumber, ram+512, bw+1000, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm34 = new Vm(33, brokerId, 2*(mips+300), pesNumber, ram+128, bw+550, size, vmmachine, new CloudletSchedulerTimeShared());
                        Vm vm35 = new Vm(34, brokerId, 3*(mips+400), pesNumber, ram+512, bw+1000, size, vmmachine, new CloudletSchedulerTimeShared());
                        
                               
			vmlist.add(vm);
			vmlist.add(vm2);
                        vmlist.add(vm3);
                        vmlist.add(vm4);
                        vmlist.add(vm5);
                        vmlist.add(vm6);
                        vmlist.add(vm7);
                        vmlist.add(vm8);
                        vmlist.add(vm9);
                        vmlist.add(vm10);
                        vmlist.add(vm11);
			vmlist.add(vm12);
                        vmlist.add(vm13);
                        vmlist.add(vm14);
                        vmlist.add(vm15);
                        vmlist.add(vm16);
                        vmlist.add(vm17);
                        vmlist.add(vm18);
                        vmlist.add(vm19);
                        vmlist.add(vm20);
                        vmlist.add(vm21);
			vmlist.add(vm22);
                        vmlist.add(vm23);
                        vmlist.add(vm24);
                        vmlist.add(vm25);
                        vmlist.add(vm26);
                        vmlist.add(vm27);
                        vmlist.add(vm28);
                        vmlist.add(vm29);
                        vmlist.add(vm30);
                        vmlist.add(vm31);
                        vmlist.add(vm32);
                        vmlist.add(vm33);
                        vmlist.add(vm34);
                        vmlist.add(vm35);
                        //.......
                    //    List<Host> hostList2 = new ArrayList<Host>();
                   //     hostList2=datacenter0.getHostList();                        
                    //    myvmallocation.allocateHostForVm(vmlist.get(0),hostList2.get(0));
                        
                        //.......
			broker.submitVmList(vmlist);
			
			cloudletList = new ArrayList<MyCloudlet>();
			long length = 5000;
			long fileSize = 300;
			long outputSize = 300;
			
			UtilizationModel utilizationModel = new UtilizationModelFull();
                        int pesNumber2=1;
                        //Cloudlet length is 400000 till 4000000
			MyCloudlet cloudlet1 = new MyCloudlet(0, 6*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,0);
			MyCloudlet cloudlet2 = new MyCloudlet(1, 10*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,400);
			MyCloudlet cloudlet3 = new MyCloudlet(2, 5*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,800);
                        MyCloudlet cloudlet4 = new MyCloudlet(3, 4*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,1200);
                        MyCloudlet cloudlet5 = new MyCloudlet(4, 10*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,1600);
                        MyCloudlet cloudlet6 = new MyCloudlet(5, 3*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,2000);
                        MyCloudlet cloudlet7 = new MyCloudlet(6, 8*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,2400);
                        MyCloudlet cloudlet8 = new MyCloudlet(7, 2*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,2800);
                        MyCloudlet cloudlet9 = new MyCloudlet(8, 8*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,3200);
                        MyCloudlet cloudlet10 = new MyCloudlet(9, 2*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,3600);
                        MyCloudlet cloudlet11 = new MyCloudlet(10, 6*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,4000);
			MyCloudlet cloudlet12 = new MyCloudlet(11, 10*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,4400);
			MyCloudlet cloudlet13 = new MyCloudlet(12, 5*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,4800);
                        MyCloudlet cloudlet14 = new MyCloudlet(13, 4*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,5200);
                        MyCloudlet cloudlet15 = new MyCloudlet(14, 1*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,5800);
                        MyCloudlet cloudlet16 = new MyCloudlet(15, 3*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,6200);
                        MyCloudlet cloudlet17 = new MyCloudlet(16, 8*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,6600);
                        MyCloudlet cloudlet18 = new MyCloudlet(17, 2*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,7000);
                        MyCloudlet cloudlet19 = new MyCloudlet(18, 8*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,7400);
                        MyCloudlet cloudlet20 = new MyCloudlet(19, 2*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,7800);
                        MyCloudlet cloudlet21 = new MyCloudlet(20, 6*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,8200);
			MyCloudlet cloudlet22 = new MyCloudlet(21, 10*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,8600);
			MyCloudlet cloudlet23 = new MyCloudlet(22, 5*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,9000);
                        MyCloudlet cloudlet24 = new MyCloudlet(23, 4*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,9400);
                        MyCloudlet cloudlet25 = new MyCloudlet(24, 1*length, pesNumber2, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel,9800);
                        
                        
                        
                        
			cloudlet1.setUserId(brokerId);
			cloudlet2.setUserId(brokerId);
			cloudlet3.setUserId(brokerId);
                        cloudlet4.setUserId(brokerId);
                        cloudlet5.setUserId(brokerId);
                        cloudlet6.setUserId(brokerId);
                        cloudlet7.setUserId(brokerId);
                        cloudlet8.setUserId(brokerId);
                        cloudlet9.setUserId(brokerId);
                        cloudlet10.setUserId(brokerId);
                        
                        cloudlet11.setUserId(brokerId);
			cloudlet12.setUserId(brokerId);
			cloudlet13.setUserId(brokerId);
                        cloudlet14.setUserId(brokerId);
                        cloudlet15.setUserId(brokerId);
                        cloudlet16.setUserId(brokerId);
                        cloudlet17.setUserId(brokerId);
                        cloudlet18.setUserId(brokerId);
                        cloudlet19.setUserId(brokerId);
                        cloudlet20.setUserId(brokerId);
                        
                        cloudlet21.setUserId(brokerId);
			cloudlet22.setUserId(brokerId);
			cloudlet23.setUserId(brokerId);
                        cloudlet24.setUserId(brokerId);
                        cloudlet25.setUserId(brokerId);
                                               
                        
                        
                        cloudlet1.setVmId(5);
			cloudlet2.setVmId(0);
			cloudlet3.setVmId(3);
                        cloudlet4.setVmId(1);
                        cloudlet5.setVmId(4);
                        cloudlet6.setVmId(7);
                        cloudlet7.setVmId(2);
                        cloudlet8.setVmId(6);
                        cloudlet9.setVmId(21);
                        cloudlet10.setVmId(35);
                        
                        cloudlet11.setVmId(15);
			cloudlet12.setVmId(10);
			cloudlet13.setVmId(13);
                        cloudlet14.setVmId(11);
                        cloudlet15.setVmId(17);
                        cloudlet16.setVmId(14);
                        cloudlet17.setVmId(12);
                        cloudlet18.setVmId(16);
                        cloudlet19.setVmId(31);
                        cloudlet20.setVmId(20);
                        
                        cloudlet21.setVmId(24);
			cloudlet22.setVmId(25);
			cloudlet23.setVmId(29);
                        cloudlet24.setVmId(32);
                        cloudlet25.setVmId(28);
                        
                        
			cloudletList.add(cloudlet1);
			cloudletList.add(cloudlet2);
			cloudletList.add(cloudlet3);
                        cloudletList.add(cloudlet4);
                        cloudletList.add(cloudlet5);
                        cloudletList.add(cloudlet6);
                        cloudletList.add(cloudlet7);
                        cloudletList.add(cloudlet8);
                        cloudletList.add(cloudlet9);
                        cloudletList.add(cloudlet10);
                        cloudletList.add(cloudlet11);
			cloudletList.add(cloudlet12);
			cloudletList.add(cloudlet13);
                        cloudletList.add(cloudlet14);
                        cloudletList.add(cloudlet15);
                        cloudletList.add(cloudlet16);
                        cloudletList.add(cloudlet17);
                        cloudletList.add(cloudlet18);
                        cloudletList.add(cloudlet19);
                        cloudletList.add(cloudlet20);
                        cloudletList.add(cloudlet21);
			cloudletList.add(cloudlet22);
			cloudletList.add(cloudlet23);
                        cloudletList.add(cloudlet24);
                        cloudletList.add(cloudlet25);
                        
			broker.submitCloudletList(cloudletList);
                        //*************************************
                                                                       
                        //............
			CloudSim.startSimulation();
                        CloudSim.stopSimulation();
                        List<MyCloudlet> newList = broker.getCloudletReceivedList();
			printCloudletList(newList);                       
                        //datacenter0.printDebts();
                        
                        
			Log.printLine("Example_FT finished!");
                                                
                        
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("EXAMPLE_FT: Unwanted errors happen");
		}
	}
	
	private static Datacenter createDatacenter(String name)
	{
		List<Host> hostList = new ArrayList<Host>();
		int mips = 12000;
		int ram = 40048; // host memory (MB)
		long storage = 1000000; // host storage
		int bw = 100000;
		for (int i = 0; i < hostNumber; i++)
		{
			List<Pe> pes = new ArrayList<Pe>();
			pes.add(new Pe(0, new PeProvisionerSimple(mips))); 
                        
			hostList.add(
					new Host(
						i,
						new RamProvisionerSimple(ram),
						new BwProvisionerSimple(bw),
						storage,
						pes,
						new VmSchedulerTimeShared(pes)
					)
				);
			
		}
                
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this
										// resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are not adding SAN
													// devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
				arch, os, vmm, hostList, time_zone, cost, costPerMem,
				costPerStorage, costPerBw);

		Datacenter datacenter = null;
		try {
			datacenter = new Datacenter(name,
					characteristics, 
					new VmAllocationPolicySimple(hostList), 
					storageList,
					5.0);
                        
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	private static MyDatacenterBroker createBroker() {
		MyDatacenterBroker broker = null;
		try
		{
		
			broker = new MyDatacenterBroker("Broker");
			
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
                
	}
	private static void printCloudletList(List<MyCloudlet> list) {
		int size = list.size();
		Cloudlet cloudlet;

		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent
				+ "Data center ID" + indent + "VM ID" + indent + "Time" + indent
				+ "Start Time" + indent + "Finish Time");

		DecimalFormat dft = new DecimalFormat("###.##");
                double jam=0;
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
				Log.print("SUCCESS");

				Log.printLine(indent + indent + cloudlet.getResourceId()
						+ indent + indent + indent + cloudlet.getVmId()
						+ indent + indent
						+ dft.format(cloudlet.getActualCPUTime()) + indent
						+ indent + dft.format(cloudlet.getSubmissionTime())
						+ indent + indent
						+ dft.format(cloudlet.getFinishTime()));
                                jam+=cloudlet.getActualCPUTime();
                                //Here getSubmissionTime equls with getExecStartTime. Because we have no waiting time
			}
		}
                Log.printLine(jam/30);
	}
}
