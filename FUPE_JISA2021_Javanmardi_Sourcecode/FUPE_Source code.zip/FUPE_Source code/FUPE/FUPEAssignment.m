function Position = FUPEAssignment(Model, Credit, Rate)
    addpath('FuzzySystem\Security\');
    addpath('FuzzySystem\Utility\');
    SafeDevices = Security(Model, Credit, Rate);
    Position=MPSO(Model, Rate, SafeDevices);
    Position = Position.Position;

end