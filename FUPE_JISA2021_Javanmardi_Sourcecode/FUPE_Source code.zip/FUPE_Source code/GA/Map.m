function NewValues=Map(Value, Min, Max)


    NewValues = ( Value - Min) / ( Max - Min );

    
end