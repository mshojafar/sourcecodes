function Position = PSOAssignment(model, rate)

    % Cost Function
    CostFunction=@(q) MyCost(q, model, rate);   
    
    nVar= model.NIoT;                             % Number of Decision Variables

    VarSize=[1 nVar];                   % Size of Decision Variables Matrix

    VarMin = 1;
    VarMax = model.NFD;
    %% MPSO Parameters

    MaxIt=100;               % Maximum Number of Iterations
    nPop=100;                % Population Size

    % Constriction Coefficients
    phi1=2.05;
    phi2=2.05;
    phi=phi1+phi2;
    chi=2/(phi-2+sqrt(phi^2-4*phi));
    w=chi;          % Inertia Weight
    wdamp=1;        % Inertia Weight Damping Ratio
    c1=chi*phi1;    % Personal Learning Coefficient
    c2=chi*phi2;    % Global Learning Coefficient

    % Velocity Limits
    VelMax=0.1*(VarMax-VarMin);
    VelMin=-VelMax;

    %% Initialization

    % Create Empty Structure
    empty_pop.Position=[];
    empty_pop.Cost=[];
    empty_pop.Velocity=[];
    empty_pop.Best.Position=[];
    empty_pop.Best.Cost=[];

    % Create Structre Array to Save Population Data
    pop=repmat(empty_pop,nPop,1);

    GlobalBest.Cost=inf;
    
    % Initilize Population
    for i=1:nPop
        % Create Random Solution (Position)
        pop(i).Position =CreateRandomSolution(model);
        
        % Initialize Velocity
        pop(i).Velocity=zeros(VarSize);
        
        pop(i).Cost=CostFunction(pop(i).Position);

        % Update Personal Best
        pop(i).Best.Position=pop(i).Position;
        pop(i).Best.Cost=pop(i).Cost;

        % Update Global Best
        if pop(i).Best.Cost<GlobalBest.Cost
            GlobalBest=pop(i).Best;
        end
    end
    
    BestCost=zeros(MaxIt,1);
   
    %% Main Loop

    for it=1:MaxIt
        disp(it)
        % Moving
        for i=1:nPop
            %{
            pop(i).Position=Moving(pop(i).Position, pop(i).LBestPosition, GlobalBest.Position, w1, w2);
            pop(i).Cost=CostFunction(pop(i).Position);
            %}
            
            % Update Velocity
            pop(i).Velocity = w*pop(i).Velocity ...
                +c1*rand(VarSize).*(pop(i).Best.Position-pop(i).Position) ...
                +c2*rand(VarSize).*(GlobalBest.Position-pop(i).Position);

            % Apply Velocity Limits
            pop(i).Velocity = max(pop(i).Velocity,VelMin);
            pop(i).Velocity = min(pop(i).Velocity,VelMax);

            % Update Position
            pop(i).Position = pop(i).Position + pop(i).Velocity;

            % Velocity Mirror Effect
            IsOutside=(pop(i).Position<VarMin | pop(i).Position>VarMax);
            pop(i).Velocity(IsOutside)=-pop(i).Velocity(IsOutside);

            % Apply Position Limits
            pop(i).Position = floor(pop(i).Position);
            
            pop(i).Position = max(pop(i).Position,VarMin);
            pop(i).Position = min(pop(i).Position,VarMax);
            %
            % Evaluation
            pop(i).Cost = CostFunction(pop(i).Position);

            % Update Personal Best
            if pop(i).Cost<pop(i).Best.Cost

                pop(i).Best.Position=pop(i).Position;
                pop(i).Best.Cost=pop(i).Cost;

                % Update Global Best
                if pop(i).Best.Cost<GlobalBest.Cost
                    GlobalBest=pop(i).Best;
                end
            end
        end

        BestCost(it)=GlobalBest.Cost;

        %disp(['Iteration ' num2str(it) ', Best Cost = ' num2str(BestCost(it))]);

        w=w*wdamp;

    end
    Position = GlobalBest.Position;
end